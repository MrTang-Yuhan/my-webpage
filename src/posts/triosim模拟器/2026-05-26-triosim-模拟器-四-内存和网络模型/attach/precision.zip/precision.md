<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
  <meta name="description" content="技术出版级阅读体验与在线编辑能力">
  <link rel="icon" type="image/png" href="/logo/logo.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@400;500;700&family=Source+Sans+3:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.css">
  <link rel="stylesheet" href="/css/style.css">
  
</head>
<body>
  <div class="site-shell">
    <header class="site-header">
      <div class="container header-inner">
        <a href="/" class="brand" aria-label="首页">
          <img src="/logo/logo.png" alt="Logo" class="brand-logo">
          <span class="brand-title">知识站</span>
        </a>
        <button class="nav-toggle" id="navToggle" aria-label="切换导航" aria-expanded="false">菜单</button>
        <nav class="main-nav" id="mainNav">
          <a href="/">首页</a>
          <a href="/posts">归档</a>
          <a href="/about">关于</a>
          <button class="theme-toggle" id="themeToggle" type="button" aria-label="切换深色模式">主题</button>
          <a href="/admin" id="adminLoginLink">登录</a>
          <a href="/admin" id="adminWriteLink" style="display:none;">写作后台</a>
        </nav>
      </div>
      <div class="container">
        <div class="search-container" id="searchContainer">
          <div class="search-row">
            <input type="text" class="search-input" id="searchInput" placeholder="搜索文章标题、标签、内容片段...">
            <button class="search-toggle" id="searchToggle" type="button" aria-label="搜索">搜索</button>
          </div>
          <div class="search-results" id="searchResults"></div>
        </div>
      </div>
    </header>

    <main class="container main-content">
      
<section class="hero">
  <p class="hero-kicker">Personal Knowledge Publishing</p>
  <h1 class="hero-title">唐宇涵的个人知识站</h1>
  <p class="hero-subtitle">体系结构——权衡的艺术，性能的诗歌</p>
</section>

<section class="post-list-section">
  <h2 class="section-title">最新文章</h2>
  <ul class="post-list">
    
    
      
        
      
        
      
    
      
        
      
        
      
        
      
        
      
    
      
        
      
        
      
        
      
        
      
        
      
        
      
        
      
    
      
        
      
        
      
        
      
    
      
        
      
        
      
        
      
        
      
        
      
        
      
    
      
        
      
        
      
    
      
        
      
        
      
        
      
        
      
        
      
        
      
        
      
        
      
        
      
        
      
    
      
        
      
    
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/数学原理/2026-05-25-transformer-架构-scaled-dot-product-attention-的缩放因子推导/">Transformer 架构：Scaled Dot-Product Attention 的缩放因子推导</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-25">2026-05-25</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">Transformer 中的数值稳定性：为什么 Attention 需要除以 $&#92;sqrt{d_k}$</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-17-优化器算法（一）：adam-和-adamw/">优化器算法（一）：Adam 和 AdamW</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-18">2026-05-18</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">介绍神经网络训练中的优化器算法： SGD，SGD + Momentum，AdaGrad, RMSProp，Adam，AdamW</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-18-最优模型参数选择（一）：最优-gemm-维度选择/">最优模型参数选择（一）：最优 GEMM 维度选择</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-19">2026-05-19</time>
          <span class="post-divider">·</span>
          <span>3 min read</span>
        </div>
        <p class="post-list-excerpt">汇总了GPU性能影响因素，并详细说明如何选择最优 GEMM 维度</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-22-软件调优-二-dataloader/">软件调优（二）：DataLoader</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-22">2026-05-22</time>
          <span class="post-divider">·</span>
          <span>4 min read</span>
        </div>
        <p class="post-list-excerpt">介绍 pytorch DataLoader 的用法</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-22-软件调优-三-torch-compile/">软件调优（三）：torch.compile</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-22">2026-05-22</time>
          <span class="post-divider">·</span>
          <span>1 min read</span>
        </div>
        <p class="post-list-excerpt">介绍 torch.compile
torch.compile 通过将 PyTorch 代码 JIT 编译成优化的内核来加速 PyTorch 代码的运行，同时只需要极少的代码修改。


torch.compile 编程模型 详细介绍了 torch.compiler 原理。


torch.compile 使用教程 详细介绍了如何使用 torch.compile...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-22-软件调优-一-numa-绑定/">软件调优（一）：NUMA 绑定</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-22">2026-05-22</time>
          <span class="post-divider">·</span>
          <span>6 min read</span>
        </div>
        <p class="post-list-excerpt">NUMA 亲和性和 NUMA 绑定</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-25-软件调优-五-训练损失尖峰现象观察与分析/">软件调优（五）：训练损失尖峰现象观察与分析</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-25">2026-05-25</time>
          <span class="post-divider">·</span>
          <span>4 min read</span>
        </div>
        <p class="post-list-excerpt">此处展示一些好的、不好的以及异常的训练模式。内容整理自 Stas Bekman 的 Machine Learning Engineering by Stas Bekman。
一个非常失败的训练案例
在启动 BLOOM-176B 训练之前，我们用 104B 模型做了多次实验。但始终没能解决 训练很早就出现梯度发散（diverge） 的问题。如下图所示：

我们...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-25-代码调优-一-避免训练不稳定/">软件调优（四）：避免训练不稳定</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-25">2026-05-25</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">为了避免训练不稳定，需要着重注意以下要点。内容整理自 Stas Bekman 的 Machine Learning Engineering by Stas Bekman。

术语表
训练相关内容中常包含大量缩写和专有名词。以下是本文涉及的一些重要概念：


BS：Batch Size（批次大小）—— 在这里通常指每个 GPU 上一次处理的样本数，也常称为 M...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-26-软件调优-六-checkpoint-精度选择与内存占用优化/">软件调优（六）：Checkpoint 文件优化</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-26">2026-05-26</time>
          <span class="post-divider">·</span>
          <span>3 min read</span>
        </div>
        <p class="post-list-excerpt">对 Checkpoint 进行脚本处理


torch-checkpoint-convert-to-bf16：这个脚本会将两类 checkpoint 文件： torch 的 &amp;quot;.bin&amp;quot; 文件和 safetensor 的 &amp;quot;.safetensor&amp;quot; 文件中的权重转换为 bf16 ，并在名为 bf16 的子目录下创建一个...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-26-软件调优-七-选择合适的张量数据类型/"> 软件调优（七）：选择合适的张量数据类型</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-26">2026-05-26</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">最初，神经网络训练使用的张量类型都是 fp32，但速度慢、占用显存大。此后，NVIDIA 提出了混合精度训练，研究人员结合使用 fp16 和 fp32 两种浮点精度格式，这一创新极大地提升了模型训练速度。

混合精度训练（Mixed Precision Training)

图片中的混合精度训练流程可以概括为以下步骤：
Step 1：Forward Pass...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/训练优化/2026-05-27-分布式训练-一-使用单节点模拟多节点配置/">分布式训练（一）：使用单节点模拟多节点配置</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-27">2026-05-27</time>
          <span class="post-divider">·</span>
          <span>1 min read</span>
        </div>
        <p class="post-list-excerpt">如果一个节点配备了多张 GPU，可以将该节点内的每张 GPU 模拟成一个独立的节点，从而实现“单节点模拟多节点”的配置。
需要注意的是，这种模拟方式下，各 GPU 之间通过本地的 NVLink 或 PCIe 进行互联，而不是像真实多节点环境那样使用 InfiniBand 或以太网。因此，该方法是否适用，取决于具体测试对网络互联特性的依赖程度。
更详细的配置方...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/gpu逆向工程/2026-05-14-gpu-内存子系统分析-延迟分析/">GPU 内存子系统分析（一）：延迟分析</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-15">2026-05-15</time>
          <span class="post-divider">·</span>
          <span>17 min read</span>
        </div>
        <p class="post-list-excerpt">分析GPU 的 L1/Shared Memory，L2，DRAM 的访问延迟</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/gpu逆向工程/2026-05-20-gpu-内存子系统分析-带宽分析（一）/">GPU 内存子系统分析（二）：带宽分析</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-21">2026-05-21</time>
          <span class="post-divider">·</span>
          <span>34 min read</span>
        </div>
        <p class="post-list-excerpt">DRAM 带宽分析</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/triosim模拟器/triosim 模拟器 （一）/">triosim 模拟器 （一）</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-10">2026-05-10</time>
          <span class="post-divider">·</span>
          <span>1 min read</span>
        </div>
        <p class="post-list-excerpt">triosim 模拟器（一）</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/triosim模拟器/2026-05-23-triosim-模拟器-流水线并行/"> triosim 模拟器: 流水线并行</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-23">2026-05-23</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">整体思路：
把一个 batch 切成多个 micro_batch，让不同 GPU（不同 stage）同时处理不同 micro_batch，实现时间重叠。
可用这三个维度理解：

GPU id：表示 pipeline stage（哪张卡负责哪段层）
micro_batch_id：同一 batch 里第几个小批次（代码里基本对应 round_id）
batch_...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/triosim模拟器/2026-05-24-triosim-模拟器-一-事件驱动模拟/"> TrioSim 模拟器 （一）：事件驱动模拟</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-24">2026-05-24</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">事件驱动模拟器（Event-Driven Simulator）
事件驱动模拟器简介
事件驱动模拟器是只有当某个事件发生时，模拟器才处理它，并把模拟时间跳到下一个事件的发生时间。一般它的组成是：

维护一个按时间排序的事件队列，
每次取出最早发生的事件执行，
执行事件时可能产生新的未来事件，
然后继续处理下一个事件。

在事件驱动模拟器中，“事件”被定义为“在...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/triosim模拟器/2026-05-25-triosim-模拟器-二-trace-的产生和处理/"> TrioSim 模拟器 （二）：Trace 的产生和处理</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-25">2026-05-25</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">生成 Trace 并转换为 TrioSim 格式
Trace 的采集与格式转换主要由以下两个脚本完成：

tracer/datacollect.py
tracer/dataprocess.py

具体使用方法可参考：TrioSim 模拟器（一）：事件驱动模拟。
由于本文重点介绍模拟器本身的运行机制，因此暂不展开脚本的具体实现细节，后续将另行补充说明。

Tr...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/triosim模拟器/2026-05-26-triosim-模拟器-四-内存和网络模型/">TrioSim 模拟器 （四）：内存和网络模型</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-26">2026-05-26</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">内存模型
以 main.cpp 中 PlayTrace() 函数为例：
void PlayTrace(triosim::Trace&amp;#x26; trace,
               akita::sim::SerialEngine* engine,
               triosim::TimeEstimator* timeEstimator...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/triosim模拟器/2026-05-26-triosim-模拟器-三-traceplayer/">TrioSim 模拟器 （三）：TracePlayer</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-26">2026-05-26</time>
          <span class="post-divider">·</span>
          <span>3 min read</span>
        </div>
        <p class="post-list-excerpt">TracePlayer 介绍
在 main.cpp 的 int main(int argc, char* argv[]) 函数中，可以看到如下代码：
int main(int argc, char* argv[])
{
...
    switch (config.case_num) {
        case 0:
            PlayTra...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/大模型显存和flops分析/transformer模型的gpu显存使用分析（一）：训练/">Transformer 模型 GPU 显存分析（一）：训练</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-03">2026-05-03</time>
          <span class="post-divider">·</span>
          <span>4 min read</span>
        </div>
        <p class="post-list-excerpt">transformer 模型的 GPU 显存使用分析：训练阶段分析</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/大模型显存和flops分析/transformer模型的gpu显存使用分析（二）：推理/">Transformer 模型 GPU 显存分析（二）：推理</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-11">2026-05-11</time>
          <span class="post-divider">·</span>
          <span>5 min read</span>
        </div>
        <p class="post-list-excerpt">transformer 模型的 GPU 显存使用分析：推理阶段分析</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/大模型显存和flops分析/transformer模型的gpu显存使用分析（三）：反向传播到底需要哪些中间结果/">Transformer 模型 GPU 显存分析（三）：反向传播需要保存哪些中间结果？</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-12">2026-05-12</time>
          <span class="post-divider">·</span>
          <span>5 min read</span>
        </div>
        <p class="post-list-excerpt">为了实现反向传播，前向传播时需要计算并保存一些必要的“中间值”[1]。
本文将详细讨论在 Transformer 架构的前向传播过程中，具体需要保存哪些中间值。
基本原则
核心原则：反向传播时，某个梯度公式如果要用到前向里的某个“中间值”，这个“中间值”就要暂存。
以线性层举例。对于
$$
y = xW
$$
反向传播：
$$
&#92;frac{&#92;partial...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/model-parallelism/Pipeline-Parallelism流水线并行（一）/">Pipeline-Parallelism流水线并行（一）</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-03">2026-05-03</time>
          <span class="post-divider">·</span>
          <span>5 min read</span>
        </div>
        <p class="post-list-excerpt">Model Parallelism 之 Pipeline Parallelism: Naive Pipeline Parallelism, Gpipe, PipeDream</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/model-parallelism/Data-Parallelism数据并行（二）/">Data-Parallelism数据并行（二）</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-03">2026-05-03</time>
          <span class="post-divider">·</span>
          <span>3 min read</span>
        </div>
        <p class="post-list-excerpt">Model Parallelism 之 Data Parallelism: Naive Data Parallelism, Distributed Data Parallelism (DDP), ZeRO Data Parallelism</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/model-parallelism/Data-Parallelism数据并行（一）/">Data-Parallelism数据并行（一）</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-03">2026-05-03</time>
          <span class="post-divider">·</span>
          <span>3 min read</span>
        </div>
        <p class="post-list-excerpt">Model Parallelism 之 Data Parallelism: Naive Data Parallelism, Distributed Data Parallelism (DDP), ZeRO Data Parallelism</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/model-parallelism/tensor-parallelism张量并行（二）/">Tensor Parallelism张量并行（二）</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-13">2026-05-13</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">这是一篇基于 Megatron-LM Tensor Parallelism (TP) 核心逻辑的源码解析文章。
代码路径：Megatron-LM/megatron/legacy/model/transformer.py
前言
在大模型训练中，Tensor Parallelism (张量并行，TP) 是最核心的并行策略之一。它不仅仅是简单的分片训练，而是将一个...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/model-parallelism/tensor-parallelism张量并行（三）/">Tensor Parallelism张量并行（三）</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-13">2026-05-13</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">在分布式大模型训练（如 GPT-3, Llama 3, DeepSeek）中，张量并行 (Tensor Parallelism, TP) 是处理超大规模参数的核心技术。而 Megatron-LM 的 TP 源码设计充满了系统工程的智慧。
今天我们将深入 Megatron-LM 剖析其最基础的组件——ColumnParallelLinear（列并行线性层）。我...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/model-parallelism/tensor-parallelism张量并行（一）/">Tensor Parallelism张量并行（一）</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-13">2026-05-13</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">论文来自 Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism。
什么是 Tensor Parallelism（张量并行）
大模型训练通常面临两个核心问题：

显存压力大：当模型参数规模达到数十亿甚至更高时，在每张 GPU 上都完整保存一份模...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/model-parallelism/2026-05-13-sequence-parallelism序列并行（一）/">Sequence Parallelism序列并行（一）</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-14">2026-05-14</time>
          <span class="post-divider">·</span>
          <span>3 min read</span>
        </div>
        <p class="post-list-excerpt">原始论文 Reducing Activation Recomputation in Large Transformer Models
序列并行
序列并行是在张量并行的基础上进行的进一步深度优化，旨在减少“中间值”带来的显存占用(“中间值”是反向传播所必需的。如果不保存这些中间值，在反向传播过程中就必须重新执行前向计算来生成它们，这会显著增加训练的时间开销)。...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/备忘录/网页语法/">网页语法</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-01">2026-05-01</time>
          <span class="post-divider">·</span>
          <span>1 min read</span>
        </div>
        <p class="post-list-excerpt">写网页的一些语法介绍</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/备忘录/gdb-dashboard-工具/">gdb-dashboard-工具</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-01">2026-05-01</time>
          <span class="post-divider">·</span>
          <span>1 min read</span>
        </div>
        <p class="post-list-excerpt">gdb dashboard 工具指南</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/备忘录/2026-05-17-vscode-ssh-免密远程连接配置/">VSCode SSH 免密远程连接配置</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-18">2026-05-18</time>
          <span class="post-divider">·</span>
          <span>1 min read</span>
        </div>
        <p class="post-list-excerpt">在 Windows 系统下配置 SSH 免密登录远程服务器，并且支持多用户配置。</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/备忘录/2026-05-27-ubuntu-系统服务器远程连接配置/">Ubuntu 系统服务器远程连接配置</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-27">2026-05-27</time>
          <span class="post-divider">·</span>
          <span>3 min read</span>
        </div>
        <p class="post-list-excerpt">参考
玩转Ubuntu SSH：从零开始开启远程连接大门
Ubuntu设置静态IP地址的几种方法（亲测有效）
ubuntu20.04和22.04关闭自动休眠，息屏
Ubuntu修改DNS方法（临时和永久修改DNS）
Linux 如何将用户设为管理员（Admin）：详细指南

环境

服务器：Ubuntu 20.04，带图形化 UI
主机：windows 11...</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/interconnect/互联网络/">互联网络（一）：集合通信原语</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-04-30">2026-04-30</time>
          <span class="post-divider">·</span>
          <span>4 min read</span>
        </div>
        <p class="post-list-excerpt">AI 加速卡的互联介绍</p>
      </li>
    
      <li class="post-list-item">
        <h3 class="post-list-title"><a href="/posts/interconnect/2026-05-13-互联网络（二）/">互联网络（二）：伴随通信算子</a></h3>
        <div class="post-list-meta">
          <time datetime="2026-05-14">2026-05-14</time>
          <span class="post-divider">·</span>
          <span>2 min read</span>
        </div>
        <p class="post-list-excerpt">介绍通信算子和伴随通信算子</p>
      </li>
    
  </ul>
</section>

    </main>

    <footer class="site-footer">
      <div class="container footer-inner">
        <p>&copy; 2026 个人知识站</p>
        <div class="footer-links">
          <a href="https://github.com/MrTang-Yuhan" target="_blank" rel="noopener noreferrer">GitHub</a>
          <a href="/rss.xml">RSS</a>
          <a href="/admin" id="footerAdminLoginLink">登录</a>
          <a href="/admin" id="footerAdminWriteLink" style="display:none;">写作后台</a>
        </div>
      </div>
    </footer>
  </div>

  <script src="/js/main.js"></script>
  <script>
    (function() {
      const OWNER_LOGIN = "MrTang-Yuhan";
      const loginLinks = [
        document.getElementById("adminLoginLink"),
        document.getElementById("footerAdminLoginLink")
      ];
      const writeLinks = [
        document.getElementById("adminWriteLink"),
        document.getElementById("footerAdminWriteLink")
      ];

      function setWriteVisible(isVisible) {
        loginLinks.forEach(function(el) {
          if (el) el.style.display = isVisible ? "none" : "";
        });
        writeLinks.forEach(function(el) {
          if (el) el.style.display = isVisible ? "" : "none";
        });
      }

      async function detectOwnerLogin() {
        const raw = localStorage.getItem("netlify-cms-user") || localStorage.getItem("decap-cms-user");
        if (!raw) return false;
        let parsed;
        try {
          parsed = JSON.parse(raw);
        } catch {
          return false;
        }

        const token = parsed && (parsed.token || parsed.access_token || parsed.jwt);
        if (!token) return false;

        try {
          const res = await fetch("https://api.github.com/user", {
            headers: { Authorization: "token " + token }
          });
          if (!res.ok) return false;
          const user = await res.json();
          return user && user.login === OWNER_LOGIN;
        } catch {
          return false;
        }
      }

      detectOwnerLogin().then(setWriteVisible);
    })();
  </script>
  
</body>
</html>
