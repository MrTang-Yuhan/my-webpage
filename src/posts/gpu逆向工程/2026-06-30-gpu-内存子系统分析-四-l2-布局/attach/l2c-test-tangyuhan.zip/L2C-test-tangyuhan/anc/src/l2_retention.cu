// 本文件测量热集（hot set）在遭受冷流（cold stream）污染前后的 L2 缓存保留程度。
//
// 命令行参数：热集大小(MiB)、冷集大小(MiB)、行大小(字节)、探测访问次数、
// 重复次数、随机种子、设备号，以及策略标识 normal / persist。
// 输出为 CSV，比较热集在冷流污染后再次探测的平均延迟。
// 该程序对应 Persisting L2 Cache 对冷/热数据抗污染能力的实验。

#include <cuda_runtime.h>

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <random>
#include <string>
#include <vector>


#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t error__ = (call);                                               \
    if (error__ != cudaSuccess) {                                               \
      std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << ": "   \
                << cudaGetErrorString(error__) << "\n";                         \
      std::exit(EXIT_FAILURE);                                                  \
    }                                                                          \
  } while (0)

// 通过 L2 缓存路径（绕过 L1）加载一个 32 位链表项。
// PTX 指令 ld.global.cg.u32 中的 .cg（cache at global level）表示仅在 L2 及以下层级缓存，
// 不占用 L1 缓存空间，避免 L1 对指针追踪链路的干扰。
__device__ __forceinline__ uint32_t load_cg_u32(const uint32_t *address) {
  uint32_t value;
  asm volatile("ld.global.cg.u32 %0, [%1];"
               : "=r"(value)
               : "l"(address)
               : "memory");
  return value;
}

// 通过 L2 缓存路径一次性加载四个相邻的 32 位字（128 位）。
// address 必须满足 uint4 对齐要求。该辅助函数仅用于冷流扫描，
// 目的是将流式污染压力放大到更宽的带宽路径，而非逐字访问。
__device__ __forceinline__ uint4 load_cg_u32x4(const uint4 *address) {
  uint4 value;
  asm volatile("ld.global.cg.v4.u32 {%0,%1,%2,%3}, [%4];"
               : "=r"(value.x), "=r"(value.y), "=r"(value.z), "=r"(value.w)
               : "l"(address)
               : "memory");
  return value;
}

// 测量热集依赖加载链（pointer-chase）的访问延迟。
//
// measure=false 时仅预热链路，不向 elapsed_cycles 写入数据，用于将热集载入 L2。
// measure=true  时记录两次 clock64() 之间的 GPU 时钟周期差值。
// final_index 记录链的最终指针，防止编译器将依赖链优化消除。
__global__ void chase_hot_kernel(const uint32_t *next, uint32_t start,
                                 uint64_t accesses, bool measure,
                                 uint64_t *elapsed_cycles,
                                 uint32_t *final_index) {
  if (blockIdx.x != 0 || threadIdx.x != 0) {
    return;
  }
  uint32_t index = start;
  const uint64_t begin = measure ? clock64() : 0;
  for (uint64_t i = 0; i < accesses; ++i) {
    index = load_cg_u32(next + index);
  }
  const uint64_t end = measure ? clock64() : 0;
  if (measure) {
    *elapsed_cycles = end - begin;
  }
  *final_index = index;
}

// 流式遍历大容量冷缓冲区并累加校验和。
// 该 kernel 有两个作用：
// (1) 将 L2 预热到高压状态（填充缓存）；
// (2) 形成冷流污染，驱逐热集缓存行。
__global__ void stream_kernel(const uint4 *data, uint64_t count,
                              unsigned long long *sink) {
  __shared__ unsigned long long block_sums[256];
  unsigned long long local = 0;
  // Grid-Stride Loop：线程以整个 grid 的总线程数为步长遍历数据。
  // 每个数据元素仅被读取一次，体现流式访问模式，不利用时间局部性。
  for (uint64_t i = static_cast<uint64_t>(blockIdx.x) * blockDim.x +
                    threadIdx.x;
       i < count; i += static_cast<uint64_t>(blockDim.x) * gridDim.x) {
    const uint4 value = load_cg_u32x4(data + i);
    local += static_cast<unsigned long long>(value.x) + value.y + value.z +
             value.w;
  }
  block_sums[threadIdx.x] = local;
  // __syncthreads()：块内线程屏障同步。确保所有线程完成共享内存写入后，
  // 再进入下一步的规约读取，避免数据竞争。
  __syncthreads();

  // 块内二叉树规约（reduction）：将 256 个线程的局部和逐级合并。
  for (unsigned int offset = blockDim.x / 2; offset > 0; offset >>= 1) {
    if (threadIdx.x < offset) {
      block_sums[threadIdx.x] += block_sums[threadIdx.x + offset];
    }
    // 每次规约步后同步，确保下一轮读取时共享内存已更新完毕。
    __syncthreads();
  }
  // 原子累加到全局 sink，防止编译器将无副作用的访存优化消除。
  if (threadIdx.x == 0) {
    atomicAdd(sink, block_sums[0]);
  }
}

// 解析无符号十进制命令行参数。
static uint64_t parse_u64(const char *text, const char *name) {
  errno = 0;
  char *end = nullptr;
  const unsigned long long value = std::strtoull(text, &end, 10);
  if (errno != 0 || end == text || *end != '\0') {
    std::cerr << "Invalid " << name << ": " << text << "\n";
    std::exit(EXIT_FAILURE);
  }
  return static_cast<uint64_t>(value);
}

// 解析正浮点数或非负浮点数字段。
// allow_zero=true 用于冷集大小和 setaside 容量这类允许为零的实验参数。
static double parse_double(const char *text, const char *name,
                           bool allow_zero = false) {
  errno = 0;
  char *end = nullptr;
  const double value = std::strtod(text, &end);
  if (errno != 0 || end == text || *end != '\0' || !std::isfinite(value) ||
      (allow_zero ? value < 0.0 : value <= 0.0)) {
    std::cerr << "Invalid " << name << ": " << text << "\n";
    std::exit(EXIT_FAILURE);
  }
  return value;
}

int main(int argc, char **argv) {
  if (argc != 11) {
    std::cerr << "Usage: " << argv[0]
              << " <hot_mib> <cold_mib> <line_bytes> <probe_accesses> "
                 "<repetitions> <seed> <device> <normal|persist> "
                 "<setaside_mib> <hit_ratio>\n";
    return EXIT_FAILURE;
  }

  // 解析命令行参数
  const double hot_mib = parse_double(argv[1], "hot_mib");            // 热集大小，决定 pointer-chase 环的工作集
  const double cold_mib = parse_double(argv[2], "cold_mib", true);    // 冷集大小，可为 0，决定污染流的带宽压力
  const uint64_t line_bytes = parse_u64(argv[3], "line_bytes");       // 缓存行大小
  const uint64_t probe_accesses = parse_u64(argv[4], "probe_accesses");  // 热集探测访问次数，用于计时
  const uint64_t repetitions = parse_u64(argv[5], "repetitions");        // 实验重复次数
  const uint64_t seed = parse_u64(argv[6], "seed");                      // 随机数种子
  const int device = static_cast<int>(parse_u64(argv[7], "device"));     // 目标 GPU 设备号
  const std::string policy = argv[8];                                    // "normal" 或 "persist"，决定 L2 策略
  const double setaside_mib = parse_double(argv[9], "setaside_mib", true);  // Persisting L2 预留容量（MiB）
  const double hit_ratio = parse_double(argv[10], "hit_ratio", true);  // Persisting L2 的命中比例目标，范围 [0, 1]

  if (policy != "normal" && policy != "persist") {
    std::cerr << "policy must be normal or persist\n";
    return EXIT_FAILURE;
  }
  if (hit_ratio > 1.0) {
    std::cerr << "hit_ratio must be in [0, 1]\n";
    return EXIT_FAILURE;
  }
  // 链表项类型为 uint32_t，因此 line_bytes 必须是 4 的倍数
  if (line_bytes < sizeof(uint32_t) ||
      line_bytes % sizeof(uint32_t) != 0) {
    std::cerr << "line_bytes must be a multiple of 4\n";
    return EXIT_FAILURE;
  }

  CUDA_CHECK(cudaSetDevice(device));
  cudaDeviceProp properties{};
  CUDA_CHECK(cudaGetDeviceProperties(&properties, device));
  const uint64_t hot_bytes = static_cast<uint64_t>(
      std::llround(hot_mib * 1024.0 * 1024.0));
  const uint64_t cold_bytes = static_cast<uint64_t>(
      std::llround(cold_mib * 1024.0 * 1024.0));
  // 热集大小决定 pointer-chase 环的工作集，冷集大小决定污染流的带宽压力。
  const uint64_t line_count = hot_bytes / line_bytes;  // 热集包含的缓存行数
  const uint64_t words_per_line = line_bytes / sizeof(uint32_t);
  const uint64_t word_count = line_count * words_per_line;
  if (line_count < 2 || word_count > std::numeric_limits<uint32_t>::max()) {
    std::cerr << "unsupported hot footprint\n";
    return EXIT_FAILURE;
  }

  std::vector<uint32_t> host_next(word_count, 0);  // Host 端数组，存储链表后继索引，初始化为 0
  std::vector<uint32_t> order(line_count);         // 缓存行号的排列数组，长度 line_count
  std::iota(order.begin(), order.end(), 0);
  std::mt19937_64 generator(seed);
  std::shuffle(order.begin(), order.end(), generator);
  // 随机排列后，仅在每条缓存行的第一个 word 写入后继索引。
  // 避免同一行内多 word 访问稀释 L2 slice 映射信号，确保每次访问触发独立缓存行访问。

  // 构建随机环形链表：只在每条缓存行的首个 word 写入后继索引。
  // 这样保证每次访问都触发一次独立的 L2/DRAM 访问，不利用行内空间局部性。
  for (uint64_t i = 0; i < line_count; ++i) {
    const uint32_t current = static_cast<uint32_t>(
        static_cast<uint64_t>(order[i]) * words_per_line);
    const uint32_t next = static_cast<uint32_t>(
        static_cast<uint64_t>(order[(i + 1) % line_count]) * words_per_line); // % line_count 确保最后一个节点指向第一个节点，形成闭环
    host_next[current] = next;
  }
  // start 使用 word 索引而非 byte 偏移，因为设备端链表项直接存储下一跳 word 索引。
  const uint32_t start =
      static_cast<uint32_t>(static_cast<uint64_t>(order[0]) * words_per_line);

  uint32_t *device_hot = nullptr;
  uint4 *device_cold = nullptr;
  uint4 *device_flush = nullptr;
  uint64_t *device_elapsed = nullptr;
  uint32_t *device_final = nullptr;
  unsigned long long *device_sink = nullptr;

  // Flush 缓冲区大小取 L2 容量的 3 倍与 256 MiB 的较大者。
  // 目的是充分冲刷 L2，消除前次实验的缓存残留状态。
  const uint64_t flush_bytes =
      std::max<uint64_t>(properties.l2CacheSize * 3ULL, 256ULL << 20);

  CUDA_CHECK(cudaMalloc(&device_hot, hot_bytes));
  CUDA_CHECK(cudaMalloc(&device_cold, std::max<uint64_t>(cold_bytes, 16)));
  CUDA_CHECK(cudaMalloc(&device_flush, flush_bytes));
  CUDA_CHECK(cudaMalloc(&device_elapsed, sizeof(uint64_t)));
  CUDA_CHECK(cudaMalloc(&device_final, sizeof(uint32_t)));
  CUDA_CHECK(cudaMalloc(&device_sink, sizeof(unsigned long long)));
  CUDA_CHECK(cudaMemcpy(device_hot, host_next.data(), hot_bytes,
                        cudaMemcpyHostToDevice));
  CUDA_CHECK(cudaMemset(device_cold, 1, std::max<uint64_t>(cold_bytes, 16)));
  CUDA_CHECK(cudaMemset(device_flush, 2, flush_bytes));

  cudaStream_t stream;
  CUDA_CHECK(cudaStreamCreate(&stream));

  // 用户请求的 persisting L2 容量，裁剪到硬件上限（persistingL2CacheMaxSize）。
  size_t requested_setaside = static_cast<size_t>(
      std::llround(setaside_mib * 1024.0 * 1024.0));
  requested_setaside = std::min(
      requested_setaside,
      static_cast<size_t>(properties.persistingL2CacheMaxSize));

  // L2 缓存替换策略在此分为三层理解：
  // (1) accessPolicyWindow 内的访问按 hitRatio 进行采样：窗口内 hitRatio 比例的访问
  //     应用 hitProp 策略，其余 (1 - hitRatio) 比例应用 missProp 策略。
  // (2) accessPolicyWindow 外的数据默认采用 Normal 策略。
  // (3) hitProp = Persisting 表示数据优先驻留于预留的 L2 区域；missProp = Streaming
  //     表示数据按流式策略（evict-first）处理，减少缓存污染。
  if (policy == "persist") {
    // 设置全局 Persisting L2 预留容量上限。
    // 该容量从总 L2 中划分出来，专供标记为 Persisting 的访问使用。
    CUDA_CHECK(cudaDeviceSetLimit(cudaLimitPersistingL2CacheSize,
                                  requested_setaside));
    cudaStreamAttrValue attribute{};
    // 指定热数据在设备全局内存中的起始地址。
    attribute.accessPolicyWindow.base_ptr = device_hot;
    // 限制窗口大小不超过硬件允许的单窗口上限（accessPolicyMaxWindowSize）。
    attribute.accessPolicyWindow.num_bytes =
        std::min<size_t>(hot_bytes, properties.accessPolicyMaxWindowSize);
    // hitRatio：访问策略的采样比例。对于窗口内地址，约 hitRatio 比例的访问
    // 应用 hitProp 策略，其余应用 missProp 策略。该值为性能提示（hint），
    // 实际行为取决于硬件架构与内存范围。
    attribute.accessPolicyWindow.hitRatio = static_cast<float>(hit_ratio);
    // hitProp = Persisting：命中时数据优先保留在预留 L2 区域，降低被驱逐概率。
    attribute.accessPolicyWindow.hitProp = cudaAccessPropertyPersisting;
    // missProp = Streaming：未命中时按流式策略分配缓存行（evict-first），
    // 快速清退，减少对热数据的干扰。
    attribute.accessPolicyWindow.missProp = cudaAccessPropertyStreaming;
    // 将上述访问策略窗口绑定到指定 CUDA 流。后续该流中的 kernel 对窗口内地址的
    // 全局内存访问将受该策略影响。
    CUDA_CHECK(cudaStreamSetAttribute(
        stream, cudaStreamAttributeAccessPolicyWindow, &attribute));
  }

  constexpr int threads = 256;
  // block 数设为 SM 数量的 4 倍，确保足够的并行度以占满 GPU 计算资源。
  const int blocks = std::max(1, properties.multiProcessorCount * 4);
  const uint64_t flush_count = flush_bytes / sizeof(uint4);  // uint4 为 16 字节
  const uint64_t cold_count = cold_bytes / sizeof(uint4);

  std::cout
      << "run,policy,hot_mib,cold_mib,line_bytes,hot_line_count,"
         "probe_accesses,seed,setaside_requested_mib,setaside_effective_bytes,"
         "hit_ratio,elapsed_cycles,cycles_per_access,final_index\n";
  std::cout << std::setprecision(12);

  // 测量不同 L2 缓存策略（normal / persist）的抗污染能力。
  // 单次运行只测量一种策略；若要完整对比两种策略，需分别运行两次程序。
  for (uint64_t run = 0; run < repetitions; ++run) {
    // 每次重复实验前清空 persisting L2 状态，保证不同 run 的污染条件一致。
    // cudaCtxResetPersistingL2Cache() 将所有持久化缓存行重置为普通状态，
    // 在函数返回时生效。
    CUDA_CHECK(cudaCtxResetPersistingL2Cache());
    // device_sink 清零，用于接收新一轮冷流 kernel 的校验和。
    CUDA_CHECK(cudaMemsetAsync(device_sink, 0, sizeof(unsigned long long),
                               stream));
    // 先用大 flush 流把 L2 预热成高压状态，填充现有缓存行。
    stream_kernel<<<blocks, threads, 0, stream>>>(device_flush, flush_count,
                                                  device_sink);

    // 预热：将热集从 DRAM 加载进 L2，建立缓存驻留，但不计时。
    chase_hot_kernel<<<1, 1, 0, stream>>>(
        device_hot, start, line_count, false, device_elapsed, device_final);
    if (cold_count > 0) {
      // 冷流在热集之后插入，检验 persisting L2 是否能抵抗后续污染。
      stream_kernel<<<blocks, threads, 0, stream>>>(device_cold, cold_count,
                                                    device_sink);
    }

    // 测量：在冷流污染后再次访问热集，记录 clock64() 差值，结果输出到 CSV。
    chase_hot_kernel<<<1, 1, 0, stream>>>(
        device_hot, start, probe_accesses, true, device_elapsed, device_final);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaStreamSynchronize(stream));

    uint64_t elapsed = 0;
    uint32_t final_index = 0;
    CUDA_CHECK(cudaMemcpy(&elapsed, device_elapsed, sizeof(elapsed),
                          cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(&final_index, device_final, sizeof(final_index),
                          cudaMemcpyDeviceToHost));
    std::cout << run << ',' << policy << ',' << hot_mib << ',' << cold_mib
              << ',' << line_bytes << ',' << line_count << ','
              << probe_accesses << ',' << seed << ',' << setaside_mib << ','
              << requested_setaside << ',' << hit_ratio << ',' << elapsed << ','
              << static_cast<double>(elapsed) /
                     static_cast<double>(probe_accesses)
              << ',' << final_index << '\n';
  }

  CUDA_CHECK(cudaStreamDestroy(stream));
  CUDA_CHECK(cudaFree(device_sink));
  CUDA_CHECK(cudaFree(device_final));
  CUDA_CHECK(cudaFree(device_elapsed));
  CUDA_CHECK(cudaFree(device_flush));
  CUDA_CHECK(cudaFree(device_cold));
  CUDA_CHECK(cudaFree(device_hot));
  return 0;
}