#!/usr/bin/env python3
"""

输入是 JSON 配置文件和 CUDA 设备号，输出为 raw 结果目录、`l2_latency.csv` 与 manifest。
该脚本负责构建二进制、记录环境信息并执行容量/预取扫描。

该脚本执行了三个可执行文件:
1. make —— 在仓库根目录执行 make -j2, 编译 CUDA 源码。
2. ROOT/build/device_info —— 获取 GPU 设备信息，输出保存到 device_info.json。
3. ROOT/build/l2_latency —— 核心 benchmark 可执行文件，负责实际的 L2 latency 
测量。其路径由 ROOT / "build" / "l2_latency" 拼接而成，接收 8 个命令行参数: footprint_mib、
line_bytes、accesses、repetitions、seed、device、prefetch_mode。

"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import platform
import random
import shlex
import subprocess
import sys
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[1]  # 根目录为当前目录的上级目录

def run(
    command: list[str],
    *,
    cwd: pathlib.Path = ROOT,
    capture: bool = True,
) -> subprocess.CompletedProcess[str]:
    """在指定工作目录下运行子进程，可选捕获输出。
    
    Args:
        command: 命令和参数列表。
        cwd: 工作目录；默认是仓库根目录。
        capture: 为 true 时捕获 stdout/stderr，便于写入 manifest。
    
    Returns:
        `subprocess.CompletedProcess`，调用失败时抛出异常。"""
    return subprocess.run(
        command,
        cwd=cwd,
        check=True,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
    )


def sha256_file(path: pathlib.Path) -> str:
    """以流式方式计算文件的 SHA-256 摘要（分块读取，避免大文件占满内存）。
    
    Args:
        path: 要纳入 manifest 的文件路径。
    
    Returns:
        十六进制 digest 字符串。"""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def command_output(command: list[str]) -> dict[str, Any]:
    """运行一条诊断命令，并将执行结果序列化为字典。
    
    Args:
        command: 诊断命令和参数。
    
    Returns:
        包含 command、returncode、stdout、stderr 或 error 的字典。"""
    try:
        completed = run(command)
        return {
            "command": command,
            "returncode": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
        }
    except (FileNotFoundError, subprocess.CalledProcessError) as error:
        return {
            "command": command,
            "error": repr(error),
        }


def main() -> int:
    """脚本的命令行入口函数。
    
    Returns:
        进程退出码，0 表示成功。"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=pathlib.Path) # 该参数指向实验的 JSON 配置文件。
    parser.add_argument("--device", default=0, type=int)              # 该参数指定目标 CUDA 设备号。
    args = parser.parse_args()

    config_path = args.config.resolve()                               # 将用户提供的配置路径转换为绝对路径
    config = json.loads(config_path.read_text(encoding="utf-8"))      # 读取 json 配置文件
    # 生成 UTC 时间戳（格式如 20260731T120000Z），用于唯一标识本次实验
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"{config['campaign']}_{timestamp}"                      
    run_dir = ROOT / "results" / "raw" / run_id                       # 构造原始结果目录路径

    # parents=True 表示自动创建缺失的父目录；exist_ok=False 表示若目录已存在则抛出 FileExistsError，防止意外覆盖旧数据
    run_dir.mkdir(parents=True, exist_ok=False)                       
    run(["make", "-j2"], capture=False)                 # capture=False 表示将编译输出直接透传到终端，便于实时观察

    device_info_path = run_dir / "device_info.json"           # 构造设备信息输出文件路径
    device_info = run([str(ROOT / "build" / "device_info")])  # 执行 ROOT/build/device_info 可执行文件，获取 GPU 设备信息
    device_info_path.write_text(device_info.stdout, encoding="utf-8")  # 将 device_info 的标准输出写入到 device_info.json 文件

    # Manifest 固化配置、源码 hash、环境和命令行，保证 raw 结果可追溯。
    source_paths = sorted(
        [   
            ROOT / "Makefile",                          # Makefile 文件路径
            config_path,                                # 配置文件路径
            *sorted((ROOT / "src").glob("*.cu")),       # cuda 源文件路径，sorted() 保证顺序确定性，便于比较
            pathlib.Path(__file__).resolve(),           # 以及当前脚本自身路径
        ]
    )
    manifest: dict[str, Any] = {
        "schema_version": 1,
        "run_id": run_id,
        "started_utc": timestamp,
        "config": config,
        "config_path": str(config_path.relative_to(ROOT)),
        "device": args.device,
        "python": sys.version,
        "platform": platform.platform(),
        "uname": list(platform.uname()),
        "cwd": str(ROOT),
        "environment": {
            key: os.environ.get(key)
            for key in (
                "CUDA_VISIBLE_DEVICES",
                "CUDA_HOME",
                "NVIDIA_VISIBLE_DEVICES",
                "NVIDIA_DRIVER_CAPABILITIES",
            )
        },
        "source_sha256": {
            str(path.relative_to(ROOT)): sha256_file(path) for path in source_paths
        },
        "system_commands": {
            "nvidia_smi": command_output(["nvidia-smi", "-q"]),
            "nvidia_topology": command_output(["nvidia-smi", "topo", "-m"]),
            "nvcc_version": command_output(["nvcc", "--version"]),
            "lscpu_json": command_output(["lscpu", "-J"]),
            "numactl_hardware": command_output(["numactl", "--hardware"]),
        },
        "benchmark_commands": [],
    }
    
    
    combined_csv = run_dir / "l2_latency.csv"   # 所有实验结果将追加写入此文件
    header_written = False                      # 用于控制 CSV 表头只写入一次
    conditions: list[tuple[int, str, float]] = []   # 初始化实验条件列表，分别对应 (line_bytes, prefetch_mode, footprint_mib)
    if "condition_groups" in config:
        """
        分组模式：支持按组指定不同的预取模式
        """
        for group in config["condition_groups"]:
            group_modes = group.get(
                "prefetch_modes", config.get("prefetch_modes", ["default"]) # 优先级：组内配置 > 全局配置 > 默认值 ["default"]
            )
            for line_bytes in group["line_bytes"]:
                for prefetch_mode in group_modes:
                    for footprint_mib in group["footprints_mib"]:
                        conditions.append(
                            (int(line_bytes), str(prefetch_mode), float(footprint_mib))
                        )
    else:
        """
        非分组模式
        """
        line_bytes_values = config["line_bytes"]
        if not isinstance(line_bytes_values, list):
            line_bytes_values = [line_bytes_values]
        prefetch_modes = config.get("prefetch_modes", ["default"])
        for line_bytes in line_bytes_values:
            for prefetch_mode in prefetch_modes:
                for footprint_mib in config["footprints_mib"]:
                    conditions.append(
                        (int(line_bytes), str(prefetch_mode), float(footprint_mib))
                    )
    # 对分组列表进行确定性随机打乱，从而消除因实验顺序造成的系统性偏差
    if config.get("shuffle_conditions", False):
        random.Random(int(config["order_seed"])).shuffle(conditions)


    # 遍历所有的实验条件，开始执行测试
    condition_index = 0
    with combined_csv.open("w", encoding="utf-8") as output:
        for line_bytes, prefetch_mode, footprint_mib in conditions:
            if config.get("common_seed_by_shape", False):
                seed = (
                    int(config["seed"])
                    + int(line_bytes) * 1_000_000
                    + int(round(footprint_mib * 1000.0))
                )
            else:
                seed = int(config["seed"]) + condition_index
            condition_index += 1
            command = [
                str(ROOT / "build" / "l2_latency"),     # 执行了 l2_latency 应用
                str(footprint_mib),
                str(line_bytes),                        # pointer-chase 节点之间的地址跨度，即相邻两次 load 在内存中的字节间距
                str(config["accesses"]),
                str(config["repetitions"]),
                str(seed),
                str(args.device),
                str(prefetch_mode),
            ]
            print("+", shlex.join(command), flush=True)
            # 在 benchmark 运行前采集一次 GPU 遥测
            before = command_output(
                [
                    "nvidia-smi",
                    "--query-gpu=timestamp,pstate,clocks.sm,clocks.mem,"
                    "temperature.gpu,power.draw",
                    "--format=csv,noheader,nounits",
                ]
            )
            completed = run(command)
            # benchmark 运行后再采集一次 GPU 遥测，用于对比运行前后的频率/温度变化
            after = command_output(
                [
                    "nvidia-smi",
                    "--query-gpu=timestamp,pstate,clocks.sm,clocks.mem,"
                    "temperature.gpu,power.draw",
                    "--format=csv,noheader,nounits",
                ]
            )
            lines = completed.stdout.splitlines()
            if not lines:
                raise RuntimeError(f"no output from {shlex.join(command)}")
            if not header_written:
                output.write(lines[0] + "\n")
                header_written = True
            for line in lines[1:]:
                output.write(line + "\n")
            output.flush()
            manifest["benchmark_commands"].append(
                {
                    "command": command,
                    "seed": seed,
                    "telemetry_before": before,
                    "telemetry_after": after,
                    "stderr": completed.stderr,
                }
            )

    # 将输出文件的 SHA-256 摘要写入 manifest，便于事后校验结果文件未被篡改
    manifest["outputs"] = {
        "device_info.json": sha256_file(device_info_path),
        "l2_latency.csv": sha256_file(combined_csv),
    }
    manifest["completed_utc"] = dt.datetime.now(dt.timezone.utc).strftime(
        "%Y%m%dT%H%M%SZ"
    )
    # 序列化 manifest 并写入结果目录，结尾补换行符
    (run_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(run_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())