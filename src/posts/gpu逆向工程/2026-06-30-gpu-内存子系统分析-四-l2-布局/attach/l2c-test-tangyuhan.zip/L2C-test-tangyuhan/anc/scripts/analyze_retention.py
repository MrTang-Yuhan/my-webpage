#!/usr/bin/env python3
"""
汇总受控冷流污染后的热集保留实验。

输入是 `l2_retention` 的 CSV，输出为聚合 CSV、PDF 和 PNG。该脚本分析 normal 与 
persisting L2 policy 对热集再次探测延迟的影响。
"""

from __future__ import annotations
# 启用 PEP 563 推迟注解求值，允许在类型提示中使用尚未定义的前向引用（如类自身）。
# 该特性在 Python 3.7+ 引入，3.10+ 成为推荐写法。

import argparse
import csv
import pathlib
import statistics
from collections import defaultdict

import matplotlib.pyplot as plt


def main() -> int:
    """脚本的命令行入口。

    Returns:
        进程退出码，0 表示成功。
    """
    # 创建命令行参数解析器。
    # ArgumentParser 对象包含将命令行解析成 Python 数据类型所需的全部信息，
    # 并自动生成帮助手册与错误提示。
    parser = argparse.ArgumentParser()
    # 位置参数：输入 CSV 文件路径。type=pathlib.Path 会在解析后返回 Path 对象。
    parser.add_argument("csv_path", type=pathlib.Path)
    # --processed：非图片输出目录，CSV 文件将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--processed", required=True, type=pathlib.Path)
    # --figures：图片输出目录，PDF/PNG 将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--figures", required=True, type=pathlib.Path)
    args = parser.parse_args()

    # 从输入 CSV 文件名提取主干（stem），用于命名输出文件。
    # pathlib.Path.stem：返回去掉最后一个后缀的文件名，如 "retention.csv" → "retention"。
    output_stem = args.csv_path.stem

    # 聚合数据结构：键为实验条件四元组 (policy, hot_mib, cold_mib, hit_ratio)，
    # 值为该条件下所有重复测量的 cycles_per_access 列表。
    # defaultdict(list) 在访问不存在的键时自动以空列表作为默认值，避免手动 setdefault。
    groups: dict[tuple[str, float, float, float], list[float]] = defaultdict(list)
    # 以 UTF-8 编码打开输入 CSV；newline="" 是 csv 模块官方推荐做法，
    # 防止在 Windows 上写入时产生多余的空行。
    with args.csv_path.open(newline="", encoding="utf-8") as handle:
        # DictReader 将 CSV 首行作为字段名，后续每行读取为 OrderedDict[str, str]。
        for row in csv.DictReader(handle):
            key = (
                row["policy"],
                float(row["hot_mib"]),
                float(row["cold_mib"]),
                float(row["hit_ratio"]),
            )
            groups[key].append(float(row["cycles_per_access"]))

    # 对每个实验条件聚合统计量：重复次数、中位数、最小值、最大值。
    summaries = []
    for (policy, hot_mib, cold_mib, hit_ratio), values in sorted(groups.items()):
        summaries.append(
            {
                "policy": policy,
                "hot_mib": hot_mib,
                "cold_mib": cold_mib,
                "hit_ratio": hit_ratio,
                "repetitions": len(values),
                # statistics.median 返回数据的中位数（中间值），
                # 数据无需预先排序；若数据量为偶数，返回两个中间值的算术平均。
                "median_cycles": statistics.median(values),
                "min_cycles": min(values),
                "max_cycles": max(values),
            }
        )

    # 创建 --processed 目录，CSV 将写入此目录。
    # Path.mkdir(parents=True, exist_ok=True) 递归创建目录；
    # exist_ok=True 避免目录已存在时抛出异常。
    args.processed.mkdir(parents=True, exist_ok=True)
    # 构造 CSV 完整路径：目录 / 输入文件名主干 + .csv
    summary_path = args.processed / f"{output_stem}.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        # DictWriter 按 fieldnames 指定的列顺序将字典序列写入 CSV。
        writer = csv.DictWriter(handle, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)

    # 创建 Figure 与单个子图 Axes；figsize 以英寸为单位 (宽, 高)。
    fig, ax = plt.subplots(figsize=(6.6, 3.7))
    # 按 (policy, hit_ratio) 分组绘制曲线；sorted + set 去重并保证图例顺序稳定。
    for (policy, hit_ratio) in sorted(
        {(row["policy"], row["hit_ratio"]) for row in summaries}
    ):
        # 筛选出当前 policy 与 hit_ratio 对应的所有 summary 行。
        rows = [
            row
            for row in summaries
            if row["policy"] == policy and row["hit_ratio"] == hit_ratio
        ]
        # 按冷流大小（cold_mib）升序排序，保证折线横坐标单调递增。
        rows.sort(key=lambda row: row["cold_mib"])
        # 图例标签：normal 策略不附带 hit_ratio，其余策略标注 hitRatio。
        label = policy if policy == "normal" else f"{policy}, hitRatio={hit_ratio:g}"
        # 绘制中位数折线；marker="o" 在每个数据点显示圆点。
        ax.plot(
            [row["cold_mib"] for row in rows],
            [row["median_cycles"] for row in rows],
            marker="o",
            linewidth=1.4,
            label=label,
        )
        # 填充 min~max 区间作为误差带，alpha=0.12 使填充色半透明，避免遮挡主曲线。
        ax.fill_between(
            [row["cold_mib"] for row in rows],
            [row["min_cycles"] for row in rows],
            [row["max_cycles"] for row in rows],
            alpha=0.12,
        )

    ax.set_xlabel("Cold-stream footprint inserted after warming (MiB)")
    ax.set_ylabel("Subsequent hot-set probe latency (cycles)")
    ax.grid(True, alpha=0.22)
    ax.legend(frameon=False)
    # 自动调整子图参数，使布局紧凑、标签不重叠。
    fig.tight_layout()

    # 创建 --figures 目录，图片将写入此目录。
    args.figures.mkdir(parents=True, exist_ok=True)
    # 构造图片完整路径：目录 / 输入文件名主干 + .pdf / .png
    figure_pdf = args.figures / f"{output_stem}.pdf"
    figure_png = args.figures / f"{output_stem}.png"
    # 分别保存为矢量图 PDF 与位图 PNG（dpi=220 保证高分辨率）。
    fig.savefig(figure_pdf)
    fig.savefig(figure_png, dpi=220)
    return 0


if __name__ == "__main__":
    # 当以脚本方式直接运行时，执行 main() 并将其返回值作为进程退出码。
    # SystemExit 是 Python 内置异常，用于终止解释器并向上层传递退出状态。
    raise SystemExit(main())