#!/usr/bin/env python3
"""汇总 NUCA-aware work placement 实验结果。

输入是 placement campaign 的原始 CSV，输出为统计 JSON 和图像。该脚本比较 oblivious、aware 和 dynamic 三种调度策略在 L2 与 DRAM regime 下的 makespan。"""

from __future__ import annotations

import argparse
import csv
import json
import pathlib
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt

REGIME_LABEL = {
    "l2_t1": "L2-resident\n(1 warp/SM)",
    "l2_t8": "L2-resident\n(8 warps/SM)",
    "dram_fill": "DRAM-bound\n(27 GiB)",
}


def load(path):
    """Loads a CSV file into dictionaries for grouped aggregation.
    
    Args:
        path: placement CSV 路径。
    
    Returns:
        CSV 行字典列表。"""
    return list(csv.DictReader(path.open()))


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    ap = argparse.ArgumentParser()
    ap.add_argument("run_dir", type=pathlib.Path)
    ap.add_argument("--figures", required=True, type=pathlib.Path)
    ap.add_argument("--processed", required=True, type=pathlib.Path)
    args = ap.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    args.processed.mkdir(parents=True, exist_ok=True)

    regimes = ["l2_t1", "l2_t8", "dram_fill"]
    stats = {}
    for name in regimes:
        rows = load(args.run_dir / f"placement_{name}.csv")
        by = defaultdict(list)
        for r in rows:
            by[r["policy"]].append(float(r["makespan_ms"]))
        ob = float(np.median(by["oblivious"]))
        entry = {"vram_used_mib": float(rows[0]["vram_used_mib"]),
                 "threads_per_block": int(rows[0]["threads_per_block"]),
                 "footprint_mib": int(rows[0]["region_words"]) * int(rows[0]["threads_per_block"]) * 142 * 4 / 2**20,
                 "policies": {}}
        for pol in ["oblivious", "aware", "dynamic"]:
            if pol in by:
                med = float(np.median(by[pol]))
                entry["policies"][pol] = {
                    "makespan_ms": med,
                    "speedup_vs_oblivious": ob / med,
                    "improvement_pct": 100 * (ob / med - 1),
                }
        stats[name] = entry
    (args.processed / "placement_stats.json").write_text(
        json.dumps(stats, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(stats, indent=2))

    # Grouped bar chart of makespan improvement over oblivious.
    fig, ax = plt.subplots(figsize=(7.6, 3.8))
    x = np.arange(len(regimes))
    width = 0.36
    aware = [stats[r]["policies"]["aware"]["improvement_pct"] for r in regimes]
    dyn = [stats[r]["policies"]["dynamic"]["improvement_pct"] for r in regimes]
    ax.bar(x - width / 2, aware, width, label="aware (model, static)", color="tab:green")
    ax.bar(x + width / 2, dyn, width, label="dynamic (work-stealing)", color="tab:orange")
    ax.axhline(0, color="0.4", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels([REGIME_LABEL[r] for r in regimes], fontsize=8)
    ax.set_ylabel("Makespan reduction vs oblivious (%)")
    ax.set_title("NUCA-aware work placement")
    ax.grid(True, axis="y", alpha=0.24)
    ax.legend(fontsize=8)
    for xi, v in zip(x - width / 2, aware):
        ax.annotate(f"{v:+.1f}%", (xi, v), textcoords="offset points",
                    xytext=(0, 3 if v >= 0 else -10), ha="center", fontsize=7.5)
    fig.tight_layout()
    fig.savefig(args.figures / "placement.pdf")
    fig.savefig(args.figures / "placement.png", dpi=220)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
