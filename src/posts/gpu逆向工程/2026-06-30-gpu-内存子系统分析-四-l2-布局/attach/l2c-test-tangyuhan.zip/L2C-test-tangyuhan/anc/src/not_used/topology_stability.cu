// 长时间拓扑稳定性探测：在持续满载 GPU/VRAM 的压力下，验证 SM-L2 延迟拓扑是否漂移。
//
// 本文件将"持续满载压力源"与"逐 SM 指纹探测"交替运行，用于检验 SM-L2
// 延迟拓扑是否会随温度、频率、VRAM 压力或长时间运行而发生漂移。
//
// 申请一块大 Buffer 占满绝大部分 VRAM，并由一个计算+访存混合的负载 Kernel
// 以突发（burst）方式反复 hammer，使 GPU 持续处于满载状态。
// 在两次 burst 之间，使用与 placement oracle 相同的"每 SM 一个 block、串行轮询"探测方式，
// 基于相同的 32-probe bank 测量每个物理 SM 的 L2 延迟指纹，确保快照之间可直接对比。
// 每次快照记录每个物理 SM 的指纹及经过时间，从而量化拓扑（以及位置侧信道）
// 在持续负载下的稳定性。

#include <cuda_runtime.h>

#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <vector>

// CUDA 运行时错误检查宏：若调用失败，则打印文件、行号及错误信息并终止程序。
#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t e__ = (call);                                                  \
    if (e__ != cudaSuccess) {                                                  \
      std::cerr << "CUDA error " << __FILE__ << ":" << __LINE__ << ": "        \
                << cudaGetErrorString(e__) << "\n";                            \
      std::exit(1);                                                            \
    }                                                                          \
  } while (0)

// 通过内联 PTX 指令读取当前线程所在的物理 SM（Streaming Multiprocessor）编号。
// %smid 是只读特殊寄存器，返回当前 warp 所在物理 SM 的索引。
__device__ __forceinline__ uint32_t physical_smid() {
  uint32_t id;
  asm volatile("mov.u32 %0, %%smid;" : "=r"(id));
  return id;
}

// 使用内联 PTX 指令执行一次全局内存加载，带有 .cg（cache-global）缓存修饰符。
// .cg 表示绕过 L1 Cache，仅将数据缓存到 L2，常用于测量 L2 或显存延迟。
__device__ __forceinline__ uint32_t load_cg_u32(const uint32_t *a) {
  uint32_t v;
  asm volatile("ld.global.cg.u32 %0, [%1];" : "=r"(v) : "l"(a) : "memory");
  return v;
}

// 计算+访存负载 Kernel：反复扫描大 Buffer，执行读-改-写 float4 并穿插 FMA 运算，
// 使 GPU 在两次 fingerprint 快照之间保持热态（高占用、高功耗）。
__global__ void load_kernel(float4 *buf, uint64_t n, int iters) {
  uint64_t i = static_cast<uint64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
  const uint64_t stride = static_cast<uint64_t>(gridDim.x) * blockDim.x;
  for (uint64_t k = i; k < n; k += stride) {
    float4 v = buf[k];
    for (int j = 0; j < iters; ++j) {
      v.x = fmaf(v.x, 1.0001f, 1.0f);
      v.y = fmaf(v.y, 1.0001f, 1.0f);
      v.z = fmaf(v.z, 1.0001f, 1.0f);
      v.w = fmaf(v.w, 1.0001f, 1.0f);
    }
    buf[k] = v;
  }
}

// 逐 SM 指纹探测 Kernel（串行轮询，每 SM 一个 block）。
// 与 topology/placement 中的 fingerprint 逻辑一致：一次仅允许一个 SM 独占计时窗口，
// 对固定 probe bank 逐项记录 cycles_per_access，避免并发干扰。
__global__ void fingerprint_kernel(const uint32_t *next, const uint32_t *starts,
                                   int n_probes, uint64_t warm, uint64_t measured,
                                   int *turn_claim, int *now_serving,
                                   uint32_t *out_smid, uint64_t *out_cycles,
                                   uint32_t *out_sink) {
  if (threadIdx.x != 0) return;          // 每个 block 仅由 0 号线程执行，减少扰动
  const int b = blockIdx.x;
  out_smid[b] = physical_smid();         // 记录该 block 实际映射到的物理 SM ID
  const int my = atomicAdd(turn_claim, 1); // 原子取号，获取当前轮次序号
  // 自旋等待：直到 now_serving 等于自己的序号，才进入独占测量窗口。
  // __nanosleep(2000) 让线程休眠约 2000 纳秒，降低忙等时的功耗与 SM 资源争抢。
  while (atomicAdd(now_serving, 0) != my) __nanosleep(2000);
  uint32_t sink = 0;
  for (int p = 0; p < n_probes; ++p) {
    uint32_t idx = starts[p];
    // Warm-up 阶段：预先遍历 probe chain，将数据带入 Cache，排除冷启动噪声。
    for (uint64_t i = 0; i < warm; ++i) idx = load_cg_u32(next + idx);
    // __threadfence() 确保 warm-up 的内存访问全局可见，防止后续 clock64() 计时
    // 与 warm-up 访存发生乱序，保证测量区间边界严格。
    __threadfence();
    // 正式测量窗口：记录 clock64() 前后差值，即 measured 次访存的总周期数。
    const uint64_t t0 = clock64();
    for (uint64_t i = 0; i < measured; ++i) idx = load_cg_u32(next + idx);
    const uint64_t t1 = clock64();
    out_cycles[static_cast<uint64_t>(b) * n_probes + p] = t1 - t0;
    sink ^= idx;                         // 伪消耗，防止编译器将访存优化掉
  }
  out_sink[b] = sink;
  // 原子交换：释放当前独占窗口，将 now_serving 推进到下一个序号，允许下一 SM 进入。
  atomicExch(now_serving, my + 1);
}

// 将命令行参数字符串解析为 uint64_t。
static uint64_t pu64(const char *t) { return std::strtoull(t, nullptr, 10); }
// 将命令行参数字符串解析为 double。
static double pf(const char *t) { return std::strtod(t, nullptr); }

int main(int argc, char **argv) {
  if (argc != 8) {
    std::cerr << "Usage: " << argv[0]
              << " <vram_gib> <duration_sec> <snapshot_period_sec> "
                 "<load_iters> <n_probes> <measured> <device>\n";
    return 1;
  }
  const double vram_gib = pf(argv[1]);
  const double duration_sec = pf(argv[2]);
  const double period_sec = pf(argv[3]);
  const int load_iters = (int)pu64(argv[4]);
  const int n_probes = (int)pu64(argv[5]);
  const uint64_t measured = pu64(argv[6]);
  const int device = (int)pu64(argv[7]);

  CUDA_CHECK(cudaSetDevice(device));
  cudaDeviceProp prop{};
  CUDA_CHECK(cudaGetDeviceProperties(&prop, device));
  const int num_sm = prop.multiProcessorCount;
  int clk = 0;
  // 获取设备的着色器时钟频率（单位：kHz），用于后续将 cycle 数换算为时间。
  CUDA_CHECK(cudaDeviceGetAttribute(&clk, cudaDevAttrClockRate, device));

  // 申请大 Buffer 占满 VRAM，制造高容量压力。
  const uint64_t big_bytes = (uint64_t)(vram_gib * (1ull << 30));
  const uint64_t n_float4 = big_bytes / sizeof(float4);
  // 大 Buffer 尽量占满 VRAM，确保稳定性实验覆盖高容量压力，而非仅测试空闲 GPU。
  float4 *d_big = nullptr;
  CUDA_CHECK(cudaMalloc(&d_big, n_float4 * sizeof(float4)));
  CUDA_CHECK(cudaMemset(d_big, 1, n_float4 * sizeof(float4)));

  // 申请小容量 L2-resident 自循环 probe bank（16 MiB），用于指纹探测。
  // 该 bank 尺寸远小于 L2 容量，确保探测访存命中 L2，不引入显存延迟噪声。
  const uint64_t bank_words = (16ull << 20) / sizeof(uint32_t);
  std::vector<uint32_t> h_bank(bank_words);
  std::iota(h_bank.begin(), h_bank.end(), 0u);
  uint32_t *d_bank = nullptr;
  CUDA_CHECK(cudaMalloc(&d_bank, bank_words * sizeof(uint32_t)));
  CUDA_CHECK(cudaMemcpy(d_bank, h_bank.data(), bank_words * sizeof(uint32_t),
                        cudaMemcpyHostToDevice));
  std::vector<uint32_t> h_starts(n_probes);
  for (int p = 0; p < n_probes; ++p) h_starts[p] = (uint32_t)((256ull * p) / 4);
  // 每个 probe 起始地址间隔 256B，形成固定 offset bank；
  // 不同 snapshot 之间可逐列比较，观察延迟漂移。
  uint32_t *d_starts = nullptr;
  CUDA_CHECK(cudaMalloc(&d_starts, sizeof(uint32_t) * n_probes));
  CUDA_CHECK(cudaMemcpy(d_starts, h_starts.data(), sizeof(uint32_t) * n_probes,
                        cudaMemcpyHostToDevice));

  // 申请极大的动态共享内存，人为压低 occupancy，使得每个物理 SM 上只能同时驻留
  // 一个 probe block，确保 fingerprint 测量时 SM 独占。
  const size_t shmem = prop.sharedMemPerMultiprocessor / 2 + 1024;
  CUDA_CHECK(cudaFuncSetAttribute(fingerprint_kernel,
             cudaFuncAttributeMaxDynamicSharedMemorySize, (int)shmem));

  // 分配设备端同步与输出缓冲区。
  int *d_turn, *d_serv;
  uint32_t *d_smid, *d_sink;
  uint64_t *d_cyc;
  CUDA_CHECK(cudaMalloc(&d_turn, sizeof(int)));
  CUDA_CHECK(cudaMalloc(&d_serv, sizeof(int)));
  CUDA_CHECK(cudaMalloc(&d_smid, sizeof(uint32_t) * num_sm));
  CUDA_CHECK(cudaMalloc(&d_sink, sizeof(uint32_t) * num_sm));
  CUDA_CHECK(cudaMalloc(&d_cyc, sizeof(uint64_t) * num_sm * n_probes));
  std::vector<uint32_t> h_smid(num_sm);
  std::vector<uint64_t> h_cyc((uint64_t)num_sm * n_probes);

  // 负载 Kernel 的 block 数：num_sm * 32，确保足够并行度以维持 GPU 满载。
  const int load_blocks = num_sm * 32;

  // 输出 CSV 表头：snapshot 序号、经过时间、SM ID、测量次数、核心时钟频率、各 probe 延迟。
  std::cout << "snapshot,elapsed_sec,smid,measured,core_clock_khz";
  for (int p = 0; p < n_probes; ++p) std::cout << ",lat_" << p;
  std::cout << "\n";

  const auto t_start = std::chrono::steady_clock::now();
  auto elapsed = [&]() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now() - t_start).count();
  };

  int snap = 0;
  while (elapsed() < duration_sec) {
    // 持续负载突发：运行 load_kernel 直到下一个快照时间点。
    const double burst_end = std::min(elapsed() + period_sec, duration_sec);
    while (elapsed() < burst_end) {
      load_kernel<<<load_blocks, 256>>>(d_big, n_float4, load_iters);
      CUDA_CHECK(cudaGetLastError());
      CUDA_CHECK(cudaDeviceSynchronize());
    }
    // 快照探测：此时 GPU 处于热态且 VRAM 接近占满。
    // 每次 snapshot 前重置 turn counter，避免上一轮串行顺序影响本轮输出。
    CUDA_CHECK(cudaMemset(d_turn, 0, sizeof(int)));
    CUDA_CHECK(cudaMemset(d_serv, 0, sizeof(int)));
    fingerprint_kernel<<<num_sm, 32, shmem>>>(d_bank, d_starts, n_probes, 24,
                                              measured, d_turn, d_serv, d_smid,
                                              d_cyc, d_sink);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
    // 将设备端探测结果拷贝回主机。
    CUDA_CHECK(cudaMemcpy(h_smid.data(), d_smid, sizeof(uint32_t) * num_sm,
                          cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(h_cyc.data(), d_cyc,
                          sizeof(uint64_t) * num_sm * n_probes,
                          cudaMemcpyDeviceToHost));
    const double e = elapsed();
    // 按 CSV 格式逐行输出每个 SM 的指纹结果，延迟已除以 measured 换算为单次访存周期。
    for (int b = 0; b < num_sm; ++b) {
      std::cout << snap << ',' << e << ',' << h_smid[b] << ',' << measured << ','
                << clk;
      for (int p = 0; p < n_probes; ++p)
        std::cout << ',' << (double)h_cyc[(uint64_t)b * n_probes + p] / (double)measured;
      std::cout << '\n';
    }
    std::cout.flush();
    ++snap;
  }
  std::cerr << "snapshots=" << snap << " elapsed=" << elapsed() << "s\n";
  return 0;
}