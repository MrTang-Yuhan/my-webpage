// 持续内存带宽饱和微基准测试。
//
// 该文件在指定 GPU 上分配大工作集，并反复执行 float4 read-modify-write。
// 每次 pass 统计读写总带宽和可选 FMA 吞吐，用于制造或量化接近满载的
// 访存压力。它是拓扑稳定性和负控制实验的配套压力源。

#include <cuda_runtime.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>

#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t error__ = (call);                                               \
    if (error__ != cudaSuccess) {                                               \
      std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << ": "   \
                << cudaGetErrorString(error__) << "\n";                         \
      std::exit(EXIT_FAILURE);                                                  \
    }                                                                          \
  } while (0)

// 遍历整个缓冲区并对每个元素执行写回。
//
// 每个 float4 被读入寄存器，执行 `fma_iterations` 轮 FMA 后写回原地址。
// 当迭代数为 0 时主要测内存读写带宽；迭代数增大后可同时施加计算压力。
__global__ void read_modify_write_kernel(float4 *data, uint64_t count,
                                         int fma_iterations) {
  // 计算该线程在全局网格中的唯一线性索引。
  const uint64_t start =
      static_cast<uint64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
  // 采用 grid-stride loop 模式，使每个线程可处理多个元素，提升 SM 利用率并支持任意数据规模。
  const uint64_t stride = static_cast<uint64_t>(blockDim.x) * gridDim.x;
  for (uint64_t index = start; index < count; index += stride) {
    // 从全局内存读取 128-bit 向量 float4 到寄存器。
    // 连续线程访问连续地址，满足合并访问（coalesced access）条件，单次事务传输 128 bit。
    float4 value = data[index];
    for (int iteration = 0; iteration < fma_iterations; ++iteration) {
      // 单精度融合乘加（fused multiply-add，fmaf）。
      // 1 条 fmaf 指令完成 1 次乘法和 1 次加法，仅 1 次舍入，计为 2 FLOP。
      // 各分量使用略微不同的常数，防止编译器将循环优化为无操作或完全相同的重复计算。
      value.x = fmaf(value.x, 1.000000119f, 0.000000119f);  
      value.y = fmaf(value.y, 0.999999881f, 0.000000238f);
      value.z = fmaf(value.z, 1.000000238f, -0.000000119f);
      value.w = fmaf(value.w, 0.999999762f, 0.000000357f);
    }
    // 将修改后的 float4 写回全局内存同一地址，构成 read-modify-write 完整事务。
    data[index] = value;
  }
}

int main(int argc, char **argv) {
  // 命令行参数校验：需要 4 个参数。
  if (argc != 5) {
    std::cerr << "Usage: " << argv[0]
              << " <working_set_gib> <duration_seconds> <fma_iterations> "
                 "<device>\n";
    return EXIT_FAILURE;
  }

  // 解析命令行参数。
  const double working_set_gib = std::stod(argv[1]);  // 工作集大小（GiB）。注意不要超过显存容量
  const double duration_seconds = std::stod(argv[2]); // 总运行时长（秒）
  const int fma_iterations = std::stoi(argv[3]);      // 每元素 FMA 轮数
  const int device = std::stoi(argv[4]);              // 目标 GPU 设备号
  if (!(working_set_gib > 0.0) || !(duration_seconds > 0.0) ||
      fma_iterations < 0) {
    std::cerr << "invalid argument\n";
    return EXIT_FAILURE;
  }

  // 设置当前线程活跃的 CUDA 设备。
  // 后续所有设备侧内存分配与 kernel 启动均在该设备上执行。
  CUDA_CHECK(cudaSetDevice(device));
  // 查询设备属性，后续用于根据 SM 数量配置启动参数。
  cudaDeviceProp properties{};
  CUDA_CHECK(cudaGetDeviceProperties(&properties, device));
  // 查询当前设备空闲显存与总显存（字节）。
  size_t free_bytes = 0;
  size_t total_bytes = 0;
  CUDA_CHECK(cudaMemGetInfo(&free_bytes, &total_bytes));

  // 将工作集从 GiB 转换为字节，并向下对齐到 float4 边界。
  // 对齐保证 kernel 中的向量访问不会越界，也避免处理尾部非完整向量的特例。
  uint64_t requested_bytes = static_cast<uint64_t>(
      std::llround(working_set_gib * 1024.0 * 1024.0 * 1024.0));
  requested_bytes -= requested_bytes % sizeof(float4);  
  
  // 保留 2 GiB 安全余量，防止分配后系统 OOM 或 CUDA runtime 因临时缓冲而崩溃。
  constexpr uint64_t reserve_bytes = 2ULL << 30;    
  if (requested_bytes + reserve_bytes > free_bytes) {
    std::cerr << "requested allocation leaves less than 2 GiB free: requested="
              << requested_bytes << " free=" << free_bytes << "\n";
    return EXIT_FAILURE;
  }

  // 在设备上分配线性内存，并用 0 初始化。
  float4 *data = nullptr;
  CUDA_CHECK(cudaMalloc(&data, requested_bytes));
  CUDA_CHECK(cudaMemset(data, 0, requested_bytes));
  // 计算 float4 元素总数。
  const uint64_t count = requested_bytes / sizeof(float4);

  // 启动配置：256 线程/块（warp 大小的整数倍，利于占用率），
  // 块数 = SM 数量 × 8，保证足够高的常驻 warp 数以隐藏全局内存延迟。
  const int threads = 256;
  const int blocks = properties.multiProcessorCount * 8;

  // 预热三轮：稳定页表映射、缓存状态及 GPU 频率，避免冷启动偏差。
  // 计时结果仅从后续 pass 输出。
  for (int warmup = 0; warmup < 3; ++warmup) {
    read_modify_write_kernel<<<blocks, threads>>>(data, count, fma_iterations);
  }
  // 阻塞 Host，确保预热 kernel 全部执行完毕后再进入正式计时阶段。
  CUDA_CHECK(cudaDeviceSynchronize());

  // 创建 CUDA Event 用于 GPU 端精确计时。
  // Event 记录的是 GPU 时间戳，分辨率约为 0.5 微秒。
  cudaEvent_t begin;
  cudaEvent_t end;
  CUDA_CHECK(cudaEventCreate(&begin));
  CUDA_CHECK(cudaEventCreate(&end));
  // 每个 pass 的内存事务量包含一次全局读和一次全局写，故总字节数 × 2.0。
  const double bytes_per_pass = static_cast<double>(requested_bytes) * 2.0;
  // 每个 pass 的浮点运算量：count 个 float4，每个 float4 含 4 个 float 分量；
  // 每轮迭代对每个分量执行 1 次 fmaf（2 FLOP）。
  const double flops_per_pass =
      static_cast<double>(count) * 4.0 * 2.0 * fma_iterations;

  // 输出 CSV 表头。
  std::cout << "pass,working_set_bytes,fma_iterations,elapsed_ms,"
               "effective_gb_per_s,tflop_per_s\n";
  std::cout << std::setprecision(12);

  // 使用 CPU wall-clock 控制总运行时长，防止无限循环。
  const auto wall_begin = std::chrono::steady_clock::now();
  uint64_t pass = 0;
  do {
    // 使用 CUDA Event 测量单次 kernel 执行耗时。
    // cudaEventRecord 将 event 插入默认流（stream 0），捕获该时刻流中所有前置操作完成的状态。
    CUDA_CHECK(cudaEventRecord(begin));
    read_modify_write_kernel<<<blocks, threads>>>(data, count, fma_iterations);
    CUDA_CHECK(cudaEventRecord(end));
    // cudaEventSynchronize 阻塞 Host 线程，直到 end event 被记录，
    // 即 kernel 执行完毕且 end 时间戳已写入。若未设置 cudaEventBlockingSync 标志，CPU 可能忙等。
    CUDA_CHECK(cudaEventSynchronize(end));  
    // 计算 begin 与 end 两个 event 之间的时间差（毫秒）。
    float elapsed_ms = 0.0f;
    CUDA_CHECK(cudaEventElapsedTime(&elapsed_ms, begin, end));
    const double seconds = static_cast<double>(elapsed_ms) / 1000.0;
    const double gb_per_s = bytes_per_pass / seconds / 1.0e9;
    const double tflop_per_s = flops_per_pass / seconds / 1.0e12;
    std::cout << pass << ',' << requested_bytes << ',' << fma_iterations << ','
              << elapsed_ms << ',' << gb_per_s << ',' << tflop_per_s << '\n';
    ++pass;
  } while (std::chrono::duration<double>(std::chrono::steady_clock::now() -
                                         wall_begin)
               .count() < duration_seconds);

  // 清理：按与创建相反的顺序销毁 event，释放设备内存。
  CUDA_CHECK(cudaEventDestroy(end));
  CUDA_CHECK(cudaEventDestroy(begin));
  CUDA_CHECK(cudaFree(data));
  return 0;
}