// 该文件测量单 GPU 上依赖式全局加载的 L2 命中延迟。
//
// 输入为工作集大小、缓存线跨度、访问次数、重复次数、随机种子、设备号和
// 可选的 L2 预取提示模式。输出为 CSV，每行记录一次 pointer-chase 运行的
// 总 cycle 数与单次访问平均 cycle 数。该程序对应论文中容量转折与 L2 访问
// 延迟曲线的微基准，用随机环形链避免硬件预取器把依赖访问退化为顺序流。

#include <cuda_runtime.h>

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <random>
#include <string>
#include <vector>


#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t error__ = (call);                                               \
    if (error__ != cudaSuccess) {                                               \
      std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << ": "   \
                << cudaGetErrorString(error__) << "\n";                         \
      std::exit(EXIT_FAILURE);                                                  \
    }                                                                          \
  } while (0)

// 通过全局缓存路径加载一条 32-bit 链式索引。
//
// `PrefetchMode` 为 “不配置”、64、128 或 256，分别表示默认 `ld.global.cg` 或带
// L2 预取粒度提示的 PTX 指令。`address` 必须是设备端有效地址，返回值是
// 下一次 pointer-chase 的 word 索引。
template <int PrefetchMode>
__device__ __forceinline__ uint32_t load_cg_u32(const uint32_t *address) {
  uint32_t value;
  if constexpr (PrefetchMode == 64) {
    // 向 L2 缓存子系统发出提示（非强制），将当前地址所在的 64 字节连续区域一并拉取到 L2 中
    asm volatile("ld.global.cg.L2::64B.u32 %0, [%1];"
                 : "=r"(value)
                 : "l"(address)
                 : "memory");
  } else if constexpr (PrefetchMode == 128) {
    asm volatile("ld.global.cg.L2::128B.u32 %0, [%1];"
                 : "=r"(value)
                 : "l"(address)
                 : "memory");
  } else if constexpr (PrefetchMode == 256) {
    asm volatile("ld.global.cg.L2::256B.u32 %0, [%1];"
                 : "=r"(value)
                 : "l"(address)
                 : "memory");
  } else {
    asm volatile("ld.global.cg.u32 %0, [%1];"
                 : "=r"(value)
                 : "l"(address)
                 : "memory");
  }
  return value;
}

// 在 GPU 上测量单线程依赖加载链的延迟。
//
// `next` 是设备端索引表，`start` 是起始 word 索引，`warm_accesses` 用于把
// 链路预热进 L2，`measured_accesses` 是计入计时窗口的依赖加载次数。
// 该 kernel 只允许 block 0 的 thread 0 工作，以消除线程间干扰。
template <int PrefetchMode>
__global__ void pointer_chase_kernel(const uint32_t *next, uint32_t start,
                                     uint64_t warm_accesses,
                                     uint64_t measured_accesses,
                                     uint64_t *elapsed_cycles,
                                     uint32_t *final_index) {
  if (blockIdx.x != 0 || threadIdx.x != 0) {
    return;
  }

  uint32_t index = start;
  for (uint64_t i = 0; i < warm_accesses; ++i) {
    // 即 index = next[index]
    index = load_cg_u32<PrefetchMode>(next + index);
  }

  const uint64_t begin = clock64();
  for (uint64_t i = 0; i < measured_accesses; ++i) {
    index = load_cg_u32<PrefetchMode>(next + index);
  }
  const uint64_t end = clock64();

  *elapsed_cycles = end - begin;
  *final_index = index;         // 将变量写到全局内存防止编译器优化
}

// 解析命令行中的无符号十进制参数。
//
// `text` 不能为 null，`name` 仅用于诊断输出。返回值保留完整 64-bit 范围，
// 具体语义约束由调用处按实验参数检查。
static uint64_t parse_u64(const char *text, const char *name) {
  errno = 0;
  char *end = nullptr;
  const unsigned long long value = std::strtoull(text, &end, 10);
  if (errno != 0 || end == text || *end != '\0') {
    std::cerr << "Invalid " << name << ": " << text << "\n";
    std::exit(EXIT_FAILURE);
  }
  return static_cast<uint64_t>(value);
}

// 解析命令行中的正有限浮点参数。
//
// `text` 表示 MiB 等实验单位下的数值，必须大于 0。返回值后续会按显式公式
// 转换为字节数，因此这里拒绝 NaN、Inf 和非正值。
static double parse_double(const char *text, const char *name) {
  errno = 0;
  char *end = nullptr;
  const double value = std::strtod(text, &end);
  if (errno != 0 || end == text || *end != '\0' || !std::isfinite(value) ||
      value <= 0.0) {
    std::cerr << "Invalid " << name << ": " << text << "\n";
    std::exit(EXIT_FAILURE);
  }
  return value;
}

int main(int argc, char **argv) {
  if (argc != 7 && argc != 8) {
    std::cerr
        << "Usage: " << argv[0]
        << " <footprint_mib> <line_bytes> <accesses> <repetitions> <seed> "
           "<device> [default|64B|128B|256B]\n";
    return EXIT_FAILURE;
  }

  const double footprint_mib = parse_double(argv[1], "footprint_mib");
  // `footprint_mib` 表示受测地址跨度，而不是实际分配请求；最终字节数会向下
  // 对齐到整数个 `line_bytes`。
  const uint64_t line_bytes = parse_u64(argv[2], "line_bytes");
  // `accesses` 是计时窗口内的依赖加载次数，决定 cycles_per_access 的分母。
  const uint64_t accesses = parse_u64(argv[3], "accesses");
  const uint64_t repetitions = parse_u64(argv[4], "repetitions");
  const uint64_t seed = parse_u64(argv[5], "seed");
  // 设备号由 `parse_u64` 解析后收窄为 int；命令行约束假定其落在 CUDA 可见设备范围内。
  const int device = static_cast<int>(parse_u64(argv[6], "device"));
  const std::string prefetch_mode = argc == 8 ? argv[7] : "default";
  if (prefetch_mode != "default" && prefetch_mode != "64B" &&
      prefetch_mode != "128B" && prefetch_mode != "256B") {
    std::cerr << "invalid prefetch mode: " << prefetch_mode << "\n";
    return EXIT_FAILURE;
  }

  if (line_bytes < sizeof(uint32_t) ||
      line_bytes % sizeof(uint32_t) != 0) {
    std::cerr << "line_bytes must be a multiple of 4\n";
    return EXIT_FAILURE;
  }

  CUDA_CHECK(cudaSetDevice(device));
  int reported_core_clock_khz = 0;
  CUDA_CHECK(cudaDeviceGetAttribute(
      &reported_core_clock_khz, cudaDevAttrClockRate, device));

  const uint64_t requested_bytes =
      static_cast<uint64_t>(std::llround(footprint_mib * 1024.0 * 1024.0));
  // MiB 到 bytes 的换算先四舍五入，再按缓存行大小截断，保证每个节点落在行起点。
  const uint64_t line_count = requested_bytes / line_bytes;
  if (line_count < 2) {
    std::cerr << "footprint contains fewer than two lines\n";
    return EXIT_FAILURE;
  }

  const uint64_t actual_bytes = line_count * line_bytes;
  const uint64_t words_per_line = line_bytes / sizeof(uint32_t);
  const uint64_t word_count = line_count * words_per_line;
  if (word_count > std::numeric_limits<uint32_t>::max()) {
    std::cerr << "footprint exceeds 32-bit chain index range\n";
    return EXIT_FAILURE;
  }

  std::vector<uint32_t> host_next(word_count, 0);
  std::vector<uint32_t> order(line_count);
  std::iota(order.begin(), order.end(), 0);   // 按 index 顺序上升的值
  std::mt19937_64 generator(seed);
  std::shuffle(order.begin(), order.end(), generator);

  // 随机排列只在每个缓存行的第一个 word 写入后继索引，避免同一行内多 word
  // 访问稀释 L2 slice 映射信号。
  for (uint64_t i = 0; i < line_count; ++i) {
    // 构建环形链表：每个缓存行的第一个 word 存储下一个缓存行的第一个 word 的索引
    const uint32_t current_word =
        static_cast<uint32_t>(static_cast<uint64_t>(order[i]) *
                              words_per_line);
    const uint32_t next_word =
        static_cast<uint32_t>(static_cast<uint64_t>(
                                  order[(i + 1) % line_count]) *
                              words_per_line);
    host_next[current_word] = next_word;
  }

  uint32_t *device_next = nullptr;
  uint64_t *device_elapsed = nullptr;
  uint32_t *device_final = nullptr;
  CUDA_CHECK(cudaMalloc(&device_next, actual_bytes));
  CUDA_CHECK(cudaMalloc(&device_elapsed, sizeof(uint64_t)));
  CUDA_CHECK(cudaMalloc(&device_final, sizeof(uint32_t)));
  CUDA_CHECK(cudaMemcpy(device_next, host_next.data(), actual_bytes,
                        cudaMemcpyHostToDevice));

  // `start` 使用 word 索引而不是 byte 偏移，因为设备端链表项直接存储下一跳 word。
  const uint32_t start =
      static_cast<uint32_t>(static_cast<uint64_t>(order[0]) * words_per_line);
  const uint64_t warm_accesses = line_count;

  std::cout << "run,prefetch_mode,footprint_mib,actual_bytes,line_bytes,line_count,"
               "warm_accesses,measured_accesses,seed,elapsed_cycles,"
               "cycles_per_access,reported_core_clock_khz,final_index\n";
  std::cout << std::setprecision(12);

  for (uint64_t run = 0; run < repetitions; ++run) {
    // 64B 模式显式要求 L2 以 64 字节窗口预取，用来观察预取粒度对依赖加载的影响。
    if (prefetch_mode == "64B") {
      pointer_chase_kernel<64><<<1, 1>>>(
          device_next, start, warm_accesses, accesses, device_elapsed,
          device_final);
    // 128B 模式对应常见缓存线粒度，便于和默认 `ld.global.cg` 对照。
    } else if (prefetch_mode == "128B") {
      pointer_chase_kernel<128><<<1, 1>>>(
          device_next, start, warm_accesses, accesses, device_elapsed,
          device_final);
    // 256B 模式扩大 L2 预取窗口，用于检验相邻 slice/sector 是否改变延迟曲线。
    } else if (prefetch_mode == "256B") {
      pointer_chase_kernel<256><<<1, 1>>>(
          device_next, start, warm_accesses, accesses, device_elapsed,
          device_final);
    // 默认模式不携带 L2 预取大小提示，是容量转折实验的基准路径。
    } else {
      pointer_chase_kernel<0><<<1, 1>>>(
          device_next, start, warm_accesses, accesses, device_elapsed,
          device_final);
    }
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());

    uint64_t elapsed = 0;
    uint32_t final_index = 0;
    CUDA_CHECK(cudaMemcpy(&elapsed, device_elapsed, sizeof(elapsed),
                          cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(&final_index, device_final, sizeof(final_index),
                          cudaMemcpyDeviceToHost));

    std::cout << run << ',' << prefetch_mode << ',' << footprint_mib << ','
              << actual_bytes << ',' << line_bytes << ',' << line_count << ','
              << warm_accesses << ',' << accesses << ',' << seed << ','
              << elapsed << ','
              << static_cast<double>(elapsed) /
                     static_cast<double>(accesses)
              << ',' << reported_core_clock_khz << ',' << final_index << '\n';
  }

  CUDA_CHECK(cudaFree(device_final));
  CUDA_CHECK(cudaFree(device_elapsed));
  CUDA_CHECK(cudaFree(device_next));
  return 0;
}