#!/usr/bin/env python3
"""
汇总热集大小跨越 persisting set-aside 时的保留能力。

输入是 retention CSV，输出为按 policy 与 hot-set 大小聚合的表格。该脚本用于量化热集
超过 set-aside 容量后延迟是否出现退化。

结果发现：
(1)
| 区域                 | 热集大小范围    | 物理含义                                    |
| ------------------   | --------- | --------------------------------------- |
|  Persisting 保护区   | ≤ ~32 MiB  | 热集完全落在 Persisting L2 set-aside 内，硬件强制驻留      |
|  L2 总容量区         | 32–64 MiB  | 热集超过 set-aside 但仍在 L2 总容量内，persist 部分保护     |
|  DRAM 主导区         | > ~64 MiB  | 热集超过 L2 总容量，无论何种策略都大量回退到 DRAM           |

(2) Persisting L2 存在最大为总容量 50% 的硬件限制。
"""

# PEP 563: 推迟注解求值（Postponed Evaluation of Annotations）。
# 根据 Python 官方文档，from __future__ import annotations 使所有注解在运行时以字符串形式存储，
# 而非立即求值。这允许在类定义内部引用自身类型（前向引用），且显著提升模块导入速度。
from __future__ import annotations

import argparse
import csv
import pathlib
import statistics
from collections import defaultdict

import matplotlib.pyplot as plt


def main() -> int:
    """脚本的命令行入口函数。

    Returns:
        进程退出码，0 表示成功。
    """
    # argparse.ArgumentParser : Python 标准库命令行参数解析器。
    # 根据官方文档，它会自动生成 usage 和 help 信息，并对无效参数报错。
    parser = argparse.ArgumentParser()
    # add_argument("csv_path") : 定义位置参数（positional argument），
    # 用户必须在命令行提供输入 CSV 文件路径。
    # type=pathlib.Path : 自动将字符串转换为 Path 对象，支持跨平台路径操作。
    parser.add_argument("csv_path", type=pathlib.Path)
    # --processed：非图片输出目录，CSV 文件将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--processed", required=True, type=pathlib.Path)
    # --figures：图片输出目录，PDF/PNG 将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--figures", required=True, type=pathlib.Path)
    # --cold-mib : 定义可选参数，指定冷流大小（单位 MiB），默认 256.0。
    parser.add_argument("--cold-mib", default=256.0, type=float)
    args = parser.parse_args()

    # 从输入 CSV 文件名提取主干（stem），用于命名输出文件。
    # pathlib.Path.stem：返回去掉最后一个后缀的文件名，如 "retention_hotset.csv" → "retention_hotset"。
    output_stem = args.csv_path.stem

    # 动态生成列名标签，避免硬编码 256。
    # f"{args.cold_mib:g}" 使用 g 格式符自动去除小数点后无意义的零（如 256.0 → "256"）。
    cold_label = f"{args.cold_mib:g}"

    # 聚合键保留实验条件，值列表保存重复测量以便报告 median/min/max。
    # defaultdict(list) : collections.defaultdict 是 dict 的子类，访问不存在的键时
    # 自动调用 default_factory（此处为 list）生成默认值，避免手动检查 KeyError。
    # 根据 Python 官方文档，defaultdict 的 __missing__ 方法会触发 default_factory。
    groups: dict[tuple[str, float, float], list[float]] = defaultdict(list)
    # Path.open() : 以文本模式打开文件，与内置 open() 等价，但支持路径对象直接调用。
    # newline="" : 根据 csv 模块官方文档，必须传入空字符串以正确处理 CSV 中的换行符，
    # 防止在 Windows 平台上出现额外的空行。
    with args.csv_path.open(newline="", encoding="utf-8") as handle:
        # csv.DictReader : 将 CSV 文件的每一行读取为 OrderedDict，键来自首行表头。
        # 根据官方文档，它自动处理引号、转义和分隔符，比 csv.reader 更适合按列名访问数据。
        for row in csv.DictReader(handle):
            # 聚合键：(策略, 热集大小, 冷集大小)；值：cycles_per_access 列表。
            key = (row["policy"], float(row["hot_mib"]), float(row["cold_mib"]))
            groups[key].append(float(row["cycles_per_access"]))

    rows = []
    # 提取所有不重复的热集大小并按升序排列，保证输出表格按 hot_mib 递增。
    hot_values = sorted({hot for _, hot, _ in groups})
    for hot_mib in hot_values:
        baseline = {}
        # 遍历两种策略（normal / persist）和两种冷集条件（0 / cold_mib）。
        for policy in ("normal", "persist"):
            for cold_mib in (0.0, args.cold_mib):
                values = groups.get((policy, hot_mib, cold_mib), [])
                if not values:
                    continue
                # statistics.median : 返回数据的中位数（中间值）。
                # 根据 Python 官方文档，数据量为奇数时返回中间元素；
                # 为偶数时返回中间两个元素的算术平均值。数据无需预先排序。
                baseline[(policy, cold_mib)] = {
                    "median": statistics.median(values),
                    "min": min(values),
                    "max": max(values),
                    "n": len(values),
                }
        # 提取各条件下的中位数结果。
        normal_cold = baseline.get(("normal", args.cold_mib))
        persist_cold = baseline.get(("persist", args.cold_mib))
        normal_zero = baseline.get(("normal", 0.0))
        persist_zero = baseline.get(("persist", 0.0))
        # 若 normal_cold 或 persist_cold 缺失，跳过该 hot_mib（数据不完整）。
        if not normal_cold or not persist_cold:
            continue
        rows.append(
            {
                "hot_mib": hot_mib,
                f"normal_cold{cold_label}_median_cycles": normal_cold["median"],
                f"persist_cold{cold_label}_median_cycles": persist_cold["median"],
                # persist_advantage_cycles : persist 策略相比 normal 策略的延迟优势（cycle 数）。
                # 正值表示 persist 更快（cycle 更少）。
                "persist_advantage_cycles": normal_cold["median"]
                - persist_cold["median"],
                "normal_cold0_median_cycles": normal_zero["median"]
                if normal_zero
                else "",
                "persist_cold0_median_cycles": persist_zero["median"]
                if persist_zero
                else "",
                "repetitions": normal_cold["n"],
            }
        )

    if not rows:
        print("No valid data rows to output.", file=__import__("sys").stderr)
        return 1

    # 创建 --processed 目录，CSV 将写入此目录。
    # Path.mkdir(parents=True, exist_ok=True) : 递归创建目录。
    # parents=True 表示按需创建所有缺失的父目录（类似 mkdir -p）；
    # exist_ok=True 表示目录已存在时不抛出 FileExistsError。
    args.processed.mkdir(parents=True, exist_ok=True)
    # 构造 CSV 完整路径：目录 / 输入文件名主干 + .csv
    summary_path = args.processed / f"{output_stem}.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        # csv.DictWriter : 将字典列表写入 CSV 文件。
        # fieldnames 指定列顺序；writeheader() 写入表头；writerows() 批量写入数据行。
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    # 2. 绘制图表
    fig, ax = plt.subplots(figsize=(6.6, 4.7))

    hot_mibs = [row["hot_mib"] for row in rows]
    normal_cold_vals = [row[f"normal_cold{cold_label}_median_cycles"] for row in rows]
    persist_cold_vals = [row[f"persist_cold{cold_label}_median_cycles"] for row in rows]

    # ax.plot() : 在 Axes 上绘制折线图。
    # marker : 数据点标记样式（"o" 为圆点，"s" 为方块）；
    # linewidth : 线宽；label : 图例标签。
    ax.plot(
        hot_mibs,
        normal_cold_vals,
        marker="o",
        linewidth=1.4,
        label="normal",
    )
    ax.plot(
        hot_mibs,
        persist_cold_vals,
        marker="s",
        linewidth=1.4,
        label="persist",
    )

    ax.set_xlabel("Hot-set footprint (MiB)")
    ax.set_ylabel(
        f"Probe latency after {cold_label} MiB cold stream (cycles)"
    )
    # grid(True, alpha=0.22) : 显示网格线，alpha 控制透明度（0 为完全透明，1 为不透明）。
    ax.grid(True, alpha=0.22)
    # legend(frameon=False) : 显示图例，frameon=False 去掉图例边框，使图表更简洁。
    ax.legend(frameon=False)
    # tight_layout() : 自动调整子图参数，使图表元素（标签、标题等）不重叠，填充整个 figure 区域。
    fig.tight_layout()

    # 3. 导出 PDF 与 PNG
    # 创建 --figures 目录，图片将写入此目录。
    args.figures.mkdir(parents=True, exist_ok=True)
    # 构造图片完整路径：目录 / 输入文件名主干 + .pdf / .png
    figure_pdf = args.figures / f"{output_stem}.pdf"
    figure_png = args.figures / f"{output_stem}.png"
    # fig.savefig() : 将 Figure 保存到文件。
    # DPI（dots per inch）仅对位图格式（PNG）有效；PDF 为矢量格式，不受 DPI 影响。
    fig.savefig(figure_pdf)
    fig.savefig(figure_png, dpi=220)

    return 0


if __name__ == "__main__":
    # raise SystemExit(main()) : 将 main() 的返回值作为进程退出码抛出。
    # SystemExit 是 BaseException 的子类，被解释器捕获后转化为进程退出状态，
    # 比直接 sys.exit() 更简洁，且避免在模块被导入时意外退出。
    raise SystemExit(main())