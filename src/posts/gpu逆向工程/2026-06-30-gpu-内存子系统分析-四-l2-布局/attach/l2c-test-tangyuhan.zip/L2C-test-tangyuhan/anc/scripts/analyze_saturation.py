#!/usr/bin/env python3
"""
汇总长时间高 VRAM 压力实验（saturation run）。

输入是 saturation run 的目录或 CSV，输出为吞吐、功耗和温度相关统计与图像。

结果分析：
(1) 左图 (Bandwidth regime) 为什么先平、后骤降？
  - 低 AI（算术强度）时内核是纯内存压力测试。内存控制器、HBM/DRAM 全速运转，
    有效读写带宽接近硬件理论上限 ~790 GB/s。此时带宽是真实的物理带宽。
  - 进入 Compute-bound 后，内核执行时间被大量 FMA 运算占据，内存子系统出现大量空闲周期。
(2) 右图 (Compute regime) 为什么先斜升、后平台？
  - 当 AI 很低时，每搬运 1 byte 数据只做极少运算，SM 大部分时间花在等数据上。
    此时性能由显存带宽决定。
  - 当 AI 继续增大，内存子系统已无法继续喂饱 SM，FMA 单元成为瓶颈。
    此时性能被峰值算力封顶。
"""

from __future__ import annotations

import argparse
import csv
import io
import pathlib
import subprocess
import statistics

import matplotlib.pyplot as plt


def read_csv(path: pathlib.Path) -> list[dict[str, str]]:
    """读取普通或压缩 CSV 文件为字典列表。

    Args:
        path: 输入 CSV 路径。`.zst` 后缀会通过 zstd 命令行工具解压后读取。

    Returns:
        CSV 行字典列表。
    """
    if path.name.endswith(".zst"):
        # subprocess.run：运行外部命令并等待其完成，返回 CompletedProcess 对象。
        # check=True 表示若命令返回非零退出码则抛出 CalledProcessError。
        # stdout=subprocess.PIPE 将子进程的标准输出捕获到返回对象的 stdout 属性中。
        completed = subprocess.run(
            ["zstd", "-dc", str(path)],
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        # io.StringIO：在内存中创建文本流对象，实现文件接口。
        # 用于将子进程输出的字符串当作文件对象传递给 csv.DictReader。
        handle = io.StringIO(completed.stdout)
        return [row for row in csv.DictReader(handle) if None not in row]
    with path.open(newline="", encoding="utf-8") as handle:
        return [row for row in csv.DictReader(handle) if None not in row]


def numeric(rows: list[dict[str, str]], key: str) -> list[float]:
    """从 CSV 行字典列表中提取指定数值列，跳过空值。

    Args:
        rows: CSV 行字典列表。
        key: 要提取的列名。

    Returns:
        float 列表。
    """
    values = []
    for row in rows:
        value = row.get(key)
        if value is None:
            continue
        value = value.strip()
        if value:
            values.append(float(value))
    return values


def main() -> int:
    """脚本的命令行入口函数。

    Returns:
        进程退出码，0 表示成功。
    """
    parser = argparse.ArgumentParser()
    # type=pathlib.Path：将命令行输入字符串自动转换为 Path 对象，支持跨平台路径语义。
    parser.add_argument("run_dir", type=pathlib.Path)
    # --processed：非图片输出目录，CSV 文件将放在此目录下，文件名与输入目录同名。
    parser.add_argument("--processed", required=True, type=pathlib.Path)
    # --figures：图片输出目录，PDF/PNG 将放在此目录下，文件名与输入目录同名。
    parser.add_argument("--figures", required=True, type=pathlib.Path)
    args = parser.parse_args()

    output_stem = "roofline_saturation"

    summaries = []
    result_paths = {}
    # 先扫描未压缩的 .csv 文件
    for result_path in sorted(args.run_dir.glob("saturation_*.csv")):
        result_paths[result_path.stem.replace("saturation_", "")] = result_path

    # 再扫描 .csv.zst；若同名 mode 已存在，setdefault 保留先找到的（未压缩版优先）
    for result_path in sorted(args.run_dir.glob("saturation_*.csv.zst")):
        mode = result_path.name.replace("saturation_", "").replace(".csv.zst", "")
        result_paths.setdefault(mode, result_path)

    for mode, result_path in sorted(result_paths.items()):
        # 重新提取 mode 名（兼容 .csv 与 .csv.zst 的命名差异）
        if result_path.name.endswith(".csv.zst"):
            mode = result_path.name.replace("saturation_", "").replace(".csv.zst", "")
        else:
            mode = result_path.stem.replace("saturation_", "")
        result_rows = read_csv(result_path)
        telemetry_path = args.run_dir / f"telemetry_{mode}.csv"
        telemetry_rows = read_csv(telemetry_path) if telemetry_path.exists() else []
        if not result_rows:
            continue
        fma_iterations = int(float(result_rows[0]["fma_iterations"]))
        if fma_iterations == 0:
            # 零算术强度时，编译器可能将 read-modify-write 内核优化为退化版本。
            # 保留在原始日志中以保证透明，但排除在 Roofline 汇总外。
            continue
        working_set_bytes = int(result_rows[0]["working_set_bytes"])
        gbps = numeric(result_rows, "effective_gb_per_s")
        tflops = numeric(result_rows, "tflop_per_s")
        if not gbps or not tflops:
            continue
        ai = 0.0
        if fma_iterations > 0:
            # 每个 float4 元素每迭代执行 4 次 FMA（8 flop），内核读+写共 32 bytes。
            ai = (8.0 * fma_iterations) / 32.0
        summary = {
            "mode": mode,
            "fma_iterations": fma_iterations,
            "arithmetic_intensity_flop_per_byte": ai,
            "working_set_gib": working_set_bytes / 2**30,
            "passes": len(result_rows),
            # statistics.median：返回数据的中位数（中间值）。
            "median_gb_per_s": statistics.median(gbps),
            "min_gb_per_s": min(gbps),
            "max_gb_per_s": max(gbps),
            "median_tflop_per_s": statistics.median(tflops),
            "min_tflop_per_s": min(tflops),
            "max_tflop_per_s": max(tflops),
        }
        if telemetry_rows:
            for key, out_key in [
                ("gpu_util_percent", "median_gpu_util_percent"),
                ("memory_util_percent", "median_memory_util_percent"),
                ("memory_used_mib", "max_memory_used_mib"),
                ("power_w", "median_power_w"),
                ("temperature_c", "max_temperature_c"),
                ("sm_clock_mhz", "median_sm_clock_mhz"),
                ("memory_clock_mhz", "median_memory_clock_mhz"),
            ]:
                vals = numeric(telemetry_rows, key)
                if not vals:
                    continue
                summary[out_key] = max(vals) if out_key.startswith("max_") else statistics.median(vals)
        summaries.append(summary)

    summaries.sort(key=lambda row: row["fma_iterations"])

    # 创建 --processed 目录，CSV 将写入此目录。
    # pathlib.Path.mkdir：递归创建目录（parents=True），若目录已存在不报错（exist_ok=True）。
    args.processed.mkdir(parents=True, exist_ok=True)
    # 构造 CSV 完整路径：目录 / 输入目录名主干 + .csv
    csv_path = args.processed / f"{output_stem}.csv"
    fieldnames = sorted({key for row in summaries for key in row})
    # 将人眼最关心的列排在前面
    preferred = [
        "mode",
        "fma_iterations",
        "arithmetic_intensity_flop_per_byte",
        "working_set_gib",
        "passes",
        "median_gb_per_s",
        "median_tflop_per_s",
        "median_gpu_util_percent",
        "median_memory_util_percent",
        "max_memory_used_mib",
        "median_power_w",
        "max_temperature_c",
        "median_sm_clock_mhz",
        "median_memory_clock_mhz",
    ]
    fieldnames = preferred + [key for key in fieldnames if key not in preferred]
    # csv.DictWriter：以字典形式写入 CSV，fieldnames 指定列顺序。
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summaries)

    # 绘制 Roofline 风格双图
    if summaries:
        # plt.subplots：创建 Figure 和一组子图。
        # nrows=1, ncols=2 表示 1 行 2 列；figsize 指定宽高（英寸）。
        fig, (ax_bw, ax_flop) = plt.subplots(1, 2, figsize=(10.2, 3.6))
        x = [row["arithmetic_intensity_flop_per_byte"] for row in summaries]
        # 对数坐标下 0 无法显示，故将零强度点左移至 0.125，保证可视化。
        plot_x = [value if value > 0 else 0.125 for value in x]
        labels = [str(row["fma_iterations"]) for row in summaries]  # 用 fma_iterations 标注每个点
        bw_y = [row["median_gb_per_s"] for row in summaries]
        flop_y = [row["median_tflop_per_s"] for row in summaries]
        # semilogx：X 轴为对数刻度的 plot 封装，其余参数与 plot 相同。
        ax_bw.semilogx(
            plot_x,
            bw_y,
            marker="o",
            linewidth=1.4,
        )
        ax_flop.semilogx(
            plot_x,
            flop_y,
            marker="o",
            linewidth=1.4,
            color="tab:red",
        )
        for axis in (ax_bw, ax_flop):
            axis.grid(True, alpha=0.24)
            axis.set_xlabel("Arithmetic intensity (flop/byte)")
            ydata = axis.lines[0].get_ydata()
            for px, py, label in zip(plot_x, ydata, labels):
                # annotate：在坐标 (px, py) 处添加文本 label。
                # textcoords="offset points" 表示 xytext 以点（1/72 英寸）为偏移单位。
                # xytext=(3, 3) 将文本向右上方偏移 3 点。
                axis.annotate(label, (px, py),
                              textcoords="offset points", xytext=(3, 3), fontsize=7)
        ax_bw.set_ylabel("Effective read+write bandwidth (GB/s)")
        ax_bw.set_title("(a) Bandwidth regime")
        ax_flop.set_ylabel("Throughput (TFLOP/s)")
        ax_flop.set_title("(b) Compute regime")
        # tight_layout：自动调整子图间的间距和边距，防止标签、标题重叠。
        fig.tight_layout()

        # 创建 --figures 目录，图片将写入此目录。
        args.figures.mkdir(parents=True, exist_ok=True)
        # 构造图片完整路径：目录 / 输入目录名主干 + .pdf / .png
        figure_pdf = args.figures / f"{output_stem}.pdf"
        figure_png = args.figures / f"{output_stem}.png"
        fig.savefig(figure_pdf)
        fig.savefig(figure_png, dpi=220)
    return 0


if __name__ == "__main__":
    # raise SystemExit(main())：以 main() 的返回值作为进程退出码，0 表示正常退出。
    raise SystemExit(main())