#!/usr/bin/env python3
"""比较不同 GPU 架构上的 per-SM L2 延迟拓扑。

输入是 Ada L40 与 Blackwell RTX 5090 的拓扑和指纹 CSV，输出为跨设备统计 JSON 与图像。该脚本检验 L40 训练出的 SM 定位 oracle 是否能迁移到另一架构。"""

from __future__ import annotations

import argparse
import csv
import io
import json
import pathlib
import subprocess
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt
import joblib
from sklearn.ensemble import RandomForestClassifier


def read_any(path: pathlib.Path):
    """Reads a plain CSV or `.zst` compressed CSV into row dictionaries.
    
    Args:
        path: 输入数据路径，允许普通 CSV 或 zstd 压缩 CSV。
    
    Returns:
        CSV 行字典列表，字段生命周期由调用者持有。"""
    if path.suffix == ".zst":
        raw = subprocess.run(["zstd", "-dc", str(path)], check=True,
                             stdout=subprocess.PIPE).stdout
        return list(csv.DictReader(io.StringIO(raw.decode())))
    with path.open() as f:
        return list(csv.DictReader(f))


def slice_matrix(rows):
    """Builds an SM-by-probe latency matrix from topology rows.
    
    Args:
        rows: `l2_topology` 输出的 CSV 行。
    
    Returns:
        包含平均延迟的 NumPy 矩阵。"""
    acc = defaultdict(list)
    for d in rows:
        acc[(int(d["smid"]), int(d["probe_id"]))].append(float(d["cycles_per_access"]))
    n_sm = max(k[0] for k in acc) + 1
    n_off = max(k[1] for k in acc) + 1
    M = np.zeros((n_sm, n_off))
    for (s, o), v in acc.items():
        M[s, o] = np.mean(v)
    return M


def topo_stats(M, ghz):
    """Computes topology summary statistics from a latency matrix.
    
    Args:
        M: 行为 SM、列为 probe 的延迟矩阵。
        ghz: GPU 核心频率，单位为 GHz。
    
    Returns:
        可写入 JSON 的统计字典。"""
    n = M.shape[0]
    mu = M.mean()
    a = M.mean(1) - mu
    b = M.mean(0) - mu
    fit = mu + a[:, None] + b[None, :]
    r2 = 1 - ((M - fit) ** 2).sum() / ((M - mu) ** 2).sum()
    best = (n // 2, -1.0)
    for sp in range(n // 2 - 15, n // 2 + 15):
        x, y = a[:sp], a[sp:]
        m = min(len(x), len(y))
        rr = float(np.corrcoef(x[:m], y[:m])[0, 1])
        if rr > best[1]:
            best = (sp, rr)
    b0 = b - b.mean()
    ac = np.correlate(b0, b0, "full")[len(b0) - 1:]
    ac /= ac[0]
    period = next((k for k in range(2, 40)
                   if ac[k] > 0.45 and ac[k] >= ac[k - 1] and ac[k] >= ac[k + 1]), None)
    return {
        "n_sm": int(n),
        "clock_ghz": ghz,
        "lat_cyc_min": float(M.min()), "lat_cyc_max": float(M.max()),
        "spread_pct": float(100 * (M.max() - M.min()) / M.min()),
        "lat_ns_min": float(M.min() / ghz), "lat_ns_max": float(M.max() / ghz),
        "per_sm_spread_pct": float(100 * (M.mean(1).max() - M.mean(1).min()) / M.mean(1).min()),
        "additive_r2": float(r2),
        "sm_term_cyc": float(a.max() - a.min()),
        "slice_term_cyc": float(b.max() - b.min()),
        "twofold_split": int(best[0]), "twofold_r": float(best[1]),
        "slice_interleave_bytes": (int(period) * 128 if period else None),
    }, M.mean(1)


def read_fp(path: pathlib.Path):
    """Reads fingerprint CSV rows into feature, label, and shot arrays.
    
    Args:
        path: fingerprint CSV 或压缩 CSV 路径。
    
    Returns:
        特征矩阵、标签向量和 shot 标识，供分类器训练或评估。"""
    raw = subprocess.run(["zstd", "-dc", str(path)], check=True,
                         stdout=subprocess.PIPE).stdout
    h = raw.split(b"\n", 1)[0].decode().split(",")
    lat = [i for i, c in enumerate(h) if c.startswith("lat_")]
    smi = h.index("smid")
    sh = h.index("shot")
    arr = np.loadtxt(io.BytesIO(raw), delimiter=",", skiprows=1)
    return arr[:, lat].astype(np.float32), arr[:, smi].astype(int), arr[:, sh].astype(int)


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    p = argparse.ArgumentParser()
    p.add_argument("--l40-sweep", required=True, type=pathlib.Path)
    p.add_argument("--rtx-sweep", required=True, type=pathlib.Path)
    p.add_argument("--rtx-fp", required=True, type=pathlib.Path)
    p.add_argument("--l40-model", required=True, type=pathlib.Path)
    p.add_argument("--figures", required=True, type=pathlib.Path)
    p.add_argument("--processed", required=True, type=pathlib.Path)
    args = p.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    args.processed.mkdir(parents=True, exist_ok=True)

    ML = slice_matrix(read_any(args.l40_sweep))
    M5 = slice_matrix(read_any(args.rtx_sweep))
    sL, avgL = topo_stats(ML, 2.49)
    s5, avg5 = topo_stats(M5, 2.407)

    # Oracle transfer test.
    X5, y5, shot5 = read_fp(args.rtx_fp)
    clf_l40 = joblib.load(args.l40_model)
    transfer_acc = float((clf_l40.predict(X5) == y5).mean())
    shots = np.unique(shot5)
    rng = np.random.default_rng(0)
    rng.shuffle(shots)
    tr_sh = set(shots[:int(len(shots) * 0.7)].tolist())
    tr = np.array([s in tr_sh for s in shot5])
    clf5 = RandomForestClassifier(n_estimators=160, n_jobs=-1,
                                  random_state=0).fit(X5[tr], y5[tr])
    native_acc = float((clf5.predict(X5[~tr]) == y5[~tr]).mean())

    out = {
        "L40_Ada_AD102": sL,
        "RTX5090_Blackwell_GB202": s5,
        "oracle_transfer": {
            "l40_model_on_rtx5090_exact_acc": transfer_acc,
            "rtx5090_native_exact_acc": native_acc,
            "rtx5090_chance": 1.0 / s5["n_sm"],
            "rtx5090_n_classes": s5["n_sm"],
        },
    }
    (args.processed / "cross_device_stats.json").write_text(
        json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(out, indent=2))

    # Figure: per-SM latency by SM id, and the per-SM spectra in ns.
    fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(10.2, 3.7))
    ax0.plot(np.arange(len(avgL)) / len(avgL), avgL / 2.49, lw=1.0,
             color="tab:blue", label=f"L40 (Ada, {len(avgL)} SMs)")
    ax0.plot(np.arange(len(avg5)) / len(avg5), avg5 / 2.407, lw=1.0,
             color="tab:red", label=f"RTX 5090 (Blackwell, {len(avg5)} SMs)")
    ax0.set_xlabel("Physical SM (normalized index)")
    ax0.set_ylabel("Mean L2-hit latency (ns)")
    ax0.set_title("(a) Per-SM L2 latency, two architectures")
    ax0.grid(True, alpha=0.24)
    ax0.legend(fontsize=7.5)
    ax1.hist(avgL / 2.49, bins=30, color="tab:blue", alpha=0.6, label="L40 (Ada)")
    ax1.hist(avg5 / 2.407, bins=30, color="tab:red", alpha=0.6, label="RTX 5090")
    ax1.set_xlabel("Mean L2-hit latency per SM (ns)")
    ax1.set_ylabel("Number of SMs")
    ax1.set_title("(b) Per-SM latency spectra")
    ax1.grid(True, alpha=0.24)
    ax1.legend(fontsize=7.5)
    fig.tight_layout()
    fig.savefig(args.figures / "cross_device.pdf")
    fig.savefig(args.figures / "cross_device.png", dpi=220)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
