#!/usr/bin/env python3
"""训练并评估 SM-placement oracle。

数据来源与物理含义：
X（特征）: CSV 中 lat_0 ~ lat_N-1 列。每行是一个 SM 的 N 维 L2 延迟指纹
         （cycles per access），不同 SM 到 L2 slice 的 NoC 路径长度不同，
         导致延迟具有 SM 特异性。
y（标签）: CSV 中 smid 列。物理 SM 硬件编号 (0~M-1)，由 CUDA 内联汇编
         `mov.u32 %0, %%smid;` 读取。共 M 类。
shot（切分）: CSV 中 shot 列，标识 kernel 启动批次。按 shot 切分（70% 训练，
            30% 测试）防止同次测量的所有 SM 样本同时泄漏到两边。

目标: 学习映射 f: R^N → {0,...,M-1}，从延迟指纹推断物理 SM 位置。

输入为带标签的指纹数据（fingerprint shots），输出包括：
- joblib 模型文件
- 元数据 JSON
- 评估结果 JSON
- 可视化图像
- 离线演示样本

采用按 shot 切分训练/测试集，防止数据泄漏。
"""

from __future__ import annotations
# 启用 PEP 563 推迟注解求值，允许在类型提示中使用尚未定义的前向引用。

import argparse
import io
import json
import pathlib
import subprocess

import numpy as np
import matplotlib.pyplot as plt
import joblib
from sklearn.ensemble import RandomForestClassifier

# 聚类分界：SM 分为两半，0 ~ CLUSTER_SPLIT-1 与 CLUSTER_SPLIT ~ N_SM-1
# RTX 5080 共 84 个 SM，对称拓扑取半分点 42
CLUSTER_SPLIT = 42
# SM 总数由 CLUSTER_SPLIT 自动推导（假设对称拓扑，总数 = 2 × 半分点）
N_SM = 2 * CLUSTER_SPLIT


def read_csv(path: pathlib.Path):
    """读取 CSV 指纹文件，返回特征、标签和 shot 标识。"""
    # 先读表头，定位关键列
    with path.open(encoding="utf-8") as f:
        header = f.readline().strip().split(",")
    
    # 延迟特征列：lat_0, lat_1, ..., lat_31
    lat_cols = [i for i, c in enumerate(header) if c.startswith("lat_")]
    smid_col = header.index("smid")      # 物理 SM ID（标签）
    shot_col = header.index("shot")      # 测量批次标识（用于分组）
    
    # np.loadtxt 从文本文件加载数据，skiprows=1 跳过表头行，delimiter 指定分隔符。
    arr = np.loadtxt(path, delimiter=",", skiprows=1)
    X = arr[:, lat_cols].astype(np.float32)   # 指纹特征矩阵
    y = arr[:, smid_col].astype(np.int32)     # 标签向量
    shot = arr[:, shot_col].astype(np.int32)  # shot 分组标识
    return X, y, shot


def split_by_shot(shot, frac=0.7, seed=0):
    """按 shot 切分训练/测试集，避免同次测量泄漏到两边。
    
    Args:
        shot: 每条样本的 shot 编号。
        frac: 训练集 shot 占比。
        seed: 随机种子。
    
    Returns:
        (train_mask, test_mask): 布尔数组，可直接用于数组索引。
    """
    # np.unique 返回数组中去重后的元素，并保持出现顺序。
    shots = np.unique(shot)                # shot ID 去重
    # np.random.default_rng 创建独立的随机数生成器对象（Generator），
    # 提供现代化的随机数接口，比旧版 np.random 更可控。
    rng = np.random.default_rng(seed)      # 独立的随机数生成器对象
    # shuffle 原地打乱数组顺序。
    rng.shuffle(shots)                     # 随机打乱 shot 顺序
    
    n_train = int(len(shots) * frac)
    train_shots = set(shots[:n_train].tolist())
    
    # 逐条样本判断其 shot 是否属于训练集
    train_mask = np.array([s in train_shots for s in shot])
    # ~ 对布尔数组取反，得到测试集掩码。
    return train_mask, ~train_mask         # 训练集掩码和测试集掩码


def top_k_accuracy(model, X, y, k):
    """计算 top-k 分类准确率。
    
    若真实标签落在模型预测概率最高的 k 个类别中，即算命中。
    """
    # predict_proba 返回每个样本属于每个类别的概率矩阵，形状为 (n_samples, n_classes)。
    proba = model.predict_proba(X)           # 输出每个样本属于每个类别的概率 (n_samples, n_classes)
    # classes_ 属性存储模型在训练时见到的所有类别标签。
    classes = model.classes_                 # 类别标签列表
    # np.argsort 返回将数组升序排列后的索引序列；[:, -k:] 取每行概率最高的 k 个索引。
    topk = np.argsort(proba, axis=1)[:, -k:] # 每行概率最高的 k 个索引
    
    hit = np.array([y[i] in classes[topk[i]] for i in range(len(y))])
    # hit.mean() 计算布尔数组的均值，True 计为 1，False 计为 0，即准确率。
    return float(hit.mean())


def evaluate_for_A(X, y, shot, n_estimators=160, seed=0):
    """针对单一 averaging factor A 训练并评估 oracle。
    
    Args:
        X: 指纹特征矩阵 (n_samples, n_probes)。
        y: 物理 SM 标签。
        shot: shot 标识，用于无泄漏切分。
        n_estimators: RandomForest 树数量。
        seed: 随机种子。
    
    Returns:
        (metrics_dict, trained_clf, test_sample_tuple)
    """
    # 按 shot 切分，确保训练/测试无泄漏
    tr, te = split_by_shot(shot, seed=seed)
    
    # 训练随机森林
    # RandomForestClassifier：scikit-learn 实现的随机森林分类器。
    # n_estimators 指定森林中决策树的数量；n_jobs=-1 使用全部 CPU 核心并行训练；
    # random_state 固定随机种子以保证结果可复现。
    clf = RandomForestClassifier(
        n_estimators=n_estimators, 
        n_jobs=-1,          # 使用全部 CPU 核心
        random_state=seed
    )
    # fit(X, y)：从训练数据中学习分类规则，构建随机森林。
    clf.fit(X[tr], y[tr])   # 从训练集 (X, y) 中构建一个随机森林
    
    # N_SM-way 精确匹配准确率：计算模型精确预测到具体 SM 编号的准确率
    # predict(X)：对输入样本进行类别预测，返回预测标签数组。
    pred = clf.predict(X[te])
    # (pred == y[te]) 返回布尔数组，.mean() 计算 True 的比例即准确率。
    exact = float((pred == y[te]).mean())
    
    # 2-way 聚类准确率（SM 两半分组）：评估模型是否至少能判断样本属于哪一半 SM 组
    # astype(int) 将布尔数组转换为 0/1 整型数组。
    cluster_pred = (pred >= CLUSTER_SPLIT).astype(int)
    cluster_true = (y[te] >= CLUSTER_SPLIT).astype(int)
    cluster = float((cluster_pred == cluster_true).mean())
    
    # top-5 准确率
    top5 = top_k_accuracy(clf, X[te], y[te], 5)
    
    # 最近质心基线：验证 RF 是否学到超越简单平均延迟的判别信息。
    # 最近质心基线不是训练出来的，它代表了最简单、最粗糙的判别策略。
    # cents：对每个训练类别，计算其所有样本在特征空间中的均值向量（质心）。形状为 
    # (n_classes, n_probes)。
    train_classes = np.unique(y[tr])  # SM 类别（去重）
    # np.stack 沿新轴连接数组序列，将各 SM 的质心向量堆叠为二维矩阵。
    cents = np.stack([X[tr][y[tr] == c].mean(0) for c in train_classes])
    # 计算每个测试样本到每个训练类别质心的平方欧氏距离。
    # X[te][:, None, :] 扩展维度以便广播，(None, -) 等价于 (np.newaxis, -)。
    dist = ((X[te][:, None, :] - cents[None]) ** 2).sum(-1)
    # argmin(1) 沿列方向（每个样本到各类别距离）取最小值索引，即最近质心。
    nc_pred = train_classes[dist.argmin(1)]         # 对每个测试样本，选择距离最近质心所属的 SM 类别
    nc_exact = float((nc_pred == y[te]).mean())     # 该"模板匹配"方法的准确率
    
    metrics = {
        "exact_acc": exact,
        "cluster_acc": cluster,
        "top5_acc": top5,
        "centroid_exact_acc": nc_exact,
        "n_train": int(tr.sum()),
        "n_test": int(te.sum()),
    }
    return metrics, clf, (X[te], y[te])


def accuracy_vs_probes(X, y, shot, probe_counts, seed=0):
    """评估不同 probe 数量下的 oracle 准确率。
    
    逐次只取前 k 个 probe 特征，观察准确率随 probe 数的变化趋势。
    """
    tr, te = split_by_shot(shot, seed=seed)
    out = []
    for k in probe_counts:
        clf = RandomForestClassifier(
            n_estimators=80, n_jobs=-1, random_state=seed
        )
        clf.fit(X[tr, :k], y[tr])          # 仅使用前 k 列特征
        pred = clf.predict(X[te, :k])

        # N_SM-way 精确匹配准确率：计算模型精确预测到具体 SM 编号的准确率
        exact = float((pred == y[te]).mean())

        # 2-way 聚类准确率（SM 两半分组）：评估模型是否至少能判断样本属于哪一半 SM 组
        cluster = float(((pred >= CLUSTER_SPLIT) == (y[te] >= CLUSTER_SPLIT)).mean())

        out.append({"probes": int(k), "exact_acc": exact, "cluster_acc": cluster})
    return out


def main() -> int:
    """命令行入口。"""
    # 创建命令行参数解析器。
    # ArgumentParser 对象包含将命令行解析成 Python 数据类型所需的全部信息，
    # 并自动生成帮助手册与错误提示。
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=pathlib.Path, help="指纹 CSV 所在目录")
    parser.add_argument("--models", required=True, type=pathlib.Path, help="模型输出目录")
    parser.add_argument("--figures", required=True, type=pathlib.Path, help="图像输出目录")
    parser.add_argument("--processed", required=True, type=pathlib.Path, help="评估结果输出目录")
    args = parser.parse_args()
    
    # 确保输出目录存在；mkdir(parents=True, exist_ok=True) 递归创建目录，
    # 若目录已存在则不抛出异常。
    for d in (args.models, args.figures, args.processed):
        d.mkdir(parents=True, exist_ok=True)
    
    # 加载所有 topology_fp_a*.csv 文件；glob 返回匹配给定模式的路径生成器，sorted 排序。
    a_files = sorted(args.run_dir.glob("topology_fp_a*.csv"))
    by_A = {}
    for path in a_files:
        # 从文件名提取 A 值，如 topology_fp_a256.csv -> 256
        a = int(path.stem.replace("topology_fp_a", "").replace(".csv", ""))
        by_A[a] = read_csv(path)
    
    # 初始化评估结果结构；n_classes 随 N_SM 自动变化
    eval_out = {
        "n_classes": N_SM,
        "cluster_split_smid": CLUSTER_SPLIT,
        "per_A": [],
        "vs_probes_A": max(by_A),           # 用最大 A 做 probe 数量实验
        "vs_probes": [],
    }
    
    # 选择最大 A 的模型作为最终发布版本（信噪比最高）
    published_A = max(by_A)
    published_clf = None
    published_sample = None
    
    # 遍历每个 A 值，独立训练并评估
    for a in sorted(by_A):
        X, y, shot = by_A[a]
        metrics, clf, sample = evaluate_for_A(X, y, shot)
        metrics["A_loads"] = a
        metrics["n_probes"] = X.shape[1]
        eval_out["per_A"].append(metrics)
        
        print(f"A={a:4d}  exact={metrics['exact_acc']:.3f}  "
              f"cluster={metrics['cluster_acc']:.3f}  "
              f"top5={metrics['top5_acc']:.3f}  "
              f"(centroid exact={metrics['centroid_exact_acc']:.3f})")
        
        if a == published_A:
            published_clf = clf
            published_sample = sample
    
    # 在最大 A 下，评估不同 probe 数量的影响
    X, y, shot = by_A[published_A]
    probe_counts = [1, 2, 4, 8, 16, 32]
    # probe_counts = [1, 2, 4, 8, 16, 32, 64, 128, 256]
    eval_out["vs_probes"] = accuracy_vs_probes(X, y, shot, probe_counts)
    
    for r in eval_out["vs_probes"]:
        print(f"probes={r['probes']:2d}  exact={r['exact_acc']:.3f}  "
              f"cluster={r['cluster_acc']:.3f}")
    
    # json.dumps 将 Python 对象序列化为 JSON 格式字符串；indent=2 启用美观缩进。
    # write_text 将字符串写入文件；with_suffix(".json") 替换或追加 .json 后缀。
    (args.processed / "oracle_eval.json").write_text(
        json.dumps(eval_out, indent=2) + "\n", encoding="utf-8"
    )
    
    # joblib.dump 将 Python 对象持久化到文件；compress=3 使用 zlib 压缩级别 3，
    # 在速度与磁盘空间之间取得平衡。
    joblib.dump(published_clf, args.models / "sm_oracle.joblib", compress=3)
    
    # 保存模型元数据，所有 SM 数量相关字段均随 N_SM 自动变化
    n_probes = int(by_A[published_A][0].shape[1])
    meta = {
        "task": f"Predict the physical SM (0..{N_SM-1}) of an NVIDIA RTX5080 from a {n_probes}-probe "
                "L2-hit latency fingerprint (cycles per access).",
        "model": "sklearn RandomForestClassifier",
        "trained_on_A_loads": published_A,
        "n_probes": n_probes,
        "probe_offsets_bytes": [256 * i for i in range(n_probes)],
        "feature_units": "cycles per dependent ld.global.cg load",
        "device_clock_ghz": 2.49,
        "labels": "physical SM identifier from %smid",
        "cluster_split_smid": CLUSTER_SPLIT,
        "usage": f"joblib.load('sm_oracle.joblib').predict(fingerprint[:, :{n_probes}])",
    }
    (args.models / "sm_oracle_meta.json").write_text(
        json.dumps(meta, indent=2) + "\n", encoding="utf-8"
    )
    
    # 抽取部分测试样本作为离线演示数据（无需 GPU 即可验证）
    Xs, ys = published_sample
    # rng.choice 从给定数组中随机抽取指定数量的不重复元素。
    idx = np.random.default_rng(0).choice(
        len(ys), size=min(256, len(ys)), replace=False
    )
    # np.savez_compressed 将多个数组保存为压缩的 .npz 文件，减小磁盘占用。
    np.savez_compressed(
        args.models / "sample_fingerprints.npz", X=Xs[idx], y=ys[idx]
    )
    
    # 绘制双图：左图 accuracy vs A，右图 accuracy vs probe count
    # plt.subplots 创建 Figure 和一组子图，返回 (fig, axes) 元组。
    fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(10.2, 3.7))
    
    # 左图：不同 A 下的准确率
    As = [m["A_loads"] for m in eval_out["per_A"]]
    # ax.plot 绘制折线图；"o-" 表示带圆点标记的实线。
    ax0.plot(As, [m["exact_acc"] for m in eval_out["per_A"]], "o-",
             label=f"exact SM ({N_SM}-way)")
    ax0.plot(As, [m["top5_acc"] for m in eval_out["per_A"]], "s--",
             label="top-5 SM")
    ax0.plot(As, [m["cluster_acc"] for m in eval_out["per_A"]], "^-",
             label="cluster (2-way)")
    # ax.axhline 绘制水平参考线；ls 指定线型，lw 指定线宽。
    ax0.axhline(1 / N_SM, color="red", ls="--", lw=1.0, label="random baseline (exact SM)")
    ax0.set_xlabel("Probe length $A$ (loads per probe)")
    ax0.set_ylabel("Test accuracy")
    ax0.set_title("(a) Placement accuracy vs probe cost")
    # set_xscale("log", base=2) 将 X 轴设为以 2 为底的对数刻度。
    ax0.set_xscale("log", base=2)
    ax0.set_ylim(0, 1.02)
    ax0.grid(True, alpha=0.24)
    ax0.legend(fontsize=7.5, loc="center right")
    
    # 右图：不同 probe 数量下的准确率
    ks = [r["probes"] for r in eval_out["vs_probes"]]
    ax1.plot(ks, [r["exact_acc"] for r in eval_out["vs_probes"]], "o-",
             label="exact SM")
    ax1.plot(ks, [r["cluster_acc"] for r in eval_out["vs_probes"]], "^-",
             label="cluster (2-way)")
    ax1.set_xlabel("Number of probes in fingerprint")
    ax1.set_ylabel("Test accuracy")
    ax1.set_title(f"(b) Accuracy vs probe count (A={published_A})")
    ax1.set_xscale("log", base=2)
    ax1.set_ylim(0, 1.02)
    ax1.grid(True, alpha=0.24)
    ax1.legend(fontsize=7.5, loc="lower right")
    
    # fig.tight_layout 自动调整子图参数，使布局紧凑、标签不重叠。
    fig.tight_layout()
    # fig.savefig 将 Figure 保存为图像文件；dpi=220 指定分辨率。
    fig.savefig(args.figures / "oracle_accuracy.pdf")
    fig.savefig(args.figures / "oracle_accuracy.png", dpi=220)
    
    print("saved model:", (args.models / "sm_oracle.joblib").stat().st_size, "bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())