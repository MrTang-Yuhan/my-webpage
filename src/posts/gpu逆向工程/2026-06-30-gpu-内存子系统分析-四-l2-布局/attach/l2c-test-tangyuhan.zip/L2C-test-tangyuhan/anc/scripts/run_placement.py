#!/usr/bin/env python3
"""运行带 manifest 的 NUCA-aware placement campaign。

输入是配置文件和设备号，输出为 placement CSV 与可复现 manifest。该脚本把拓扑延迟模型喂给调度微基准，比较静态感知调度与动态队列。"""

# PEP 563: 推迟注解求值（Postponed Evaluation of Annotations）。
# 根据 Python 官方文档，from __future__ import annotations 使所有注解在运行时以字符串形式存储，
# 而非立即求值。这允许在类定义内部引用自身类型（前向引用），且显著提升模块导入速度。
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pathlib
import platform
import shlex
import subprocess
import sys
from typing import Any

# Path(__file__) 获取当前脚本路径；resolve() 将其解析为绝对路径并消除符号链接和 ".." 组件；
# parents[1] 取父目录的父目录（即仓库根目录）。
# 例如：src/scripts/run_placement.py → resolve() → .../src/scripts/run_placement.py → parents[1] → .../
ROOT = pathlib.Path(__file__).resolve().parents[1]


def run(cmd, capture=True):
    """在仓库根目录下运行子进程，并可选择捕获输出。

    Args:
        cmd: 命令和参数列表（字符串序列）。
        capture: 为 True 时捕获 stdout/stderr，便于写入 manifest；
                 为 False 时直接输出到终端。

    Returns:
        subprocess.CompletedProcess 对象。
        若 check=True 且进程返回非零退出码，则抛出 subprocess.CalledProcessError。
    """
    # subprocess.run : Python 标准库中运行外部命令的推荐接口（Python 3.5+）。
    #   cwd=ROOT : 设置子进程工作目录为仓库根目录，确保相对路径解析正确。
    #   check=True : 进程返回非零退出码时自动抛出 CalledProcessError，避免静默忽略错误。
    #   text=True : 以文本模式处理 I/O，stdout/stderr 返回 str 而非 bytes。
    #   stdout=subprocess.PIPE : 将标准输出重定向到管道，使输出可被捕获。
    #   stderr=subprocess.PIPE : 将标准错误重定向到管道。
    # 根据 Python 官方文档，PIPE 是一个特殊值，表示为子进程创建新的管道。
    return subprocess.run(cmd, cwd=ROOT, check=True, text=True,
                          stdout=subprocess.PIPE if capture else None,
                          stderr=subprocess.PIPE if capture else None)


def sha256_file(path: pathlib.Path) -> str:
    """以流式方式计算文件的 SHA-256 摘要。

    Args:
        path: 要纳入 manifest 的文件路径。

    Returns:
        十六进制 digest 字符串（64 个字符）。
    """
    h = hashlib.sha256()
    # 以二进制模式打开文件，"rb" 表示 read binary。
    with path.open("rb") as fh:
        # iter(callable, sentinel) : 创建一个迭代器，反复调用 callable 直到其返回值等于 sentinel。
        # 根据 Python 官方文档，这是读取大文件的内存高效惯用法：
        #   lambda: fh.read(1 << 20) 每次读取 1 MiB（1 << 20 = 1048576 字节）；
        #   b"" 作为哨兵值，当 read() 到达 EOF 时返回空字节串，迭代终止。
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def cmd_out(cmd):
    """运行命令并将 stdout/stderr 存入可序列化的字典，用于 manifest。

    Args:
        cmd: 命令和参数列表。

    Returns:
        包含 command、stdout、stderr 键的字典；若命令失败则包含 error 键。
    """
    try:
        c = run(cmd)
        return {"command": cmd, "stdout": c.stdout, "stderr": c.stderr}
    # FileNotFoundError : 命令可执行文件不存在时抛出（如 nvidia-smi 未安装）。
    # subprocess.CalledProcessError : 进程返回非零退出码时抛出（因 run() 设置了 check=True）。
    except (FileNotFoundError, subprocess.CalledProcessError) as e:
        return {"command": cmd, "error": repr(e)}


def main() -> int:
    """脚本的命令行入口函数。

    Returns:
        进程退出码，0 表示成功。
    """
    # argparse.ArgumentParser : Python 标准库命令行参数解析器。
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, type=pathlib.Path)
    ap.add_argument("--device", default=0, type=int)
    args = ap.parse_args()
    # Path.resolve() : 将路径解析为绝对路径，消除符号链接和 ".." 组件。
    # 确保配置路径是绝对路径，避免后续相对路径解析出错。
    args.config = args.config.resolve()
    # json.loads : 将 JSON 字符串反序列化为 Python 对象（此处为 dict）。
    cfg = json.loads(args.config.read_text())
    # datetime.now(timezone.utc) : 获取当前 UTC 时区的感知时间（aware datetime）。
    # 根据 Python 官方文档，timezone.utc 是 UTC 时区的单例，避免使用已弃用的 datetime.utcnow()。
    # strftime("%Y%m%dT%H%M%SZ") : 格式化为 ISO 8601 基本格式的时间戳字符串，
    # 例如 "20250731T110105Z"。末尾的 "Z" 表示零时区偏移（Zulu time）。
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    # run_id : 由 campaign 名称和时间戳拼接而成，作为本次实验的唯一标识。
    run_id = f"{cfg['campaign']}_{ts}"
    # Path 的 / 运算符 : 根据 Python 官方文档，Path 对象支持 / 运算符拼接路径，
    # 自动处理不同操作系统的路径分隔符，是 os.path.join() 的面向对象替代。
    run_dir = ROOT / "results" / "raw" / run_id
    # mkdir(parents=True, exist_ok=False) : 递归创建目录。
    # parents=True 按需创建所有缺失的父目录（类似 mkdir -p）；
    # exist_ok=False 表示若目录已存在则抛出 FileExistsError，防止意外覆盖已有实验结果。
    run_dir.mkdir(parents=True, exist_ok=False)

    # 运行 device_info 可执行文件，获取 GPU 设备信息并保存为 JSON。
    di = run([str(ROOT / "build" / "device_info")]).stdout
    (run_dir / "device_info.json").write_text(di, encoding="utf-8")

    # Manifest 固化配置、源码 hash、环境和命令行，保证 raw 结果可追溯。
    # dict[str, Any] : 键为字符串、值类型无约束的字典。Any 来自 typing 模块，
    # 表示该变量可以是任何类型，常用于 manifest 这类结构灵活的数据。
    manifest: dict[str, Any] = {
        "schema_version": 1, "run_id": run_id, "started_utc": ts, "config": cfg,
        "platform": platform.platform(), "python": sys.version,
        "source_sha256": {
            "src/placement_sched.cu": sha256_file(ROOT / "src" / "placement_sched.cu"),
            args.config.name: sha256_file(args.config),
        },
        "nvidia_smi": cmd_out(["nvidia-smi", "-q"]),
        "runs": [], "outputs": {},
    }
    # platform.platform() : 返回底层平台的标识字符串，如 "Linux-5.15.0-x86_64-with-glibc2.35"。
    # 根据 Python 官方文档，它整合了操作系统名称、版本、架构等信息，用于环境记录。
    # sys.version : 包含 Python 解释器版本号及构建信息的字符串，如 "3.11.0 (main, ...)"。

    # 遍历配置文件中的每个运行配置（run config）。
    for rc in cfg["runs"]:
        binary = str(ROOT / "build" / "placement_sched")
        lat = rc.get("lat_csv", "none")
        cmd = [binary, str(rc["region_words"]), str(rc["threads_per_block"]),
               rc["chain_kind"], str(rc["base_work"]), str(rc["reps"]),
               str(rc["seed"]), lat, str(args.device)]
        # shlex.join : 将命令列表安全地拼接为可打印的字符串。
        # 根据 Python 官方文档，它正确处理引号和转义，生成的字符串可直接复制到 shell 执行。
        # 此处仅用于日志打印，便于用户复现命令。
        print("+", shlex.join(cmd), flush=True)
        # nvidia-smi --query-gpu=... : 在运行前后分别采样 GPU 遥测数据，
        # 包括时间戳、SM 时钟频率、温度、功耗、显存使用率和 GPU 利用率。
        before = cmd_out(["nvidia-smi", "--query-gpu=timestamp,clocks.sm,"
                          "temperature.gpu,power.draw,memory.used,utilization.gpu",
                          "--format=csv,noheader,nounits"])
        c = run(cmd)
        after = cmd_out(["nvidia-smi", "--query-gpu=timestamp,clocks.sm,"
                         "temperature.gpu,power.draw,memory.used,utilization.gpu",
                         "--format=csv,noheader,nounits"])
        # 将 placement 结果写入 CSV 文件。
        csv_path = run_dir / f"placement_{rc['name']}.csv"
        csv_path.write_text(c.stdout, encoding="utf-8")
        manifest["runs"].append({"name": rc["name"], "config": rc, "command": cmd,
                                 "telemetry_before": before, "telemetry_after": after})
        manifest["outputs"][csv_path.name] = sha256_file(csv_path)

    # 记录实验完成时间。
    manifest["completed_utc"] = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    # json.dumps : 将 Python 对象序列化为 JSON 字符串。
    #   indent=2 : 使用 2 个空格缩进，生成人类可读的格式化 JSON。
    #   sort_keys=True : 按字典键的字母顺序排序输出，保证 manifest 的确定性（diff 友好）。
    # 根据 Python 官方文档，sort_keys 对测试断言和版本控制尤其有用。
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n",
                                           encoding="utf-8")
    print(run_dir)
    return 0


if __name__ == "__main__":
    # raise SystemExit(main()) : 将 main() 的返回值作为进程退出码抛出。
    # SystemExit 是 BaseException 的子类，被解释器捕获后转化为进程退出状态，
    # 比直接 sys.exit() 更简洁，且避免在模块被导入时意外退出。
    raise SystemExit(main())