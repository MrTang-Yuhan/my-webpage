#!/usr/bin/env python3
"""离线演示 L40 SM-placement oracle。

输入是已发布模型和保留样本，输出为预测到的物理 SM 标签。
该脚本不需要 GPU，用于验证论文 artifact 中的模型加载与推理路径。"""

from __future__ import annotations

import argparse
import json
import pathlib

import numpy as np
import joblib


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    parser = argparse.ArgumentParser()
    # 命令行参数
    parser.add_argument("--models", default=pathlib.Path("models"),
                        type=pathlib.Path)
    parser.add_argument("--n", default=8, type=int,
                        help="number of example fingerprints to print")
    args = parser.parse_args()

    meta = json.loads((args.models / "sm_oracle_meta.json").read_text())
    clf = joblib.load(args.models / "sm_oracle.joblib")
    sample = np.load(args.models / "sample_fingerprints.npz")
    X, y = sample["X"], sample["y"]
    split = meta["cluster_split_smid"]

    pred = clf.predict(X)
    exact = float((pred == y).mean())
    cluster = float(((pred >= split) == (y >= split)).mean())
    print(f"held-out fingerprints: {len(y)}")
    print(f"exact-SM accuracy:  {exact:.3f}  (chance {1/142:.3f})")
    print(f"cluster accuracy:   {cluster:.3f}")
    print()
    print("example predictions (fingerprint -> SM):")
    for i in range(min(args.n, len(y))):
        mark = "ok" if pred[i] == y[i] else (
            "twin" if abs(int(pred[i]) - int(y[i])) == 72 else "miss")
        head = ", ".join(f"{v:.1f}" for v in X[i, :4])
        print(f"  [{head}, ...] cyc  ->  predicted SM {int(pred[i]):3d}  "
              f"(true {int(y[i]):3d})  [{mark}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
