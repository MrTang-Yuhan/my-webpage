// NUCA-aware 工作分配：评估三种策略是否能利用前面测得的 SM-L2 拓扑差异。
//
// 所有策略的总 dependent-load 工作量保持一致，仅改变每个 SM 承担的份额或领取方式。
//
// 固定总量的延迟受限依赖加载工作被分配到各 SM，通过三种策略测量 wall-clock makespan
//（即最慢 SM 完成的时间），使用 CUDA Event 计时：
//
//   oblivious : 每个 SM 承担相同工作量（无拓扑知识）。
//   aware     : 每个 SM 的工作量与 1/latency 成正比，利用拓扑研究中测得的
//               各 SM L2 延迟映射。更快的 SM 承担更多工作，使所有 SM 同时完成。
//   dynamic   : 全局原子工作队列；每个 block 自领取 chunk 直到队列耗尽，
//               运行时自动平衡，无需任何模型。
//
// 三种策略的总工作量相同，仅分配方式不同。
// 当每个线程 footprint 很大（chain_kind=seq）时，工作负载进入 DRAM/带宽受限 regime，
// 填满 VRAM，作为负向对照：此时拓扑知识不再有效。

#include <cuda_runtime.h>

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <vector>

// CUDA 运行时 API 错误检查宏：若调用返回非 cudaSuccess，则打印错误信息并终止程序。
#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t error__ = (call);                                             \
    if (error__ != cudaSuccess) {                                             \
      std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << ": "    \
                << cudaGetErrorString(error__) << "\n";                       \
      std::exit(EXIT_FAILURE);                                                \
    }                                                                         \
  } while (0)

// 读取当前线程所在 SM 的物理 ID。
// PTX 特殊寄存器 %smid 返回当前 warp 所在 Streaming Multiprocessor 的索引。
__device__ __forceinline__ uint32_t physical_smid() {
  uint32_t id;
  asm volatile("mov.u32 %0, %%smid;" : "=r"(id));
  return id;
}

// 通过 L2 缓存路径（绕过 L1）加载一个 32 位字。
// PTX 指令 ld.global.cg.u32 中 .cg（cache at global level）表示仅在 L2 及以下层级缓存，
// 不占用 L1 缓存空间，避免 L1 对指针追踪链路的干扰。
__device__ __forceinline__ uint32_t load_cg_u32(const uint32_t *address) {
  uint32_t value;
  asm volatile("ld.global.cg.u32 %0, [%1];" : "=r"(value) : "l"(address)
               : "memory");
  return value;
}

// 在设备端构建顺序（DRAM-regime）缓冲区，使 footprint 能填满 VRAM，
// 而无需在 Host 端分配大内存。
// 每个 region 形成顺序环，访问跨越大 footprint 后进入 DRAM/bandwidth regime，
// 弱化 NUCA 片上拓扑优势，作为负向对照。
__global__ void seq_fill(uint32_t *buf, uint32_t region_words,
                         uint64_t total_words) {
  const uint64_t k = static_cast<uint64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
  if (k >= total_words) return;
  const uint64_t base = (k / region_words) * region_words;
  const uint32_t j = static_cast<uint32_t>(k % region_words);
  buf[k] = static_cast<uint32_t>(base + (j + 1u) % region_words);
}

// 静态调度：每个线程在其独立 region 上执行 work_per_sm[smid] 次依赖加载。
// work_per_sm 由 Host 按策略写入：oblivious 为均匀值，aware 按 1/latency 加权分配。
__global__ void static_kernel(const uint32_t *buf, uint32_t region_words,
                              const uint64_t *work_per_sm, uint32_t *sink) {
  const uint32_t sm = physical_smid();
  const uint64_t work = work_per_sm[sm];
  const uint64_t region =
      (static_cast<uint64_t>(blockIdx.x) * blockDim.x + threadIdx.x) *
      region_words;
  uint32_t idx = static_cast<uint32_t>(region);
  for (uint64_t i = 0; i < work; ++i) {
    idx = load_cg_u32(buf + idx);
  }
  sink[blockIdx.x * blockDim.x + threadIdx.x] = idx;
}

// 动态调度：block 从全局原子队列中领取固定大小的 chunk，直到队列耗尽。
// 自平衡机制，无需 per-SM 模型。
// 原子队列以 block 为单位领取 chunk，适合作为"不需要拓扑模型"的运行时基线。
__global__ void dynamic_kernel(const uint32_t *buf, uint32_t region_words,
                               uint64_t chunk_loads, uint64_t total_chunks,
                               unsigned long long *next_chunk, uint32_t *sink) {
  const uint64_t region =
      (static_cast<uint64_t>(blockIdx.x) * blockDim.x + threadIdx.x) *
      region_words;
  const uint32_t start = static_cast<uint32_t>(region);
  uint32_t idx = start;
  __shared__ unsigned long long claimed;
  for (;;) {
    if (threadIdx.x == 0) {
      // atomicAdd 对全局计数器执行原子的读-改-写操作，保证多 block 并发领取时不冲突。
      claimed = atomicAdd(next_chunk, 1ULL);
    }
    // __syncthreads()：块内线程屏障同步。确保 thread 0 完成原子操作并将结果写入
    // shared memory 后，块内其他线程才能读取 claimed 值。
    __syncthreads();
    if (claimed >= total_chunks) {
      break;
    }
    for (uint64_t i = 0; i < chunk_loads; ++i) {
      idx = load_cg_u32(buf + idx);
    }
    __syncthreads();
  }
  sink[blockIdx.x * blockDim.x + threadIdx.x] = idx;
}

// 解析无符号十进制命令行参数。
static uint64_t parse_u64(const char *t, const char *n) {
  errno = 0;
  char *e = nullptr;
  unsigned long long v = std::strtoull(t, &e, 10);
  if (errno || e == t || *e) { std::cerr << "bad " << n << ": " << t << "\n"; std::exit(1); }
  return v;
}

int main(int argc, char **argv) {
  if (argc != 9) {
    std::cerr << "Usage: " << argv[0]
              << " <region_words_per_thread> <threads_per_block> "
                 "<random|seq> <base_work> <reps> <seed> <lat_csv|none> "
                 "<device>\n";
    return 1;
  }
  const uint32_t region_words = static_cast<uint32_t>(parse_u64(argv[1], "region_words"));
  const int tpb = static_cast<int>(parse_u64(argv[2], "threads_per_block"));
  const std::string chain_kind = argv[3];
  const uint64_t base_work = parse_u64(argv[4], "base_work");
  const uint64_t reps = parse_u64(argv[5], "reps");
  const uint64_t seed = parse_u64(argv[6], "seed");
  const std::string lat_csv = argv[7];
  const int device = static_cast<int>(parse_u64(argv[8], "device"));

  CUDA_CHECK(cudaSetDevice(device));
  cudaDeviceProp prop{};
  CUDA_CHECK(cudaGetDeviceProperties(&prop, device));
  const int num_sm = prop.multiProcessorCount;
  int core_clock_khz = 0;
  // cudaDeviceGetAttribute 查询设备属性；cudaDevAttrClockRate 返回 GPU 核心时钟频率（单位：KHz）。
  CUDA_CHECK(cudaDeviceGetAttribute(&core_clock_khz, cudaDevAttrClockRate, device));

  const size_t shared_per_sm = prop.sharedMemPerMultiprocessor;
  size_t dyn_shared = shared_per_sm / 2 + 1024;
  // cudaFuncSetAttribute 设置核函数属性。
  // cudaFuncAttributeMaxDynamicSharedMemorySize 指定该核函数每次启动时允许分配的最大动态共享内存字节数。
  // 该值与函数属性 sharedSizeBytes 之和不能超过 cudaDevAttrMaxSharedMemoryPerBlockOptin。
  CUDA_CHECK(cudaFuncSetAttribute(static_kernel,
             cudaFuncAttributeMaxDynamicSharedMemorySize, (int)dyn_shared));
  CUDA_CHECK(cudaFuncSetAttribute(dynamic_kernel,
             cudaFuncAttributeMaxDynamicSharedMemorySize, (int)dyn_shared));

  const uint64_t n_regions = static_cast<uint64_t>(num_sm) * tpb;
  const uint64_t total_words = n_regions * region_words;
  const size_t bytes = total_words * sizeof(uint32_t);
  // 每个线程拥有独立 region，避免线程之间共享同一 pointer chain 导致额外争用。

  uint32_t *d_buf = nullptr;
  CUDA_CHECK(cudaMalloc(&d_buf, bytes));
  if (chain_kind == "random") {
    // 每个 region 构建随机环（Host 端生成）：L2 驻留的延迟受限 regime。
    // 随机环让每一步都依赖上一跳地址，吞吐主要由 L2 hit latency 而非并行内存带宽决定。
    std::vector<uint32_t> host(total_words);
    std::mt19937_64 gen(seed);
    for (uint64_t r = 0; r < n_regions; ++r) {
      const uint64_t base = r * region_words;
      std::vector<uint32_t> perm(region_words);
      std::iota(perm.begin(), perm.end(), 0u);
      std::shuffle(perm.begin(), perm.end(), gen);
      for (uint32_t k = 0; k < region_words; ++k) {
        host[base + perm[k]] = static_cast<uint32_t>(base + perm[(k + 1) % region_words]);
      }
    }
    CUDA_CHECK(cudaMemcpy(d_buf, host.data(), bytes, cudaMemcpyHostToDevice));
  } else {
    // 每个 region 构建顺序环（设备端生成）：DRAM/bandwidth regime。
    // 作为负向对照，在大 region 下弱化 NUCA 片上拓扑优势，证明 aware 策略不是普遍提速。
    const uint64_t threads = 256;
    const uint64_t blocks = (total_words + threads - 1) / threads;
    seq_fill<<<blocks, threads>>>(d_buf, region_words, total_words);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
  }

  // 读取 per-SM 延迟估计，用于 aware 策略的加权分配。
  std::vector<double> lat(num_sm, 1.0);
  bool have_lat = false;
  if (lat_csv != "none") {
    std::ifstream f(lat_csv);
    std::string line;
    std::getline(f, line);  // 跳过 CSV 表头
    while (std::getline(f, line)) {
      std::stringstream ss(line);
      std::string a, b;
      std::getline(ss, a, ',');
      std::getline(ss, b, ',');
      int sm = std::atoi(a.c_str());
      double l = std::atof(b.c_str());
      if (sm >= 0 && sm < num_sm && l > 0) { lat[sm] = l; have_lat = true; }
    }
  }

  // 每个线程的总工作量 = base_work * num_sm（即所有 SM 的工作量之和）。
  const uint64_t total_loads_per_thread = base_work * num_sm;
  std::vector<uint64_t> w_oblivious(num_sm, base_work);
  std::vector<uint64_t> w_aware(num_sm, base_work);
  if (have_lat) {
    // Aware 分配：让低延迟 SM 承担更多 dependent-load 工作，目标是让所有 SM 同时收尾。
    // 权重为 1/latency，总工作量按权重比例分配。
    double inv_sum = 0.0;
    for (int s = 0; s < num_sm; ++s) inv_sum += 1.0 / lat[s];
    for (int s = 0; s < num_sm; ++s) {
      w_aware[s] = static_cast<uint64_t>(std::llround(
          total_loads_per_thread * (1.0 / lat[s]) / inv_sum));
      if (w_aware[s] < 1) w_aware[s] = 1;
    }
  }

  uint64_t *d_work = nullptr;
  CUDA_CHECK(cudaMalloc(&d_work, sizeof(uint64_t) * num_sm));
  uint32_t *d_sink = nullptr;
  CUDA_CHECK(cudaMalloc(&d_sink, sizeof(uint32_t) * n_regions));
  unsigned long long *d_next = nullptr;
  CUDA_CHECK(cudaMalloc(&d_next, sizeof(unsigned long long)));

  size_t free_b = 0, total_b = 0;
  // cudaMemGetInfo 返回当前设备的全局内存空闲字节数和总字节数。
  CUDA_CHECK(cudaMemGetInfo(&free_b, &total_b));
  const double vram_used_mib = (total_b - free_b) / (1024.0 * 1024.0);

  cudaEvent_t e0, e1;
  // CUDA Event 用于 GPU 端精确计时。cudaEventCreate 创建事件对象。
  CUDA_CHECK(cudaEventCreate(&e0));
  CUDA_CHECK(cudaEventCreate(&e1));

  std::cout << "policy,lat_source,chain_kind,rep,threads_per_block,region_words,"
               "base_work,total_loads,makespan_ms,gloads_per_s,vram_used_mib,"
               "core_clock_khz\n";

  // 运行静态调度策略（oblivious / aware）。
  // CUDA Event 记录整次 kernel launch 的 makespan，即最慢 SM 的完成时间。
  auto run_static = [&](const char *name, const std::vector<uint64_t> &w) {
    CUDA_CHECK(cudaMemcpy(d_work, w.data(), sizeof(uint64_t) * num_sm,
                          cudaMemcpyHostToDevice));
    const uint64_t total_loads =
        std::accumulate(w.begin(), w.end(), uint64_t{0}) * tpb;
    for (uint64_t r = 0; r < reps; ++r) {
      // cudaEventRecord 在 GPU 时间线上记录事件 e0。
      CUDA_CHECK(cudaEventRecord(e0));
      static_kernel<<<num_sm, tpb, dyn_shared>>>(d_buf, region_words, d_work, d_sink);
      // cudaEventRecord 在 GPU 时间线上记录事件 e1。
      CUDA_CHECK(cudaEventRecord(e1));
      // cudaEventSynchronize 阻塞 Host 线程，直到 GPU 上事件 e1 之前的所有工作完成。
      // 因此测得的时间包含最慢 SM 的执行时间，即 makespan。
      CUDA_CHECK(cudaEventSynchronize(e1));
      float ms = 0;
      // cudaEventElapsedTime 计算两个事件之间的时间差，单位毫秒。
      CUDA_CHECK(cudaEventElapsedTime(&ms, e0, e1));
      const double gls = total_loads / (ms / 1000.0) / 1e9;
      std::cout << name << ',' << (lat_csv == "none" ? "none" : lat_csv) << ','
                << chain_kind << ',' << r << ',' << tpb << ',' << region_words
                << ',' << base_work << ',' << total_loads << ',' << ms << ','
                << gls << ',' << vram_used_mib << ',' << core_clock_khz << '\n';
    }
  };

  run_static("oblivious", w_oblivious);
  if (have_lat) run_static("aware", w_aware);

  // 动态 work-stealing 调度：总工作量与静态策略相同。
  const uint64_t chunk_loads = std::max<uint64_t>(1, base_work / 16);
  const uint64_t total_chunks = (total_loads_per_thread + chunk_loads - 1) / chunk_loads;
  const uint64_t total_loads_dyn = total_chunks * chunk_loads * tpb;
  // chunk 粒度取 base_work 的 1/16，在调度开销和负载均衡之间取折中。
  for (uint64_t r = 0; r < reps; ++r) {
    CUDA_CHECK(cudaMemset(d_next, 0, sizeof(unsigned long long)));
    CUDA_CHECK(cudaEventRecord(e0));
    dynamic_kernel<<<num_sm, tpb, dyn_shared>>>(d_buf, region_words, chunk_loads,
                                                total_chunks, d_next, d_sink);
    CUDA_CHECK(cudaEventRecord(e1));
    CUDA_CHECK(cudaEventSynchronize(e1));
    float ms = 0;
    CUDA_CHECK(cudaEventElapsedTime(&ms, e0, e1));
    const double gls = total_loads_dyn / (ms / 1000.0) / 1e9;
    std::cout << "dynamic," << (lat_csv == "none" ? "none" : lat_csv) << ','
              << chain_kind << ',' << r << ',' << tpb << ',' << region_words
              << ',' << base_work << ',' << total_loads_dyn << ',' << ms << ','
              << gls << ',' << vram_used_mib << ',' << core_clock_khz << '\n';
  }

  CUDA_CHECK(cudaFree(d_next));
  CUDA_CHECK(cudaFree(d_sink));
  CUDA_CHECK(cudaFree(d_work));
  CUDA_CHECK(cudaFree(d_buf));
  return 0;
}