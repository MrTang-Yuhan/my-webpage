import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

N = 256
period = 8
noise_std = 0.4
conf_level = 1.96 / np.sqrt(N)
max_lag = 60
n = np.arange(N)

def compute_acf(x):
    ac = np.correlate(x, x, "full")[len(x)-1:]
    ac = ac / ac[0]
    return ac

def find_sig_peaks(ac, threshold, min_lag=2, max_lag_search=60):
    peaks = []
    for k in range(min_lag, min(max_lag_search, len(ac)-1)):
        if ac[k] > threshold and ac[k] >= ac[k-1] and ac[k] >= ac[k+1]:
            peaks.append(k)
    return peaks

# 构造5种信号
signals = {}

# (1) 标准正弦波
s1 = np.sin(2 * np.pi * n / period)
signals['(1) Standard Sine Wave\nTrue period = 8 samples'] = s1

# (2) 白噪声
s2 = np.random.normal(0, noise_std, N)
signals['(2) White Noise\nNo periodicity'] = s2

# (3) 正弦波 + 白噪声
s3 = np.sin(2 * np.pi * n / period) + np.random.normal(0, noise_std, N)
signals['(3) Sine + White Noise\nTrue period = 8 samples'] = s3

# (4) 奇怪周期波形：周期8，严重不对称，半周期也有结构
weird_base = np.array([1.0, 0.7, -0.6, -0.9, 0.2, 0.5, -0.3, 0.1])
s4 = np.tile(weird_base, N // period)
remainder = N % period
if remainder > 0:
    s4 = np.concatenate([s4, weird_base[:remainder]])
signals['(4) Weird Periodic Wave\nTrue period = 8 samples (half-period structure at 4)'] = s4

# (5) 奇怪周期波形 + 白噪声
s5 = s4 + np.random.normal(0, noise_std, N)
signals['(5) Weird Periodic + Noise\nTrue period = 8 samples (half-period structure at 4)'] = s5

# 绘图
fig, axes = plt.subplots(5, 2, figsize=(14, 20))
colors = ['tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple']

for idx, (title, sig) in enumerate(signals.items()):
    sig0 = sig - sig.mean()
    ac = compute_acf(sig0)
    peaks = find_sig_peaks(ac, conf_level, max_lag_search=max_lag)
    
    # 左图：时域（前64个点展示）
    ax_left = axes[idx, 0]
    ax_left.plot(n[:64], sig[:64], 'o-', color=colors[idx], markersize=3, lw=1.2)
    
    # 标注真实周期边界（绿色虚线）
    if 'period = 8' in title:
        for phase in range(0, 64, period):
            ax_left.axvline(phase, color='tab:green', ls='--', lw=1.0, alpha=0.6)
        ax_left.axvline(-10, color='tab:green', ls='--', lw=1.0, alpha=0.6, label='True period boundary')
        ax_left.legend(loc='upper right', fontsize=8)
    
    ax_left.set_title(f'{title}', fontsize=11)
    ax_left.set_xlabel('Sample index $n$')
    ax_left.set_ylabel('Amplitude')
    ax_left.grid(True, alpha=0.3)
    ax_left.set_xlim(0, 64)
    
    # 右图：自相关 + 显著峰值
    ax_right = axes[idx, 1]
    markerline, stemlines, baseline = ax_right.stem(np.arange(max_lag), ac[:max_lag], basefmt=" ")
    plt.setp(stemlines, linewidth=1.0, color=colors[idx])
    plt.setp(markerline, markersize=3.5, color=colors[idx])
    
    # 95% CI
    ax_right.axhline(conf_level, color='tab:red', ls='--', lw=1.2, 
                     label=f'95% CI upper bound ({conf_level:.3f})')
    ax_right.axhline(-conf_level, color='tab:red', ls='--', lw=1.2)
    ax_right.axhline(0, color='0.6', lw=0.8)
    
    # 标注真实周期位置（绿色虚线）和半周期（橙色点线）
    if 'period = 8' in title:
        for p in range(period, max_lag, period):
            ax_right.axvline(p, color='tab:green', ls='--', lw=1.0, alpha=0.5)
        if 'Weird' in title:
            for p in range(period//2, max_lag, period):
                ax_right.axvline(p, color='tab:orange', ls=':', lw=1.0, alpha=0.5)
            ax_right.axvline(-10, color='tab:green', ls='--', lw=1.0, alpha=0.5, label='True period (8)')
            ax_right.axvline(-10, color='tab:orange', ls=':', lw=1.0, alpha=0.5, label='Half-period (4)')
        else:
            ax_right.axvline(-10, color='tab:green', ls='--', lw=1.0, alpha=0.5, label='True period (8)')
    
    # 标注所有 significant peaks（交替上下避免重叠）
    for i, pk in enumerate(peaks):
        if pk >= max_lag:
            continue
        ax_right.plot(pk, ac[pk], 'o', color='tab:green', ms=6, zorder=5)
        offset = 0.15 if i % 2 == 0 else 0.28
        ax_right.annotate(f'{pk}', 
                          xy=(pk, ac[pk]), 
                          xytext=(pk, ac[pk] + offset),
                          ha='center', fontsize=7.5, color='tab:green',
                          fontweight='bold')
    
    peak_info = f"{len(peaks)} significant peaks" if peaks else "no significant peaks"
    ax_right.set_title(f'ACF — {peak_info}', fontsize=11)
    ax_right.set_xlabel('Lag $k$')
    ax_right.set_ylabel('Normalized autocorr $\\rho(k)$')
    ax_right.legend(loc='upper right', fontsize=8)
    ax_right.grid(True, alpha=0.3)
    ax_right.set_ylim(-1.1, 1.1)

plt.suptitle('Autocorrelation Periodicity Test: 5 Signal Types with True Period Annotations', 
             fontsize=14, fontweight='bold', y=0.995)
plt.tight_layout()

output_path = './acf_5_signals_with_period_annotations.png'
plt.savefig(output_path, dpi=220, bbox_inches='tight', facecolor='white')
plt.show()

print(f"Saved to: {output_path}")
print(f"\n95% Bartlett CI threshold: {conf_level:.4f}")

# 打印每个信号的峰值详情
for title, sig in signals.items():
    sig0 = sig - sig.mean()
    ac = compute_acf(sig0)
    peaks = find_sig_peaks(ac, conf_level, max_lag_search=max_lag)
    print(f"\n{title.split(chr(10))[0]}:")
    print(f"  Significant peaks (lag, ac_value): {[(p, round(float(ac[p]),4)) for p in peaks]}")
    if len(peaks) >= 2:
        spacings = [peaks[i+1]-peaks[i] for i in range(len(peaks)-1)]
        print(f"  Spacings: {spacings}")