#!/usr/bin/env python3
"""分析 per-SM L2 延迟。

输入是 `l2_topology` 的 raw CSV，输出为统计 JSON、per-SM CSV、热图和模型图。

功能：
  1. 支持通过 --gpcs 和 --tpcs 参数指定 GPU 的 GPC/TPC 拓扑。
  2. **不预设 SM ID 与物理位置的任何关联**，基于延迟特征向量进行聚类推断。
  3. 所有 GPC/TPC 分析可视化合并为一张大图（6 个子图）。
"""

from __future__ import annotations  # 延迟注解求值，允许在注解中使用 list[...] 等内置泛型

import argparse
import csv
import json
import pathlib
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt

from scipy.optimize import linear_sum_assignment  # Hungarian（Kuhn-Munkres）算法：求解线性分配问题

def read_csv(path: pathlib.Path) -> list[dict[str, str]]:
    """读取普通或压缩的 CSV 文件，解析为行字典列表。

    Args:
        path: 输入 CSV 路径，`.zst` 后缀会通过 zstd 解压。

    Returns:
        CSV 行字典列表。"""
    with path.open(newline="", encoding="utf-8") as handle:
        # DictReader 以首行表头为键生成字典；过滤掉含多余列（None 键）的异常行
        return [row for row in csv.DictReader(handle) if None not in row]


def build_matrix(rows: list[dict[str, str]]):
    """构建用于拓扑分析的 SM × probe 延迟矩阵。

    Args:
        rows: raw topology CSV 行。

    Returns:
        矩阵、SM 标签和 probe 标签。"""

    # 提取所有唯一的 smid 和 probe_id，排序
    smids = sorted({int(r["smid"]) for r in rows})
    offs = sorted({int(r["probe_id"]) for r in rows})
    si = {s: i for i, s in enumerate(smids)}
    oi = {o: i for i, o in enumerate(offs)}
    acc = defaultdict(list)  # 按 (smid, probe_id) 聚合所有重复测量值
    for r in rows:
        acc[(int(r["smid"]), int(r["probe_id"]))].append(
            float(r["cycles_per_access"]))
    # 初始化全 NaN 矩阵：未测到的 (SM, probe) 组合保持 NaN，后续按行均值填补
    matrix = np.full((len(smids), len(offs)), np.nan)
    repstd = []  # 收集有重复测量的组合的标准差，用于估计测量噪声水平
    for (s, o), vals in acc.items():
        matrix[si[s], oi[o]] = float(np.mean(vals))
        if len(vals) > 1:
            repstd.append(float(np.std(vals)))
    return matrix, np.array(smids), np.array(offs), float(np.median(repstd) if repstd else 0.0)


def greedy_grouping(sm_indices: np.ndarray, features: np.ndarray,
                    n_groups: int, group_size: int) -> list[list[int]]:
    """基于特征向量欧氏距离的贪心分组，支持任意组大小。

    将 sm_indices 分成 n_groups 组，每组尽可能 group_size 个 SM。
    如果 n_sm 不能整除 n_groups，剩余 SM 均匀分配到前几个组。

    Args:
        sm_indices: 待分组的 SM 索引数组。
        features: 完整特征矩阵 (n_sm, n_features)。
        n_groups: 目标组数。
        group_size: 每组目标大小。

    Returns:
        groups: 每个元素是一个 SM 索引列表（一个组/TPC）。
    """
    n = len(sm_indices)
    ungrouped = set(int(x) for x in sm_indices)
    groups = []

    # 计算余数：前 remainder 个组多分配 1 个 SM
    remainder = n % n_groups
    base_size = n // n_groups

    # 为每个目标组创建一次迭代
    for g_idx in range(n_groups):
        if not ungrouped:
            break
        # 当前组大小：base_size 或 base_size + 1
        current_size = base_size + (1 if g_idx < remainder else 0)
        if current_size == 0:
            groups.append([])
            continue

        group = []
        # 选种子：取未分组中最小索引（保证确定性）
        seed = min(ungrouped)
        group.append(seed)
        ungrouped.remove(seed)

        # 贪心补充：每次选离当前组质心最近的 SM
        # 只要当前组还没达到目标大小，且还有未分配的 SM，就继续寻找下一个成员
        while len(group) < current_size and ungrouped:
            group_feats = features[group]
            centroid = group_feats.mean(axis=0)
            min_dist = float('inf')
            best_sm = None
            # 对每个未分配 SM，计算其特征向量与当前组质心的欧氏距离。若距离更小，
            # 更新 min_dist 和 best_sm。
            for sm in ungrouped:
                dist = np.linalg.norm(features[sm] - centroid)  # 计算 L2 范数
                if dist < min_dist:
                    min_dist = dist
                    best_sm = sm
            if best_sm is None:
                break
            group.append(best_sm)
            ungrouped.remove(best_sm)

        groups.append(group)

   
    if ungrouped:
        raise AssertionError(
            "Incorrect SM, TPC, and GPC configuration. Please refer "
            "to the architecture white paper for correction."
        )
    # 处理剩余（理论上不应发生）
    # for sm in ungrouped:
        # if groups:
        #     groups[-1].append(sm)
        # else:
        #     groups.append([sm])

    return groups

def balanced_kmeans(data: np.ndarray, k: int, cluster_sizes: list[int],
                     n_restarts: int = 30, max_iter: int = 100,
                     seed: int = 42) -> np.ndarray:
    """容量约束的平衡 K-Means（簇大小可以不相等）。

    cluster_sizes[c] 指定第 c 个簇应包含的样本数，sum(cluster_sizes) 必须等于
    样本总数 n。当 n_tpc 不能被 n_gpc 整除时，给前几个簇多分配 1 个槽位即可，
    不再要求所有簇大小完全相同。

    分配步骤仍用 Hungarian 算法（线性分配问题）求解，在给定中心点前提下
    保证全局最优的等容量（或指定容量）分配。

    多次随机初始化后取总代价最小的解，降低对随机种子的敏感度。
    """
    n, d = data.shape
    assert sum(cluster_sizes) == n, "cluster_sizes 之和必须等于样本总数"
    assert len(cluster_sizes) == k, "cluster_sizes 长度必须等于簇数 k"

    rng = np.random.default_rng(seed)  # 固定种子的随机数生成器，保证多次运行结果可复现
    best_labels, best_cost = None, np.inf

    # 槽位 -> 簇的映射：簇 c 重复 cluster_sizes[c] 次
    slot_to_cluster = np.concatenate([
        np.full(size, c, dtype=int) for c, size in enumerate(cluster_sizes)
    ])

    for _trial in range(n_restarts):
        # 随机选 k 个不重复样本作为初始簇中心
        centers = data[rng.choice(n, size=k, replace=False)].copy()
        labels = None

        for _ in range(max_iter):
            # 广播计算每个样本到每个簇中心的欧氏距离，得到 n x k 距离矩阵
            dists = np.linalg.norm(data[:, None, :] - centers[None, :, :], axis=2)  # n x k
            cost = dists[:, slot_to_cluster]          # n x n（槽位总数 == 样本数）
            # Hungarian 算法求解线性分配问题：在容量约束下得到总代价最小的“样本→槽位”分配
            _, col_ind = linear_sum_assignment(cost)
            new_labels = slot_to_cluster[col_ind]

            if labels is not None and np.array_equal(new_labels, labels):
                break
            labels = new_labels
            for c in range(k):
                mask = labels == c
                if mask.any():
                    centers[c] = data[mask].mean(axis=0)

        # 本轮总代价：所有样本到其簇中心的距离之和，用于跨重启选最优
        total_cost = float(sum(
            np.linalg.norm(data[i] - centers[labels[i]]) for i in range(n)
        ))
        if total_cost < best_cost:
            best_cost, best_labels = total_cost, labels.copy()

    return best_labels

def infer_gpc_tpc_mapping(M: np.ndarray, per_sm_avg: np.ndarray,
                          n_sm: int, n_gpc: int, n_tpc: int) -> tuple:
    """先做 TPC 配对（信号最强、噪声最小），再基于 TPC 级特征聚类出 GPC。"""
    sm_per_tpc = n_sm // n_tpc  # 仅用于 Step 1 的分组基准，余数由 greedy_grouping 内部处理

    # 缺失值用该 SM 的行均值（忽略 NaN）填补，避免 NaN 干扰距离计算
    sm_means = np.nanmean(M, axis=1, keepdims=True)
    M_filled = np.where(np.isnan(M), sm_means, M)

    # Step 1: 全局 TPC 分组（不预设任何 GPC 分组），SM 数不整除 TPC 数时
    # greedy_grouping 内部已按余数把多出来的 SM 分给前几个 TPC。
    groups = greedy_grouping(np.arange(n_sm), M_filled, n_groups=n_tpc, group_size=sm_per_tpc)
    # 按组内最小 SM 索引排序，保证 TPC 编号的确定性
    groups = sorted(groups, key=lambda g: min(g) if g else float('inf'))

    tpc_ids = np.full(n_sm, -1, dtype=int)
    tpc_features = np.zeros((n_tpc, M_filled.shape[1]))
    for t, group in enumerate(groups):
        for sm in group:
            tpc_ids[sm] = t
        tpc_features[t] = M_filled[group].mean(axis=0)

    # Step 2: TPC 数不整除 GPC 数时，前 remainder 个 GPC 多分配 1 个 TPC，
    # 而不是要求每个 GPC 严格拿到相同数量的 TPC。
    base_tpc_per_gpc = n_tpc // n_gpc
    tpc_remainder = n_tpc % n_gpc
    cluster_sizes = [
        base_tpc_per_gpc + (1 if g < tpc_remainder else 0) for g in range(n_gpc)
    ]

    tpc_gpc = balanced_kmeans(tpc_features, k=n_gpc, cluster_sizes=cluster_sizes,
                              n_restarts=30, seed=42)

    # 将 TPC 级聚类标签下放到 SM 级：同一 TPC 内所有 SM 属于同一 GPC
    gpc_ids = np.zeros(n_sm, dtype=int)
    tpc_local_ids = np.zeros(n_sm, dtype=int)
    for t, group in enumerate(groups):
        for sm in group:
            gpc_ids[sm] = tpc_gpc[t]

    for g in range(n_gpc):
        tpcs_in_g = sorted(
            (t for t in range(n_tpc) if tpc_gpc[t] == g),
            key=lambda t: tpc_features[t].mean(),
        )
        for local_idx, t in enumerate(tpcs_in_g):
            for sm in groups[t]:
                tpc_local_ids[sm] = local_idx

    # 验证 TPC 分组大小（允许余数分布）
    for t in range(n_tpc):
        cnt = int((tpc_ids == t).sum())
        expected = sm_per_tpc + (1 if t < (n_sm % n_tpc) else 0)
        assert cnt == expected, f"TPC{t} has {cnt} SMs, expected {expected}"

    # 验证 GPC 分组大小（允许余数分布，不再要求严格均分）
    for g in range(n_gpc):
        cnt = int((np.array([tpc_gpc[t] for t in range(n_tpc)]) == g).sum())
        assert cnt == cluster_sizes[g], f"GPC{g} has {cnt} TPCs, expected {cluster_sizes[g]}"

    # 用单因素方差分析 F 统计量评估 GPC 分组置信度：组间方差 / 组内方差
    overall_mean = per_sm_avg.mean()
    ssb = ssw = 0.0
    for g in range(n_gpc):
        mask = gpc_ids == g
        gpc_mean = per_sm_avg[mask].mean()
        ssb += mask.sum() * (gpc_mean - overall_mean) ** 2
        ssw += ((per_sm_avg[mask] - gpc_mean) ** 2).sum()
    confidence = (ssb / (n_gpc - 1)) / (ssw / (n_sm - n_gpc) + 1e-9) if ssw > 0 else 0.0

    return gpc_ids, tpc_ids, tpc_local_ids, float(confidence)


def main() -> int:
    """脚本的命令行入口。

    Returns:
        进程退出码，0 表示成功。"""
    parser = argparse.ArgumentParser()

    parser.add_argument("run_dir", type=pathlib.Path)                     # 指向输入的测量结果目录
    parser.add_argument("--figures", required=True, type=pathlib.Path)    # 指定输出图表的目录  
    parser.add_argument("--processed", required=True, type=pathlib.Path)  # 指定处理后数据输出的目录

    # GPC/TPC 拓扑参数
    parser.add_argument("--gpcs", type=int, default=None,
                        help="GPC 总数 (如 5080 为 7)")
    parser.add_argument("--tpcs", type=int, default=None,
                        help="TPC 总数 (如 5080 为 42)")
    args = parser.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    args.processed.mkdir(parents=True, exist_ok=True)

    # 读取两个 CSV 文件
    sweep = read_csv(args.run_dir / "topology_slice_sweep.csv")
    chain = read_csv(args.run_dir / "topology_chain_uniform.csv")
    clock_khz = float(sweep[0]["core_clock_khz"])
    ghz = clock_khz / 1e6

    # 构建 SM × probe 延迟矩阵
    M, smids, offs, rep_std = build_matrix(sweep)
    n_sm, n_slice = M.shape
    assert (smids == np.arange(n_sm)).all(), "smid ids are not 0..n-1"

    # NUCA 模型拟合: L(sm, slice) ~= mu + a(sm) + b(slice)。
    mu = float(M.mean())
    a = M.mean(axis=1) - mu            # per-SM 项, 使用 smid 索引
    b = M.mean(axis=0) - mu            # per-slice 项
    fit = mu + a[:, None] + b[None, :] # 使用 NUCA 模型拟合的结果
    resid = M - fit                    # 残差项。越小说明 SM 与 Slice 之间几乎没有复杂交互，延迟就是简单的距离叠加
    r2 = 1.0 - (resid ** 2).sum() / ((M - mu) ** 2).sum()  # 决定系数 R2：加性模型对实测延迟的解释力

    per_sm_avg = M.mean(axis=1)
    order = np.argsort(per_sm_avg)  # 按 per-SM 平均延迟升序排列，用于找出最快/最慢的 SM

    # 二重对称性检测：在中心附近搜索最佳切分点，
    # 使 a(sm) 两个半区轮廓的 Pearson 相关性最大。
    best_split, best_r = n_sm // 2, -1.0
    for sp in range(n_sm // 2 - 12, n_sm // 2 + 12):
        x, y = a[:sp], a[sp:]
        m = min(len(x), len(y))

        # np.corrcoef(a, b): 计算数组 a 和数组 b 的 Pearson 相关系数，并且返回 1 个
        # 2 x 2 的相关系数矩阵, 形状如下：
        # corr(x, x)=1, corr(x, y)
        # corr(x, y)  , corr(y, y)=1
        rr = float(np.corrcoef(x[:m], y[:m])[0, 1]) 
        if rr > best_r:
            best_split, best_r = sp, rr
    # 两半区对应位置 SM 的延迟项平均绝对差：越小说明对称性越强
    half_pairs = min(best_split, n_sm - best_split)
    pair_absdiff = float(np.mean(np.abs(a[:half_pairs] - a[best_split:best_split + half_pairs])))

    # 半区内部的“延迟-位置”梯度。
    # 检测半个 GPC 内部的延迟梯度（如距离 L2 越近延迟越低）。
    h1 = a[:best_split]
    grad_r = float(np.corrcoef(np.arange(len(h1)), h1)[0, 1])

    # 跨实验交叉验证：chain 模式（独立启动）与 sweep 模式对比。
    # 算 single 模式与 chain 模式 per-SM 平均延迟的 Pearson 相关性。
    cacc = defaultdict(list)
    for r in chain:
        cacc[int(r["smid"])].append(float(r["cycles_per_access"]))
    chain_avg = np.array([np.mean(cacc[s]) for s in range(n_sm)])
    cross_r = float(np.corrcoef(per_sm_avg, chain_avg)[0, 1])
    chain_spread = float(chain_avg.max() - chain_avg.min())

    # 通过对 b(slice) 做自相关，检测 slice 项的交错周期。
    # 自相关分析，目的是从 per-slice 延迟项 b 中检测出周期性模式，从而推断地址到 L2 
    # Slice 的交错周期。
    # 
    # 自相关能检测周期，本质是因为周期信号平移一个完整周期后，与自身完全重合。
    # 对于周期信号，对齐时相干叠加，错开时相互抵消
    b0 = b - b.mean()                                   # 去均值化，使得只剩下波动部分
    ac = np.correlate(b0, b0, "full")[len(b0) - 1:]     # 计算自相关函数
    ac = ac / ac[0]                                     # 归一化处理，处理后 ac[0] = 1，其余值落在 [−1,1]  之间
                                                        # ac[0] 即能量信号
    
    # 视觉检验法：使用 95% Bartlett 置信带作为显著性判据。
    # 白噪声的自相关近似服从 N(0, 1/N)，因此 95% 置信区间为 ±1.96/√N。
    # 若某个 lag 处的自相关值超出置信带，则拒绝「该 lag 处无自相关」的原假设，
    # 认为存在显著周期性。这比固定阈值 0.9 更科学，能自适应样本量。
    conf_level = 1.96 / np.sqrt(len(b0))
    
    # 在自相关序列中寻找第一个显著的周期峰值（超出 95% 置信带且为局部最大）
    period = next((k for k in range(2, 40)  # next() 的作用：从生成器中取第一个满足条件的元素
                   if ac[k] > conf_level and ac[k] >= ac[k - 1] and ac[k] >= ac[k + 1]), None)

    # 收集所有超出 95% 置信带的显著峰值（用于写入 JSON 和可视化）
    max_lag_for_peaks = min(60, len(ac) - 1)
    significant_peaks = [
        k for k in range(2, max_lag_for_peaks)
        if ac[k] > conf_level and ac[k] >= ac[k - 1] and ac[k] >= ac[k + 1]
    ]

    # 计算显著峰值的间距，用于判断等间距周期性
    peak_spacings = []
    is_equally_spaced = False
    if len(significant_peaks) >= 2:
        peak_spacings = [significant_peaks[i+1] - significant_peaks[i] 
                        for i in range(len(significant_peaks) - 1)]
        # 若前 3 个间距相同，则认为存在强等间距周期性
        if len(peak_spacings) >= 3 and len(set(peak_spacings[:3])) == 1:
            is_equally_spaced = True

    # 侧信道分析：仅凭单次探测即可区分的 SM 类别数。
    # 基于测量噪声估计，将 SM 按延迟分为可区分的类别（5-sigma 分离）
    single_sigma = max(rep_std, 0.01)
    sv = np.sort(per_sm_avg)
    classes, last = 1, sv[0]
    for x in sv[1:]:
        if x - last > 5 * single_sigma:
            classes += 1
        last = x
    # 按 0.5 cycle 粒度分箱，统计可区分的延迟级别数
    binned = len({int(round((v - per_sm_avg.min()) / 0.5)) for v in per_sm_avg})

    # GPC / TPC 拓扑推断（不依赖 SM ID 顺序）
    gpc_stats = {}
    tpc_stats = {}
    gpc_ids = None
    tpc_ids = None
    tpc_local_ids = None
    mapping_confidence = None

    # 仅当用户同时提供 GPC/TPC 数量时才执行拓扑推断
    if args.gpcs is not None and args.tpcs is not None:
        if args.tpcs > n_sm or args.gpcs > args.tpcs or args.gpcs < 1 or args.tpcs < 1:
            print(f"[WARN] Invalid topology: need 1 <= GPCs({args.gpcs}) <= "
                f"TPCs({args.tpcs}) <= SM({n_sm}).")
        elif n_sm % args.tpcs != 0 or args.tpcs % args.gpcs != 0:
            print(f"[INFO] SM({n_sm})/TPC({args.tpcs}) or TPC({args.tpcs})/GPC({args.gpcs}) "
                f"do not divide evenly; extra SMs/TPCs are distributed to the "
                f"first few groups (remainder-based balancing).")

        gpc_ids, tpc_ids, tpc_local_ids, mapping_confidence = \
            infer_gpc_tpc_mapping(M, per_sm_avg, n_sm, args.gpcs, args.tpcs)

        print(f"[INFO] Mapping inference completed. confidence={mapping_confidence:.2f}")

        for g in range(args.gpcs):
            gpc_sm = np.where(gpc_ids == g)[0]
            print(f"  GPC{g}: SM {sorted(gpc_sm.tolist())}")

        # Per-GPC 统计
        for g in range(args.gpcs):
            mask = (gpc_ids == g)
            gpc_sm_avg = per_sm_avg[mask]
            gpc_a = a[mask]
            gpc_stats[f"GPC{g}"] = {
                "sm_count": int(mask.sum()),                                    # 该 GPC 包含的 SM 数
                "mean_cycles": float(gpc_sm_avg.mean()),                        # 该 GPC 所有 SM 的平均延迟
                "min_cycles": float(gpc_sm_avg.min()),                  
                "max_cycles": float(gpc_sm_avg.max()),                      
                "spread_cycles": float(gpc_sm_avg.max() - gpc_sm_avg.min()),    
                "sm_term_mean": float(gpc_a.mean()),                            # 加性模型中该 GPC 的 SM 独立延迟项均值
                "sm_term_min": float(gpc_a.min()),
                "sm_term_max": float(gpc_a.max()),
                "sm_ids": np.where(mask)[0].tolist(),
                "half": 0 if g < args.gpcs // 2 else 1,                         # 所属半区（0 = 前半区，1 = 后半区）
            }

        # Per-TPC 统计
        for t in range(args.tpcs):
            mask = (tpc_ids == t)
            if not mask.any():
                continue
            tpc_sm_avg = per_sm_avg[mask]
            tpc_a = a[mask]
            # 推断该 TPC 所属的 GPC（取众数）
            tpc_gpc = int(np.bincount(gpc_ids[mask]).argmax())
            tpc_stats[f"TPC{t}"] = {
                "gpc": tpc_gpc,
                "sm_count": int(mask.sum()),
                "mean_cycles": float(tpc_sm_avg.mean()),
                "min_cycles": float(tpc_sm_avg.min()),
                "max_cycles": float(tpc_sm_avg.max()),
                "spread_cycles": float(tpc_sm_avg.max() - tpc_sm_avg.min()),
                "sm_term_mean": float(tpc_a.mean()),                            # 加性模型中该 TPC 的 SM 独立延迟项均值
                "sm_ids": np.where(mask)[0].tolist(),
            }

    stats = {
        "device_clock_ghz": ghz,                                        # GPU 核心频率
        "n_sm": int(n_sm),                                              # 被测量的物理 SM 总数
        "n_slice_probes": int(n_slice),                                 # 测试中扫描了不同的地址偏移（probe）来采样 L2 Slice，不等于物理 Slice 数
        "rep_std_cycles": rep_std,                                      # 重复测量间的标准差。值越小说明测量越稳定，噪声越小
        "latency_cycles": {
            # 所有 SM-Slice 组合中，最快、最慢和平均的的 L2 命中延迟
            "min": float(M.min()), 
            "max": float(M.max()), 
            "mean": mu,   
            # 延迟跨度
            "spread": float(M.max() - M.min()),                         
            "spread_pct": float(100 * (M.max() - M.min()) / M.min()),   
        },
        "latency_ns": {
            "min": float(M.min() / clock_khz * 1e6),                    
            "max": float(M.max() / clock_khz * 1e6),
            "spread": float((M.max() - M.min()) / clock_khz * 1e6),
        },
        "per_sm_avg_cycles": {
            "min": float(per_sm_avg.min()), 
            "max": float(per_sm_avg.max()),
            "spread": float(per_sm_avg.max() - per_sm_avg.min()),
            "spread_pct": float(100 * (per_sm_avg.max() - per_sm_avg.min()) / per_sm_avg.min()),
        },
        "additive_model": {
            "r2": float(r2),                                            # Additive NUCA 模型拟合度，越接近 1 说明建模越精准
            "sm_term_range": float(a.max() - a.min()),                  # SM 位置效应导致的延迟跨度
            "slice_term_range": float(b.max() - b.min()),               # Slice 位置效应导致的延迟跨度
            "resid_std": float(resid.std()),                            # 模型残差标准差。越小说明 SM 与 Slice 之间几乎没有
                                                                        # 复杂交互，延迟就是简单的距离叠加
        },
        "two_fold_symmetry": {
            "split_smid": int(best_split),                              # 芯片被分为 2 个对称半区，每区 split_smid 个 SM
            "half_correlation": float(best_r),                          # 两半区的延迟轮廓的相关性。越接近 1 证明芯片具有严格
                                                                        # 的二重对称性
            "pair_mean_abs_diff_cycles": pair_absdiff,                  # 两半区对应位置 SM 的延迟项平均差异
            "within_half_gradient_r": grad_r,                           # 半区内部，SM 位置越靠后（index 越大），延迟项的变
                                                                        # 化。如果为负，说明 SM 位置越靠后，越远离该半区 L2 
                                                                        # 接入点；如果为正，说明 SM 位置越靠后，越接近该半区 
                                                                        # L2 接入点
        },
        "cross_experiment_r": cross_r,                                  # single 模式与 chain 模式测得的 per-SM 平均延迟。
                                                                        # 越接近 1 说明方法越可靠
        "chain_per_sm_spread_cycles": chain_spread,                     # Chain 模式独立验证的 SM 延迟跨度
        "slice_interleave_period_lines": (int(period) if period else None),         # 通过自相关分析，Slice 延迟模式每 period 
                                                                                    # 个 cacheline 重复一次。这可以用于推断
                                                                                    # 地址到 Slice 的映射/交错粒度
        "slice_interleave_period_bytes": (int(period) * 128 if period else None),
        "autocorr_significant_peaks": {                                 # 所有超出 95% 置信带的显著峰值
            "conf_level": float(conf_level),                            # 使用的 95% Bartlett 置信带上界
            "n_peaks": len(significant_peaks),                          # 显著峰值总数
            "peaks": significant_peaks,                                 # 峰值 lag 列表
            "ac_values": [float(ac[k]) for k in significant_peaks],     # 对应自相关值
            "spacings": peak_spacings,                                  # 相邻峰值间距
            "is_equally_spaced": is_equally_spaced,                     # 前 3 个间距是否一致（强周期性证据）
        },
        "side_channel": {
            "distinguishable_classes_5sigma": int(classes),  # 在 5 倍测量噪声的严格阈值下，所有 SM 可分为 classes 个可区分的
                                                             # 延迟类别
            "bits_5sigma": float(np.log2(classes)),          # 攻击者通过延迟测量可获取约 bits_5sigma 比特的 SM 身份信息
            "levels_half_cycle_bins": int(binned),           # 按 0.5 cycle 粒度分箱，有 levels_half_cycle_bins 个不同的延迟级别
            "bits_half_cycle_bins": float(np.log2(binned)),  # 对应约 bits_half_cycle_bins 比特信息泄露
        },
        "fastest_sm_ids": order[:6].tolist(),                                       # 物理上最靠近 L2 接入点的 6 个 SM

        "fastest_sm_cycles": [round(float(per_sm_avg[i]), 1) for i in order[:6]],   
        "slowest_sm_ids": order[-6:].tolist(),                                      # 物理上最远离 L2 接入点的 6 个 SM

        "slowest_sm_cycles": [round(float(per_sm_avg[i]), 1) for i in order[-6:]],

        # GPC/TPC 拓扑信息
        "gpc_topology": {
            "n_gpc": args.gpcs,
            "n_tpc": args.tpcs,
            "mapping_confidence": mapping_confidence,           # 映射推断置信度
            "gpc_stats": gpc_stats,
            "tpc_stats": tpc_stats,
        } if args.gpcs and args.tpcs else None,
    }
    # 将统计结果写入 JSON
    (args.processed / "topology_stats.json").write_text(
        json.dumps(stats, indent=2) + "\n", encoding="utf-8")

    # 导出 per-SM 汇总表。
    with (args.processed / "topology_per_sm.csv").open("w", newline="", encoding="utf-8") as handle:
        w = csv.writer(handle)
        headers = ["smid",             # 物理 SM 编号
                   "mean_cycles",      # 该 SM 访问扫描了不同的地址偏移（probe）的平均延迟
                   "min_cycles",       # 该 SM 访问最近 Slice 的延迟
                   "max_cycles",       # 该 SM 访问最远 Slice 的延迟
                   "sm_term_cycles",   # 加性模型分解出的 SM 独立延迟项 a(sm) （已扣除全局均值和 Slice 效应）
                   "half"]             # 所属半区：0 = 第一半区，1 = 第二半区
        # 如果提供了 GPC/TPC 信息，追加列
        if args.gpcs and args.tpcs:
            headers += ["gpc", "tpc"]
        w.writerow(headers)

        for s in range(n_sm):
            row = [s, round(float(per_sm_avg[s]), 3),
                   round(float(M[s].min()), 3), round(float(M[s].max()), 3),
                   round(float(a[s]), 3), 0 if s < best_split else 1]
            if args.gpcs and args.tpcs:
                row += [int(gpc_ids[s]), int(tpc_ids[s])]
            w.writerow(row)

    # ---- 图 1：per-SM 延迟与二重对称性 ----
    fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(10.2, 3.7))
    # 子图 (a)：per-SM 平均延迟曲线，虚线标出最佳二重对称切分点
    ax0.plot(np.arange(n_sm), per_sm_avg, lw=1.0, color="tab:blue")
    ax0.axvline(best_split - 0.5, color="0.4", ls="--", lw=1.0)
    ax0.set_xlabel("Physical SM identifier")
    ax0.set_ylabel("Mean L2-hit latency (cycles)")
    ax0.set_title("(a) Latency by physical SM")
    ax0.grid(True, alpha=0.24)
    ax0.annotate(f"two halves of {best_split} SMs\n(profile correlation r={best_r:.3f})",
                 xy=(best_split - 0.5, per_sm_avg.max()), xytext=(6, -4),
                 textcoords="offset points", fontsize=7.5, va="top")
    # 子图 (b)：两个半区的 SM 延迟项 a(sm) 轮廓对比（实线=前半区，虚线=后半区）
    ax1.plot(np.arange(len(h1)), a[:best_split], lw=1.2, label="half 1 (SM 0..%d)" % (best_split - 1))
    ax1.plot(np.arange(n_sm - best_split), a[best_split:], lw=1.2, ls="--",
             label="half 2 (SM %d..%d)" % (best_split, n_sm - 1))
    ax1.set_xlabel("Position within half")
    ax1.set_ylabel("Per-SM latency term $a(\\mathrm{sm})$ (cycles)")
    ax1.set_title("(b) Two-fold symmetry of the SM term")
    ax1.grid(True, alpha=0.24)
    ax1.legend(fontsize=7.5, loc="upper right")
    fig.tight_layout()
    fig.savefig(args.figures / "topology_per_sm.pdf")
    fig.savefig(args.figures / "topology_per_sm.png", dpi=220)
    plt.close(fig)

    # ---- 图 2：SM × slice 延迟热图 ----
    # 热力图展示的是原始测量矩阵本身
    col_order = np.argsort(b)
    Msorted = M[order][:, col_order]
    fig, ax = plt.subplots(figsize=(7.4, 4.4))
    im = ax.imshow(Msorted, aspect="auto", origin="lower", cmap="viridis")
    ax.set_xlabel("L2 slice probe (sorted by slice latency term)")
    ax.set_ylabel("Physical SM (sorted by mean latency)")
    ax.set_title("L2-hit latency $L(\\mathrm{sm},\\mathrm{slice})$")
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Latency (cycles)")
    fig.tight_layout()
    fig.savefig(args.figures / "topology_heatmap.pdf")
    fig.savefig(args.figures / "topology_heatmap.png", dpi=220)
    plt.close(fig)

    # ---- 图 3：加性模型拟合 + 侧信道分析 ----
    fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(10.2, 3.7))
    # fit.ravel()：将加性模型拟合矩阵 fit（形状 n_sm × n_slice）展平为一维，作为 X 轴（模型预测值）。
    # M.ravel()：将实测延迟矩阵 M 展平，作为 Y 轴（真实测量值）。
    # ax0.plot([lo, hi], [lo, hi], color="0.3", lw=1.0)：画一条实测延迟矩阵测参考对角线
    ax0.scatter(fit.ravel(), M.ravel(), s=2, alpha=0.10, color="tab:purple",
                edgecolors="none")
    lo, hi = M.min(), M.max()
    ax0.plot([lo, hi], [lo, hi], color="0.3", lw=1.0)
    ax0.set_xlabel("Additive model $\\mu+a(\\mathrm{sm})+b(\\mathrm{slice})$ (cycles)")
    ax0.set_ylabel("Measured latency (cycles)")
    ax0.set_title("(a) Additive NUCA model ($R^2=%.4f$)" % r2)
    ax0.grid(True, alpha=0.24)
    # 子图 (b)：per-SM 平均延迟直方图（延迟谱），展示 SM 间延迟可分性
    ax1.hist(per_sm_avg, bins=40, color="tab:green", alpha=0.85)
    ax1.set_xlabel("Mean L2-hit latency per SM (cycles)")
    ax1.set_ylabel("Number of SMs")
    ax1.set_title("(b) Per-SM latency spectrum")
    ax1.grid(True, alpha=0.24)
    ax1.annotate("%d SMs span %.0f cycles;\n%d levels separable at 0.5 cyc"
                 % (n_sm, per_sm_avg.max() - per_sm_avg.min(), binned),
                 xy=(0.5, 0.92), xycoords="axes fraction", ha="center",
                 fontsize=7.5, va="top")
    fig.tight_layout()
    fig.savefig(args.figures / "topology_model.pdf")
    fig.savefig(args.figures / "topology_model.png", dpi=220)
    plt.close(fig)

    # ---- 图 4：slice 项自相关（交错周期检测） ----
    """
    作用：
        自相关分析的首要作用是证明 b(slice) 的波动来自固定的地址映射规则，而非随机噪声。
    原理：
    (1) 如果 b 是纯白噪声，那么 95% 的 lag 处的自相关值应该落在置信区间; 剩下 5 % 
        的点会随机随机超出置信区间。
    (2) 为什么 Lag 越大，自相关函数值会越小？这是因为计算 lag=k  的自相关时，实际参与
        运算的样本对只有 N-k  对。lag 越大，样本对越少，估计方差越大，但期望值趋于 0。
    """
    # 自相关在滞后 = 交错周期的整数倍处出现峰值，据此推断 L2 slice 的地址交错粒度。
    max_lag = min(len(ac) - 1, 60)          # 只画前 60 个滞后，覆盖 period 搜索范围
    lags = np.arange(max_lag + 1)

    fig, ax = plt.subplots(figsize=(7.4, 4.0))
    # 用 stem 更直观地展示离散滞后处的自相关强度
    markerline, stemlines, baseline = ax.stem(lags, ac[:max_lag + 1], basefmt=" ")
    plt.setp(stemlines, linewidth=1.0, color="tab:blue")
    plt.setp(markerline, markersize=3.5, color="tab:blue")

    # 视觉检验：红线画出 95% Bartlett 置信带（白噪声假设下，样本自相关函数的 95% 置信
    # 边界： ±1.96/√N）。超出该范围有 95 % 的把握不是白噪声。
    ax.axhline(conf_level, color="tab:red", ls="--", lw=1.0,
               label=f"95% CI upper bound (±1.96/√N = {conf_level:.3f})")
    ax.axhline(-conf_level, color="tab:red", ls="--", lw=1.0)
    ax.axhline(0.0, color="0.6", lw=0.8)
    # 保留旧阈值作为参考对比
    # ax.axhline(0.9, color="0.5", ls=":", lw=0.8, alpha=0.6, label="legacy threshold (0.9)")

    # 为避免标签重叠：其他显著峰值只画小圆点，不标具体数字。
    # 等间距的绿点本身就是周期性的视觉证据。
    for pk in significant_peaks:
        if pk <= max_lag and pk != period:  # period 单独用菱形高亮
            ax.plot(pk, ac[pk], "o", color="tab:green", ms=4, zorder=5, alpha=0.8)

    # 单独高亮检测到的第一个周期（绿色菱形），标注放在右侧避免遮挡
    if period is not None and period <= max_lag:
        ax.axvline(period, color="tab:green", ls="-.", lw=1.2, alpha=0.7)
        ax.plot(period, ac[period], "D", color="tab:green", ms=8, zorder=6,
                label=f"detected period = {period} lines ({period * 128} B)")
        # 将文字放在数据点右侧，避免与左侧密集 stem 重叠
        ax.annotate(f"period = {period}\n({period * 128} B)",
                    xy=(period, ac[period]),
                    xytext=(period + 15, ac[period] + 0.15),
                    fontsize=8, color="tab:green",
                    arrowprops=dict(arrowstyle="->", color="tab:green", lw=0.8),
                    bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.8, edgecolor="tab:green"))
    elif period is None:
        ax.annotate("no significant period detected",
                    xy=(0.5, 0.9), xycoords="axes fraction", ha="center",
                    fontsize=9, color="tab:red")

    # 在图例中说明绿色圆点的含义
    if significant_peaks:
        # 添加一个虚拟点用于图例
        ax.plot([], [], "o", color="tab:green", ms=4, label="significant peaks (95% CI)")

    ax.set_xlabel("Lag (in 128 B cache-line stride units)")
    ax.set_ylabel("Normalized autocorrelation of $b(\\mathrm{slice})$")
    ax.set_title("Slice-term autocorrelation: L2 interleave-period detection")
    ax.set_xlim(-0.5, max_lag + 0.5)
    ax.grid(True, alpha=0.24)
    ax.legend(fontsize=8, loc="upper right")
    fig.tight_layout()
    fig.savefig(args.figures / "topology_autocorr.pdf")
    fig.savefig(args.figures / "topology_autocorr.png", dpi=220)
    plt.close(fig)

    # --- Figure 5: 合并 GPC/TPC 分析到一张大图（6 个子图） ---
    # 不依赖 SM ID 顺序，基于聚类结果展示
    if args.gpcs and args.tpcs:
        tpc_per_gpc_counts = [
            sum(1 for t in range(args.tpcs) if tpc_stats[f"TPC{t}"]["gpc"] == g)
            for g in range(args.gpcs)
        ]
        tpc_per_gpc = max(tpc_per_gpc_counts)  # 用最大值撑开网格宽度，容纳 TPC 数较多的 GPC

        fig = plt.figure(figsize=(16, 22))
        gs = fig.add_gridspec(4, 2, hspace=0.35, wspace=0.25)

        # 为每个 GPC 从 tab10 离散色板中均匀取样一种颜色
        colors = plt.cm.tab10(np.linspace(0, 1, args.gpcs))

        # --- 子图 (0,0): SM 延迟散点图，按推断的 GPC 分色 ---
        # 不排序，直接按原始 smid 展示，颜色表示推断的 GPC
        ax00 = fig.add_subplot(gs[0, 0])
        for g in range(args.gpcs):
            mask = (gpc_ids == g)
            sm_indices = np.where(mask)[0]
            ax00.scatter(sm_indices, per_sm_avg[mask], s=25, color=colors[g],
                       label=f"GPC{g}", alpha=0.8, edgecolors='black', linewidth=0.3)
        ax00.set_xlabel("SM identifier (smid)")
        ax00.set_ylabel("Mean L2-hit latency (cycles)")
        ax00.set_title(f"(a) SM Latency by Inferred GPC\n(confidence={mapping_confidence:.2f})")
        ax00.grid(True, alpha=0.24)
        ax00.legend(fontsize=7, loc="upper right", ncol=2)

        # --- 子图 (0,1): GPC 延迟分布箱线图 ---
        ax01 = fig.add_subplot(gs[0, 1])
        gpc_data = [per_sm_avg[gpc_ids == g] for g in range(args.gpcs)]
        # 箱线图展示每个 GPC 内 SM 延迟分布：方块=均值，红点=离群值
        bp = ax01.boxplot(
            gpc_data,
            patch_artist=True,
            showmeans=True,
            meanprops=dict(
                marker='s',
                markerfacecolor='white',
                markeredgecolor='black',
                markersize=7,
                markeredgewidth=1.2
            ),
            flierprops=dict(
                marker='o',              # 圆点
                markerfacecolor='red',   # 填充红色
                markeredgecolor='red',   # 边框红色
                markersize=5,
                alpha=0.8
            )
        )
        ax01.set_xticklabels([f"GPC{g}" for g in range(args.gpcs)])
        for patch, color in zip(bp['boxes'], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        ax01.set_ylabel("Mean L2-hit latency (cycles)")
        ax01.set_title("(b) GPC Latency Distribution\n(box = SM spread within GPC)")
        ax01.grid(True, alpha=0.24, axis='y')

        # --- 子图 (1,0): Per-GPC 平均延迟柱状图 ---
        ax10 = fig.add_subplot(gs[1, 0])
        gpc_names = [f"GPC{g}" for g in range(args.gpcs)]
        gpc_means = [gpc_stats[f"GPC{g}"]["mean_cycles"] for g in range(args.gpcs)]
        gpc_mins = [gpc_stats[f"GPC{g}"]["min_cycles"] for g in range(args.gpcs)]
        gpc_maxs = [gpc_stats[f"GPC{g}"]["max_cycles"] for g in range(args.gpcs)]

        bars = ax10.bar(gpc_names, gpc_means, color=colors[:args.gpcs], alpha=0.85,
                        edgecolor='black', linewidth=0.5)
        for i, (mn, mx) in enumerate(zip(gpc_mins, gpc_maxs)):
            ax10.plot([i, i], [mn, mx], color='black', lw=1.5)
            ax10.plot([i-0.1, i+0.1], [mn, mn], color='black', lw=1.5)
            ax10.plot([i-0.1, i+0.1], [mx, mx], color='black', lw=1.5)

        ax10.set_ylabel("Mean L2-hit latency (cycles)")
        ax10.set_title("(c) Per-GPC Average Latency\n(lower = closer to L2 access point)")
        ax10.grid(True, alpha=0.24, axis='y')
        for bar, val in zip(bars, gpc_means):
            ax10.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.5,
                      f"{val:.1f}", ha='center', va='bottom', fontsize=8)

        # --- 子图 (1,1): Per-TPC 平均延迟柱状图 ---
        ax11 = fig.add_subplot(gs[1, 1])
        tpc_names = [f"TPC{t}" for t in range(args.tpcs)]
        tpc_means = [tpc_stats[f"TPC{t}"]["mean_cycles"] for t in range(args.tpcs)]
        tpc_gpcs = [tpc_stats[f"TPC{t}"]["gpc"] for t in range(args.tpcs)]
        tpc_colors = [colors[g] for g in tpc_gpcs]

        bars = ax11.bar(tpc_names, tpc_means, color=tpc_colors, alpha=0.85,
                        edgecolor='black', linewidth=0.3)
        ax11.set_ylabel("Mean L2-hit latency (cycles)")
        ax11.set_title("(d) Per-TPC Average Latency (colored by parent GPC)")
        ax11.grid(True, alpha=0.24, axis='y')

        # 在不同 GPC 的 TPC 交界处画灰色虚线分隔，便于按 GPC 分组阅读
        for g in range(1, args.gpcs):
            first_tpc_of_gpc = min([t for t in range(args.tpcs) if tpc_stats[f"TPC{t}"]["gpc"] == g])
            x_pos = first_tpc_of_gpc - 0.5
            ax11.axvline(x_pos, color='gray', ls='--', lw=0.8, alpha=0.6)

        # for g in range(args.gpcs):
        #     tpcs_in_gpc = [t for t in range(args.tpcs) if tpc_stats[f"TPC{t}"]["gpc"] == g]
        #     if tpcs_in_gpc:
        #         center = np.mean(tpcs_in_gpc)
        #         ax11.text(center, ax11.get_ylim()[1] * 0.95, f"GPC{g}",
        #                   ha='center', va='top', fontsize=8, fontweight='bold',
        #                   bbox=dict(boxstyle='round', facecolor=colors[g], alpha=0.3))

        plt.setp(ax11.xaxis.get_majorticklabels(), rotation=60, ha='right', fontsize=5)

        # --- 子图 (2,0): GPC 距离 L2 的色块图 ---
        ax20 = fig.add_subplot(gs[2, 0])
        for g in range(args.gpcs):
            mean_lat = gpc_stats[f"GPC{g}"]["mean_cycles"]
            # 将 GPC 平均延迟归一化到 [0,1]，映射到 RdYlGn_r 色板（红=远/高延迟，绿=近/低延迟）
            norm = (mean_lat - min(gpc_means)) / (max(gpc_means) - min(gpc_means) + 1e-9)
            rect_color = plt.cm.RdYlGn_r(norm)
            rect = plt.Rectangle((g, 0), 0.9, 1, facecolor=rect_color,
                                 edgecolor='black', linewidth=1.5)
            ax20.add_patch(rect)
            ax20.text(g + 0.45, 0.5, f"GPC{g}\n{mean_lat:.1f}",
                      ha='center', va='center', fontsize=9, fontweight='bold')

        ax20.set_xlim(-0.2, args.gpcs)
        ax20.set_ylim(-0.2, 1.3)
        ax20.set_xlabel("GPC Index (sorted by inferred cluster)")
        ax20.set_title("(e) GPC Distance to L2\n(red = far/high latency, green = close/low latency)")
        ax20.set_yticks([])
        ax20.set_xticks(np.arange(args.gpcs) + 0.45)
        ax20.set_xticklabels([f"GPC{g}" for g in range(args.gpcs)])

        sm = plt.cm.ScalarMappable(cmap=plt.cm.RdYlGn_r,
                                    norm=plt.Normalize(vmin=min(gpc_means), vmax=max(gpc_means)))
        sm.set_array([])
        cbar = fig.colorbar(sm, ax=ax20, orientation='vertical', pad=0.02, shrink=0.6)
        cbar.set_label("Latency (cycles)")

        # --- 子图 (2,1): TPC 距离 L2 的 2D 网格图 ---
        # 按 GPC 分组排列，每个 GPC 一行，内部按 TPC 延迟排序
        ax21 = fig.add_subplot(gs[2, 1])

        # 每个 GPC 占一行（y_pos 为行号），行内 TPC 按延迟从近到远（绿到红）排列
        y_pos = 0
        for g in range(args.gpcs):
            tpcs_in_gpc = [(t, tpc_stats[f"TPC{t}"]["mean_cycles"]) 
                           for t in range(args.tpcs) if tpc_stats[f"TPC{t}"]["gpc"] == g]
            tpcs_in_gpc.sort(key=lambda x: x[1])  # 按延迟排序

            for local_x, (t, mean_lat) in enumerate(tpcs_in_gpc):
                # 将 TPC 平均延迟归一化到 [0,1]，映射到 RdYlGn_r 色板（红=远，绿=近）
                norm = (mean_lat - min(tpc_means)) / (max(tpc_means) - min(tpc_means) + 1e-9)
                rect_color = plt.cm.RdYlGn_r(norm)
                rect = plt.Rectangle((local_x, y_pos), 0.9, 0.9, facecolor=rect_color,
                                       edgecolor='black', linewidth=0.5)
                ax21.add_patch(rect)
                ax21.text(local_x + 0.45, y_pos + 0.45, f"TPC{t}\n{mean_lat:.1f}",
                          ha='center', va='center', fontsize=5)
            y_pos += 1

        ax21.set_xlim(-0.2, tpc_per_gpc)
        ax21.set_ylim(-0.2, args.gpcs)
        ax21.set_xlabel("TPC Position within GPC (sorted by latency)")
        ax21.set_ylabel("GPC Index")
        ax21.set_title("(f) TPC Distance to L2 Grid\n(red = far, green = close)")
        ax21.set_yticks(np.arange(args.gpcs) + 0.45)
        ax21.set_yticklabels([f"GPC{g}" for g in range(args.gpcs)])
        ax21.set_xticks(np.arange(tpc_per_gpc) + 0.45)
        ax21.set_xticklabels([f"Rank{t}" for t in range(tpc_per_gpc)])

        sm2 = plt.cm.ScalarMappable(cmap=plt.cm.RdYlGn_r,
                                     norm=plt.Normalize(vmin=min(tpc_means), vmax=max(tpc_means)))
        sm2.set_array([])
        cbar2 = fig.colorbar(sm2, ax=ax21, orientation='vertical', pad=0.02, shrink=0.6)
        cbar2.set_label("Latency (cycles)")

        fig.suptitle(f"GPC/TPC Topology Analysis ({args.gpcs} GPCs, {args.tpcs} TPCs, {n_sm} SMs)\n"
                     f"Confidence = {mapping_confidence:.2f} | "
                     f"No SM-ID ordering assumption",
                     fontsize=12, fontweight='bold', y=0.98)

        # --- 子图 (3,0): 层次化布局 GPC → TPC → SM ---
        # 底部横跨两列，展示每个 GPC 内 TPC 的物理布局及所属 SM
        ax_new = fig.add_subplot(gs[3, :])

        for g in range(args.gpcs):
            tpcs_in_gpc = [(t, tpc_stats[f"TPC{t}"]["mean_cycles"], tpc_stats[f"TPC{t}"]["sm_ids"])
                           for t in range(args.tpcs) if tpc_stats[f"TPC{t}"]["gpc"] == g]
            tpcs_in_gpc.sort(key=lambda x: x[1])  # 按延迟排序

            for local_x, (t, mean_lat, sm_ids) in enumerate(tpcs_in_gpc):
                # 矩形颜色基于 TPC 平均延迟（归一化到 [0,1]，1e-9 防止除零）
                norm = (mean_lat - min(tpc_means)) / (max(tpc_means) - min(tpc_means) + 1e-9)
                rect_color = plt.cm.RdYlGn_r(norm)

                # 画 TPC 外框（细黑线）
                rect = plt.Rectangle((local_x, g), 0.95, 0.95,
                                     facecolor=rect_color, edgecolor='black', linewidth=0.8)
                ax_new.add_patch(rect)

                # 内部动态分块：每个 SM 一个子块，颜色按该 SM 自身延迟着色，高度按 SM 数量均分
                n_sm_in_tpc = len(sm_ids)
                sm_height = 0.95 / n_sm_in_tpc if n_sm_in_tpc > 0 else 0.95
                for sm_idx, sm in enumerate(sm_ids):
                    sm_lat = per_sm_avg[sm]
                    sm_norm = (sm_lat - min(per_sm_avg)) / (max(per_sm_avg) - min(per_sm_avg) + 1e-9)
                    sm_color = plt.cm.RdYlGn_r(sm_norm)
                    y_offset = g + sm_idx * sm_height
                    sm_rect = plt.Rectangle((local_x + 0.02, y_offset + 0.02), 0.91, sm_height - 0.03,
                                            facecolor=sm_color, edgecolor='gray', linewidth=0.2)
                    ax_new.add_patch(sm_rect)
                    # 标注 SM 编号，右侧追加该 SM 的平均延迟（cycles）
                    ax_new.text(local_x + 0.475, y_offset + sm_height / 2, f"SM{sm} {sm_lat:.1f}",
                                ha='center', va='center', fontsize=4.5, color='white' if sm_norm < 0.3 or sm_norm > 0.7 else 'black')

                # 在 TPC 矩形中央标注 TPC 编号，右侧追加其平均延迟（cycles，覆盖在 SM 块上方）
                ax_new.text(local_x + 0.475, g + 0.475, f"TPC{t} {mean_lat:.1f}",
                            ha='center', va='center', fontsize=6, fontweight='bold',
                            color='white' if norm < 0.3 or norm > 0.7 else 'black',
                            bbox=dict(boxstyle='round,pad=0.1', facecolor='black', alpha=0.35, edgecolor='none'))

        ax_new.set_xlim(-0.1, tpc_per_gpc)
        ax_new.set_ylim(-0.1, args.gpcs)
        ax_new.set_xlabel("TPC Position within GPC (sorted by latency, low→high)")
        ax_new.set_ylabel("GPC Index")
        ax_new.set_title("(g) Hierarchical Layout: GPC -> TPC -> SM\n"
                         "(outer frame = TPC avg latency; inner half-blocks = per-SM latency; "
                         "red = far from L2, green = close to L2)")
        ax_new.set_yticks(np.arange(args.gpcs) + 0.5)
        ax_new.set_yticklabels([f"GPC{g}" for g in range(args.gpcs)])
        ax_new.set_xticks(np.arange(tpc_per_gpc) + 0.5)
        ax_new.set_xticklabels([f"Rank{t}" for t in range(tpc_per_gpc)])

        # 添加全局颜色条（基于 SM 延迟范围）
        sm_global = plt.cm.ScalarMappable(cmap=plt.cm.RdYlGn_r,
                                           norm=plt.Normalize(vmin=min(per_sm_avg), vmax=max(per_sm_avg)))
        sm_global.set_array([])
        cbar_sm = fig.colorbar(sm_global, ax=ax_new, orientation='vertical', pad=0.01, shrink=0.5, aspect=15)
        cbar_sm.set_label("Per-SM latency (cycles)")

        fig.savefig(args.figures / "topology_gpc_tpc_combined.pdf")
        fig.savefig(args.figures / "topology_gpc_tpc_combined.png", dpi=220)
        plt.close(fig)

    print(json.dumps(stats, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())