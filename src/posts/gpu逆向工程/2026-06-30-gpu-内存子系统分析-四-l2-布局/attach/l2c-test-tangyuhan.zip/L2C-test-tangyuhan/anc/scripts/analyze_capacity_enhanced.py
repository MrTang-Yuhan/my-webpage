#!/usr/bin/env python3
"""汇总 pointer-chase 容量扫描结果并绘制 L2 容量转折曲线。

输入是 `l2_latency` 生成的 CSV，输出为聚合后的 CSV、PDF 和 PNG。

所有曲线合成单张多子图大图：
  - 第 1 行：总览图（所有 mode 与 stride 叠放）
  - 第 2 行起：按 prefetch_mode 分图（每个子图展示该 mode 下不同 stride)
  - 随后：按 line_bytes 分图（每个子图展示该 stride 下不同 mode）

得出的结论是：预取粒度修饰符对 L2 容量边界没有影响。
  - 容量拐点 (midpoint) 在四种预取粒度下几乎不变。
  - 绝对延迟上，预取粒度几乎没有影响。
  - 此外，如果预取粒度修饰符是强制的（比如256B），那么 tag 阵列会消耗的很快，预取粒度越大，拐点应该越左移。
"""

from __future__ import annotations

import argparse
import csv
import pathlib
import statistics
from collections import defaultdict

import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt


def main() -> int:
    """脚本的命令行入口函数。

    Returns:
        进程退出码，0 表示成功。
    """
    # argparse.ArgumentParser：创建命令行参数解析器，自动处理 --help 并生成 usage 信息。
    parser = argparse.ArgumentParser()
    # type=pathlib.Path：将命令行输入字符串自动转换为 Path 对象，支持跨平台路径语义。
    parser.add_argument("csv_path", type=pathlib.Path)
    # --processed：非图片输出目录，CSV 文件将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--processed", required=True, type=pathlib.Path)
    # --figures：图片输出目录，PDF/PNG 将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--figures", required=True, type=pathlib.Path)
    args = parser.parse_args()

    # 从输入 CSV 文件名提取主干（stem），用于命名输出文件。
    # pathlib.Path.stem：返回去掉最后一个后缀的文件名，如 "capacity_pilot.csv" → "capacity_pilot"。
    output_stem = args.csv_path.stem

    # 聚合键保留实验条件 (prefetch_mode, line_bytes, footprint_mib)，
    # 值列表保存重复测量值，用于后续计算 median/min/max。
    # defaultdict(list)：collections 模块中的 dict 子类，访问缺失键时自动调用 list() 创建默认值，
    # 避免手动检查键是否存在。
    groups: dict[tuple[str, int, float], list[float]] = defaultdict(list)
    # csv.DictReader：以字典形式读取 CSV，每行映射为 dict，键来自首行表头。
    with args.csv_path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            mode = row.get("prefetch_mode", "default")
            key = (mode, int(row["line_bytes"]), float(row["footprint_mib"]))
            groups[key].append(float(row["cycles_per_access"]))

    # 对每个实验条件计算统计量：中位数、最小值、最大值。
    summaries = []
    for (mode, line_bytes, footprint_mib), values in sorted(groups.items()):
        summaries.append(
            {
                "prefetch_mode": mode,
                "line_bytes": line_bytes,
                "footprint_mib": footprint_mib,
                "repetitions": len(values),
                # statistics.median：返回数据的中位数（中间值）。
                # 数据点为奇数时返回中间值；为偶数时返回两个中间值的算术平均。
                "median_cycles": statistics.median(values),
                "min_cycles": min(values),
                "max_cycles": max(values),
            }
        )

    # pathlib.Path.mkdir：递归创建目录（parents=True），若目录已存在不报错（exist_ok=True）。
    # 创建 --processed 目录，CSV 将写入此目录。
    args.processed.mkdir(parents=True, exist_ok=True)
    # 构造 CSV 完整路径：目录 / 输入文件名主干 + .csv
    summary_path = args.processed / f"{output_stem}.csv"
    # csv.DictWriter：以字典形式写入 CSV，fieldnames 指定列顺序。
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)

    # 标记样式映射：不同 prefetch_mode 使用不同 marker，便于图例区分。
    markers = {"default": "o", "64B": "s", "128B": "^", "256B": "D"}

    # ------------------------------------------------------------------
    # 准备数据：提取所有唯一 mode 与 stride
    # ------------------------------------------------------------------
    modes = sorted({row["prefetch_mode"] for row in summaries})
    strides = sorted({row["line_bytes"] for row in summaries})
    n_modes = len(modes)
    n_strides = len(strides)

    # ------------------------------------------------------------------
    # 布局：3 列，总览图占第 1 行整行；mode 图占随后行；stride 图占最后行
    # ------------------------------------------------------------------
    ncols = 3
    # 向上取整：计算容纳所有 mode/stride 子图所需的行数。
    nrows_mode = (n_modes + ncols - 1) // ncols
    nrows_stride = (n_strides + ncols - 1) // ncols
    nrows = 1 + nrows_mode + nrows_stride
    fig = plt.figure(figsize=(3.3 * ncols, 2.8 * nrows))
    gs = gridspec.GridSpec(nrows, ncols, figure=fig, hspace=0.38, wspace=0.28)

    # ---------- 子图 0：总览图（跨第 1 行所有列）----------
    # gs[0, :] 选取第 0 行的全部列，形成跨列子图。
    ax0 = fig.add_subplot(gs[0, :])
    for (mode, line_bytes) in sorted(
        {(row["prefetch_mode"], row["line_bytes"]) for row in summaries}
    ):
        rows = [
            row
            for row in summaries
            if row["prefetch_mode"] == mode and row["line_bytes"] == line_bytes
        ]
        rows.sort(key=lambda row: row["footprint_mib"])
        label = f"{mode}, stride {line_bytes} B"
        ax0.plot(
            [row["footprint_mib"] for row in rows],
            [row["median_cycles"] for row in rows],
            marker=markers.get(mode, "o"),
            markersize=3.6,
            linewidth=1.25,
            label=label,
        )
    ax0.set_xlabel("Address-span footprint (MiB)")
    ax0.set_ylabel("Dependent-load latency (cycles)")
    ax0.set_title("Overview")
    ax0.grid(True, alpha=0.22)
    ax0.legend(frameon=False, fontsize=6, ncol=2)

    # ---------- 子图 1..n_modes：按 prefetch_mode 分图 ----------
    for idx, mode in enumerate(modes):
        r = 1 + idx // ncols
        c = idx % ncols
        ax = fig.add_subplot(gs[r, c])
        strides_in_mode = sorted(
            {row["line_bytes"] for row in summaries if row["prefetch_mode"] == mode}
        )
        for lb in strides_in_mode:
            rows = [
                row
                for row in summaries
                if row["prefetch_mode"] == mode and row["line_bytes"] == lb
            ]
            rows.sort(key=lambda row: row["footprint_mib"])
            ax.plot(
                [row["footprint_mib"] for row in rows],
                [row["median_cycles"] for row in rows],
                marker="o",
                markersize=3.6,
                linewidth=1.25,
                label=f"stride {lb} B",
            )
        ax.set_xlabel("Footprint (MiB)")
        ax.set_ylabel("Latency (cycles)")
        ax.set_title(f"mode = {mode}")
        ax.grid(True, alpha=0.22)
        ax.legend(frameon=False, fontsize=6)

    # ---------- 子图 n_modes+1..：按 line_bytes 分图 ----------
    base_row = 1 + nrows_mode
    for idx, lb in enumerate(strides):
        r = base_row + idx // ncols
        c = idx % ncols
        ax = fig.add_subplot(gs[r, c])
        modes_in_stride = sorted(
            {row["prefetch_mode"] for row in summaries if row["line_bytes"] == lb}
        )
        for mode in modes_in_stride:
            rows = [
                row
                for row in summaries
                if row["prefetch_mode"] == mode and row["line_bytes"] == lb
            ]
            rows.sort(key=lambda row: row["footprint_mib"])
            ax.plot(
                [row["footprint_mib"] for row in rows],
                [row["median_cycles"] for row in rows],
                marker=markers.get(mode, "o"),
                markersize=3.6,
                linewidth=1.25,
                label=f"{mode}",
            )
        ax.set_xlabel("Footprint (MiB)")
        ax.set_ylabel("Latency (cycles)")
        ax.set_title(f"stride = {lb} B")
        ax.grid(True, alpha=0.22)
        ax.legend(frameon=False, fontsize=6)

    # 创建 --figures 目录，图片将写入此目录。
    args.figures.mkdir(parents=True, exist_ok=True)
    # 构造图片完整路径：目录 / 输入文件名主干 + .pdf / .png
    figure_pdf = args.figures / f"{output_stem}.pdf"
    figure_png = args.figures / f"{output_stem}.png"

    # Figure.savefig：将图像保存到文件。PDF 为矢量格式，PNG 为位图格式。
    fig.savefig(figure_pdf)
    fig.savefig(figure_png, dpi=220)
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())