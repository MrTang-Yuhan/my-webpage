#!/usr/bin/env python3
"""
运行高 VRAM GPU 压力源并采样设备遥测。

输入是工作集大小、持续时间和设备号等配置，输出为 saturation CSV、telemetry log 与 
manifest。该脚本为稳定性实验提供可审计的持续负载记录。
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pathlib
import subprocess
import threading
import time


ROOT = pathlib.Path(__file__).resolve().parents[1]


def sha256_file(path: pathlib.Path) -> str:
    """Computes a streaming SHA-256 digest for a file.
    
    Args:
        path: 要纳入 manifest 的文件路径。
    
    Returns:
        十六进制 digest 字符串。"""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sample_telemetry(stop: threading.Event, path: pathlib.Path) -> None:
    """Samples GPU telemetry until the stop event is set.
    
    Args:
        stop: 线程间停止信号。
        path: 遥测 CSV 输出路径。
    
    Returns:
        None。"""
    # timestamp: 采样时刻（本地时间，精度到毫秒）
    # pstate: NVIDIA Performance State
    # gpu_util_percent: GPU 计算利用率（SM 活跃周期占比）
    # memory_util_percent: 显存带宽利用率（内存控制器活跃周期占比）	
    # memory_used_mib: 已分配显存（MiB）
    # memory_total_mib: 物理显存总量
    # sm_clock_mhz: SM 核心时钟频率
    # memory_clock_mhz: 显存等效时钟（GDDR7）
    # temperature_c: GPU 核心温度
    # power_w: 整卡功耗
    query = (
        "timestamp,pstate,utilization.gpu,utilization.memory,memory.used,"
        "memory.total,clocks.sm,clocks.mem,temperature.gpu,power.draw"
    )
    with path.open("w", encoding="utf-8") as output:
        output.write(
            "timestamp,pstate,gpu_util_percent,memory_util_percent,"
            "memory_used_mib,memory_total_mib,sm_clock_mhz,memory_clock_mhz,"
            "temperature_c,power_w\n"
        )
        # threading.Event 是线程间通信的简单机制；is_set() 检查内部标志是否被设置，
        # wait() 阻塞直到标志被设置或超时。cite🛠web_search:5#3:~:text=event = Event()...task() function call the wait() method of the event object, both t1 and t2 threads will wait for the event to be set before continuing.
        while not stop.is_set():
            completed = subprocess.run(
                [
                    "nvidia-smi",
                    f"--query-gpu={query}",
                    "--format=csv,noheader,nounits",
                ],
                check=True,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            output.write(completed.stdout)
            output.flush()
            # stop.wait(0.5) 阻塞 0.5 秒或直到 stop 事件被设置，实现约 2 Hz 的采样频率。
            stop.wait(0.5)


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=pathlib.Path)   # 该参数指向实验的 JSON 配置文件。
    parser.add_argument("--device", default=0, type=int)                # 该参数指定目标 CUDA 设备号。
    args = parser.parse_args()
    config_path = args.config.resolve()
    config = json.loads(config_path.read_text(encoding="utf-8"))

    subprocess.run(["make", "-j2"], cwd=ROOT, check=True)
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"{config['campaign']}_{timestamp}"
    run_dir = ROOT / "results" / "raw" / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    # Manifest 固化配置、源码 hash、环境和命令行，保证 raw 结果可追溯。
    manifest = {
        "schema_version": 1,
        "run_id": run_id,
        "started_utc": timestamp,
        "config": config,
        "config_sha256": sha256_file(config_path),
        "source_sha256": {
            "src/memory_saturation.cu": sha256_file(
                ROOT / "src" / "memory_saturation.cu"
            ),
            "scripts/run_saturation.py": sha256_file(pathlib.Path(__file__)),
        },
        "commands": [],
    }
    # 遍历所有参数配置
    for mode in config["modes"]:
        telemetry_path = run_dir / f"telemetry_{mode['name']}.csv"
        result_path = run_dir / f"saturation_{mode['name']}.csv"
        command = [
            str(ROOT / "build" / "memory_saturation"),
            str(config["working_set_gib"]),
            str(config["duration_seconds"]),
            str(mode["fma_iterations"]),
            str(args.device),
        ]

        # 使用独立遥测线程的核心原因是：CUDA 负载程序与 GPU 状态采样必须物理上**并发**执行，
        # 且采样过程不能侵入或阻塞被测程序。
        # threading.Event() 创建线程事件对象，用于主线程向采样线程发送停止信号。
        stop = threading.Event()    # 线程间 bool 信号
        # threading.Thread 创建新线程；target 指定线程执行的可调用对象，
        # args 传递位置参数，daemon=True 设为守护线程（主线程退出时自动终止）。cite🛠web_search:5#3:~:text=t1 = Thread(target=task, args=(event,1))...t1.start()
        sampler = threading.Thread(
            target=sample_telemetry, args=(stop, telemetry_path), daemon=True
        )
        sampler.start()

        # 运行 CUDA 负载
        # time.monotonic() 返回单调递增的秒数，不受系统时间调整影响，适合测量时间间隔。
        started = time.monotonic()
        try:
            with result_path.open("w", encoding="utf-8") as output:
                
                completed = subprocess.run(
                    command,
                    cwd=ROOT,
                    check=True,
                    text=True,
                    stdout=output,
                    stderr=subprocess.PIPE,
                )
        finally:
            # 无论 CUDA 负载是否成功，都设置停止事件并等待采样线程结束，
            # 防止采样线程无限循环或成为孤儿线程。
            stop.set()
            sampler.join(timeout=5)
        manifest["commands"].append(
            {
                "mode": mode["name"],
                "command": command,
                # time.monotonic() - started 计算 wall-clock 运行时长（秒）。
                "wall_seconds": time.monotonic() - started,
                "stderr": completed.stderr,
                "result_sha256": sha256_file(result_path),
                "telemetry_sha256": sha256_file(telemetry_path),
            }
        )

    manifest["completed_utc"] = dt.datetime.now(dt.timezone.utc).strftime(
        "%Y%m%dT%H%M%SZ"
    )
    (run_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(run_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())