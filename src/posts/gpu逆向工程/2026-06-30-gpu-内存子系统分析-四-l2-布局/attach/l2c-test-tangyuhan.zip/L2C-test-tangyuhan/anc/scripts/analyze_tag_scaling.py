#!/usr/bin/env python3
"""
证明 L2 缓存的容量边界是由"唯一 128B cache line 的 tag 数"决定的，
而不是由"分配的总字节数"决定的。
"""

# PEP 563: 推迟注解求值（Postponed Evaluation of Annotations）。
# 根据 Python 官方文档，from __future__ import annotations 使所有注解在运行时以字符串形式存储，
# 而非立即求值。这允许在类定义内部引用自身类型（前向引用），且显著提升模块导入速度。
from __future__ import annotations

import argparse
import csv
import pathlib
import statistics
from collections import defaultdict

import matplotlib.pyplot as plt


def interpolate_crossing(points: list[tuple[float, float]]) -> tuple[float, float]:
    """对延迟过渡曲线的中点交叉进行插值。

    Args:
        points: 按 x 递增排列的 `(x, latency)` 点序列。

    Returns:
        交叉点 x 坐标和阈值 latency。
    """

    # 对前 3 个点的 latency 取中位数，代表低延迟平台（L2 命中区）的基线。
    low = statistics.median(y for _, y in points[:3])       # 前 3 个元素 latency 值（低延迟）计算中位数
    # 对后 2 个点的 latency 取中位数，代表高延迟平台（DRAM 回退区）的基线。
    high = statistics.median(y for _, y in points[-2:])     # 后 2 个元素的 latency 值（高延迟）计算中位数
    threshold = (low + high) / 2.0                          # latency 阈值：低平台与高平台的中间值
    
    # zip(points, points[1:]) : 遍历相邻点对（adjacent pairs）。
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if y0 <= threshold <= y1 and y1 != y0:
            fraction = (threshold - y0) / (y1 - y0)
            return x0 + fraction * (x1 - x0), threshold     # 返回的 x_crossing 是拐点 footprint（MiB），threshold 是拐点 latency（cycles）
    raise RuntimeError("latency curve does not cross its midpoint")


def main() -> int:
    """脚本的命令行入口函数。

    Returns:
        进程退出码，0 表示成功。
    """
    # argparse.ArgumentParser : Python 标准库命令行参数解析器。
    parser = argparse.ArgumentParser()
    # 命令行参数描述当前实验的数据源、输出位置。
    parser.add_argument("csv_path", type=pathlib.Path)
    # --processed：非图片输出目录，CSV 文件将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--processed", required=True, type=pathlib.Path)
    # --figures：图片输出目录，PDF/PNG 将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--figures", required=True, type=pathlib.Path)
    args = parser.parse_args()

    # 从输入 CSV 文件名提取主干（stem），用于命名输出文件。
    # pathlib.Path.stem：返回去掉最后一个后缀的文件名，如 "capacity_pilot.csv" → "capacity_pilot"。
    output_stem = args.csv_path.stem

    # 聚合键保留实验条件，值列表保存重复测量以便报告 median/min/max。
    # defaultdict(lambda: defaultdict(list)) : 两层嵌套 defaultdict。
    # 外层 defaultdict 的 default_factory 是一个 lambda，返回另一个 defaultdict(list)。
    # 因此访问不存在的 stride 键时自动创建内层 defaultdict；
    # 访问不存在的 footprint 键时自动创建空 list。避免多层 KeyError 检查。
    groups: dict[int, dict[float, list[float]]] = defaultdict(
        lambda: defaultdict(list)
    )
    # Path.open(newline="") : 根据 csv 模块官方文档，必须传入空字符串以正确处理 CSV 中的换行符，
    # 防止在 Windows 平台上出现额外的空行。
    with args.csv_path.open(newline="", encoding="utf-8") as handle:
        # csv.DictReader : 将 CSV 文件的每一行读取为 OrderedDict，键来自首行表头。
        # 根据官方文档，它自动处理引号、转义和分隔符，比 csv.reader 更适合按列名访问数据。
        for row in csv.DictReader(handle):
            # 将 CSV 数据按 line_bytes → footprint_mib → cycles_per_access 列表 的三层嵌套结构组织
            groups[int(row["line_bytes"])][float(row["footprint_mib"])].append(
                float(row["cycles_per_access"])
            )

    curves: dict[int, list[tuple[float, float]]] = {}
    transitions = []
    # sorted(groups.items()) : 按 stride（line_bytes）升序排序，返回 (key, value) 列表。
    # 然后对结果按 footprint 升序排序，保证每个 curve 的点按 x 坐标递增排列。
    for stride, footprint_groups in sorted(groups.items()):
        points = sorted(
            (footprint, statistics.median(values))  # 中位数聚合多次测量的 cycles_per_access
            for footprint, values in footprint_groups.items()
        )
        curves[stride] = points
        crossing, threshold = interpolate_crossing(points)
        # tag_scale : 将原始 footprint 归一化为"等效 128B cache line 数"的缩放因子。
        # 若 stride ≤ 128B，每个节点至少对应一个 128B line，scale = 1.0（不缩小）；
        # 若 stride > 128B，每个节点跨越多个 128B line，scale = 128.0 / stride（按比例缩小）。
        tag_scale = min(1.0, 128.0 / stride)
        transitions.append(
            {
                "stride_bytes": stride,                         # 当前实验使用的 stride 大小，即微基准中的 line_bytes
                "midpoint_address_span_mib": crossing,          # 在原始 footprint 坐标下，latency curve 从低延迟平台过渡到
                                                                # 高延迟平台的拐点对应的 footprint 大小
                "midpoint_tag_equivalent_mib": crossing * tag_scale,    # 将原始拐点 footprint 归一化到"等效 128B cache 
                                                                        # line 数"后的值
                "latency_midpoint_cycles": threshold,           # 拐点处的延迟值，即 threshold latency
            }
        )

    # pathlib.Path.mkdir：递归创建目录（parents=True），若目录已存在不报错（exist_ok=True）。
    # 创建 --processed 目录，CSV 将写入此目录。
    args.processed.mkdir(parents=True, exist_ok=True)
    # 构造 CSV 完整路径：目录 / 输入文件名主干 + .csv
    summary_path = args.processed / f"{output_stem}.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        # csv.DictWriter : 将字典列表写入 CSV 文件。
        # fieldnames 指定列顺序；writeheader() 写入表头；writerows() 批量写入数据行。
        writer = csv.DictWriter(handle, fieldnames=list(transitions[0]))
        writer.writeheader()
        writer.writerows(transitions)

    fig, (raw_ax, normalized_ax) = plt.subplots(1, 2, figsize=(10.4, 3.7))
    # 遍历每个 stride 的 curve 数据
    for stride, points in curves.items():
        raw_ax.plot(
            [x for x, _ in points],
            [y for _, y in points],
            marker="o",
            markersize=3.4,
            linewidth=1.2,
            label=f"{stride} B",
        )
        # 若 stride ≤ 128B，每个节点对应至少一个 128B cache line，
        # tag 等效 footprint 不缩小；若 stride > 128B，每个节点跨越
        # 多个 128B line，tag 等效 footprint 按比例缩小。
        scale = min(1.0, 128.0 / stride)
        normalized_ax.plot(
            [x * scale for x, _ in points],
            [y for _, y in points],
            marker="o",
            markersize=3.4,
            linewidth=1.2,
            label=f"{stride} B",
        )

    raw_ax.set_xlabel("Address-span footprint (MiB)")
    raw_ax.set_ylabel("Dependent-load latency (cycles)")
    raw_ax.set_title("(a) Raw address span")
   
    # normalized_ax.axvline(96, color="0.3", linestyle="--", linewidth=1)
    normalized_ax.set_xlabel("128-B tag-equivalent footprint (MiB)")
    normalized_ax.set_title("(b) Normalized unique-line footprint")
    for axis in (raw_ax, normalized_ax):
        axis.grid(True, alpha=0.22)
        axis.legend(title="Stride", frameon=False, fontsize=7, title_fontsize=7)
    fig.tight_layout()

    # 创建 --figures 目录，图片将写入此目录。
    args.figures.mkdir(parents=True, exist_ok=True)
    # 构造图片完整路径：目录 / 输入文件名主干 + .pdf / .png
    figure_pdf = args.figures / f"{output_stem}.pdf"
    figure_png = args.figures / f"{output_stem}.png"
    fig.savefig(figure_pdf)
    fig.savefig(figure_png, dpi=220)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())