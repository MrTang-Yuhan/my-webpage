#!/usr/bin/env python3
"""汇总 pointer-chase 容量扫描结果并绘制 L2 容量转折曲线。

输入是 `l2_latency` 生成的 CSV，输出为聚合后的 CSV、PDF 和 PNG。"""

from __future__ import annotations

import argparse
import csv
import pathlib
import statistics
from collections import defaultdict

import matplotlib.pyplot as plt


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    parser = argparse.ArgumentParser()
    # 命令行参数描述当前实验的数据源和输出位置
    parser.add_argument("csv_path", type=pathlib.Path)
    # --processed：非图片输出目录，CSV 文件将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--processed", required=True, type=pathlib.Path)
    # --figures：图片输出目录，PDF/PNG 将放在此目录下，文件名与输入 CSV 同名。
    parser.add_argument("--figures", required=True, type=pathlib.Path)
    args = parser.parse_args()

    # 从输入 CSV 文件名提取主干（stem），用于命名输出文件。
    # pathlib.Path.stem：返回去掉最后一个后缀的文件名，如 "capacity_pilot.csv" → "capacity_pilot"。
    output_stem = args.csv_path.stem

    # 聚合键保留实验条件，值列表保存重复测量以便报告 median/min/max。
    groups: dict[tuple[str, int, float], list[float]] = defaultdict(list)
    with args.csv_path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            mode = row.get("prefetch_mode", "default")
            key = (mode, int(row["line_bytes"]), float(row["footprint_mib"]))
            groups[key].append(float(row["cycles_per_access"]))

    summaries = []
    for (mode, line_bytes, footprint_mib), values in sorted(groups.items()):
        summaries.append(
            {
                "prefetch_mode": mode,
                "line_bytes": line_bytes,
                "footprint_mib": footprint_mib,
                "repetitions": len(values),
                "median_cycles": statistics.median(values),
                "min_cycles": min(values),
                "max_cycles": max(values),
            }
        )

    # pathlib.Path.mkdir：递归创建目录（parents=True），若目录已存在不报错（exist_ok=True）。
    # 创建 --processed 目录，CSV 将写入此目录。
    args.processed.mkdir(parents=True, exist_ok=True)
    # 构造 CSV 完整路径：目录 / 输入文件名主干 + .csv
    summary_path = args.processed / f"{output_stem}.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)

    fig, ax = plt.subplots(figsize=(6.6, 3.7))
    markers = {"default": "o", "64B": "s", "128B": "^", "256B": "D"}
    for (mode, line_bytes) in sorted(
        {(row["prefetch_mode"], row["line_bytes"]) for row in summaries}
    ):
        rows = [
            row
            for row in summaries
            if row["prefetch_mode"] == mode and row["line_bytes"] == line_bytes
        ]
        rows.sort(key=lambda row: row["footprint_mib"])
        label = f"{mode}, stride {line_bytes} B"
        ax.plot(
            [row["footprint_mib"] for row in rows],
            [row["median_cycles"] for row in rows],
            marker=markers.get(mode, "o"),
            markersize=3.6,
            linewidth=1.25,
            label=label,
        )

    # ax.axvline(96, color="0.35", linestyle="--", linewidth=1, label="Nominal L2")
    ax.set_xlabel("Address-span footprint (MiB)")
    ax.set_ylabel("Dependent-load latency (cycles)")
    ax.grid(True, alpha=0.22)
    ax.legend(frameon=False, fontsize=7, ncol=2)
    fig.tight_layout()

    # 创建 --figures 目录，图片将写入此目录。
    args.figures.mkdir(parents=True, exist_ok=True)
    # 构造图片完整路径：目录 / 输入文件名主干 + .pdf / .png
    figure_pdf = args.figures / f"{output_stem}.pdf"
    figure_png = args.figures / f"{output_stem}.png"
    fig.savefig(figure_pdf)
    fig.savefig(figure_png, dpi=220)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())