#!/usr/bin/env python3
"""运行带 manifest 的 L2 hot-set retention campaign。

输入是 retention 配置和设备号，输出为 `l2_retention.csv` 与 manifest。该脚本遍历 
policy、hot set 和 cold stream 条件，记录污染前后的设备遥测。

"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pathlib
import shlex
import subprocess


# pathlib.Path(__file__) 获取当前脚本路径；resolve() 返回绝对路径并解析符号链接；
# parents[1] 获取祖父目录（即仓库根目录）。cite🛠web_search:5#24:~:text=上级目录|os.path.dirname|PurePath.parent
ROOT = pathlib.Path(__file__).resolve().parents[1]


def run(command: list[str], capture: bool = True) -> subprocess.CompletedProcess[str]:
    """Runs a subprocess in the artifact root and optionally captures output.
    
    Args:
        command: 命令和参数列表。
        cwd: 工作目录；默认是仓库根目录。
        capture: 为 true 时捕获 stdout/stderr，便于写入 manifest。
    
    Returns:
        `subprocess.CompletedProcess`，调用失败时抛出异常。"""
    # subprocess.run 是 Python 推荐的子进程调用方式；check=True 时若命令返回非零退出码
    # 则抛出 CalledProcessError。text=True 以文本模式处理流，stdout/stderr 返回字符串。
    # stdout=subprocess.PIPE 捕获标准输出。cite🛠web_search:5#26:~:text=Run the command described by args. Wait for command to complete, then return a CompletedProcess instance.
    return subprocess.run(
        command,
        cwd=ROOT,
        check=True,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
    )


def sha256_file(path: pathlib.Path) -> str:
    """Computes a streaming SHA-256 digest for a file.
    
    Args:
        path: 要纳入 manifest 的文件路径。
    
    Returns:
        十六进制 digest 字符串。"""
    # hashlib.sha256() 创建 SHA-256 哈希对象；update() 逐块更新数据；
    # hexdigest() 返回十六进制摘要字符串。cite🛠web_search:5#20:~:text=m = hashlib.sha256()...m.update(b"Nobody inspects")...m.hexdigest()
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        # iter(callable, sentinel) 重复调用 callable 直到返回值等于 sentinel；
        # 此处每次读取 1 MiB，直到读到空字节串（文件末尾）。
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def telemetry() -> str:
    """Captures the current GPU telemetry used around benchmark runs.
    
    Returns:
        nvidia-smi 输出字符串或可写入 manifest 的结构。"""
    command = [
        "nvidia-smi",
        "--query-gpu=timestamp,pstate,clocks.sm,clocks.mem,temperature.gpu,"
        "power.draw",
        "--format=csv,noheader,nounits",
    ]
    return run(command).stdout.strip()


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    parser = argparse.ArgumentParser()
    # 命令行参数描述当前实验的数据源、输出位置和目标 CUDA 设备。
    parser.add_argument("--config", required=True, type=pathlib.Path)
    parser.add_argument("--device", default=0, type=int)
    args = parser.parse_args()

    # resolve() 返回路径的绝对路径形式，解析所有符号链接。
    config_path = args.config.resolve()
    # json.loads 将 JSON 字符串反序列化为 Python 对象。cite🛠web_search:6#4:~:text=json.loads('["foo", {"bar":["baz", null, 1.0, 2]}]')
    config = json.loads(config_path.read_text(encoding="utf-8"))
    # datetime.now(timezone.utc) 获取带时区信息的 UTC 当前时间；
    # strftime 按指定格式格式化为字符串。cite🛠web_search:6#0:~:text=datetime.now(timezone.utc)...strftime
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"{config['campaign']}_{timestamp}"
    run_dir = ROOT / "results" / "raw" / run_id
    # mkdir(parents=True, exist_ok=False) 递归创建目录；若目录已存在则抛出 FileExistsError，
    # 防止意外覆盖已有实验结果。
    run_dir.mkdir(parents=True, exist_ok=False)
    # capture=False 将子进程输出直接打印到终端，便于实时观察编译进度。
    run(["make", "-j2"], capture=False)

    # Manifest 固化配置、源码 hash、环境和命令行，保证 raw 结果可追溯。
    manifest = {
        "schema_version": 1,
        "run_id": run_id,
        "started_utc": timestamp,
        "config": config,
        "config_sha256": sha256_file(config_path),
        "source_sha256": {
            "src/l2_retention.cu": sha256_file(ROOT / "src" / "l2_retention.cu"),
            "scripts/run_retention.py": sha256_file(pathlib.Path(__file__)),
            "Makefile": sha256_file(ROOT / "Makefile"),
        },
        "commands": [],
    }

    csv_path = run_dir / "l2_retention.csv"
    header_written = False
    condition_index = 0
    hot_values = config["hot_mib"]
    if not isinstance(hot_values, list):
        hot_values = [hot_values]

    with csv_path.open("w", encoding="utf-8") as output:
        for policy in config["policies"]:
            for hot_mib in hot_values:
                for cold_mib in config["cold_mib"]:
                    seed = int(config["seed"]) + condition_index
                    condition_index += 1
                    command = [
                        str(ROOT / "build" / "l2_retention"),
                        str(hot_mib),
                        str(cold_mib),
                        str(config["line_bytes"]),
                        str(config["probe_accesses"]),
                        str(config["repetitions"]),
                        str(seed),
                        str(args.device),
                        policy["name"],
                        str(policy["setaside_mib"]),
                        str(policy["hit_ratio"]),
                    ]
                    # shlex.join 将命令列表安全地拼接为 shell 命令字符串，
                    # 正确处理包含空格或特殊字符的参数。
                    print("+", shlex.join(command), flush=True)
                    before = telemetry()
                    completed = run(command)
                    after = telemetry()
                    lines = completed.stdout.splitlines()
                    if not header_written:
                        output.write(lines[0] + "\n")
                        header_written = True
                    for line in lines[1:]:
                        output.write(line + "\n")
                    output.flush()
                    manifest["commands"].append(
                        {
                            "command": command,
                            "seed": seed,
                            "telemetry_before": before,
                            "telemetry_after": after,
                            "stderr": completed.stderr,
                        }
                    )

    manifest["completed_utc"] = dt.datetime.now(dt.timezone.utc).strftime(
        "%Y%m%dT%H%M%SZ"
    )
    manifest["output_sha256"] = sha256_file(csv_path)
    (run_dir / "manifest.json").write_text(
        # sort_keys=True 按键名排序输出，保证 manifest 的确定性（相同内容产生相同字节）。
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(run_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())