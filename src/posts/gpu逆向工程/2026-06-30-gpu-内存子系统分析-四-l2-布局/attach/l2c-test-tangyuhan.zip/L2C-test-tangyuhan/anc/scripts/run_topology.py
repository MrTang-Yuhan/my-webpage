#!/usr/bin/env python3
"""运行带完整 manifest 的 per-SM L2 topology 测量任务。

输入为拓扑配置和设备号，输出 single、chain 或 fingerprint 模式的 CSV 与 manifest。
该脚本负责执行每个 probe sweep，并将硬件与源码 hash 写入结果目录。"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import platform
import shlex
import subprocess
import sys
from typing import Any

# pathlib.Path(__file__) 获取当前脚本路径；resolve() 返回绝对路径并解析符号链接；
# parents[1] 获取祖父目录。
ROOT = pathlib.Path(__file__).resolve().parents[1]


def run(command: list[str], *, cwd: pathlib.Path = ROOT,
        capture: bool = True) -> subprocess.CompletedProcess[str]:
    """在仓库根目录下运行子进程，可选捕获输出。

    Args:
        command: 命令及其参数列表。
        cwd: 工作目录；默认为仓库根目录。
        capture: 为 True 时捕获 stdout/stderr，便于写入 manifest。

    Returns:
        `subprocess.CompletedProcess` 对象；调用失败时抛出异常。
    """
    # subprocess.run 是 Python 3.5+ 推荐的子进程调用方式；check=True 时若命令返回非零
    # 退出码则抛出 CalledProcessError。text=True 以文本模式处理流。
    return subprocess.run(
        command, cwd=cwd, check=True, text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
    )


def sha256_file(path: pathlib.Path) -> str:
    """以流式方式计算文件的 SHA-256 摘要。

    Args:
        path: 待纳入 manifest 的文件路径。

    Returns:
        十六进制 digest 字符串。
    """
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def command_output(command: list[str]) -> dict[str, Any]:
    """运行诊断命令并将其结果序列化。

    Args:
        command: 诊断命令及其参数。

    Returns:
        包含 command、returncode、stdout、stderr 或 error 的字典。
    """
    try:
        completed = run(command)
        return {"command": command, "returncode": completed.returncode,
                "stdout": completed.stdout, "stderr": completed.stderr}
    except (FileNotFoundError, subprocess.CalledProcessError) as error:
        return {"command": command, "error": repr(error)}


def telemetry() -> dict[str, Any]:
    """采集 benchmark 运行前后的 GPU 遥测数据。

    Returns:
        nvidia-smi 输出字符串，或可直接写入 manifest 的结构化数据。
    """
    return command_output([
        "nvidia-smi",
        "--query-gpu=timestamp,pstate,clocks.sm,clocks.mem,temperature.gpu,"
        "power.draw,utilization.gpu",
        "--format=csv,noheader,nounits",
    ])


def build_command(run_cfg: dict[str, Any], device: int) -> list[str]:
    """根据单条拓扑配置构造 `l2_topology` 命令行。

    Args:
        run_cfg: 单条拓扑运行配置。
        device: CUDA 设备号。

    Returns:
        可直接传给 subprocess 的命令列表。
    """
    binary = str(ROOT / "build" / "l2_topology")
    mode = run_cfg["mode"]
    if mode == "single":
        return [binary, "single", str(run_cfg["arena_mib"]),
                str(run_cfg["offset_start_bytes"]),
                str(run_cfg["offset_step_bytes"]),
                str(run_cfg["offset_count"]), str(run_cfg["warm"]),
                str(run_cfg["measured"]), str(run_cfg["reps"]),
                str(run_cfg["seed"]), str(device)]
    if mode == "chain":
        return [binary, "chain", str(run_cfg["footprint_mib"]),
                str(run_cfg["line_bytes"]), str(run_cfg["warm"]),
                str(run_cfg["measured"]), str(run_cfg["reps"]),
                str(run_cfg["seed"]), str(device)]
    if mode == "fingerprint":
        return [binary, "fingerprint", str(run_cfg["arena_mib"]),
                str(run_cfg["offset_start_bytes"]),
                str(run_cfg["offset_step_bytes"]), str(run_cfg["n_probes"]),
                str(run_cfg["warm"]), str(run_cfg["measured"]),
                str(run_cfg["shots"]), str(run_cfg["seed"]), str(device)]
    raise ValueError(f"unknown mode: {mode}")


def main() -> int:
    """命令行入口。

    Returns:
        进程退出码，0 表示成功。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=pathlib.Path)  # 指向实验 JSON 配置文件。
    parser.add_argument("--device", default=0, type=int)              # 指定目标 CUDA 设备号。
    args = parser.parse_args()

    config_path = args.config.resolve()
    config = json.loads(config_path.read_text(encoding="utf-8"))
    # UTC 时间戳，格式为 ISO-8601 基本格式（无分隔符），用于构造唯一运行 ID。
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"{config['campaign']}_{timestamp}"
    # 结果目录：results/raw/<run_id>/；parents=True 递归创建父目录，exist_ok=False 防止覆盖已有结果。
    run_dir = ROOT / "results" / "raw" / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    # 编译 CUDA 可执行文件 。
    run(["make", "-j2"], capture=False)

    # 采集设备静态信息（SM 数量、显存等）并落盘。
    device_info_path = run_dir / "device_info.json"
    device_info_path.write_text(
        run([str(ROOT / "build" / "device_info")]).stdout, encoding="utf-8")

    # 收集所有需要纳入 manifest 的源码路径，用于计算 hash 以保证结果可追溯。
    source_paths = sorted([
        ROOT / "Makefile", config_path,
        # Path.glob 返回匹配给定模式（*.cu）的路径生成器；sorted 排序保证确定性。
        *sorted((ROOT / "src").glob("*.cu")),
        pathlib.Path(__file__).resolve(),
    ])
    # Manifest 固化配置、源码 hash、环境信息和命令行，保证 raw 结果可复现、可追溯。
    manifest: dict[str, Any] = {
        "schema_version": 1, "run_id": run_id, "started_utc": timestamp,
        "config": config, "config_path": str(config_path.relative_to(ROOT)),
        "device": args.device, "python": sys.version,
        "platform": platform.platform(), "uname": list(platform.uname()),
        "source_sha256": {str(p.relative_to(ROOT)): sha256_file(p)
                          for p in source_paths},
        "system_commands": {
            "nvidia_smi": command_output(["nvidia-smi", "-q"]),
            "nvidia_topology": command_output(["nvidia-smi", "topo", "-m"]),
            "nvcc_version": command_output(["nvcc", "--version"]),
            "lscpu_json": command_output(["lscpu", "-J"]),
        },
        "runs": [],
        "outputs": {"device_info.json": sha256_file(device_info_path)},
    }

    # 遍历配置中的每条 run，依次执行、采集遥测、落盘 CSV 并更新 manifest。
    for run_cfg in config["runs"]:
        command = build_command(run_cfg, args.device)
        # shlex.join 将命令列表安全地拼接为 shell 命令字符串，便于日志记录与复现。
        print("+", shlex.join(command), flush=True)
        # 运行前后各采集一次 GPU 遥测，用于排查温度/功耗/频率漂移对延迟的影响。
        before = telemetry()
        completed = run(command)
        after = telemetry()
        csv_path = run_dir / f"topology_{run_cfg['name']}.csv"
        csv_path.write_text(completed.stdout, encoding="utf-8")
        manifest["runs"].append({
            "name": run_cfg["name"], "config": run_cfg, "command": command,
            "telemetry_before": before, "telemetry_after": after,
            "stderr": completed.stderr,
        })
        manifest["outputs"][csv_path.name] = sha256_file(csv_path)

    # 记录完成时间并写入 manifest.json。
    manifest["completed_utc"] = dt.datetime.now(dt.timezone.utc).strftime(
        "%Y%m%dT%H%M%SZ")
    (run_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(run_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())