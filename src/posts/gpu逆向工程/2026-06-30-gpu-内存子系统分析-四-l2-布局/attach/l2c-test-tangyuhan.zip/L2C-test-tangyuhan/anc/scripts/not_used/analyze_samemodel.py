#!/usr/bin/env python3
"""分析同型号但不同物理 GPU 的 L2 延迟指纹差异。

输入是两块 NVIDIA L40 的 fingerprint CSV，输出为统计 JSON 和图像。该脚本控制全局延迟偏移后，检验相同型号设备能否被 NUCA 指纹区分。"""

from __future__ import annotations

import argparse
import csv
import io
import json
import pathlib
import subprocess
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt
import joblib
from sklearn.ensemble import RandomForestClassifier


def read_any(path: pathlib.Path):
    """Reads a plain CSV or `.zst` compressed CSV into row dictionaries.
    
    Args:
        path: 输入数据路径，允许普通 CSV 或 zstd 压缩 CSV。
    
    Returns:
        CSV 行字典列表，字段生命周期由调用者持有。"""
    if path.suffix == ".zst":
        raw = subprocess.run(["zstd", "-dc", str(path)], check=True,
                             stdout=subprocess.PIPE).stdout
        return list(csv.DictReader(io.StringIO(raw.decode())))
    return list(csv.DictReader(path.open()))


def sm_map(path: pathlib.Path, n=142):
    """Builds a per-SM latency map from topology CSV.
    
    Args:
        path: topology CSV 路径。
        n: 预期 SM 数量。
    
    Returns:
        每个 SM 的聚合延迟向量。"""
    rows = read_any(path)
    acc = defaultdict(list)
    for d in rows:
        acc[int(d["smid"])].append(float(d["cycles_per_access"]))
    return np.array([np.mean(acc[s]) for s in range(n)])


def read_fp(path: pathlib.Path):
    """Reads fingerprint CSV rows into feature, label, and shot arrays.
    
    Args:
        path: fingerprint CSV 或压缩 CSV 路径。
    
    Returns:
        特征矩阵、标签向量和 shot 标识，供分类器训练或评估。"""
    raw = subprocess.run(["zstd", "-dc", str(path)], check=True,
                         stdout=subprocess.PIPE).stdout
    h = raw.split(b"\n", 1)[0].decode().split(",")
    lat = [i for i, c in enumerate(h) if c.startswith("lat_")]
    smi = h.index("smid")
    arr = np.loadtxt(io.BytesIO(raw), delimiter=",", skiprows=1)
    return arr[:, lat].astype(np.float32), arr[:, smi].astype(int)


def classify(XA, XB, demean=False):
    """Classifies whether fingerprints came from two same-model devices.
    
    Args:
        XA: 第一块 GPU 的特征矩阵。
        XB: 第二块 GPU 的特征矩阵。
        demean: 为 true 时移除全局延迟偏移。
    
    Returns:
        分类准确率。"""
    X = np.vstack([XA, XB])
    y = np.r_[np.zeros(len(XA)), np.ones(len(XB))]
    if demean:
        X = X - X.mean(axis=1, keepdims=True)
    rng = np.random.default_rng(0)
    idx = rng.permutation(len(X))
    tr, te = idx[:int(.7 * len(X))], idx[int(.7 * len(X)):]
    c = RandomForestClassifier(n_estimators=100, n_jobs=-1, random_state=0).fit(X[tr], y[tr])
    return float((c.predict(X[te]) == y[te]).mean())


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--map1", required=True, type=pathlib.Path)
    ap.add_argument("--map2", required=True, type=pathlib.Path)
    ap.add_argument("--fp1", required=True, type=pathlib.Path)
    ap.add_argument("--fp2", required=True, type=pathlib.Path)
    ap.add_argument("--oracle1", required=True, type=pathlib.Path)
    ap.add_argument("--figures", required=True, type=pathlib.Path)
    ap.add_argument("--processed", required=True, type=pathlib.Path)
    args = ap.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    args.processed.mkdir(parents=True, exist_ok=True)

    m1, m2 = sm_map(args.map1), sm_map(args.map2)
    corr = float(np.corrcoef(m1, m2)[0, 1])
    resid = (m2 - m2.mean()) - (m1 - m1.mean())
    X1, y1 = read_fp(args.fp1)
    X2, y2 = read_fp(args.fp2)
    o1 = joblib.load(args.oracle1)
    transfer = float((o1.predict(X2) == y2).mean())
    # native L40#2 oracle
    rng = np.random.default_rng(0)
    idx = rng.permutation(len(X2)); tr, te = idx[:int(.7 * len(X2))], idx[int(.7 * len(X2)):]
    o2 = RandomForestClassifier(n_estimators=160, n_jobs=-1, random_state=0).fit(X2[tr], y2[tr])
    native2 = float((o2.predict(X2[te]) == y2[te]).mean())

    stats = {
        "global_mean_cyc_dev1": float(m1.mean()), "global_mean_cyc_dev2": float(m2.mean()),
        "global_offset_cyc": float(m2.mean() - m1.mean()),
        "per_sm_map_correlation": corr,
        "per_sm_residual_std_cyc": float(resid.std()),
        "per_sm_residual_max_cyc": float(np.abs(resid).max()),
        "device_classify_raw": classify(X1, X2),
        "device_classify_demeaned": classify(X1, X2, demean=True),
        "oracle_dev1_on_dev2": transfer,
        "oracle_dev2_native": native2,
        "n_sm": 142,
    }
    (args.processed / "samemodel_stats.json").write_text(json.dumps(stats, indent=2) + "\n",
                                                         encoding="utf-8")
    print(json.dumps(stats, indent=2))

    fig, ax0 = plt.subplots(figsize=(5.6, 4.2))
    ax0.scatter(m1, m2, s=12, alpha=0.55, color="tab:blue", edgecolors="none")
    lo, hi = min(m1.min(), m2.min()), max(m1.max(), m2.max())
    ax0.plot([lo, hi], [lo, hi], color="0.4", lw=1.0)
    ax0.set_xlabel("L40 #1 per-SM mean latency (cycles)")
    ax0.set_ylabel("L40 #2 per-SM mean latency (cycles)")
    ax0.set_title("Per-SM map: two same-model L40s ($r=%.2f$)" % corr)
    ax0.grid(True, alpha=0.24)
    fig.tight_layout()
    fig.savefig(args.figures / "samemodel.pdf")
    fig.savefig(args.figures / "samemodel.png", dpi=220)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
