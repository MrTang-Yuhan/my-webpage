// 单 GPU 的"每 SM 到 L2 访问延迟拓扑"探测程序。
//
// 该文件用于重建"物理 SM 到 L2 slice"的访问延迟拓扑。核心思想是让每个
// SM 上恰好驻留一个 block，并用全局轮次计数器串行化计时窗口，使同一时刻
// 只有一个 SM 在执行依赖式 L2 load。这样测得的 cycle 差异主要来自片上路径，
// 而不是来自并发争用。
//
// 程序测量从每个物理流式多处理器（SM）到一组驻留 L2 的缓存行的依赖加载延迟。
// 支持两种缓冲布局：
//
//   single : 自引用链，在主机选定的字节偏移处对一条 128 B 缓存行无限循环。
//            对该行重复执行 ld.global.cg 加载，均为命中单个 L2 slice 的 L2 命中，
//            因此测得的 cycles 隔离了 SM -> slice 路径。扫描偏移量可将行映射到不同 slice。
//   chain  : 在小块 L2 驻留足迹上的随机排列指针链，触及多个 slice。
//            测得的延迟是 SM 到 slice 集合的平均距离（近似均匀对照组）。
//
// 通过全局轮次计数器在各 SM 间串行化测量：一次只有一个 block 进入计时区域，
// 其余 block 以 __nanosleep 退让，因此被计时的加载流不会遇到片上争用。
// 通过申请大量动态共享内存强制每个 SM 只驻留一个 block，单次启动即可覆盖所有 SM。

#include <cuda_runtime.h>

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>

#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t error__ = (call);                                              \
    if (error__ != cudaSuccess) {                                              \
      std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << ": "     \
                << cudaGetErrorString(error__) << "\n";                        \
      std::exit(EXIT_FAILURE);                                                 \
    }                                                                          \
  } while (0)

// 读取当前线程所在物理 SM 的编号（smid）。
// __forceinline__ 建议编译器强制内联，消除函数调用开销。
__device__ __forceinline__ uint32_t physical_smid() {
  uint32_t id;
  asm volatile("mov.u32 %0, %%smid;" : "=r"(id));
  return id;
}

// 通过 global-cache 路径加载一个 32 位链式条目。
//
// 使用 `ld.global.cg` 避免 L1 行为主导结果，使指针追踪更直接地反映
// L2 命中路径。返回值为下一跳的 word 索引。
//
// 【PTX 缓存修饰符说明】
// .cg (cache global): 仅在 L2 缓存，绕过 L1 缓存。适用于只访问一次或
// 访问模式不规则的数据，防止 L1 缓存污染。根据 NVIDIA PTX 文档，.cg 确保
// 数据只被缓存到全局可访问的 L2 级别，不对 L1 进行分配。
//
// 内联汇编约束字符说明：
//   "=r" : 输出操作数，写入 32 位通用寄存器（GPR）
//   "l"  : 输入操作数，64 位寄存器（通常用于全局内存指针）
//   "memory" : 内存屏障，防止编译器重排此汇编前后的内存操作
__device__ __forceinline__ uint32_t load_cg_u32(const uint32_t *address) {
  uint32_t value;
  asm volatile("ld.global.cg.u32 %0, [%1];"
               : "=r"(value)
               : "l"(address)
               : "memory");
  return value;
}

// 每个 SM 驻留一个 block，仅 thread 0 执行测量。
// 申领一个轮次，等待轮到自己，预热指针链，然后在独占轮次内对依赖加载流计时。
//
// 【设计原理】
// 依赖加载链（index = load(next + index)）确保 GPU 无法并行化或重排这些加载，
// 因为每次加载的地址取决于前一次加载的结果。这形成严格的串行依赖，保证
// 测得的周期数真实反映内存访问延迟，而非被指令级并行掩盖后的结果。
__global__ void per_sm_latency_kernel(const uint32_t *next, uint32_t start,
                                      uint64_t warm_accesses,
                                      uint64_t measured_accesses,
                                      int *turn_claim, int *now_serving,
                                      uint32_t *out_smid, int *out_turn,
                                      uint64_t *out_cycles,
                                      uint32_t *out_sink) {
  if (threadIdx.x != 0) {
    return;
  }
  const int block = blockIdx.x;
  out_smid[block] = physical_smid();

  // 通过 turn_claim/now_serving 实现分布式轮次锁，强制所有 block 在时间上互斥执行测量区域。
  // 原子操作在全局内存上执行，具有全局可见性。
  //
  // 【原子操作语义】
  // atomicAdd(turn_claim, 1) 返回旧值，每个 block 获得唯一递增的轮次号 my_turn。
  // 这是经典的"取票-叫号"分布式锁模式：
  //   turn_claim : 下一个可分配的轮次号（取票机）
  //   now_serving : 当前正在服务的轮次号（叫号器）
  const int my_turn = atomicAdd(turn_claim, 1);
  out_turn[block] = my_turn;

  // 等待获得独占轮次。未获得轮次的 block 主动退让，当被计时的 block 执行时，
  // 它们不产生任何片上流量。
  //
  // __nanosleep(t) : 使当前线程睡眠约 t 个时钟周期。参数为 32 位有符号整数。
  // 根据 NVIDIA PTX 文档，nanosleep 指令在 SM 70+ 可用，让 warp 主动放弃执行资源。
  while (atomicAdd(now_serving, 0) != my_turn) {
    __nanosleep(2000);
  }

  uint32_t index = start;

  // 预热：使正式测量不受冷启动影响。
  // 预热访问次数通常远小于正式测量次数，目的是将目标数据带入 L2 缓存。
  for (uint64_t i = 0; i < warm_accesses; ++i) {
    // 即 next[index] = index
    index = load_cg_u32(next + index);  // 依赖链：每次加载地址取决于前一次结果，GPU 无法并行化
  }

  // __threadfence() : Thread Memory Fence。
  // 根据 CUDA 编程指南，__threadfence() 保证调用线程此前对全局内存、共享内存
  // 和纹理内存的所有写操作已经完成，并且对设备上所有线程可见。它不会阻塞其他线程，
  // 只保证内存顺序。在此处用于确保预热加载完全完成后再开始计时。
  __threadfence();

  // 正式计时区域。
  // clock64() 返回每个 SM 的 64 位计数器，每时钟周期递增。根据 NVIDIA 文档，
  // 该计数器在设备代码中执行时返回每个多处理器的计数值，用于精确测量指令周期。
  // 注意：由于线程可能被时间片轮转，clock64() 测量的是 wall-clock 周期而非仅执行周期。
  const uint64_t begin = clock64();
  for (uint64_t i = 0; i < measured_accesses; ++i) {
    index = load_cg_u32(next + index);
  }
  const uint64_t end = clock64();
  __threadfence();

  out_cycles[block] = end - begin;
  out_sink[block] = index;          // 防止编译器认为 index 未被使用而删除整段计算

  // 释放轮次给下一个 block。
  // atomicExch(addr, val) : 原子交换操作，将 val 写入 addr 并返回旧值。
  // 此处将 now_serving 更新为 my_turn + 1，通知下一个等待的 block 可以进入计时区域。
  atomicExch(now_serving, my_turn + 1);
}

// 每个 SM 驻留一个 block，在单次串行轮次中测量 P-probe 延迟指纹。
// 对每个 probe 偏移，先在目标缓存行预热依赖加载流，再正式计时。
// 一次核函数启动即产生一个完整 shot（所有 SM × P 个 probe），
// 作为 SM 放置 oracle 的带标签训练数据。
__global__ void per_sm_fingerprint_kernel(const uint32_t *next,
                                          const uint32_t *starts, int n_probes,
                                          uint64_t warm_accesses,
                                          uint64_t measured_accesses,
                                          int *turn_claim, int *now_serving,
                                          uint32_t *out_smid, int *out_turn,
                                          uint64_t *out_cycles,
                                          uint32_t *out_sink) {
  if (threadIdx.x != 0) {
    return;
  }
  const int block = blockIdx.x;
  out_smid[block] = physical_smid();

  // 分布式轮次锁：原子操作在全局内存执行，全局可见。
  const int my_turn = atomicAdd(turn_claim, 1);
  out_turn[block] = my_turn;
  while (atomicAdd(now_serving, 0) != my_turn) {
    __nanosleep(2000);
  }

  uint32_t sink = 0;
  // 遍历每个 probe 偏移，依次测量该偏移对应的 L2 命中延迟。
  for (int p = 0; p < n_probes; ++p) {
    uint32_t index = starts[p];
    for (uint64_t i = 0; i < warm_accesses; ++i) {
      // 即 next[index] = index
      index = load_cg_u32(next + index);
    }
    __threadfence();
    const uint64_t begin = clock64();
    for (uint64_t i = 0; i < measured_accesses; ++i) {
      index = load_cg_u32(next + index);
    }
    const uint64_t end = clock64();
    // 二维数组扁平化索引：out_cycles[block * n_probes + p]
    // 使用扁平化索引避免在设备端动态分配二维数组，提高内存访问效率。
    out_cycles[static_cast<uint64_t>(block) * n_probes + p] = end - begin;
    sink ^= index;        // 将多次探测结果关联起来，防止编译器消除任何一次循环
  }
  out_sink[block] = sink; // 使用 sink 防止编译器优化
  atomicExch(now_serving, my_turn + 1);
}

// 将命令行字符串解析为无符号 64 位整数。
// 使用 std::strtoull 进行转换，并严格校验错误：
//   - errno != 0 : 数值溢出或转换错误
//   - end == text : 没有有效数字被解析
//   - *end != '\0' : 字符串包含非数字后缀（如 "123abc"）
static uint64_t parse_u64(const char *text, const char *name) {
  errno = 0;
  char *end = nullptr;
  const unsigned long long value = std::strtoull(text, &end, 10); // 字符串转 unsigned long long，基数为 10
  if (errno != 0 || end == text || *end != '\0') {
    std::cerr << "Invalid " << name << ": " << text << "\n";
    std::exit(EXIT_FAILURE);
  }
  return static_cast<uint64_t>(value);
}

// 将命令行字符串解析为正有限浮点数。
// 使用 std::strtod 进行转换，并校验：
//   - 必须为正数 (value > 0.0)
//   - 必须为有限数 (!std::isfinite(value) 排除 NaN 和 Inf)
static double parse_double(const char *text, const char *name) {
  errno = 0;
  char *end = nullptr;
  const double value = std::strtod(text, &end);  // 字符串转 double
  if (errno != 0 || end == text || *end != '\0' || !std::isfinite(value) ||
      value <= 0.0) {
    std::cerr << "Invalid " << name << ": " << text << "\n";
    std::exit(EXIT_FAILURE);
  }
  return value;
}

int main(int argc, char **argv) {
  if (argc < 9) {
    std::cerr
        << "Usage:\n  " << argv[0]
        << " single <arena_mib> <offset_start_bytes> <offset_step_bytes> "
           "<offset_count> <warm> <measured> <reps> <seed> <device>\n  "
        << argv[0]
        << " chain <footprint_mib> <line_bytes> <warm> <measured> <reps> "
           "<seed> <device>\n  "
        << argv[0]
        << " fingerprint <arena_mib> <offset_start_bytes> <offset_step_bytes> "
           "<n_probes> <warm> <measured> <shots> <seed> <device>\n";
    return EXIT_FAILURE;
  }

  const std::string mode = argv[1];
  const int device = static_cast<int>(parse_u64(argv[argc - 1], "device"));
  CUDA_CHECK(cudaSetDevice(device));

  cudaDeviceProp prop{};
  CUDA_CHECK(cudaGetDeviceProperties(&prop, device));
  int core_clock_khz = 0;

  // 查询 GPU 核心时钟频率（单位：kHz）。
  CUDA_CHECK(cudaDeviceGetAttribute(&core_clock_khz, cudaDevAttrClockRate,
                                    device));
  const int num_sm = prop.multiProcessorCount;

  // 让每个 block 申请超过单 SM 共享内存容量的一半，从而强制每个 SM 只能同时驻留一个 block。
  const size_t shared_per_sm = prop.sharedMemPerMultiprocessor;
  size_t dyn_shared = shared_per_sm / 2 + 1024;
  if (dyn_shared > shared_per_sm) {
    dyn_shared = shared_per_sm - 1024;
  }

  // 动态共享内存申请超过单 SM 容量的一半，因此 occupancy 被压到每个 SM 一个 resident block；
  // 这保证 block 数可直接对应物理 SM 数。
  //
  // cudaFuncSetAttribute : 设置核函数启动属性。
  // cudaFuncAttributeMaxDynamicSharedMemorySize = 8 : 允许核函数使用超过默认限制的动
  // 态共享内存，最大可达 SM 级别的上限。根据 NVIDIA 文档，此属性需要在核函数启动前设置，
  // 且设置值不能超过设备查询返回的 sharedMemPerBlockOptin 限制。
  CUDA_CHECK(cudaFuncSetAttribute(per_sm_latency_kernel,
                                  cudaFuncAttributeMaxDynamicSharedMemorySize,
                                  static_cast<int>(dyn_shared)));
  CUDA_CHECK(cudaFuncSetAttribute(per_sm_fingerprint_kernel,
                                  cudaFuncAttributeMaxDynamicSharedMemorySize,
                                  static_cast<int>(dyn_shared)));
  int blocks_per_sm = 0;

  // cudaOccupancyMaxActiveBlocksPerMultiprocessor : 计算在给定 block 大小和动态共享内存下，
  // 每个 SM 最多能同时驻留的活跃 block 数量。此处用于验证 dyn_shared 是否成功将 occupancy
  // 限制为 1（即每个 SM 只能同时运行 1 个 block）。
  CUDA_CHECK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
      &blocks_per_sm, per_sm_latency_kernel, 32, dyn_shared));
  std::cerr << "num_sm=" << num_sm << " dyn_shared=" << dyn_shared
            << " blocks_per_sm=" << blocks_per_sm << "\n";

  // 设备端临时缓冲区，每次启动复用。
  int *turn_claim = nullptr;
  int *now_serving = nullptr;
  uint32_t *out_smid = nullptr;
  int *out_turn = nullptr;
  uint64_t *out_cycles = nullptr;
  uint32_t *out_sink = nullptr;
  CUDA_CHECK(cudaMalloc(&turn_claim, sizeof(int)));
  CUDA_CHECK(cudaMalloc(&now_serving, sizeof(int)));
  CUDA_CHECK(cudaMalloc(&out_smid, sizeof(uint32_t) * num_sm));
  CUDA_CHECK(cudaMalloc(&out_turn, sizeof(int) * num_sm));
  const int max_probes = 64;
  // const int max_probes = 256;   // 如果 256 太大导致显存溢出，请切换为 64
  CUDA_CHECK(cudaMalloc(&out_cycles, sizeof(uint64_t) * num_sm * max_probes));
  CUDA_CHECK(cudaMalloc(&out_sink, sizeof(uint32_t) * num_sm));

  std::vector<uint32_t> h_smid(num_sm);
  std::vector<int> h_turn(num_sm);
  std::vector<uint64_t> h_cycles(num_sm);

  std::cout << std::setprecision(12);
  if (mode == "single" || mode == "chain") {
    std::cout << "mode,probe_id,probe_bytes,rep,block,smid,turn,measured,"
                 "elapsed_cycles,cycles_per_access,core_clock_khz\n";
  }

  // 启动一次测量：重置轮次状态，启动核函数，回传结果并打印 CSV。
  // 使用 C++ lambda 捕获设备端缓冲区，避免重复代码。
  auto launch_one = [&](const std::string &mode_label, long long probe_id,
                        long long probe_bytes, uint64_t rep, uint32_t start,
                        const uint32_t *device_next, uint64_t warm,
                        uint64_t measured) {
    CUDA_CHECK(cudaMemset(turn_claim, 0, sizeof(int)));
    CUDA_CHECK(cudaMemset(now_serving, 0, sizeof(int)));
    // 设置的执行配置强制 launch_one 每次调用都会启动 num_sm 个 Block，所有 SM 都执行，
    // 但它们被轮次锁串行化，且都追踪同一条指定的指针链。
    // 每次启动重置轮次状态，使不同 probe/repetition 的串行顺序互不继承。
    per_sm_latency_kernel<<<num_sm, 32, dyn_shared>>>(
        device_next, start, warm, measured, turn_claim, now_serving, out_smid,
        out_turn, out_cycles, out_sink);
    CUDA_CHECK(cudaGetLastError());
    // cudaDeviceSynchronize() : 阻塞主机线程，直到设备完成所有先前提交的任务。
    // 在计时测量中必须调用，确保核函数完全执行完毕后再拷贝结果回主机。
    CUDA_CHECK(cudaDeviceSynchronize());
    CUDA_CHECK(cudaMemcpy(h_smid.data(), out_smid, sizeof(uint32_t) * num_sm,
                          cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(h_turn.data(), out_turn, sizeof(int) * num_sm,
                          cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(h_cycles.data(), out_cycles, sizeof(uint64_t) * num_sm,
                          cudaMemcpyDeviceToHost));
    for (int b = 0; b < num_sm; ++b) {
      std::cout << mode_label << ',' << probe_id << ',' << probe_bytes << ','
                << rep << ',' << b << ',' << h_smid[b] << ',' << h_turn[b] << ','
                << measured << ',' << h_cycles[b] << ','
                << static_cast<double>(h_cycles[b]) /
                       static_cast<double>(measured)
                << ',' << core_clock_khz << '\n';
    }
    // std::cout.flush() : 刷新输出缓冲区，确保数据立即写入标准输出。
    // 当输出被重定向到管道或文件时，此操作尤为重要，防止数据滞留在缓冲区。
    std::cout.flush();
  };

  if (mode == "single") {
    // single 模式：测得的是特定 SM 到特定地址探针的精确延迟
    
    if (argc != 11) {
      std::cerr << "single mode expects 9 parameters\n";
      return EXIT_FAILURE;
    }
    const double arena_mib = parse_double(argv[2], "arena_mib");
    const uint64_t offset_start = parse_u64(argv[3], "offset_start_bytes");
    const uint64_t offset_step = parse_u64(argv[4], "offset_step_bytes");
    const uint64_t offset_count = parse_u64(argv[5], "offset_count");
    const uint64_t warm = parse_u64(argv[6], "warm");
    const uint64_t measured = parse_u64(argv[7], "measured");
    const uint64_t reps = parse_u64(argv[8], "reps");

    const uint64_t arena_bytes =
        static_cast<uint64_t>(std::llround(arena_mib * 1024.0 * 1024.0));
    const uint64_t word_count = arena_bytes / sizeof(uint32_t);
    const uint64_t max_offset =
        offset_start + (offset_count == 0 ? 0 : (offset_count - 1)) *
                           offset_step;
    if (max_offset / sizeof(uint32_t) >= word_count) {
      std::cerr << "offset sweep exceeds arena\n";
      return EXIT_FAILURE;
    }

    // 自引用缓冲：buf[i] = i，因此任意起始 word 都在自己的 128 B 行上无限自环。
    // 单行自环把所有 measured load 固定到同一地址，扫描偏移量则将该地址映射到不同 L2 slice，
    // 从而观察每个 SM 到不同 slice 的路径差异。
    //
    // std::iota : 用递增序列填充容器，从起始值（此处为 0u）开始，每次 +1。
    // 因此 host_next[i] = i，形成恒等映射。
    std::vector<uint32_t> host_next(word_count);
    std::iota(host_next.begin(), host_next.end(), 0u);
    uint32_t *device_next = nullptr;
    CUDA_CHECK(cudaMalloc(&device_next, arena_bytes));
    CUDA_CHECK(cudaMemcpy(device_next, host_next.data(), arena_bytes,
                          cudaMemcpyHostToDevice));

    // device_next 是恒等映射，存在 device_next[0] = 0, device_next[1] = 1, device_next[2] = 2, ...
    // 而 kernel 中的加载链为 index = load_cg_u32(next + index)，即 index = next[index]
    // 所以无论 index 初始值是什么，加载后它都不会变。
    // 注意，start 相当于 index = next[index] 中的 index，改变它可以形成地址偏移
    for (uint64_t oi = 0; oi < offset_count; ++oi) {
      const uint64_t offset_bytes = offset_start + oi * offset_step;
      const uint32_t start = static_cast<uint32_t>(offset_bytes / sizeof(uint32_t));
      for (uint64_t rep = 0; rep < reps; ++rep) {
        launch_one("single", static_cast<long long>(oi),
                   static_cast<long long>(offset_bytes), rep, start,
                   device_next, warm, measured);
      }
    }
    CUDA_CHECK(cudaFree(device_next));
  } else if (mode == "chain") {
    // chain 模式：所有 SM 追踪一条随机指针链，测得一个平均延迟值

    if (argc != 9) {
      std::cerr << "chain mode expects 7 parameters\n";
      return EXIT_FAILURE;
    }
    const double footprint_mib = parse_double(argv[2], "footprint_mib");
    const uint64_t line_bytes = parse_u64(argv[3], "line_bytes");
    const uint64_t warm = parse_u64(argv[4], "warm");
    const uint64_t measured = parse_u64(argv[5], "measured");
    const uint64_t reps = parse_u64(argv[6], "reps");
    const uint64_t seed = parse_u64(argv[7], "seed");
    if (line_bytes < sizeof(uint32_t) || line_bytes % sizeof(uint32_t) != 0) {
      std::cerr << "line_bytes must be a multiple of 4\n";
      return EXIT_FAILURE;
    }
    const uint64_t requested_bytes =
        static_cast<uint64_t>(std::llround(footprint_mib * 1024.0 * 1024.0));
    const uint64_t line_count = requested_bytes / line_bytes;
    const uint64_t words_per_line = line_bytes / sizeof(uint32_t);
    const uint64_t word_count = line_count * words_per_line;
    if (line_count < 2 ||
        word_count > std::numeric_limits<uint32_t>::max()) {
      std::cerr << "footprint out of range\n";
      return EXIT_FAILURE;
    }
    std::vector<uint32_t> host_next(word_count, 0);
    std::vector<uint32_t> order(line_count);
    std::iota(order.begin(), order.end(), 0);
    // std::mt19937_64 : 64 位梅森旋转伪随机数生成器
    std::mt19937_64 generator(seed);
    std::shuffle(order.begin(), order.end(), generator);  // 打乱排序

    // 随机环覆盖多条缓存线，使每个 SM 看到近似 slice ensemble 的平均延迟；
    // 这是 single 模式的近均匀对照组。
    for (uint64_t i = 0; i < line_count; ++i) {
      // 当前缓存行的起始 word 索引
      const uint32_t cur =
          static_cast<uint32_t>(static_cast<uint64_t>(order[i]) * words_per_line);
      // 下一个缓存行的起始 word 索引
      const uint32_t nxt = static_cast<uint32_t>(
          static_cast<uint64_t>(order[(i + 1) % line_count]) * words_per_line);
      // 在当前缓存行的首 word 存下一个缓存行首 word
      host_next[cur] = nxt;
    }
    const uint32_t start =
        static_cast<uint32_t>(static_cast<uint64_t>(order[0]) * words_per_line);
    const uint64_t actual_bytes = word_count * sizeof(uint32_t);
    uint32_t *device_next = nullptr;
    CUDA_CHECK(cudaMalloc(&device_next, actual_bytes));
    CUDA_CHECK(cudaMemcpy(device_next, host_next.data(), actual_bytes,
                          cudaMemcpyHostToDevice));
    for (uint64_t rep = 0; rep < reps; ++rep) {
      launch_one("chain", 0, static_cast<long long>(requested_bytes), rep, start,
                 device_next, warm, measured);
    }
    CUDA_CHECK(cudaFree(device_next));
  } else if (mode == "fingerprint") {
    // fingerrint 模式：测得所有 SM × P 个 probe 的延迟数据

    if (argc != 11) {
      std::cerr << "fingerprint mode expects 9 parameters\n";
      return EXIT_FAILURE;
    }
    const double arena_mib = parse_double(argv[2], "arena_mib");            // 设备内存池大小（MiB）
    const uint64_t offset_start = parse_u64(argv[3], "offset_start_bytes"); // 第一个 probe 的字节偏移
    const uint64_t offset_step = parse_u64(argv[4], "offset_step_bytes");   // 相邻 probe 间的字节步长
    const int n_probes = static_cast<int>(parse_u64(argv[5], "n_probes"));  // probe 数量
    const uint64_t warm = parse_u64(argv[6], "warm");                       // 预热访问次数
    const uint64_t measured = parse_u64(argv[7], "measured");               // 正式测量访问次数
    const uint64_t shots = parse_u64(argv[8], "shots");                     // 测量轮次
    if (n_probes < 1 || n_probes > max_probes) {
      std::cerr << "n_probes must be in [1, " << max_probes << "]\n";
      return EXIT_FAILURE;
    }
    const uint64_t arena_bytes =
        static_cast<uint64_t>(std::llround(arena_mib * 1024.0 * 1024.0));
    const uint64_t word_count = arena_bytes / sizeof(uint32_t);
    const uint64_t max_offset = offset_start + (n_probes - 1) * offset_step;
    if (max_offset / sizeof(uint32_t) >= word_count) {
      std::cerr << "probe bank exceeds arena\n";
      return EXIT_FAILURE;
    }
    std::vector<uint32_t> host_next(word_count);
    std::iota(host_next.begin(), host_next.end(), 0u);  // 填充为 [0, 1, 2, ..., word_count-1]
    uint32_t *device_next = nullptr;
    CUDA_CHECK(cudaMalloc(&device_next, arena_bytes));
    CUDA_CHECK(cudaMemcpy(device_next, host_next.data(), arena_bytes,
                          cudaMemcpyHostToDevice));

    std::vector<uint32_t> host_starts(n_probes);
    for (int p = 0; p < n_probes; ++p) {
      // 计算第 p 个 probe 的字节偏移，并转为 word 索引。
      host_starts[p] =
          static_cast<uint32_t>((offset_start + p * offset_step) / sizeof(uint32_t));
    }
    // Probe bank 保存一组固定偏移，自环结构让每个 probe 形成一个可复现的
    // SM 延迟指纹维度；宽格式 CSV 后续直接作为 placement oracle 的训练样本。
    uint32_t *device_starts = nullptr;
    CUDA_CHECK(cudaMalloc(&device_starts, sizeof(uint32_t) * n_probes));
    CUDA_CHECK(cudaMemcpy(device_starts, host_starts.data(),
                          sizeof(uint32_t) * n_probes, cudaMemcpyHostToDevice));

    // 宽格式 CSV 表头：每行对应一个 (shot, SM)，其后紧跟 P 个指纹延迟。
    std::cout << "shot,block,smid,turn,measured";
    for (int p = 0; p < n_probes; ++p) {
      std::cout << ",lat_" << p;
    }
    std::cout << "\n";
    // 以轮次锁串行化所有 SM，让每个 SM 在互不干扰的情况下，依次测量 n_probes 个缓存行的
    // L2 命中延迟；重复 shots 轮后，输出带标签的宽格式 CSV 训练数据。
    std::vector<uint64_t> h_fp(static_cast<size_t>(num_sm) * n_probes);
    for (uint64_t shot = 0; shot < shots; ++shot) {
      CUDA_CHECK(cudaMemset(turn_claim, 0, sizeof(int)));
      CUDA_CHECK(cudaMemset(now_serving, 0, sizeof(int)));
      per_sm_fingerprint_kernel<<<num_sm, 32, dyn_shared>>>(
          device_next, device_starts, n_probes, warm, measured, turn_claim,
          now_serving, out_smid, out_turn, out_cycles, out_sink);
      CUDA_CHECK(cudaGetLastError());
      CUDA_CHECK(cudaDeviceSynchronize());
      CUDA_CHECK(cudaMemcpy(h_smid.data(), out_smid, sizeof(uint32_t) * num_sm,
                            cudaMemcpyDeviceToHost));
      CUDA_CHECK(cudaMemcpy(h_turn.data(), out_turn, sizeof(int) * num_sm,
                            cudaMemcpyDeviceToHost));
      CUDA_CHECK(cudaMemcpy(h_fp.data(), out_cycles,
                            sizeof(uint64_t) * num_sm * n_probes,
                            cudaMemcpyDeviceToHost));
      for (int b = 0; b < num_sm; ++b) {
        std::cout << shot << ',' << b << ',' << h_smid[b] << ',' << h_turn[b]
                  << ',' << measured;
        for (int p = 0; p < n_probes; ++p) {
          const double cyc = static_cast<double>(h_fp[static_cast<size_t>(b) * n_probes + p]) /
                             static_cast<double>(measured);
          std::cout << ',' << cyc;
        }
        std::cout << '\n';
      }
      std::cout.flush();
    }
    CUDA_CHECK(cudaFree(device_starts));
    CUDA_CHECK(cudaFree(device_next));
  } else {
    std::cerr << "unknown mode: " << mode << "\n";
    return EXIT_FAILURE;
  }

  CUDA_CHECK(cudaFree(out_sink));
  CUDA_CHECK(cudaFree(out_cycles));
  CUDA_CHECK(cudaFree(out_turn));
  CUDA_CHECK(cudaFree(out_smid));
  CUDA_CHECK(cudaFree(now_serving));
  CUDA_CHECK(cudaFree(turn_claim));
  return 0;
}