#!/usr/bin/env python3
"""用非特权 L2 延迟指纹预测物理执行位置。

输入是两类 GPU 的 fingerprint CSV，输出为设备级和 SM 级定位统计。该脚本把论文中的 NUCA 延迟差异转化为位置侧信道评估。"""

from __future__ import annotations

import argparse
import io
import json
import pathlib
import subprocess

import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.decomposition import PCA


def read_fp(path: pathlib.Path):
    """Reads fingerprint CSV rows into feature, label, and shot arrays.
    
    Args:
        path: fingerprint CSV 或压缩 CSV 路径。
    
    Returns:
        特征矩阵、标签向量和 shot 标识，供分类器训练或评估。"""
    raw = subprocess.run(["zstd", "-dc", str(path)], check=True,
                         stdout=subprocess.PIPE).stdout
    h = raw.split(b"\n", 1)[0].decode().split(",")
    lat = [i for i, c in enumerate(h) if c.startswith("lat_")]
    smi = h.index("smid")
    sh = h.index("shot")
    arr = np.loadtxt(io.BytesIO(raw), delimiter=",", skiprows=1)
    return arr[:, lat].astype(np.float32), arr[:, smi].astype(int), arr[:, sh].astype(int)


def split_by_shot(dev, shot, frac=0.7, seed=0):
    """Splits samples by measurement shot instead of by row.
    
    Args:
        shot: 每条样本所属的 shot 标识。
        frac: 训练集 shot 比例。
        seed: 随机种子。
    
    Returns:
        布尔训练掩码，避免同一 shot 同时进入训练和测试。"""
    rng = np.random.default_rng(seed)
    tr = np.zeros(len(shot), bool)
    for d in np.unique(dev):
        shots = np.unique(shot[dev == d])
        rng.shuffle(shots)
        keep = set(shots[:int(len(shots) * frac)].tolist())
        tr |= (dev == d) & np.array([s in keep for s in shot])
    return tr, ~tr


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--l40-fp", required=True, type=pathlib.Path)
    ap.add_argument("--rtx-fp", required=True, type=pathlib.Path)
    ap.add_argument("--figures", required=True, type=pathlib.Path)
    ap.add_argument("--processed", required=True, type=pathlib.Path)
    args = ap.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    args.processed.mkdir(parents=True, exist_ok=True)

    XL, smL, shL = read_fp(args.l40_fp)
    X5, sm5, sh5 = read_fp(args.rtx_fp)
    n_l40 = int(smL.max()) + 1
    X = np.vstack([XL, X5])
    dev = np.concatenate([np.zeros(len(XL), int), np.ones(len(X5), int)])
    shot = np.concatenate([shL, sh5])
    glob = np.concatenate([smL, n_l40 + sm5])  # 0..n_l40-1 ; n_l40..n_l40+n_5090-1
    n_loc = int(glob.max()) + 1

    tr, te = split_by_shot(dev, shot)

    # Device classifier (2-way).
    dclf = RandomForestClassifier(n_estimators=80, n_jobs=-1, random_state=0).fit(X[tr], dev[tr])
    dev_acc = float((dclf.predict(X[te]) == dev[te]).mean())

    # Global physical-location classifier (312-way).
    gclf = RandomForestClassifier(n_estimators=200, n_jobs=-1, random_state=0).fit(X[tr], glob[tr])
    gpred = gclf.predict(X[te])
    loc_acc = float((gpred == glob[te]).mean())
    # Decompose: device correct, and SM correct given device.
    dev_from_glob = (gpred >= n_l40).astype(int)
    dev_via_loc = float((dev_from_glob == dev[te]).mean())
    same_dev = dev_from_glob == dev[te]
    sm_acc_given_dev = float((gpred[same_dev] == glob[te][same_dev]).mean())

    # Accuracy vs number of probes for the global locator.
    vs = []
    for k in [1, 2, 4, 8, 16, 32]:
        c = RandomForestClassifier(n_estimators=120, n_jobs=-1, random_state=0).fit(X[tr, :k], glob[tr])
        vs.append({"probes": k, "location_acc": float((c.predict(X[te, :k]) == glob[te]).mean())})

    stats = {
        "n_locations": n_loc, "n_l40_sm": n_l40, "n_rtx_sm": int(n_loc - n_l40),
        "chance": 1.0 / n_loc,
        "device_acc_2way": dev_acc,
        "location_acc_312way": loc_acc,
        "device_acc_via_locator": dev_via_loc,
        "sm_acc_given_device": sm_acc_given_dev,
        "location_acc_vs_probes": vs,
        "test_fingerprints": int(te.sum()),
    }
    (args.processed / "locator_stats.json").write_text(json.dumps(stats, indent=2) + "\n",
                                                       encoding="utf-8")
    print(json.dumps(stats, indent=2))

    # Figure: PCA of fingerprint space colored by device (accuracy-vs-probes is in text).
    fig, ax0 = plt.subplots(figsize=(5.6, 4.2))
    sub = np.random.default_rng(0).choice(len(X), size=min(6000, len(X)), replace=False)
    pc = PCA(n_components=2).fit_transform(X[sub])
    for d, name, col in [(0, "L40 (Ada)", "tab:blue"), (1, "RTX 5090", "tab:red")]:
        m = dev[sub] == d
        ax0.scatter(pc[m, 0], pc[m, 1], s=3, alpha=0.25, color=col, edgecolors="none",
                    label=name)
    ax0.set_xlabel("PC 1 (cycles)")
    ax0.set_ylabel("PC 2 (cycles)")
    ax0.set_title("Fingerprint space (PCA)")
    ax0.legend(fontsize=8, markerscale=3)
    ax0.grid(True, alpha=0.24)
    fig.tight_layout()
    fig.savefig(args.figures / "locator.pdf")
    fig.savefig(args.figures / "locator.png", dpi=220)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
