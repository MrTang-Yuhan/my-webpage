#!/usr/bin/env python3
"""运行长时间满载拓扑稳定性 campaign。

输入是实验配置和设备号，输出为 fingerprint snapshots、telemetry log 与 manifest。该脚本同时启动 CUDA 稳定性探针和后台遥测采样。"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pathlib
import platform
import subprocess
import sys
import threading
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]


def sha256_file(p: pathlib.Path) -> str:
    """Computes a streaming SHA-256 digest for a file.
    
    Args:
        path: 要纳入 manifest 的文件路径。
    
    Returns:
        十六进制 digest 字符串。"""
    h = hashlib.sha256()
    with p.open("rb") as fh:
        # 1 << 20 即 1048576（1 MiB），每次读取 1 MiB 块以控制内存占用。
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main() -> int:
    """Runs the command-line entry point for this script.
    
    Returns:
        进程退出码，0 表示成功。"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, type=pathlib.Path)
    ap.add_argument("--device", default=0, type=int)
    args = ap.parse_args()
    cfg = json.loads(args.config.resolve().read_text())
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"{cfg['campaign']}_{ts}"
    run_dir = ROOT / "results" / "raw" / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    # 运行 device_info 可执行文件获取 GPU 静态信息（SM 数量、显存等）。
    di = subprocess.run([str(ROOT / "build" / "device_info")], check=True,
                        text=True, stdout=subprocess.PIPE).stdout
    (run_dir / "device_info.json").write_text(di, encoding="utf-8")

    snap_path = run_dir / "stability_snapshots.csv"
    telem_path = run_dir / "stability_telemetry.csv"

    cmd = [str(ROOT / "build" / "topology_stability"), str(cfg["vram_gib"]),
           str(cfg["duration_sec"]), str(cfg["snapshot_period_sec"]),
           str(cfg["load_iters"]), str(cfg["n_probes"]), str(cfg["measured"]),
           str(args.device)]

    stop = threading.Event()

    def sample_telemetry():
        """Samples GPU telemetry until the stop event is set.
        
        Args:
            stop: 线程间停止信号。
            path: 遥测 CSV 输出路径。
        
        Returns:
            None。"""
        with telem_path.open("w", encoding="utf-8") as fh:
            fh.write("timestamp,sm_clock_mhz,mem_clock_mhz,temperature_c,"
                     "power_w,memory_used_mib,gpu_util_percent,mem_util_percent\n")
            q = ("nvidia-smi --query-gpu=timestamp,clocks.sm,clocks.mem,"
                 "temperature.gpu,power.draw,memory.used,utilization.gpu,"
                 "utilization.memory --format=csv,noheader,nounits").split()
            while not stop.is_set():
                try:
                    out = subprocess.run(q, check=True, text=True,
                                         stdout=subprocess.PIPE).stdout.strip()
                    fh.write(out + "\n")
                    fh.flush()
                except Exception:
                    # 忽略采样过程中的偶发错误（如 nvidia-smi 瞬时不可用），
                    # 避免单个采样失败导致整个实验中断。
                    pass
                # cfg.get(key, default) 安全获取配置项，若不存在则使用默认值 3 秒。
                stop.wait(cfg.get("telemetry_period_sec", 3))

    # 创建并启动守护线程执行遥测采样。
    t = threading.Thread(target=sample_telemetry, daemon=True)
    t.start()
    print("+", " ".join(cmd), flush=True)
    with snap_path.open("w", encoding="utf-8") as out:
        proc = subprocess.run(cmd, stdout=out, stderr=subprocess.PIPE, text=True)
    stop.set()
    # join(timeout=10) 等待采样线程在 10 秒内结束；若超时则主线程继续，
    # 由于线程为 daemon，主进程退出后会被强制终止。
    t.join(timeout=10)

    # Manifest 固化配置、源码 hash、环境和命令行，保证 raw 结果可追溯。
    manifest = {
        "schema_version": 1, "run_id": run_id, "started_utc": ts,
        "completed_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
        "config": cfg, "command": cmd, "device": args.device,
        # platform.platform() 返回系统平台标识字符串；sys.version 返回 Python 解释器版本。cite🛠web_search:5#26:~:text=platform...sys.version
        "platform": platform.platform(), "python": sys.version,
        "stderr": proc.stderr,
        "source_sha256": {
            "src/topology_stability.cu": sha256_file(ROOT / "src" / "topology_stability.cu"),
        },
        "outputs": {
            "stability_snapshots.csv": sha256_file(snap_path),
            "stability_telemetry.csv": sha256_file(telem_path),
            "device_info.json": sha256_file(run_dir / "device_info.json"),
        },
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n",
                                           encoding="utf-8")
    print(run_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())