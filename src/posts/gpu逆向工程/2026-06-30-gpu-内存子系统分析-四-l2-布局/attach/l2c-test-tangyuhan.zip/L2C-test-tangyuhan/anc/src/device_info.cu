// 导出当前 CUDA 设备的静态能力信息。
//
// 输入：通过 CUDA Runtime 查询接口获取，不接收命令行参数。
// 输出：单个 JSON 对象，包含 GPU 型号、L2 容量、时钟、PCI 标识和并发能力等。
// 用途：作为 ANC 微基准系统的设备基线模块，将实验结果绑定到可复现的硬件配置。

#include <cuda_runtime.h>

#include <cstdio>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

// CUDA 错误检查宏：调用失败时打印文件名、行号和错误信息，然后终止程序。
#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t error__ = (call);                                               \
    if (error__ != cudaSuccess) {                                               \
      std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << ": "   \
                << cudaGetErrorString(error__) << "\n";                         \
      std::exit(EXIT_FAILURE);                                                  \
    }                                                                          \
  } while (0)

// 将 CUDA 提供的字符串转义为 JSON 安全格式。
//
// 参数 input：指向以 NUL 结尾的 CUDA 属性字符串，不能为 nullptr。
// 返回值：拥有独立生命周期的 std::string，可直接写入 JSON 字符串字段。
static std::string json_escape(const char *input) {
  std::ostringstream out;
  for (const unsigned char c : std::string(input)) {
    switch (c) {
    case '"':
      out << "\\\"";
      break;
    case '\\':
      out << "\\\\";
      break;
    case '\n':
      out << "\\n";
      break;
    case '\r':
      out << "\\r";
      break;
    case '\t':
      out << "\\t";
      break;
    default:
      if (c < 0x20) {
        // 控制字符转为 \u00XX 十六进制格式
        out << "\\u" << std::hex << std::setw(4) << std::setfill('0')
            << static_cast<int>(c);
      } else {
        out << c;
      }
    }
  }
  return out.str();
}

// 将 CUDA UUID 格式化为稳定的小写十六进制字符串。
//
// 参数 uuid：来自 cudaDeviceProp::uuid，用于跨运行区分同型号的不同设备。
// 返回值：不含分隔符的纯十六进制字符串，便于在 manifest 和文件名中复用。
static std::string uuid_string(const cudaUUID_t &uuid) {
  std::ostringstream out;
  out << std::hex << std::setfill('0');
  for (int i = 0; i < 16; ++i) {
    out << std::setw(2)
        << static_cast<unsigned int>(
               static_cast<unsigned char>(uuid.bytes[i]));
  }
  return out.str();
}

int main() {
  // 实验框架一次只绑定一个 CUDA 设备，默认设备 0 作为 manifest 的基线对象。
  int device = 0;
  int driver_version = 0;
  int runtime_version = 0;
  cudaDeviceProp p{};  // 设备属性结构体，{} 表示零初始化

  // 设置当前设备并查询驱动版本、运行时版本和设备属性
  CUDA_CHECK(cudaSetDevice(device));
  CUDA_CHECK(cudaDriverGetVersion(&driver_version));
  CUDA_CHECK(cudaRuntimeGetVersion(&runtime_version));
  CUDA_CHECK(cudaGetDeviceProperties(&p, device));

  int memory_clock_khz = 0;
  int core_clock_khz = 0;
  // CUDA 时钟属性单位为 kHz，后续分析脚本可用它将 cycles 换算为时间。
  CUDA_CHECK(cudaDeviceGetAttribute(
      &memory_clock_khz, cudaDevAttrMemoryClockRate, device));
  CUDA_CHECK(
      cudaDeviceGetAttribute(&core_clock_khz, cudaDevAttrClockRate, device));

  size_t persisting_limit = 0;
  // 当前 persisting L2 限制是运行时状态，可能小于硬件允许的最大 set-aside 值。
  CUDA_CHECK(cudaDeviceGetLimit(&persisting_limit,
                                cudaLimitPersistingL2CacheSize));

  // 输出 JSON 格式的设备静态能力报告
  std::cout << "{\n"
            << "  \"device_index\": " << device << ",\n"
            << "  \"name\": \"" << json_escape(p.name) << "\",\n"
            << "  \"uuid_hex\": \"" << uuid_string(p.uuid) << "\",\n"
            << "  \"compute_capability\": \"" << p.major << "." << p.minor
            << "\",\n"
            << "  \"driver_version_encoded\": " << driver_version << ",\n"
            << "  \"runtime_version_encoded\": " << runtime_version << ",\n"
            << "  \"multiprocessor_count\": " << p.multiProcessorCount << ",\n"
            << "  \"warp_size\": " << p.warpSize << ",\n"
            << "  \"global_memory_bytes\": " << p.totalGlobalMem << ",\n"
            << "  \"l2_cache_bytes\": " << p.l2CacheSize << ",\n"
            << "  \"persisting_l2_max_bytes\": "
            << p.persistingL2CacheMaxSize << ",\n"
            << "  \"persisting_l2_current_limit_bytes\": "
            << persisting_limit << ",\n"
            << "  \"access_policy_max_window_bytes\": "
            << p.accessPolicyMaxWindowSize << ",\n"
            << "  \"memory_bus_width_bits\": " << p.memoryBusWidth << ",\n"
            << "  \"memory_clock_khz\": " << memory_clock_khz << ",\n"
            << "  \"core_clock_khz\": " << core_clock_khz << ",\n"
            << "  \"max_threads_per_block\": " << p.maxThreadsPerBlock << ",\n"
            << "  \"max_threads_per_sm\": " << p.maxThreadsPerMultiProcessor
            << ",\n"
            << "  \"shared_memory_per_block_bytes\": " << p.sharedMemPerBlock
            << ",\n"
            << "  \"shared_memory_per_sm_bytes\": "
            << p.sharedMemPerMultiprocessor << ",\n"
            << "  \"registers_per_block\": " << p.regsPerBlock << ",\n"
            << "  \"registers_per_sm\": " << p.regsPerMultiprocessor << ",\n"
            << "  \"async_engine_count\": " << p.asyncEngineCount << ",\n"
            << "  \"pci_bus_id\": " << p.pciBusID << ",\n"
            << "  \"pci_device_id\": " << p.pciDeviceID << ",\n"
            << "  \"ecc_enabled\": " << (p.ECCEnabled ? "true" : "false")
            << ",\n"
            << "  \"concurrent_kernels\": "
            << (p.concurrentKernels ? "true" : "false") << ",\n"
            << "  \"managed_memory\": "
            << (p.managedMemory ? "true" : "false") << ",\n"
            << "  \"concurrent_managed_access\": "
            << (p.concurrentManagedAccess ? "true" : "false") << "\n"
            << "}\n";
  return 0;
}