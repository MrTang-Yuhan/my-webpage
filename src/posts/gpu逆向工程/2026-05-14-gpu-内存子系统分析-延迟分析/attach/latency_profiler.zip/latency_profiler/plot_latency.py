#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
示例命令：
    python3 plot_latency.py latency_result.txt -o latency.png --title "RTX 5080 Latency Test"
    python3 plot_latency.py latency_result.txt -o latency.png
"""

import re
import argparse
import matplotlib.pyplot as plt

def parse_latency_txt(filename):
    """
    从 txt 文件中提取：
      1. 工作集大小和延迟
      2. Device
      3. Compute capability
      4. Current SM clock
      5. Current memory clock

    返回：
        working_sets: List[float]
        latencies: List[float]
        info: Dict[str, str]
    """

    working_sets = []
    latencies = []

    info = {
        "Device": None,
        "Compute capability": None,
        "Current SM clock": None,
        "Current memory clock": None,
    }

    # 匹配数据行，例如：
    #   4, 43.00
    #   128, 105.5
    data_pattern = re.compile(
        r'^\s*([0-9]+(?:\.[0-9]+)?)\s*,\s*([0-9]+(?:\.[0-9]+)?)\s*$'
    )

    # 匹配字段行，例如：
    #   Device: NVIDIA GeForce RTX 5080
    #   Compute capability: 12.0
    #   Current SM clock:           997 MHz
    #   Current memory clock:       14801 MHz
    field_patterns = {
        "Device": re.compile(r'^\s*Device\s*:\s*(.+?)\s*$'),
        "Compute capability": re.compile(r'^\s*Compute capability\s*:\s*(.+?)\s*$'),
        "Current SM clock": re.compile(r'^\s*Current SM clock\s*:\s*(.+?)\s*$'),
        "Current memory clock": re.compile(r'^\s*Current memory clock\s*:\s*(.+?)\s*$'),
    }

    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            # 提取字段信息
            for key, pattern in field_patterns.items():
                match = pattern.match(line)
                if match:
                    info[key] = match.group(1).strip()

            # 提取数据点
            match = data_pattern.match(line)
            if match:
                ws_kb = float(match.group(1))
                latency_cycle = float(match.group(2))

                working_sets.append(ws_kb)
                latencies.append(latency_cycle)

    return working_sets, latencies, info

def make_title(info):
    """
    根据 txt 中提取的字段生成图标题。
    """

    device = info.get("Device") or "Unknown Device"
    compute_capability = info.get("Compute capability") or "Unknown CC"
    sm_clock = info.get("Current SM clock") or "Unknown SM clock"
    mem_clock = info.get("Current memory clock") or "Unknown memory clock"

    title = (
        f"{device}\n"
        f"Compute Capability: {compute_capability}, "
        f"SM Clock: {sm_clock}, "
        f"Memory Clock: {mem_clock}"
    )

    return title

def plot_latency(working_sets, latencies, info, output=None, title=None):
    """
    根据提取出的 working set 和 latency 画图。

    横坐标：
        从 4 KB 开始，按照 2 的倍数增长

    纵坐标：
        从 30 cycle 开始，每 100 cycle 递增

    标题：
        默认从 txt 中提取 Device、Compute capability、
        Current SM clock、Current memory clock
    """

    if not working_sets:
        raise ValueError("没有提取到任何数据，请检查 txt 文件格式。")

    plt.figure(figsize=(9, 5.5))

    plt.plot(
        working_sets,
        latencies,
        marker="o",
        linestyle="-",
        linewidth=1.8,
        markersize=4,
        label="dependent load latency"
    )

    # 横坐标使用 log2 坐标轴
    plt.xscale("log", base=2)

    # 横坐标从 1 KB 开始
    max_ws = max(working_sets)
    plt.xlim(left=4, right=max_ws)

    # 设置横坐标刻度：1, 2, 4, 8, 16, ...
    x_ticks = []
    tick = 4
    while tick <= max_ws:
        x_ticks.append(tick)
        tick *= 2

    plt.xticks(x_ticks, [f"{x}" for x in x_ticks], rotation=60)

    # 纵坐标从 30 开始，每 100 递增
    min_y = 30
    max_y = max(latencies)

    max_y_tick = min_y
    while max_y_tick < max_y:
        max_y_tick += 100

    # 额外留一点上边距
    max_y_tick += 100

    y_ticks = list(range(min_y, max_y_tick + 1, 100))

    plt.ylim(bottom=min_y, top=max_y_tick)
    plt.yticks(y_ticks)

    plt.xlabel("Working Set Size (KiB)")
    plt.ylabel("Latency (cycles)")

    if title is None:
        title = make_title(info)

    plt.title(title)

    plt.grid(True, which="both", linestyle="--", alpha=0.5)
    plt.legend()
    plt.tight_layout()

    if output:
        plt.savefig(output, dpi=300)
        print(f"图像已保存到: {output}")
    else:
        plt.show()

def main():
    parser = argparse.ArgumentParser(
        description="Parse GPU latency txt file and plot working set size vs latency."
    )

    parser.add_argument(
        "input",
        help="输入 txt 文件路径"
    )

    parser.add_argument(
        "-o", "--output",
        default=None,
        help="输出图片路径，例如 latency.png。如果不指定，则直接显示图像。"
    )

    parser.add_argument(
        "--title",
        default=None,
        help="手动指定图表标题。如果不指定，则自动从 txt 文件提取。"
    )

    args = parser.parse_args()

    working_sets, latencies, info = parse_latency_txt(args.input)

    print("提取到的设备信息：")
    for key, value in info.items():
        print(f"{key}: {value}")

    print()
    print("提取到的数据：")
    print("WorkingSet_KB, Latency_cycles")
    for ws, lat in zip(working_sets, latencies):
        print(f"{ws:g}, {lat:.2f}")

    plot_latency(
        working_sets,
        latencies,
        info,
        output=args.output,
        title=args.title
    )

if __name__ == "__main__":
    main()