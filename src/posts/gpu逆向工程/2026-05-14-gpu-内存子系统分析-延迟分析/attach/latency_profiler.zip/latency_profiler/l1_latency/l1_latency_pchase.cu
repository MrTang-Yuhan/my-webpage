#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <random>
#include <algorithm>
#include <cstdint>
#include <nvml.h>

#define CUDA_CHECK(call)                                      \
    do {                                                      \
        cudaError_t err = call;                               \
        if (err != cudaSuccess) {                             \
            fprintf(stderr, "CUDA error %s:%d: %s\n",         \
                    __FILE__, __LINE__,                       \
                    cudaGetErrorString(err));                 \
            std::exit(EXIT_FAILURE);                          \
        }                                                     \
    } while (0)

#define NVML_CHECK(call)                                                        \
do {                                                                        \
    nvmlReturn_t _status = (call);                                          \
    if (_status != NVML_SUCCESS) {                                          \
        fprintf(stderr, "NVML error %s:%d: %s\n",                           \
                __FILE__, __LINE__, nvmlErrorString(_status));              \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// 使用 inline PTX 强制 global load 经 cache 路径。
// .ca = cache at all levels，通常用于让 global load 进入 L1 + L2。
// 注意：具体缓存策略仍可能受架构和编译器影响，建议配合 SASS 检查。
__device__ __forceinline__ uint32_t ld_ca_u32(const uint32_t *ptr) {
    uint32_t val;
 
    // 把 CUDA generic pointer 显式转换成 global memory address。
    // 对 inline PTX 的 ld.global 更稳。
    unsigned long long addr =
        static_cast<unsigned long long>(__cvta_generic_to_global(ptr));
    
    // 从 global memory 地址 addr 读取一个 32-bit unsigned integer 到寄存器 val
    asm volatile("ld.global.ca.u32 %0, [%1];"
                 : "=r"(val)
                 : "l"(addr)
                 : "memory");
 
    return val;
}

// 单线程 pointer-chase。
// 每一次 load 的地址依赖上一次 load 的结果，所以无法并行隐藏 latency。
__global__ void pchase_latency_kernel(const uint32_t *__restrict__ chain,
                                      uint64_t *cycles_out,
                                      uint32_t *sink_out,
                                      int warmup_iters,
                                      int measure_iters) {
    uint32_t idx = 0;

    // warm-up：先把 working set 尽量带入 L1/L2。
    // 如果 working set 小于 L1，后续测量主要是 L1 hit。
    #pragma unroll 1
    for (int i = 0; i < warmup_iters; ++i) {
        // 功能上等价于 idx = chain[idx]，但底层明确使用 ld.global.ca.u32
        idx = ld_ca_u32(chain + idx);       
    }
    

    // 编译器层面的 barrier, 防止编译器移动 clock 前后的 load。
    asm volatile("" ::: "memory");

    uint64_t start = clock64();

    #pragma unroll 1
    for (int i = 0; i < measure_iters; ++i) {
        idx = ld_ca_u32(chain + idx);
    }

    uint64_t end = clock64();

    asm volatile("" ::: "memory");

    if (threadIdx.x == 0 && blockIdx.x == 0) {
        cycles_out[0] = end - start;
        sink_out[0] = idx;
    }
}

// overhead_kernel 用于对 pchase_latency_kernel 进行 baseline 校正。
// 它通过 global 函数内的寄存器变量 idx 构建依赖链，因此不会访问 global memory。
// 但该函数仍包含除内存访问以外的循环、计时和指令执行等开销。
// 用 pchase_latency_kernel 的延迟开销减去 overhead_kernel 的开销，
// 即可近似得到仅由访问 global memory 所产生的延迟开销。
__global__ void overhead_kernel(uint64_t *cycles_out,
                                uint32_t *sink_out,
                                int measure_iters) {
    uint32_t idx = 1;

    asm volatile("" ::: "memory");

    uint64_t start = clock64();

    #pragma unroll 1
    for (int i = 0; i < measure_iters; ++i) {
        idx = idx * 1664525u + 1013904223u;         // 一个线性同余生成器形式，类似伪随机数生成
    }

    uint64_t end = clock64();

    asm volatile("" ::: "memory");

    if (threadIdx.x == 0 && blockIdx.x == 0) {
        cycles_out[0] = end - start;
        sink_out[0] = idx;
    }
}

// 构造随机 pointer-chase 链，随机是为了避免 GPU 硬件可能通过 
// cache line、prefetch、内存合并等机制提前或高效访问
// chain[i] = next index。
// 形成一个覆盖所有元素的环。
std::vector<uint32_t> make_random_chain(size_t n, uint32_t seed = 1234) {
    std::vector<uint32_t> perm(n);
    for (size_t i = 0; i < n; ++i) {
        perm[i] = static_cast<uint32_t>(i);
    }

    std::mt19937 rng(seed);
    std::shuffle(perm.begin(), perm.end(), rng);

    std::vector<uint32_t> chain(n);

    for (size_t i = 0; i < n; ++i) {
        uint32_t cur = perm[i];
        uint32_t nxt = perm[(i + 1) % n];
        chain[cur] = nxt;
    }

    return chain;
}

double measure_one_size(size_t working_set_bytes,
                        uint64_t  warmup_iters,
                        uint64_t  measure_iters,
                        bool subtract_overhead) {
    size_t n = working_set_bytes / sizeof(uint32_t);

    if (n < 2) {
        fprintf(stderr, "working set too small\n");
        std::exit(EXIT_FAILURE);
    }

    if (n > UINT32_MAX) {
        fprintf(stderr, "working set too large for uint32 index\n");
        std::exit(EXIT_FAILURE);
    }

    std::vector<uint32_t> h_chain = make_random_chain(n);

    uint32_t *d_chain = nullptr;
    uint64_t *d_cycles = nullptr;
    uint32_t *d_sink = nullptr;         // GPU 上保存最终 idx

    CUDA_CHECK(cudaMalloc(&d_chain, n * sizeof(uint32_t)));
    CUDA_CHECK(cudaMalloc(&d_cycles, sizeof(uint64_t)));
    CUDA_CHECK(cudaMalloc(&d_sink, sizeof(uint32_t)));

    CUDA_CHECK(cudaMemcpy(d_chain,
                          h_chain.data(),       // .data() 提取指向首元素的原始指针
                          n * sizeof(uint32_t),
                          cudaMemcpyHostToDevice));

    CUDA_CHECK(cudaDeviceSynchronize());

    // hint: 尽量把统一空间划给 L1 cache
    cudaFuncSetAttribute(
        pchase_latency_kernel,
        cudaFuncAttributePreferredSharedMemoryCarveout,
        cudaSharedmemCarveoutMaxL1
    );
    // 测 p-chase
    // 由于这里是 latency 测试，只有一个线程可以避免 warp 调度隐藏 latency，
    // memory-level parallelism 增加, cache 访问干扰， 多线程访问合并等问题
    pchase_latency_kernel<<<1, 1>>>(d_chain,
                                    d_cycles,
                                    d_sink,
                                    warmup_iters,
                                    measure_iters);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());

    uint64_t h_cycles = 0;
    uint32_t h_sink = 0;

    CUDA_CHECK(cudaMemcpy(&h_cycles,
                          d_cycles,
                          sizeof(uint64_t),
                          cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(&h_sink,
                          d_sink,
                          sizeof(uint32_t),
                          cudaMemcpyDeviceToHost));

    double cycles_per_load = static_cast<double>(h_cycles) /
                             static_cast<double>(measure_iters);

    if (subtract_overhead) {
        overhead_kernel<<<1, 1>>>(d_cycles, d_sink, measure_iters);
        CUDA_CHECK(cudaGetLastError());
        CUDA_CHECK(cudaDeviceSynchronize());

        uint64_t h_overhead_cycles = 0;
        CUDA_CHECK(cudaMemcpy(&h_overhead_cycles,
                              d_cycles,
                              sizeof(uint64_t),
                              cudaMemcpyDeviceToHost));

        double overhead_per_iter =
            static_cast<double>(h_overhead_cycles) /
            static_cast<double>(measure_iters);

        cycles_per_load -= overhead_per_iter;
    }

    // 使用 sink，防止编译器认为结果无用。
    if (h_sink == 0xFFFFFFFFu) {
        printf("Impossible sink value\n");
    }

    CUDA_CHECK(cudaFree(d_chain));
    CUDA_CHECK(cudaFree(d_cycles));
    CUDA_CHECK(cudaFree(d_sink));

    return cycles_per_load;
}

int main() {
    int dev = 0;
    CUDA_CHECK(cudaSetDevice(dev));

    // 读取并打印 GPU 基本信息，方便后面解释 cache/显存边界。
    cudaDeviceProp prop{};
    CUDA_CHECK(cudaGetDeviceProperties(&prop, dev));

    printf("Device: %s\n", prop.name);
    printf("SM count: %d\n", prop.multiProcessorCount);
    printf("Compute capability: %d.%d\n", prop.major, prop.minor);
    printf("L2 cache size: %.2f MiB\n",
           prop.l2CacheSize / 1024.0 / 1024.0);
    printf("Global memory: %.2f GiB\n",
           prop.totalGlobalMem / 1024.0 / 1024.0 / 1024.0);
    printf("Memory bus width: %d bits\n", prop.memoryBusWidth);
    printf("\n");

    // 使用 NVML 获取当前实时频率
    NVML_CHECK(nvmlInit());

    // 更稳妥：通过 PCI Bus ID 找到对应 NVML 设备
    char pci_bus_id[32] = {};
    CUDA_CHECK(cudaDeviceGetPCIBusId(pci_bus_id, sizeof(pci_bus_id), dev));

    nvmlDevice_t nvml_dev;
    NVML_CHECK(nvmlDeviceGetHandleByPciBusId(pci_bus_id, &nvml_dev));

    unsigned int graphics_clock = 0;
    unsigned int sm_clock = 0;
    unsigned int mem_clock = 0;

    NVML_CHECK(nvmlDeviceGetClockInfo(nvml_dev, NVML_CLOCK_GRAPHICS, &graphics_clock));
    NVML_CHECK(nvmlDeviceGetClockInfo(nvml_dev, NVML_CLOCK_SM, &sm_clock));
    NVML_CHECK(nvmlDeviceGetClockInfo(nvml_dev, NVML_CLOCK_MEM, &mem_clock));

    printf("PCI Bus ID:                 %s\n", pci_bus_id);
    printf("Current GPU graphics clock: %u MHz\n", graphics_clock);
    printf("Current SM clock:           %u MHz\n", sm_clock);
    printf("Current memory clock:       %u MHz\n", mem_clock);
    printf("\n");
    
    bool subtract_overhead = false;

    std::vector<size_t> sizes;

    /*
     * 构造 working set 序列。
     *
     * 小 working set 主要测 L1；
     * 中等 working set 主要测 L2；
     * 超过 L2 的 working set 主要测显存。
     *
     * 在 cache 边界附近使用更细步进，
     * 因为延迟突变通常发生在这些位置。
     */

    // L1 重点区间：4KB ~ 256KB，每 4KB 测一次。
    // 你的结果显示 L1 转折大约出现在 64KB ~ 128KB，
    // 所以这里加密采样。
    for (size_t kb = 4; kb <= 256; kb += 4) {
        sizes.push_back(kb * 1024ull);
    }

    // L1 到 L2 过渡区：320KB ~ 4MB，每 64KB 测一次。
    // 用来观察延迟如何从 L1 miss 逐渐稳定到 L2 hit。
    for (size_t kb = 320; kb <= 4096; kb += 64) {
        sizes.push_back(kb * 1024ull);
    }

    // L2 稳定区：5MB ~ 32MB，每 1MB 测一次。
    // 你的结果中这一段基本稳定在 L2 hit latency。
    for (size_t mb = 5; mb <= 32; mb += 1) {
        sizes.push_back(mb * 1024ull * 1024ull);
    }

    // L2 边界区：36MB ~ 128MB，每 4MB 测一次。
    // 你的 GPU L2 是 64MiB，所以这里重点观察 L2 miss 转折。
    for (size_t mb = 36; mb <= 128; mb += 4) {
        sizes.push_back(mb * 1024ull * 1024ull);
    }

    // DRAM 区间：160MB ~ 2048MB，每 64MB 测一次。
    // 超过 L2 后主要观察显存访问延迟。
    for (size_t mb = 160; mb <= 2048; mb += 64) {
        sizes.push_back(mb * 1024ull * 1024ull);
    }

    printf("working_set_KB, cycles_per_dependent_load\n");

    for (size_t bytes : sizes) {
        size_t n = bytes / sizeof(uint32_t);

        /*
         * 动态设置迭代次数，要求至少 warmup_iters >= n，即整个 pointer chain 至少访问完整一圈
         *
         * 为什么不用固定次数？
         * - 小 working set：至少 1M 次，降低计时噪声；
         * - 大 working set：迭代次数随元素数增加，尽量覆盖更多链节点；
         * - 超大 working set：设置上限，避免运行时间过长。
         */
        uint64_t min_iters = 1ull << 20;   // 至少 1M 次
        uint64_t max_iters = 1ull << 26;   // 最多 64M 次

        uint64_t target_iters = 4ull * static_cast<uint64_t>(n);

        uint64_t warmup_iters =
            std::min<uint64_t>(
                std::max<uint64_t>(min_iters, target_iters),
                max_iters
            );

        uint64_t measure_iters =
            std::min<uint64_t>(
                std::max<uint64_t>(min_iters, target_iters),
                max_iters
            );

        printf("Running working set = %zu KB, warmup_iters = %llu, measure_iters = %llu ...\n",
               bytes / 1024,
               static_cast<unsigned long long>(warmup_iters),
               static_cast<unsigned long long>(measure_iters));
        fflush(stdout);

        // 对当前 working set 做 pointer chasing，返回平均每次依赖 load 的 cycle 数。
        double cyc = measure_one_size(bytes,
                                      warmup_iters,
                                      measure_iters,
                                      subtract_overhead);

        printf("%zu, %.2f\n", bytes / 1024, cyc);
        fflush(stdout);
    }

    return 0;
}