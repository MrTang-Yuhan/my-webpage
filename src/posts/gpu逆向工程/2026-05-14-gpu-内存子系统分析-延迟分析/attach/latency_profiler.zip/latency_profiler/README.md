# NVIDIA GPU 内存子系统延迟测试

用 单线程 pointer chasing 构造一串“下一次访存地址依赖上一次访存结果”的 global memory load，从而让 GPU 无法并行隐藏访存延迟，然后通过改变 working set 大小，观察平均每次 load 的 cycle 数，从而推断 L1 / L2 / DRAM 的访问延迟边界。

# 文件结构

- `./l1_latency/`：未旁路 L1 cache 的延迟测试结果  
  - `l1_latency_pchase.cu`：测试程序源码  
  - `gpu_clock_lock.sh`：用于锁定 SM 频率和显存频率的脚本，本质上是调用 `nvidia-smi` 相关命令  
  - `makefile`：用于编译和运行测试程序。编译后会在 `./l1_latency/build/` 目录下生成可执行文件 `l1_latency_pchase`，以及对应的 PTX 文件 `l1_latency_pchase_sm_120.ptx` 和 SASS 文件 `l1_latency_pchase_sm_120.sass`  
  - 程序运行结果：
    - 原始数据文件：`result_l1_latency_pchase_sm1000_mem14800.txt`、`result_l1_latency_pchase_sm2950_mem14800.txt`
    - 对应绘图结果：`result_l1_latency_pchase_sm1000_mem14800.png`、`result_l1_latency_pchase_sm2950_mem14800.png`

- `./l2_latency/`: 旁路 L1 的延迟测试结果，整体文件结构与 `./l1_latency/` 一致

- `plot_latency.py`: 画图脚本。通过输入原始数据文件（如 `result_l1_latency_pchase_sm1000_mem14800.txt`）生成对应绘图结果（如`result_l1_latency_pchase_sm1000_mem14800.png`）

# 测试结果

| 组件 | SM 997 / Mem 14801  | SM 2932 / Mem 14801 | SM 997 / Mem 14801 (bypass L1) | SM 2947 / Mem 14801 (bypass L1) |
|------|-------------------- |---------------------|--------------------------------|---------------------------------|
| L1   | 43                  | 43                  | \                              | \                               |                    
| L2   |  302                | 366                 |302                             | 366                             |                    
| Mem  | 520                 | 922                 | 518                            | 920                             |                 
