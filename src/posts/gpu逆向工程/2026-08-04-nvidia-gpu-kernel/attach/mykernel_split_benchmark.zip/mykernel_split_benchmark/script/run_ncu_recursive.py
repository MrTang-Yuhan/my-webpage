#!/usr/bin/env python3
import argparse
import os
import stat
import subprocess
from pathlib import Path

NCU_METRICS = [
    "lts__t_sectors",
    "lts__t_sectors_op_read",
    "lts__t_sectors_op_write",
    "lts__t_sectors_lookup_hit",
    "lts__t_sectors_lookup_miss",
    "lts__t_requests",
    "lts__t_requests_op_read",
    "lts__t_requests_op_write",
    "lts__t_requests_lookup_hit",
    "lts__t_requests_lookup_miss",
    "dram__sectors",
    "dram__bytes",
    "gpu__cycles_elapsed",
    "gpu__time_duration",
    "gpu__time_duration",
    "smsp__sass_thread_inst_executed_op_fadd_pred_on",
    "smsp__sass_thread_inst_executed_op_fmul_pred_on",
    "smsp__sass_thread_inst_executed_op_ffma_pred_on",
    "smsp__sass_thread_inst_executed_op_dadd_pred_on",
    "smsp__sass_thread_inst_executed_op_dmul_pred_on",
    "smsp__sass_thread_inst_executed_op_dfma_pred_on",
    "smsp__sass_thread_inst_executed_op_hadd_pred_on",
    "smsp__sass_thread_inst_executed_op_hmul_pred_on",
    "smsp__sass_thread_inst_executed_op_hfma_pred_on",
    "sm__pipe_tensor_cycles_active.avg",
    "sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed",
]

def is_executable_file(path: Path) -> bool:
    """
    判断是否是普通可执行文件。
    """
    if not path.is_file():
        return False

    try:
        mode = path.stat().st_mode
    except OSError:
        return False

    return bool(mode & stat.S_IXUSR)

def is_elf_file(path: Path) -> bool:
    """
    判断是否是 ELF 文件。
    Linux 下 CUDA 可执行文件一般是 ELF。
    """
    try:
        with path.open("rb") as f:
            magic = f.read(4)
        return magic == b"\x7fELF"
    except OSError:
        return False

def should_skip_file(path: Path) -> bool:
    """
    跳过明显不应该执行的文件。
    """
    suffixes_to_skip = {
        ".csv",
        ".txt",
        ".log",
        ".json",
        ".ncu-rep",
        ".so",
        ".a",
        ".o",
        ".cu",
        ".cpp",
        ".c",
        ".h",
        ".hpp",
        ".py",
        ".sh",
    }

    if path.suffix in suffixes_to_skip:
        return True

    return False

def find_executables(root_dir: Path, elf_only: bool = True):
    """
    递归查找可执行文件。
    """
    for path in root_dir.rglob("*"):
        if should_skip_file(path):
            continue

        if not is_executable_file(path):
            continue

        if elf_only and not is_elf_file(path):
            continue

        yield path

def run_ncu_on_executable(
    exe_path: Path,
    ncu_path: str,
    overwrite: bool,
    dry_run: bool,
    extra_args,
):
    """
    对单个可执行文件运行 ncu。
    """
    csv_path = exe_path.with_suffix(exe_path.suffix + ".csv") if exe_path.suffix else exe_path.with_suffix(".csv")

    # 如果你希望 a.out -> a.out.csv，用上面的逻辑即可。
    # 例如:
    #   xxx/a.out      -> xxx/a.out.csv
    #   xxx/my_kernel  -> xxx/my_kernel.csv

    if csv_path.exists() and not overwrite:
        print(f"[SKIP] CSV already exists: {csv_path}")
        return

    metrics_str = ",".join(NCU_METRICS)

    cmd = [
        ncu_path,
        "--csv",
        "--metrics",
        metrics_str,
        str(exe_path),
    ]

    if extra_args:
        cmd.extend(extra_args)

    print("=" * 80)
    print(f"[RUN] {exe_path}")
    print(f"[OUT] {csv_path}")
    print("[CMD]", " ".join(cmd))

    if dry_run:
        return

    try:
        with csv_path.open("w", encoding="utf-8") as fout:
            result = subprocess.run(
                cmd,
                stdout=fout,
                stderr=subprocess.PIPE,
                text=True,
                cwd=str(exe_path.parent),
            )

        if result.returncode == 0:
            print(f"[OK] {exe_path}")
        else:
            print(f"[FAILED] {exe_path}, return code = {result.returncode}")
            print("[STDERR]")
            print(result.stderr)

            err_path = csv_path.with_suffix(csv_path.suffix + ".err")
            with err_path.open("w", encoding="utf-8") as ferr:
                ferr.write(result.stderr)
            print(f"[ERR LOG] {err_path}")

    except Exception as e:
        print(f"[ERROR] Failed to run ncu on {exe_path}")
        print(e)

def main():
    parser = argparse.ArgumentParser(
        description="Recursively run Nsight Compute ncu on CUDA executables."
    )

    parser.add_argument(
        "directory",
        type=str,
        help="需要递归遍历的目录",
    )

    parser.add_argument(
        "--ncu",
        type=str,
        default="ncu",
        help="ncu 可执行文件路径，默认使用 PATH 中的 ncu",
    )

    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="如果 CSV 已存在，则覆盖",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只打印将要执行的命令，不真正运行",
    )

    parser.add_argument(
        "--no-elf-check",
        action="store_true",
        help="不检查 ELF magic，只要有可执行权限就运行",
    )

    parser.add_argument(
        "--exe-args",
        nargs=argparse.REMAINDER,
        help="传给每个可执行文件的额外参数。注意放在最后，例如 --exe-args arg1 arg2",
    )

    args = parser.parse_args()

    root_dir = Path(args.directory).resolve()

    if not root_dir.exists():
        raise FileNotFoundError(f"Directory does not exist: {root_dir}")

    if not root_dir.is_dir():
        raise NotADirectoryError(f"Not a directory: {root_dir}")

    print(f"[ROOT] {root_dir}")

    executables = list(
        find_executables(
            root_dir,
            elf_only=not args.no_elf_check,
        )
    )

    print(f"[FOUND] {len(executables)} executable file(s)")

    for exe_path in executables:
        run_ncu_on_executable(
            exe_path=exe_path,
            ncu_path=args.ncu,
            overwrite=args.overwrite,
            dry_run=args.dry_run,
            extra_args=args.exe_args,
        )

if __name__ == "__main__":
    main()