#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CUDA Kernel Extractor (Enhanced v6)

功能：
1. 提取 CUDA/C++ 源文件中的 __global__ kernel
2. 自动提取 kernel 依赖的：
   - 宏定义
   - 类型定义
   - 全局变量
   - device/helper 函数
3. 递归解析 include 文件
4. 扫描整个项目目录，补齐不在 include 链上的依赖
5. 正确提取嵌套 struct/class/union/enum
6. 支持函数模板提取（保留 template<...> 声明）
7. 宏定义也会继续分析其内部依赖（例如宏里引用的类型、其他宏、全局变量）
8. 会分析函数形参类型、返回类型中的自定义类型依赖
9. 生成输出文件时，自动添加函数前向声明
10. 生成一个独立的 main 函数框架，便于单独编译/测试 kernel

用法示例：
  python main.py some_kernel.cu
  python main.py some_kernel.cu --project-root ./rodinia-3.1
  python main.py --dir ./cuda_sources
  python main.py --rdir ./project
"""

import re
import argparse
from pathlib import Path
from typing import Set, Dict, List, Tuple, Optional
from dataclasses import dataclass, field

CUDA_BUILTINS = {
    'threadIdx', 'blockIdx', 'blockDim', 'gridDim', 'warpSize',
    'dim3', 'cudaError_t', 'cudaStream_t', 'cudaEvent_t',
    'int2', 'int3', 'int4',
    'uint2', 'uint3', 'uint4',
    'float2', 'float3', 'float4',
    'double2', 'double3', 'double4',
    'char2', 'char3', 'char4',
    'uchar2', 'uchar3', 'uchar4',
    'short2', 'short3', 'short4',
    'ushort2', 'ushort3', 'ushort4',
    'long2', 'long3', 'long4',
    'ulong2', 'ulong3', 'ulong4',
    'longlong2', 'longlong3', 'longlong4',
    '__syncthreads', '__syncwarp', '__threadfence', '__ballot_sync',
    '__shfl_sync', '__shfl_up_sync', '__shfl_down_sync', '__shfl_xor_sync',
    'atomicAdd', 'atomicSub', 'atomicExch', 'atomicMin', 'atomicMax',
    'atomicCAS', 'atomicAnd', 'atomicOr', 'atomicXor',
    '__umul24',
    'tex1Dfetch', 'tex2D', 'tex3D', 'texCubemap',
}

CPP_KEYWORDS = {
    'auto', 'break', 'case', 'char', 'const', 'continue', 'default', 'do',
    'double', 'else', 'enum', 'extern', 'float', 'for', 'goto', 'if',
    'int', 'long', 'register', 'return', 'short', 'signed', 'sizeof', 'static',
    'struct', 'switch', 'typedef', 'union', 'unsigned', 'void', 'volatile', 'while',
    'class', 'namespace', 'template', 'typename', 'bool', 'true', 'false',
    'public', 'private', 'protected', 'virtual', 'inline', 'explicit',
    'friend', 'operator', 'this', 'new', 'delete', 'using', 'try', 'catch',
    'throw', 'nullptr',
}

CUDA_QUALIFIERS = {
    '__global__', '__device__', '__host__', '__forceinline__',
    '__shared__', '__constant__', '__managed__',
    '__restrict__', '__restrict',
    'restrict',
    'static', 'inline', 'constexpr',
}

SOURCE_EXTENSIONS = {'.cu', '.cuh', '.h', '.hpp', '.hh', '.cpp', '.cc', '.cxx'}

@dataclass
class Symbol:
    name: str
    source: str
    definition: str = ""
    line_number: int = 0
    file_path: str = ""

@dataclass
class Function:
    name: str
    signature: str
    body: str
    is_kernel: bool
    is_device: bool
    params: List[str] = field(default_factory=list)

    # 函数形参类型中用到的符号
    param_type_symbols: Set[str] = field(default_factory=set)

    # 函数返回类型中用到的符号
    return_type_symbols: Set[str] = field(default_factory=set)

    called_functions: Set[str] = field(default_factory=set)
    used_symbols: Set[str] = field(default_factory=set)
    template_prefix: str = ""
    line_number: int = 0
    file_path: str = ""

@dataclass
class Macro:
    name: str
    definition: str
    line_number: int
    file_path: str = ""
    params: Set[str] = field(default_factory=set)
    used_symbols: Set[str] = field(default_factory=set)

@dataclass
class ProjectSymbolIndex:
    macros: Dict[str, Macro] = field(default_factory=dict)
    type_defs: Dict[str, Symbol] = field(default_factory=dict)
    global_vars: Dict[str, Symbol] = field(default_factory=dict)
    functions: Dict[str, Function] = field(default_factory=dict)

    def merge_from_analyzer(self, analyzer: "CUDASourceAnalyzer"):
        for k, v in analyzer.macros.items():
            self.macros.setdefault(k, v)
        for k, v in analyzer.type_defs.items():
            self.type_defs.setdefault(k, v)
        for k, v in analyzer.global_vars.items():
            self.global_vars.setdefault(k, v)
        for k, v in analyzer.functions.items():
            self.functions.setdefault(k, v)

@dataclass
class CUDASourceAnalyzer:
    source_code: str
    file_path: str = ""
    base_dir: Path = field(default_factory=Path)

    includes: List[str] = field(default_factory=list)
    macros: Dict[str, Macro] = field(default_factory=dict)
    global_vars: Dict[str, Symbol] = field(default_factory=dict)
    type_defs: Dict[str, Symbol] = field(default_factory=dict)
    functions: Dict[str, Function] = field(default_factory=dict)
    kernels: Dict[str, Function] = field(default_factory=dict)

    parsed_files: Set[str] = field(default_factory=set)

    def analyze(self, parse_includes: bool = True):
        self._extract_includes()
        self._extract_macros()
        self._extract_type_definitions()
        self._extract_global_variables()
        self._extract_functions()

        if parse_includes:
            self._parse_include_files()

    # =========================
    # 基础工具
    # =========================

    @staticmethod
    def _read_text_file(path: Path) -> Optional[str]:
        for enc in ('utf-8', 'latin-1', 'cp1252'):
            try:
                with open(path, 'r', encoding=enc) as f:
                    return f.read()
            except UnicodeDecodeError:
                continue
            except Exception:
                return None
        return None

    def _extract_includes(self):
        pattern = r'^\s*#\s*include\s*[<"]([^>"]+)[>"]'
        for line in self.source_code.splitlines():
            m = re.match(pattern, line)
            if m:
                self.includes.append(line.strip())

    def _resolve_include_path(self, include_name: str) -> Optional[Path]:
        candidates = [
            self.base_dir / include_name,
            Path(include_name),
            self.base_dir.parent / include_name,
        ]
        for p in candidates:
            if p.exists() and p.is_file():
                return p
        return None

    def _parse_include_files(self):
        pattern = r'^\s*#\s*include\s*[<"]([^>"]+)[>"]'
        for line in self.source_code.splitlines():
            m = re.match(pattern, line)
            if not m:
                continue

            include_name = m.group(1)
            include_path = self._resolve_include_path(include_name)
            if include_path is None:
                continue

            abs_path = str(include_path.resolve())
            if abs_path in self.parsed_files:
                continue
            self.parsed_files.add(abs_path)

            code = self._read_text_file(include_path)
            if code is None:
                continue

            sub = CUDASourceAnalyzer(
                source_code=code,
                file_path=str(include_path),
                base_dir=include_path.parent,
                parsed_files=self.parsed_files
            )
            sub.analyze(parse_includes=True)
            self._merge_symbols(sub)

    def _merge_symbols(self, other: "CUDASourceAnalyzer"):
        for name, macro in other.macros.items():
            self.macros.setdefault(name, macro)
        for name, typedef in other.type_defs.items():
            self.type_defs.setdefault(name, typedef)
        for name, var in other.global_vars.items():
            self.global_vars.setdefault(name, var)
        for name, func in other.functions.items():
            self.functions.setdefault(name, func)

    def _is_keyword(self, word: str) -> bool:
        return word in CPP_KEYWORDS

    def _strip_comments_and_strings(self, text: str) -> str:
        text = re.sub(r'//.*', ' ', text)
        text = re.sub(r'/\*.*?\*/', ' ', text, flags=re.DOTALL)
        text = re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
        text = re.sub(r"'(?:\\.|[^'\\])*'", "''", text)
        return text

    def _extract_identifiers(self, text: str) -> Set[str]:
        clean = self._strip_comments_and_strings(text)
        ids = set()
        for m in re.finditer(r'\b([A-Za-z_]\w*)\b', clean):
            name = m.group(1)
            if name in CUDA_BUILTINS:
                continue
            if name in CPP_KEYWORDS:
                continue
            if name in CUDA_QUALIFIERS:
                continue
            ids.add(name)
        return ids

    def _find_matching_brace(self, text: str, start_pos: int) -> Optional[int]:
        if start_pos >= len(text) or text[start_pos] != '{':
            return None

        level = 0
        i = start_pos
        in_string = False
        in_char = False
        in_line_comment = False
        in_block_comment = False
        escape = False

        while i < len(text):
            c = text[i]
            nxt = text[i + 1] if i + 1 < len(text) else ''

            if in_line_comment:
                if c == '\n':
                    in_line_comment = False
                i += 1
                continue

            if in_block_comment:
                if c == '*' and nxt == '/':
                    in_block_comment = False
                    i += 2
                    continue
                i += 1
                continue

            if escape:
                escape = False
                i += 1
                continue

            if c == '\\':
                escape = True
                i += 1
                continue

            if not in_char and c == '"':
                in_string = not in_string
                i += 1
                continue

            if not in_string and c == "'":
                in_char = not in_char
                i += 1
                continue

            if not in_string and not in_char:
                if c == '/' and nxt == '/':
                    in_line_comment = True
                    i += 2
                    continue
                if c == '/' and nxt == '*':
                    in_block_comment = True
                    i += 2
                    continue

                if c == '{':
                    level += 1
                elif c == '}':
                    level -= 1
                    if level == 0:
                        return i

            i += 1

        return None

    def _extract_statement_until_semicolon(self, start_pos: int) -> Optional[str]:
        text = self.source_code
        i = start_pos
        brace_level = 0
        paren_level = 0
        bracket_level = 0
        angle_level = 0
        in_string = False
        in_char = False
        in_line_comment = False
        in_block_comment = False
        escape = False

        while i < len(text):
            c = text[i]
            nxt = text[i + 1] if i + 1 < len(text) else ''

            if in_line_comment:
                if c == '\n':
                    in_line_comment = False
                i += 1
                continue

            if in_block_comment:
                if c == '*' and nxt == '/':
                    in_block_comment = False
                    i += 2
                    continue
                i += 1
                continue

            if escape:
                escape = False
                i += 1
                continue

            if c == '\\':
                escape = True
                i += 1
                continue

            if not in_char and c == '"':
                in_string = not in_string
                i += 1
                continue

            if not in_string and c == "'":
                in_char = not in_char
                i += 1
                continue

            if not in_string and not in_char:
                if c == '/' and nxt == '/':
                    in_line_comment = True
                    i += 2
                    continue
                if c == '/' and nxt == '*':
                    in_block_comment = True
                    i += 2
                    continue

                if c == '{':
                    brace_level += 1
                elif c == '}':
                    brace_level -= 1
                elif c == '(':
                    paren_level += 1
                elif c == ')':
                    paren_level -= 1
                elif c == '[':
                    bracket_level += 1
                elif c == ']':
                    bracket_level -= 1
                elif c == '<':
                    angle_level += 1
                elif c == '>':
                    angle_level = max(0, angle_level - 1)
                elif c == ';' and brace_level == 0 and paren_level == 0 and bracket_level == 0:
                    return text[start_pos:i + 1]

            i += 1

        return None

    def _extract_template_prefix(self, text: str, func_start: int) -> Tuple[str, int]:
        """
        如果函数前面紧邻 template<...> 声明，则一并提取。
        返回 (template_prefix, actual_start_pos)
        """
        prefix = ""
        start = func_start

        i = func_start - 1
        while i >= 0 and text[i].isspace():
            i -= 1

        line_start = text.rfind('\n', 0, i + 1) + 1
        chunk = text[line_start:func_start]

        template_match = re.search(
            r'(template\s*<[\s\S]*?>\s*)$',
            chunk,
            flags=re.DOTALL
        )

        if template_match:
            prefix = template_match.group(1)
            start = line_start + template_match.start(1)

        return prefix, start

    def _split_params(self, params_str: str) -> List[str]:
        result = []
        cur = []
        depth_angle = 0
        depth_paren = 0
        depth_bracket = 0

        for ch in params_str:
            if ch == '<':
                depth_angle += 1
            elif ch == '>':
                depth_angle = max(0, depth_angle - 1)
            elif ch == '(':
                depth_paren += 1
            elif ch == ')':
                depth_paren = max(0, depth_paren - 1)
            elif ch == '[':
                depth_bracket += 1
            elif ch == ']':
                depth_bracket = max(0, depth_bracket - 1)

            if ch == ',' and depth_angle == 0 and depth_paren == 0 and depth_bracket == 0:
                result.append(''.join(cur))
                cur = []
            else:
                cur.append(ch)

        if cur:
            result.append(''.join(cur))
        return result

    def _extract_param_names(self, params_str: str) -> List[str]:
        params = []
        if not params_str.strip():
            return params

        for raw in self._split_params(params_str):
            p = raw.strip()
            if not p or p == 'void':
                continue

            p = re.sub(r'\s*=\s*.*$', '', p).strip()
            m = re.search(r'([A-Za-z_]\w*)\s*(?:\[[^\]]*\])?\s*$', p)
            if m:
                params.append(m.group(1))
        return params

    def _extract_param_type_symbols(self, params_str: str) -> Set[str]:
        """
        从函数形参列表中提取类型符号。
        """
        type_symbols = set()

        if not params_str.strip():
            return type_symbols

        for raw in self._split_params(params_str):
            p = raw.strip()
            if not p or p == 'void':
                continue

            p = re.sub(r'\s*=\s*.*$', '', p).strip()

            param_name = None
            m = re.search(r'([A-Za-z_]\w*)\s*(?:\[[^\]]*\])?\s*$', p)
            if m:
                param_name = m.group(1)

            ids = self._extract_identifiers(p)

            if param_name:
                ids.discard(param_name)

            ids -= CUDA_QUALIFIERS
            type_symbols.update(ids)

        return type_symbols

    def _extract_return_type_symbols(self, signature: str, func_name: str) -> Set[str]:
        """
        从函数签名中提取返回类型涉及的类型符号。
        例如：
            __device__ MyType foo(int x)
        会提取 MyType
        """
        sig = self._strip_comments_and_strings(signature)
        m = re.search(r'^(.*?)\b' + re.escape(func_name) + r'\s*\(', sig, flags=re.DOTALL)
        if not m:
            return set()

        before_name = m.group(1).strip()
        ids = self._extract_identifiers(before_name)
        ids.discard(func_name)
        ids -= CUDA_QUALIFIERS
        return ids

    # =========================
    # 提取宏
    # =========================

    def _extract_macros(self):
        lines = self.source_code.splitlines()
        i = 0

        while i < len(lines):
            line = lines[i]
            if re.match(r'^\s*#\s*define\s+', line):
                start_line = i + 1
                macro_lines = [line]
                while line.rstrip().endswith('\\') and i + 1 < len(lines):
                    i += 1
                    line = lines[i]
                    macro_lines.append(line)

                full_def = '\n'.join(macro_lines)

                m = re.match(r'^\s*#\s*define\s+([A-Za-z_]\w*)\s*(\((.*?)\))?', full_def, flags=re.DOTALL)
                if m:
                    name = m.group(1)
                    raw_params = m.group(3)

                    params = set()
                    if raw_params is not None:
                        for p in self._split_params(raw_params):
                            p = p.strip()
                            if p:
                                p = p.replace('...', '').strip()
                                if p:
                                    params.add(p)

                    used_symbols = self._extract_identifiers(full_def)
                    used_symbols.discard(name)
                    used_symbols -= params

                    self.macros[name] = Macro(
                        name=name,
                        definition=full_def,
                        line_number=start_line,
                        file_path=self.file_path,
                        params=params,
                        used_symbols=used_symbols
                    )
            i += 1

    # =========================
    # 提取类型
    # =========================

    def _extract_type_definitions(self):
        text = self.source_code

        pattern = r'\b(struct|class|union)\s+([A-Za-z_]\w*)\s*\{'
        for m in re.finditer(pattern, text):
            name = m.group(2)
            tail = self._extract_statement_until_semicolon(m.start())
            if not tail:
                continue

            self.type_defs[name] = Symbol(
                name=name,
                source='global',
                definition=tail.strip(),
                line_number=text[:m.start()].count('\n') + 1,
                file_path=self.file_path
            )

        pattern = r'\benum\s+([A-Za-z_]\w*)\s*\{'
        for m in re.finditer(pattern, text):
            name = m.group(1)
            tail = self._extract_statement_until_semicolon(m.start())
            if not tail:
                continue

            self.type_defs[name] = Symbol(
                name=name,
                source='global',
                definition=tail.strip(),
                line_number=text[:m.start()].count('\n') + 1,
                file_path=self.file_path
            )

        typedef_pattern = r'\btypedef\b'
        for m in re.finditer(typedef_pattern, text):
            stmt = self._extract_statement_until_semicolon(m.start())
            if not stmt:
                continue
            s = stmt.strip()
            if not s.startswith('typedef'):
                continue

            alias_match = re.search(r'([A-Za-z_]\w*)\s*;\s*$', s)
            if alias_match:
                alias = alias_match.group(1)
                self.type_defs.setdefault(alias, Symbol(
                    name=alias,
                    source='global',
                    definition=s,
                    line_number=text[:m.start()].count('\n') + 1,
                    file_path=self.file_path
                ))

    # =========================
    # 提取全局变量
    # =========================

    def _extract_global_variables(self):
        lines = self.source_code.splitlines()
        in_function = 0

        for i, line in enumerate(lines):
            stripped = line.strip()

            if not stripped or stripped.startswith('//') or stripped.startswith('#'):
                in_function += line.count('{') - line.count('}')
                continue

            if in_function <= 0:
                tex_match = re.match(r'^\s*texture\s*<[^>]+>\s+([A-Za-z_]\w*)\s*;', stripped)
                if tex_match:
                    name = tex_match.group(1)
                    self.global_vars[name] = Symbol(
                        name=name,
                        source='global',
                        definition=stripped,
                        line_number=i + 1,
                        file_path=self.file_path
                    )
                    in_function += line.count('{') - line.count('}')
                    continue

                var_match = re.match(
                    r'^\s*(?:(?:__device__|__constant__|__shared__|static|extern|const|volatile)\s+)*'
                    r'([A-Za-z_]\w*(?:\s*[*&]\s*)*)'
                    r'\s+([A-Za-z_]\w*)'
                    r'(?:\s*\[[^\]]*\])*'
                    r'(?:\s*=\s*.+)?'
                    r'\s*;',
                    stripped
                )
                if var_match and '(' not in stripped:
                    name = var_match.group(2)
                    self.global_vars.setdefault(name, Symbol(
                        name=name,
                        source='global',
                        definition=stripped,
                        line_number=i + 1,
                        file_path=self.file_path
                    ))

            in_function += line.count('{') - line.count('}')

    # =========================
    # 提取函数（支持模板）
    # =========================

    def _extract_functions(self):
        text = self.source_code

        pattern = (
            r'((?:(?:__global__|__device__|__host__|__forceinline__|static|inline|constexpr)\s+)+)'
            r'([A-Za-z_]\w*(?:\s*[*&]\s*)*)\s+'
            r'([A-Za-z_]\w*)\s*'
            r'\(([^)]*)\)\s*\{'
        )

        for m in re.finditer(pattern, text):
            qualifiers = m.group(1) or ""
            func_name = m.group(3)
            params_str = m.group(4)

            start_brace = m.end() - 1
            end_brace = self._find_matching_brace(text, start_brace)
            if end_brace is None:
                continue

            template_prefix, actual_start = self._extract_template_prefix(text, m.start())
            signature = text[actual_start:start_brace].strip()
            body = text[start_brace + 1:end_brace]

            is_kernel = '__global__' in qualifiers
            is_device = '__device__' in qualifiers

            params = self._extract_param_names(params_str)
            param_type_symbols = self._extract_param_type_symbols(params_str)
            return_type_symbols = self._extract_return_type_symbols(signature, func_name)

            called_functions, used_symbols = self._analyze_function_body(body, set(params))

            fn = Function(
                name=func_name,
                signature=signature,
                body=body,
                is_kernel=is_kernel,
                is_device=is_device,
                params=params,
                param_type_symbols=param_type_symbols,
                return_type_symbols=return_type_symbols,
                called_functions=called_functions,
                used_symbols=used_symbols,
                template_prefix=template_prefix,
                line_number=text[:actual_start].count('\n') + 1,
                file_path=self.file_path
            )

            if is_kernel:
                self.kernels[func_name] = fn
            else:
                self.functions[func_name] = fn

    def _analyze_function_body(self, body: str, params: Set[str]) -> Tuple[Set[str], Set[str]]:
        clean_body = self._strip_comments_and_strings(body)

        called_functions = set()
        used_symbols = set()

        for m in re.finditer(r'\b([A-Za-z_]\w*)\s*\(', clean_body):
            name = m.group(1)
            if name not in {'if', 'while', 'for', 'switch', 'sizeof', 'return'}:
                called_functions.add(name)

        local_vars = set()
        local_var_pattern = (
            r'\b(?:int|float|double|char|short|long|unsigned|signed|bool|void|auto|'
            r'uchar|uchar2|uchar3|uchar4|uint|uint2|uint3|uint4|int2|int3|int4)\b'
            r'(?:\s+[*&]\s*|\s+)'
            r'([A-Za-z_]\w*)\s*(?:[;=,\[])'
        )
        for m in re.finditer(local_var_pattern, clean_body):
            local_vars.add(m.group(1))

        for m in re.finditer(r'\b([A-Za-z_]\w*)\b', clean_body):
            sym = m.group(1)
            if sym in params:
                continue
            if sym in local_vars:
                continue
            if sym in called_functions:
                continue
            if sym in CUDA_BUILTINS:
                continue
            if sym in CPP_KEYWORDS:
                continue
            if sym in CUDA_QUALIFIERS:
                continue
            used_symbols.add(sym)

        return called_functions, used_symbols

    # =========================
    # 外部项目索引补全
    # =========================

    def resolve_external_dependencies(self, project_index: ProjectSymbolIndex):
        for kernel in list(self.kernels.values()):
            self._resolve_function_recursively(kernel, project_index, set())

        for macro_name in list(self.macros.keys()):
            self._resolve_macro_recursively(macro_name, project_index, set())

    def _resolve_type_recursively(
        self,
        type_name: str,
        project_index: ProjectSymbolIndex,
        visited_types: Set[str]
    ):
        if type_name in visited_types:
            return
        visited_types.add(type_name)

        if type_name not in self.type_defs and type_name in project_index.type_defs:
            self.type_defs[type_name] = project_index.type_defs[type_name]

        if type_name not in self.type_defs:
            return

        typedef = self.type_defs[type_name]
        ids = self._extract_identifiers(typedef.definition)
        ids.discard(type_name)

        for sym in ids:
            if sym in self.type_defs or sym in project_index.type_defs:
                self._resolve_type_recursively(sym, project_index, visited_types)

            elif sym in self.macros:
                self._resolve_macro_recursively(sym, project_index, set())

            elif sym in project_index.macros:
                self.macros[sym] = project_index.macros[sym]
                self._resolve_macro_recursively(sym, project_index, set())

            elif sym not in self.global_vars and sym in project_index.global_vars:
                self.global_vars[sym] = project_index.global_vars[sym]

    def _resolve_function_recursively(
        self,
        func: Function,
        project_index: ProjectSymbolIndex,
        visited_funcs: Set[str]
    ):
        if func.name in visited_funcs:
            return
        visited_funcs.add(func.name)

        # 先解析形参类型中的依赖
        for type_sym in list(func.param_type_symbols):
            if type_sym in self.type_defs or type_sym in project_index.type_defs:
                self._resolve_type_recursively(type_sym, project_index, set())
            elif type_sym in self.macros:
                self._resolve_macro_recursively(type_sym, project_index, set())
            elif type_sym in project_index.macros:
                self.macros[type_sym] = project_index.macros[type_sym]
                self._resolve_macro_recursively(type_sym, project_index, set())

        # 再解析返回类型中的依赖
        for type_sym in list(func.return_type_symbols):
            if type_sym in self.type_defs or type_sym in project_index.type_defs:
                self._resolve_type_recursively(type_sym, project_index, set())
            elif type_sym in self.macros:
                self._resolve_macro_recursively(type_sym, project_index, set())
            elif type_sym in project_index.macros:
                self.macros[type_sym] = project_index.macros[type_sym]
                self._resolve_macro_recursively(type_sym, project_index, set())

        for called in list(func.called_functions):
            if called in self.functions:
                self._resolve_function_recursively(self.functions[called], project_index, visited_funcs)
                continue

            if called in project_index.functions:
                self.functions[called] = project_index.functions[called]
                self._resolve_function_recursively(self.functions[called], project_index, visited_funcs)
                continue

            if called in self.macros:
                self._resolve_macro_recursively(called, project_index, set())
                continue

            if called in project_index.macros:
                self.macros[called] = project_index.macros[called]
                self._resolve_macro_recursively(called, project_index, set())
                continue

        for sym in list(func.used_symbols):
            if sym in self.global_vars or sym in self.type_defs or sym in self.macros:
                continue

            if sym in project_index.global_vars:
                self.global_vars[sym] = project_index.global_vars[sym]
                continue

            if sym in project_index.type_defs:
                self.type_defs[sym] = project_index.type_defs[sym]
                self._resolve_type_recursively(sym, project_index, set())
                continue

            if sym in project_index.macros:
                self.macros[sym] = project_index.macros[sym]
                self._resolve_macro_recursively(sym, project_index, set())
                continue

        for called in list(func.called_functions):
            if called in self.functions:
                self._resolve_function_recursively(self.functions[called], project_index, visited_funcs)

    def _resolve_macro_recursively(
        self,
        macro_name: str,
        project_index: ProjectSymbolIndex,
        visited_macros: Set[str]
    ):
        if macro_name in visited_macros:
            return
        visited_macros.add(macro_name)

        macro = self.macros.get(macro_name)
        if macro is None:
            if macro_name in project_index.macros:
                self.macros[macro_name] = project_index.macros[macro_name]
                macro = self.macros[macro_name]
            else:
                return

        for sym in list(macro.used_symbols):
            if sym in self.macros:
                self._resolve_macro_recursively(sym, project_index, visited_macros)
                continue
            if sym in project_index.macros:
                self.macros[sym] = project_index.macros[sym]
                self._resolve_macro_recursively(sym, project_index, visited_macros)
                continue

            if sym not in self.type_defs and sym in project_index.type_defs:
                self.type_defs[sym] = project_index.type_defs[sym]
                self._resolve_type_recursively(sym, project_index, set())

            if sym not in self.global_vars and sym in project_index.global_vars:
                self.global_vars[sym] = project_index.global_vars[sym]

            if sym not in self.functions and sym in project_index.functions:
                self.functions[sym] = project_index.functions[sym]

    # =========================
    # 收集 kernel 依赖
    # =========================

    def collect_dependencies_for_kernel(self, kernel: Function) -> Dict[str, Set[str]]:
        deps = {
            'functions': set(),
            'global_vars': set(),
            'type_defs': set(),
            'macros': set(),
        }

        visited_funcs = set()
        visited_macros = set()
        visited_types = set()

        def visit_type(type_name: str):
            if type_name in visited_types:
                return
            visited_types.add(type_name)

            if type_name not in self.type_defs:
                return

            deps['type_defs'].add(type_name)
            typedef = self.type_defs[type_name]
            ids = self._extract_identifiers(typedef.definition)
            ids.discard(type_name)

            for sym in ids:
                if sym in self.type_defs:
                    visit_type(sym)
                elif sym in self.macros:
                    visit_macro(sym)
                elif sym in self.global_vars:
                    deps['global_vars'].add(sym)

        def visit_macro(macro_name: str):
            if macro_name in visited_macros:
                return
            visited_macros.add(macro_name)

            if macro_name not in self.macros:
                return

            deps['macros'].add(macro_name)
            macro = self.macros[macro_name]

            for sym in macro.used_symbols:
                if sym in self.macros:
                    visit_macro(sym)
                elif sym in self.type_defs:
                    visit_type(sym)
                elif sym in self.global_vars:
                    deps['global_vars'].add(sym)
                elif sym in self.functions:
                    deps['functions'].add(sym)
                    visit_function(self.functions[sym])

        def visit_function(fn: Function):
            if fn.name in visited_funcs:
                return
            visited_funcs.add(fn.name)

            # 形参类型依赖
            for sym in fn.param_type_symbols:
                if sym in self.type_defs:
                    visit_type(sym)
                elif sym in self.macros:
                    visit_macro(sym)
                elif sym in self.global_vars:
                    deps['global_vars'].add(sym)

            # 返回类型依赖
            for sym in fn.return_type_symbols:
                if sym in self.type_defs:
                    visit_type(sym)
                elif sym in self.macros:
                    visit_macro(sym)
                elif sym in self.global_vars:
                    deps['global_vars'].add(sym)

            for called in fn.called_functions:
                if called in self.functions:
                    deps['functions'].add(called)
                    visit_function(self.functions[called])
                elif called in self.macros:
                    visit_macro(called)

            for sym in fn.used_symbols:
                if sym in self.global_vars:
                    deps['global_vars'].add(sym)
                elif sym in self.type_defs:
                    visit_type(sym)
                elif sym in self.macros:
                    visit_macro(sym)

        visit_function(kernel)

        return deps

    # =========================
    # 输出文件
    # =========================

    def generate_kernel_file(self, kernel_name: str, output_dir: str):
        if kernel_name not in self.kernels:
            print(f"错误: 找不到 kernel '{kernel_name}'")
            return

        kernel = self.kernels[kernel_name]
        deps = self.collect_dependencies_for_kernel(kernel)
        content = self._generate_file_content(kernel, deps)

        out_path = Path(output_dir) / f"single_kernel_{kernel_name}.cu"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(content)

        print(f"已生成: {out_path}")

    def _make_forward_decl(self, fn: Function) -> str:
        sig = fn.signature.strip()
        sig = sig.rstrip('{').strip()
        return f"{sig};"

    def _guess_param_memory_role(self, param_name: str) -> str:
        lower = param_name.lower()
        if lower.startswith('out') or lower.startswith('dst') or lower.startswith('res') or lower.startswith('result'):
            return "output"
        if lower.startswith('in') or lower.startswith('src') or lower.startswith('input'):
            return "input"
        return "buffer"

    def _generate_main_function(self, kernel: Function) -> str:
        lines = []
        lines.append("int main(int argc, char** argv) {")
        lines.append("    cudaError_t err;")
        lines.append("")

        # 尝试推断二维 PolyBench 风格
        uses_NI = 'NI' in self.macros
        uses_NJ = 'NJ' in self.macros

        if uses_NI and uses_NJ:
            lines.append("    const int width = NJ;")
            lines.append("    const int height = NI;")
            lines.append("    const size_t size = (size_t)width * height;")
        else:
            lines.append("    // TODO: set problem size")
            lines.append("    const size_t size = 1024;")

        lines.append("")

        pointer_params = []
        scalar_params = []

        sig_params_match = re.search(r'\((.*)\)', kernel.signature, flags=re.DOTALL)
        raw_params_str = sig_params_match.group(1) if sig_params_match else ""

        raw_params = self._split_params(raw_params_str) if raw_params_str.strip() else []

        for raw in raw_params:
            p = raw.strip()
            if not p or p == "void":
                continue

            p_no_default = re.sub(r'\s*=\s*.*$', '', p).strip()
            name_match = re.search(r'([A-Za-z_]\w*)\s*(?:\[[^\]]*\])?\s*$', p_no_default)
            if not name_match:
                continue

            param_name = name_match.group(1)
            if '*' in p_no_default or '[' in p_no_default:
                pointer_params.append((param_name, p_no_default))
            else:
                scalar_params.append((param_name, p_no_default))

        lines.append("    // ===== Host/Device buffers =====")
        for param_name, raw in pointer_params:
            role = self._guess_param_memory_role(param_name)
            lines.append(f"    // {role}: {raw}")
            lines.append(f"    DATA_TYPE *h_{param_name} = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));")
            lines.append(f"    DATA_TYPE *d_{param_name} = nullptr;")
            lines.append(f"    if (!h_{param_name}) {{")
            lines.append(f'        printf("malloc failed for h_{param_name}\\n");')
            lines.append("        return -1;")
            lines.append("    }")
            lines.append("")

        for param_name, raw in scalar_params:
            lines.append(f"    // scalar param: {raw}")
            lines.append(f"    // TODO: initialize scalar parameter `{param_name}`")
            lines.append(f"    auto {param_name} = 0;")
            lines.append("")

        lines.append("    // ===== Initialize host data =====")
        for param_name, _ in pointer_params:
            lines.append(f"    for (size_t i = 0; i < size; ++i) h_{param_name}[i] = (DATA_TYPE)(i % 100);")
        if not pointer_params:
            lines.append("    // TODO: no pointer parameter detected, initialize your own inputs")
        lines.append("")

        lines.append("    // ===== Allocate device memory =====")
        for param_name, _ in pointer_params:
            lines.append(f"    err = cudaMalloc((void**)&d_{param_name}, size * sizeof(DATA_TYPE));")
            lines.append("    if (err != cudaSuccess) {")
            lines.append(f'        printf("cudaMalloc failed for d_{param_name}: %s\\n", cudaGetErrorString(err));')
            lines.append("        return -1;")
            lines.append("    }")
        lines.append("")

        lines.append("    // ===== Copy inputs to device =====")
        for param_name, _ in pointer_params:
            lines.append(f"    err = cudaMemcpy(d_{param_name}, h_{param_name}, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);")
            lines.append("    if (err != cudaSuccess) {")
            lines.append(f'        printf("cudaMemcpy H2D failed for {param_name}: %s\\n", cudaGetErrorString(err));')
            lines.append("        return -1;")
            lines.append("    }")
        lines.append("")

        lines.append("    // ===== Launch configuration =====")
        lines.append("    dim3 blockSize(16, 16);")
        if uses_NI and uses_NJ:
            lines.append("    dim3 gridSize((NJ + blockSize.x - 1) / blockSize.x,")
            lines.append("                  (NI + blockSize.y - 1) / blockSize.y);")
        else:
            lines.append("    dim3 gridSize((size + blockSize.x - 1) / blockSize.x, 1);")
        lines.append("")

        lines.append("    cudaEvent_t start, stop;")
        lines.append("    cudaEventCreate(&start);")
        lines.append("    cudaEventCreate(&stop);")
        lines.append("")

        call_args = []
        for param_name, _ in pointer_params:
            call_args.append(f"d_{param_name}")
        for param_name, _ in scalar_params:
            call_args.append(param_name)

        call_arg_str = ", ".join(call_args)

        lines.append("    // ===== Launch kernel =====")
        lines.append("    cudaEventRecord(start);")
        lines.append(f"    {kernel.name}<<<gridSize, blockSize>>>({call_arg_str});")
        lines.append("    cudaEventRecord(stop);")
        lines.append("")

        lines.append("    err = cudaGetLastError();")
        lines.append("    if (err != cudaSuccess) {")
        lines.append('        printf("Kernel launch failed: %s\\n", cudaGetErrorString(err));')
        lines.append("        return -1;")
        lines.append("    }")
        lines.append("")

        lines.append("    err = cudaDeviceSynchronize();")
        lines.append("    if (err != cudaSuccess) {")
        lines.append('        printf("Kernel execution failed: %s\\n", cudaGetErrorString(err));')
        lines.append("        return -1;")
        lines.append("    }")
        lines.append("")

        lines.append("    cudaEventSynchronize(stop);")
        lines.append("    float milliseconds = 0.0f;")
        lines.append("    cudaEventElapsedTime(&milliseconds, start, stop);")
        lines.append('    printf("Kernel execution time: %.3f ms\\n", milliseconds);')
        lines.append("")

        if pointer_params:
            last_param_name = pointer_params[-1][0]
            lines.append("    // ===== Copy one buffer back as example =====")
            lines.append(f"    err = cudaMemcpy(h_{last_param_name}, d_{last_param_name}, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);")
            lines.append("    if (err != cudaSuccess) {")
            lines.append(f'        printf("cudaMemcpy D2H failed for {last_param_name}: %s\\n", cudaGetErrorString(err));')
            lines.append("        return -1;")
            lines.append("    }")
            lines.append("")
            lines.append("    // TODO: verify results")
            lines.append(f'    printf("Sample output: %f\\n", (double)h_{last_param_name}[0]);')
            lines.append("")

        lines.append("    // ===== Cleanup =====")
        for param_name, _ in pointer_params:
            lines.append(f"    if (d_{param_name}) cudaFree(d_{param_name});")
        for param_name, _ in pointer_params:
            lines.append(f"    if (h_{param_name}) free(h_{param_name});")
        lines.append("    cudaEventDestroy(start);")
        lines.append("    cudaEventDestroy(stop);")
        lines.append("")
        lines.append('    printf("Done!\\n");')
        lines.append("    return 0;")
        lines.append("}")

        return '\n'.join(lines)

    def _generate_file_content(self, kernel: Function, deps: Dict[str, Set[str]]) -> str:
        lines = []
        lines.append(f"// Auto-generated CUDA kernel file: {kernel.name}")
        lines.append(f"// Extracted from: {self.file_path or 'source'}")
        lines.append(f"// Original line: {kernel.line_number}")
        lines.append("")

        lines.append("// ===== Includes =====")
        include_set = set(self.includes)

        # 若原始文件没包含运行 main 所需头文件，则补上
        extra_includes = [
            "#include <stdio.h>",
            "#include <stdlib.h>",
            "#include <cuda.h>",
        ]
        for inc in extra_includes:
            include_set.add(inc)

        for inc in sorted(include_set):
            lines.append(inc)
        lines.append("")

        if deps['macros']:
            lines.append("// ===== Macro Definitions =====")
            for name in sorted(deps['macros']):
                macro = self.macros[name]
                source_info = f" (from {macro.file_path})" if macro.file_path and macro.file_path != self.file_path else ""
                lines.append(f"{macro.definition}  // from line {macro.line_number}{source_info}")
            lines.append("")

        if deps['type_defs']:
            lines.append("// ===== Type Definitions =====")
            for name in sorted(deps['type_defs']):
                t = self.type_defs[name]
                source_info = f" // from {t.file_path}:{t.line_number}" if t.file_path else ""
                lines.append(f"{t.definition}{source_info}")
            lines.append("")

        if deps['global_vars']:
            lines.append("// ===== Global Variables =====")
            for name in sorted(deps['global_vars']):
                v = self.global_vars[name]
                source_info = f" (from {v.file_path}:{v.line_number})" if v.file_path else ""
                lines.append(f"{v.definition}  // global{source_info}")
            lines.append("")

        if deps['functions']:
            lines.append("// ===== Function Forward Declarations =====")
            for name in sorted(deps['functions']):
                fn = self.functions[name]
                lines.append(self._make_forward_decl(fn))
            lines.append("")

        if deps['functions']:
            lines.append("// ===== Device/Helper Functions =====")
            for name in sorted(deps['functions']):
                fn = self.functions[name]
                source_info = f" (from {fn.file_path}:{fn.line_number})" if fn.file_path else ""
                lines.append(f"// Function: {name}{source_info}")
                lines.append(f"{fn.signature} {{")
                lines.append(fn.body)
                lines.append("}")
                lines.append("")

        lines.append("// ===== Kernel =====")
        lines.append(f"// Kernel: {kernel.name} (line {kernel.line_number})")
        lines.append(f"{kernel.signature} {{")
        lines.append(kernel.body)
        lines.append("}")
        lines.append("")

        # lines.append("// ===== Main Function =====")
        # lines.append(self._generate_main_function(kernel))

        return '\n'.join(lines)

    def generate_all_kernels(self, output_dir: str):
        for kernel_name in self.kernels:
            self.generate_kernel_file(kernel_name, output_dir)

# =========================
# 项目扫描
# =========================

def build_project_index(project_root: Path) -> ProjectSymbolIndex:
    index = ProjectSymbolIndex()

    if not project_root.exists() or not project_root.is_dir():
        return index

    files = []
    for p in project_root.rglob('*'):
        if not p.is_file():
            continue
        if p.suffix.lower() not in SOURCE_EXTENSIONS:
            continue
        if p.name.startswith('single_kernel_'):
            continue
        files.append(p)

    print(f"  [项目扫描] 共发现 {len(files)} 个源码文件")

    for path in files:
        code = CUDASourceAnalyzer._read_text_file(path)
        if code is None:
            continue

        analyzer = CUDASourceAnalyzer(
            source_code=code,
            file_path=str(path),
            base_dir=path.parent
        )
        analyzer.analyze(parse_includes=False)
        index.merge_from_analyzer(analyzer)

    print(
        f"  [项目扫描] 宏: {len(index.macros)}, 类型: {len(index.type_defs)}, "
        f"全局变量: {len(index.global_vars)}, 函数: {len(index.functions)}"
    )
    return index

# =========================
# 处理入口
# =========================

def process_file(file_path: Path, parse_includes: bool = True, project_root: Optional[Path] = None):
    print(f"正在分析 {file_path}...")

    source_code = CUDASourceAnalyzer._read_text_file(file_path)
    if source_code is None:
        print(f"  警告: 无法读取文件 {file_path}，跳过\n")
        return

    analyzer = CUDASourceAnalyzer(
        source_code=source_code,
        file_path=str(file_path),
        base_dir=file_path.parent,
        parsed_files={str(file_path.resolve())}
    )
    analyzer.analyze(parse_includes=parse_includes)

    if project_root is None:
        project_root = file_path.parent

    project_index = build_project_index(project_root)
    analyzer.resolve_external_dependencies(project_index)

    print(f"  - 找到 {len(analyzer.includes)} 个 include")
    print(f"  - 找到 {len(analyzer.macros)} 个宏定义（含外部补全）")
    print(f"  - 找到 {len(analyzer.type_defs)} 个类型定义（含外部补全）")
    print(f"  - 找到 {len(analyzer.global_vars)} 个全局变量（含外部补全）")
    print(f"  - 找到 {len(analyzer.functions)} 个 device/helper 函数（含外部补全）")
    print(f"  - 找到 {len(analyzer.kernels)} 个 __global__ kernel")

    if analyzer.kernels:
        print(f"  Kernels: {', '.join(analyzer.kernels.keys())}")
        output_dir = file_path.parent
        analyzer.generate_all_kernels(str(output_dir))
    else:
        print("  未找到 kernel")

    print()

def process_directory(dir_path: Path, recursive: bool = False, parse_includes: bool = True, project_root: Optional[Path] = None):
    # 在 .cu, .cuh, .h 文件中查找 kernel 代码
    if recursive:
        cuda_files = list(dir_path.rglob("*.cu")) + list(dir_path.rglob("*.cuh")) + list(dir_path.rglob("*.h"))
    else:
        cuda_files = list(dir_path.glob("*.cu")) + list(dir_path.glob("*.cuh")) + list(dir_path.glob("*.h"))

    if not cuda_files:
        print(f"在 {dir_path} 中未找到 CUDA 文件")
        return

    print(f"找到 {len(cuda_files)} 个 CUDA 文件\n")

    if project_root is None:
        project_root = dir_path

    for cuda_file in cuda_files:
        process_file(cuda_file, parse_includes=parse_includes, project_root=project_root)

def main():
    parser = argparse.ArgumentParser(
        description='CUDA Kernel 提取工具 - 支持跨文件宏/函数/模板/参数类型依赖补全',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python main.py kernel.cu
  python main.py kernel.cu --project-root ./rodinia-3.1
  python main.py --dir ./cuda_sources
  python main.py --rdir ./project
  python main.py kernel.cu --no-includes
        """
    )

    parser.add_argument('path', nargs='?', help='CUDA 源文件路径')
    parser.add_argument('--dir', metavar='DIR', help='处理指定目录中的所有 CUDA 文件')
    parser.add_argument('--rdir', metavar='DIR', help='递归处理指定目录及其子目录中的所有 CUDA 文件')
    parser.add_argument('--project-root', metavar='DIR', help='项目根目录，用于全项目扫描依赖')
    parser.add_argument('--no-includes', action='store_true', help='不递归解析 include 文件')

    args = parser.parse_args()
    parse_includes = not args.no_includes
    project_root = Path(args.project_root) if args.project_root else None

    if args.rdir:
        dir_path = Path(args.rdir)
        if not dir_path.is_dir():
            print(f"错误: 目录不存在 '{args.rdir}'")
            return
        process_directory(dir_path, recursive=True, parse_includes=parse_includes, project_root=project_root)

    elif args.dir:
        dir_path = Path(args.dir)
        if not dir_path.is_dir():
            print(f"错误: 目录不存在 '{args.dir}'")
            return
        process_directory(dir_path, recursive=False, parse_includes=parse_includes, project_root=project_root)

    elif args.path:
        file_path = Path(args.path)
        if not file_path.exists():
            print(f"错误: 文件不存在 '{args.path}'")
            return
        if not file_path.is_file():
            print(f"错误: '{args.path}' 不是文件")
            return
        process_file(file_path, parse_includes=parse_includes, project_root=project_root)

    else:
        parser.print_help()
        return

    print("完成!")

if __name__ == "__main__":
    main()