#!/usr/bin/env python3
import argparse
import os
import shutil
import subprocess
import time
import shlex
from pathlib import Path

SETUP_ENV_SCRIPT = "/accel-sim/accel-sim-framework-dev/gpu-simulator/setup_environment.sh"          # accelsim 运行前加载环境的脚本
TIMEOUT_SECONDS = 4 * 60 * 60   # 设定程序最长执行时间为 4 hours

def is_elf_executable(path: Path) -> bool:
    """
    判断文件是否为 ELF 可执行文件。
    CUDA 编译出的可执行文件通常是 ELF 文件。
    """
    if not path.is_file():
        return False

    if not os.access(path, os.X_OK):
        return False

    try:
        with open(path, "rb") as f:
            magic = f.read(4)
            return magic == b"\x7fELF"
    except Exception:
        return False

def find_cuda_executables(search_dir: Path, build_dir: Path):
    """
    递归查找目录下所有 ELF 可执行文件。
    会跳过 build 目录本身。
    """
    executables = []

    for root, dirs, files in os.walk(search_dir):
        root_path = Path(root).resolve()

        # 跳过 build 目录，避免重复扫描输出文件
        if root_path == build_dir.resolve():
            dirs[:] = []
            continue

        for filename in files:
            file_path = root_path / filename
            if is_elf_executable(file_path):
                executables.append(file_path.resolve())

    return sorted(executables)

def make_output_name(exe_path: Path, search_dir: Path, used_names: set) -> str:
    """
    生成输出 txt 文件名。

    默认使用可执行文件名.txt。
    如果出现重名，则使用相对路径替换 / 为 __。
    """
    base_name = exe_path.name + ".txt"

    if base_name not in used_names:
        used_names.add(base_name)
        return base_name

    rel = exe_path.relative_to(search_dir.resolve())
    safe_name = str(rel).replace("/", "__") + ".txt"
    used_names.add(safe_name)
    return safe_name

def run_executable(exe_path: Path, build_dir: Path, output_file: Path):
    """
    在 build 目录下运行指定可执行文件。
    运行前 source accel-sim 环境脚本。
    """
    command = (
        f"source {shlex.quote(SETUP_ENV_SCRIPT)} && "
        f"exec {shlex.quote(str(exe_path))}"
    )

    start_time = time.time()
    timed_out = False
    return_code = None

    with open(output_file, "w") as fout:
        fout.write(f"Running executable: {exe_path}\n")
        fout.write(f"Working directory: {build_dir}\n")
        fout.write(f"Setup script: {SETUP_ENV_SCRIPT}\n")
        fout.write("=" * 80 + "\n\n")
        fout.flush()

        try:
            completed = subprocess.run(
                ["bash", "-lc", command],
                cwd=str(build_dir),
                stdout=fout,
                stderr=subprocess.STDOUT,
                timeout=TIMEOUT_SECONDS
            )
            return_code = completed.returncode

        except subprocess.TimeoutExpired:
            timed_out = True
            fout.write("\n\n")
            fout.write("=" * 80 + "\n")
            fout.write("ERROR: timeout\n")
            fout.write("=" * 80 + "\n")

    end_time = time.time()
    elapsed = end_time - start_time

    return elapsed, timed_out, return_code

def format_seconds(seconds: float) -> str:
    seconds = int(seconds)
    h = seconds // 3600
    m = seconds % 3600 // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"
"""
示例 1: 
python3 ./run_cuda_execs.py \
    --config /path/to/gpgpusim.config \
    --dir /path/to/cuda/programs
示例 2: 
python3 run_cuda_execs.py \
    -c /path/to/gpgpusim.config \
    -d /path/to/cuda/programs
"""


def main():
    parser = argparse.ArgumentParser(
        description="Run all CUDA executables under a directory with GPGPU-Sim config."
    )

    parser.add_argument(
        "-c", "--config",
        required=True,
        help="Path to gpgpusim.config"
    )

    parser.add_argument(
        "-d", "--dir",
        required=True,
        help="Directory to recursively search CUDA executables"
    )

    args = parser.parse_args()

    config_path = Path(args.config).resolve()
    search_dir = Path(args.dir).resolve()
    build_dir = search_dir / "build"

    if not config_path.is_file():
        raise FileNotFoundError(f"gpgpusim.config not found: {config_path}")

    if not search_dir.is_dir():
        raise NotADirectoryError(f"Search directory not found: {search_dir}")

    if not Path(SETUP_ENV_SCRIPT).is_file():
        raise FileNotFoundError(f"Setup environment script not found: {SETUP_ENV_SCRIPT}")

    build_dir.mkdir(parents=True, exist_ok=True)

    # 复制 gpgpusim.config 到 build 目录
    dst_config = build_dir / "gpgpusim.config"
    shutil.copy2(config_path, dst_config)

    print(f"[INFO] Search directory : {search_dir}")
    print(f"[INFO] Build directory  : {build_dir}")
    print(f"[INFO] Config copied to : {dst_config}")

    executables = find_cuda_executables(search_dir, build_dir)

    print(f"[INFO] Found {len(executables)} executable file(s).")

    record_file = build_dir / "RECODE.md"
    used_output_names = set()

    with open(record_file, "w") as frec:
        frec.write("# CUDA Executable Running Record\n\n")
        frec.write(f"- Search directory: `{search_dir}`\n")
        frec.write(f"- Build directory: `{build_dir}`\n")
        frec.write(f"- Config file: `{config_path}`\n")
        frec.write(f"- Timeout\n\n")
        frec.write("| No. | Executable | Output | Running Time(s) | Return Code |\n")
        frec.write("|---:|---|---|---|---:|\n")

        for idx, exe in enumerate(executables, start=1):
            output_name = make_output_name(exe, search_dir, used_output_names)
            output_file = build_dir / output_name

            print(f"[INFO] [{idx}/{len(executables)}] Running: {exe}")
            print(f"[INFO] Output: {output_file}")

            elapsed, timed_out, return_code = run_executable(
                exe_path=exe,
                build_dir=build_dir,
                output_file=output_file
            )

            if timed_out:
                time_record = "timeout"
                rc_record = "N/A"
                print(f"[TIMEOUT] {exe}")
            else:
                time_record = format_seconds(elapsed)
                rc_record = str(return_code)
                print(f"[DONE] {exe}, time = {time_record}, return code = {return_code}")

            frec.write(
                f"| {idx} | `{exe}` | `{output_file.name}` | {time_record} | {rc_record} |\n"
            )
            frec.flush()

    print(f"[INFO] Record written to: {record_file}")

if __name__ == "__main__":
    main()