某个 kernel 执行过程中：
- `dram__bytes`： 不同 DRAM 分区访问的字节数
- `dram__sectors`: 不同 DRAM 分区访问的 sector 数

- `gpu__cycles_elapsed`: 在 GPU 上执行期间经过了多少个 GPU 时钟周期
- `gpu__time_duration`: 在 GPU 上执行的真实时间

- `lts__t_requests`: L2 处理的请求数
- `lts__t_requests_lookup_hit`: L2 命中次数
- `lts__t_requests_lookup_miss`: L2 未命中次数
- `lts__t_requests_op_read`: L2 读请求数
- `lts__t_requests_op_write`: L2 写请求数
- `lts__t_sectors`: L2 处理的 sector 数
- `lts__t_sectors_lookup_hit`: L2 命中的 sector 数
- `lts__t_sectors_lookup_miss`: L2 未命中的 sector 数 
- `lts__t_sectors_op_read`: L2 读 sector 数
- `lts__t_sectors_op_write`: L2 写 sector 数

- `smsp__sass_thread_inst_executed_op_xxxx_pred_on`: 每个 SMSP，在 SASS 指令层面，实际执行的 `xxxx` 计算指令数量，按线程粒度统计，并且只统计 predicate 为 true 的线程。

- `sm__pipe_tensor_cycles_active`: 每个 SM 上，Tensor Core pipeline 处于 active 状态的平均 cycle 数
- `sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed`: 每个 SM 上，Tensor Core 活跃度占理论峰值百分比

