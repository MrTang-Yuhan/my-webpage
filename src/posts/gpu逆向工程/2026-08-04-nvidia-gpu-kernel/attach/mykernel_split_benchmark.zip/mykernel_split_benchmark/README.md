# Accelsim 模拟器 kernel 运行结果测试

对每个 workload 进行预处理：首先按照 `__global__` kernel 对 workload 进行拆分，将其划分为多个独立的 kernel；随后借助 AI 工具为每个 kernel 补充对应的 host 端代码，使其能够单独编译和运行。

之后，将这些可独立运行的 kernel 分别放到 Accel-Sim 模拟器上执行，并测量每个 kernel 的运行的墙钟时间。

# 文件结构

- `./script/`: 存储运行脚本的目录
    - `profiler.py`: 从一个 CUDA 源文件或项目目录中，自动找到 `__global__` kernel，并把该 kernel 依赖的宏、类型定义、全局变量、device/helper 函数等一起提取出来，生成一个相对独立的 `.cu` 文件。
    - `run_cuda_execs.py`： `run_cuda_execs.py` 是一个 批量运行 CUDA 可执行文件的脚本，主要面向 Accel-Sim 环境。它会递归扫描指定目录下的可执行文件，然后***依次***运行这些程序，并把每个程序的输出保存到 build 目录下的 `.txt` 文件中。特别注意，运行该脚本前，必须已经加载 AccelSim 环境。
    - `run_ncu_recursive.py`: 批量运行 Nsight Compute (ncu) 的 profiling 脚本, 它会递归扫描指定目录下的可执行文件，然后对每个可执行文件运行指定的 `ncu` 命令，并把 profiling 结果保存为 `.csv` 文件。

- `./benchmark/`：用于存放已经完成 `__global__` kernel 拆分的 `.cu` 文件、对应编译生成的可执行文件，以及 profiling 后得到的结果文件。  
  以 `kernel_split_benchmark/benchmark/Tango-master/GPU/LSTM/` 为例：
  - `single_kernel_ExecuteLSTM.cu`：完成 `__global__` kernel 拆分后的 `.cu` 文件
  - `single_kernel_ExecuteLSTM`：由上述 `.cu` 文件编译生成的同名可执行文件
  - `single_kernel_ExecuteLSTM.csv`：对该可执行文件进行 profiling 后得到的结果文件

- `./ncu_param.md`：用于记录和说明 Nsight Compute profiling 指标。可以通过 `ncu --query-metrics` 查看所有可用指标及其简要含义；`ncu_param.md` 则对本项目中使用到的部分指标进行了中文说明，便于理解和查阅。

- `RECORD_TIME.md`：用于汇总和统计所有 kernel 在 Accelsim 模拟器上运行的墙钟时间。