// Auto-generated CUDA kernel file: executeEltWiseLayerCUDA_split
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 882

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeEltWiseLayerCUDA_split (line 882)
__global__ void executeEltWiseLayerCUDA_split(float *Layer1_Neurons,float *Layer2_Neurons,float *Layer_Out_Neurons,int f_size,int tfactor) {

	int output = blockIdx.x;
	int row_even = threadIdx.x * tfactor;
	int col_even = threadIdx.y * tfactor;
	if(row_even < f_size && col_even < f_size)
	{      
		for(int row= row_even; row < row_even + tfactor ; row++) 
		{	
			for(int col =col_even; col < col_even+ tfactor ;col++) 
			{
				{
					Layer_Out_Neurons[output*f_size*f_size + row*f_size + col] = Layer1_Neurons[output*f_size*f_size + row*f_size + col] + Layer2_Neurons[output*f_size*f_size + row*f_size + col];
				}
			}
		}
	}

}

int main() {
    const int out = 4;
    const int f_size = 8;
    const int tfactor = 2;

    size_t total_size = (size_t)out * f_size * f_size;

    float *h_a = (float*)malloc(total_size * sizeof(float));
    float *h_b = (float*)malloc(total_size * sizeof(float));
    float *h_c = (float*)malloc(total_size * sizeof(float));

    if (!h_a || !h_b || !h_c) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < total_size; ++i) {
        h_a[i] = (float)(i % 17) * 0.1f;
        h_b[i] = (float)(i % 11) * 0.2f;
    }

    float *d_a = NULL, *d_b = NULL, *d_c = NULL;
    CHECK(cudaMalloc((void**)&d_a, total_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_b, total_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_c, total_size * sizeof(float)));

    CHECK(cudaMemcpy(d_a, h_a, total_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_b, h_b, total_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_c, 0, total_size * sizeof(float)));

    dim3 grid(out);
    dim3 block((f_size + tfactor - 1) / tfactor, (f_size + tfactor - 1) / tfactor);

    executeEltWiseLayerCUDA_split<<<grid, block>>>(d_a, d_b, d_c, f_size, tfactor);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_c, d_c, total_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeEltWiseLayerCUDA_split done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("c[%d] = %f\n", i, h_c[i]);
    }

    cudaFree(d_a);
    cudaFree(d_b);
    cudaFree(d_c);

    free(h_a);
    free(h_b);
    free(h_c);

    return 0;
}