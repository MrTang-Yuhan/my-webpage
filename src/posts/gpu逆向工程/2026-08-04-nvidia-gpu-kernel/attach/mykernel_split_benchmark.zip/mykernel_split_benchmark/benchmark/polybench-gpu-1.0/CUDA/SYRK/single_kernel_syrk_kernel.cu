// Auto-generated CUDA kernel file: syrk_kernel
// Extracted from: polybench-gpu-1.0/CUDA/SYRK/single_kernel_syrk_kernel.cu
// Original line: 26

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define M 1024  // from line 27  // from line 16
#define N 1024  // from line 26  // from line 17
#define alpha 12435  // from line 34  // from line 18
#define beta 4546  // from line 35  // from line 19

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/SYRK/single_kernel_syrk_kernel.cu:22

// ===== Kernel =====
// Kernel: syrk_kernel (line 26)
__global__ void syrk_kernel(DATA_TYPE ALPHA, DATA_TYPE BETA, DATA_TYPE *a, DATA_TYPE *c) {


	/*  C := alpha*A*A' + beta*C */
	int j = blockIdx.x * blockDim.x + threadIdx.x;
	int i = blockIdx.y * blockDim.y + threadIdx.y;

	if ((i < N) && (j < N))
	{
		c[i * N + j] *= beta;
		int k;		
		for(k=0; k< M; k++)
		{
			c[i * N + j] += alpha * a[i * M + k] * a[j * M + k];
		}
	}


}
int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_a = (size_t)N * M;
    const size_t size_c = (size_t)N * N;

    // ===== Scalar parameters =====
    DATA_TYPE ALPHA = (DATA_TYPE)alpha;
    DATA_TYPE BETA  = (DATA_TYPE)beta;

    // ===== Host/Device buffers =====
    DATA_TYPE *h_a = (DATA_TYPE*)malloc(size_a * sizeof(DATA_TYPE));
    DATA_TYPE *h_c = (DATA_TYPE*)malloc(size_c * sizeof(DATA_TYPE));

    DATA_TYPE *d_a = nullptr;
    DATA_TYPE *d_c = nullptr;

    if (!h_a) {
        printf("malloc failed for h_a\n");
        return -1;
    }

    if (!h_c) {
        printf("malloc failed for h_c\n");
        free(h_a);
        return -1;
    }

    // ===== Initialize host data =====
    for (size_t i = 0; i < size_a; ++i) {
        h_a[i] = (DATA_TYPE)((i % 100) + 1) / 100.0f;
    }

    for (size_t i = 0; i < size_c; ++i) {
        h_c[i] = (DATA_TYPE)((i % 100) + 1) / 100.0f;
    }

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_a, size_a * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_a: %s\n", cudaGetErrorString(err));
        free(h_a);
        free(h_c);
        return -1;
    }

    err = cudaMalloc((void**)&d_c, size_c * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_c: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        free(h_a);
        free(h_c);
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_a, h_a, size_a * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for a: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        cudaFree(d_c);
        free(h_a);
        free(h_c);
        return -1;
    }

    err = cudaMemcpy(d_c, h_c, size_c * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for c: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        cudaFree(d_c);
        free(h_a);
        free(h_c);
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((N + blockSize.x - 1) / blockSize.x,
                  (N + blockSize.y - 1) / blockSize.y);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);

    syrk_kernel<<<gridSize, blockSize>>>(ALPHA, BETA, d_a, d_c);

    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        cudaFree(d_c);
        free(h_a);
        free(h_c);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        cudaFree(d_c);
        free(h_a);
        free(h_c);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaEventSynchronize(stop);

    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);

    printf("syrk_kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy output back =====
    err = cudaMemcpy(h_c, d_c, size_c * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for c: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        cudaFree(d_c);
        free(h_a);
        free(h_c);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    // ===== Print sample outputs =====
    printf("c[0]           = %f\n", (double)h_c[0]);
    printf("c[N - 1]       = %f\n", (double)h_c[N - 1]);
    printf("c[(N-1)*N]     = %f\n", (double)h_c[(N - 1) * N]);
    printf("c[N*N - 1]     = %f\n", (double)h_c[size_c - 1]);

    // ===== Cleanup =====
    cudaFree(d_a);
    cudaFree(d_c);

    free(h_a);
    free(h_c);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");

    return 0;
}