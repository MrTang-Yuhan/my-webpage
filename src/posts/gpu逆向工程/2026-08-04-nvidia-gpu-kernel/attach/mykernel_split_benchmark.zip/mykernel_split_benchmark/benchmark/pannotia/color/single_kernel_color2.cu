// Auto-generated CUDA kernel file: color2
// Extracted from: pannotia/color/kernel_maxmin.cu
// Original line: 122

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: color2 (line 122)
__global__ void color2(int *node_value, int *color_array, int *max_d,
                       int *min_d, const int color, const int num_nodes,
                       const int num_edges) {

    // Get my workitem id
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    if (tid < num_nodes) {
        // If the vertex is still not colored
        if (color_array[tid] == -1) {
            // Assign a color
            if (node_value[tid] >= max_d[tid])
                color_array[tid] = color;
            if (node_value[tid] <= min_d[tid])
                color_array[tid] = color + 1;
        }
    }


}


int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;
    const int color = 0;

    const size_t size_nodes_int = (size_t)num_nodes * sizeof(int);

    int *h_node_value = (int*)malloc(size_nodes_int);
    int *h_color_array = (int*)malloc(size_nodes_int);
    int *h_max_d = (int*)malloc(size_nodes_int);
    int *h_min_d = (int*)malloc(size_nodes_int);

    int *d_node_value = nullptr;
    int *d_color_array = nullptr;
    int *d_max_d = nullptr;
    int *d_min_d = nullptr;

    if (!h_node_value || !h_color_array || !h_max_d || !h_min_d) {
        printf("host malloc failed\n");
        free(h_node_value);
        free(h_color_array);
        free(h_max_d);
        free(h_min_d);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_node_value[i] = i % 100;
        h_color_array[i] = -1;
        h_max_d[i] = h_node_value[i] - 1;
        h_min_d[i] = h_node_value[i] + 1;
    }

    // 构造几个可观察样例
    if (num_nodes > 0) {
        h_max_d[0] = h_node_value[0];
        h_min_d[0] = h_node_value[0] + 10;
    }
    if (num_nodes > 1) {
        h_max_d[1] = h_node_value[1] + 10;
        h_min_d[1] = h_node_value[1];
    }

    err = cudaMalloc((void**)&d_node_value, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_node_value failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_color_array, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_color_array failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_max_d, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_max_d failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_min_d, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_min_d failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(d_node_value, h_node_value, size_nodes_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_color_array, h_color_array, size_nodes_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_max_d, h_max_d, size_nodes_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_min_d, h_min_d, size_nodes_int, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop_evt;
    cudaEventCreate(&start);
    cudaEventCreate(&stop_evt);

    cudaEventRecord(start);
    color2<<<gridSize, blockSize>>>(
        d_node_value, d_color_array, d_max_d, d_min_d,
        color, num_nodes, num_edges
    );
    cudaEventRecord(stop_evt);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop_evt);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop_evt);
    printf("color2 execution time: %.3f ms\n", milliseconds);

    cudaMemcpy(h_color_array, d_color_array, size_nodes_int, cudaMemcpyDeviceToHost);

    printf("color_array[0] = %d\n", h_color_array[0]);
    printf("color_array[1] = %d\n", h_color_array[1]);
    printf("color_array[2] = %d\n", h_color_array[2]);

    cudaFree(d_node_value);
    cudaFree(d_color_array);
    cudaFree(d_max_d);
    cudaFree(d_min_d);

    free(h_node_value);
    free(h_color_array);
    free(h_max_d);
    free(h_min_d);

    cudaEventDestroy(start);
    cudaEventDestroy(stop_evt);

    printf("Done!\n");
    return 0;
}