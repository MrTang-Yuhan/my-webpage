// Standalone CUDA kernel file: drelax
// Smoke-test version with main()

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXBLOCKSIZE 1024
#define MYINFINITY 100000000
typedef unsigned foru;

static inline void checkCuda(cudaError_t err, const char* msg) {
  if (err != cudaSuccess) {
    fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
    exit(EXIT_FAILURE);
  }
}

struct Graph {
  enum { NotAllocated, AllocatedOnHost, AllocatedOnDevice } memory;

  unsigned nnodes, nedges;
  unsigned *noutgoing, *nincoming, *srcsrc, *psrc, *edgessrcdst;
  foru *edgessrcwt;
  unsigned *levels;
  unsigned source;

  unsigned *maxOutDegree, *maxInDegree;
  unsigned diameter;
  bool foundStats;

  __device__ unsigned getOutDegree(unsigned src) {
    return psrc[src + 1] - psrc[src];
  }

  __device__ unsigned getInDegree(unsigned src) {
    return nincoming ? nincoming[src] : 0;
  }

  __device__ unsigned getDestination(unsigned src, unsigned nthedge) {
    return edgessrcdst[psrc[src] + nthedge];
  }

  __device__ foru getWeight(unsigned src, unsigned nthedge) {
    return edgessrcwt[psrc[src] + nthedge];
  }

  __device__ unsigned getMinEdge(unsigned src) {
    return psrc[src];
  }

  __device__ unsigned getFirstEdge(unsigned src) {
    return psrc[src];
  }
};

__device__ bool processedge(foru *dist, Graph &graph, unsigned src, unsigned ii, unsigned &dst) {
  dst = graph.getDestination(src, ii);
  if (dst >= graph.nnodes) return 0;

  foru wt = graph.getWeight(src, ii);
  if (wt >= MYINFINITY) return 0;

  foru altdist = dist[src] + wt;
  if (altdist < dist[dst]) {
    foru olddist = atomicMin(&dist[dst], altdist);
    if (altdist < olddist) {
      return true;
    }
  }
  return false;
}

__device__ bool processnode(foru *dist, Graph &graph, unsigned work) {
  unsigned nn = work;
  if (nn >= graph.nnodes) return 0;
  bool changed = false;

  unsigned neighborsize = graph.getOutDegree(nn);
  for (unsigned ii = 0; ii < neighborsize; ++ii) {
    unsigned dst = graph.nnodes;
    bool olddist = processedge(dist, graph, nn, ii, dst);
    if (olddist) {
      changed = true;
    }
  }
  return changed;
}

__global__ void drelax(foru *dist, Graph graph, bool *changed) {
  unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
  unsigned start = id * (MAXBLOCKSIZE / blockDim.x);
  unsigned end = (id + 1) * (MAXBLOCKSIZE / blockDim.x);

  for (unsigned ii = start; ii < end; ++ii) {
    if (processnode(dist, graph, ii)) {
      *changed = true;
    }
  }
}

static void initTinyGraph(Graph &g) {
  // 0 -> 1 (1), 0 -> 2 (4), 1 -> 2 (2)
  const unsigned nnodes = 3;
  const unsigned nedges = 3;

  unsigned h_psrc[4] = {0, 2, 3, 3};
  unsigned h_dst[3] = {1, 2, 2};
  foru h_wt[3] = {1, 4, 2};

  g.nnodes = nnodes;
  g.nedges = nedges;
  g.noutgoing = NULL;
  g.nincoming = NULL;
  g.srcsrc = NULL;
  g.levels = NULL;
  g.source = 0;
  g.maxOutDegree = NULL;
  g.maxInDegree = NULL;
  g.diameter = 0;
  g.foundStats = false;

  checkCuda(cudaMalloc((void**)&g.psrc, (nnodes + 1) * sizeof(unsigned)), "malloc psrc");
  checkCuda(cudaMalloc((void**)&g.edgessrcdst, nedges * sizeof(unsigned)), "malloc dst");
  checkCuda(cudaMalloc((void**)&g.edgessrcwt, nedges * sizeof(foru)), "malloc wt");

  checkCuda(cudaMemcpy(g.psrc, h_psrc, sizeof(h_psrc), cudaMemcpyHostToDevice), "copy psrc");
  checkCuda(cudaMemcpy(g.edgessrcdst, h_dst, sizeof(h_dst), cudaMemcpyHostToDevice), "copy dst");
  checkCuda(cudaMemcpy(g.edgessrcwt, h_wt, sizeof(h_wt), cudaMemcpyHostToDevice), "copy wt");
}

static void freeTinyGraph(Graph &g) {
  if (g.psrc) cudaFree(g.psrc);
  if (g.edgessrcdst) cudaFree(g.edgessrcdst);
  if (g.edgessrcwt) cudaFree(g.edgessrcwt);
}

int main() {
  Graph g;
  initTinyGraph(g);

  foru h_dist[3] = {0, MYINFINITY, MYINFINITY};
  foru *d_dist = NULL;
  bool *d_changed = NULL;
  bool h_changed = false;

  checkCuda(cudaMalloc((void**)&d_dist, 3 * sizeof(foru)), "malloc dist");
  checkCuda(cudaMalloc((void**)&d_changed, sizeof(bool)), "malloc changed");

  checkCuda(cudaMemcpy(d_dist, h_dist, sizeof(h_dist), cudaMemcpyHostToDevice), "copy dist");
  checkCuda(cudaMemset(d_changed, 0, sizeof(bool)), "memset changed");

  dim3 block(256);
  dim3 grid(1);

  drelax<<<grid, block>>>(d_dist, g, d_changed);
  checkCuda(cudaGetLastError(), "drelax launch failed");
  checkCuda(cudaDeviceSynchronize(), "drelax execution failed");

  checkCuda(cudaMemcpy(h_dist, d_dist, sizeof(h_dist), cudaMemcpyDeviceToHost), "copy dist back");
  checkCuda(cudaMemcpy(&h_changed, d_changed, sizeof(bool), cudaMemcpyDeviceToHost), "copy changed");

  printf("drelax finished\n");
  printf("changed = %d\n", (int)h_changed);
  for (int i = 0; i < 3; i++) {
    printf("dist[%d] = %u\n", i, h_dist[i]);
  }

  cudaFree(d_dist);
  cudaFree(d_changed);
  freeTinyGraph(g);
  return 0;
}