// Auto-generated CUDA kernel file: executelrnNormCuda_split
// Extracted from: Tango-master/GPU/AlexNet/an_kernel.cu
// Original line: 211

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: executelrnNormCuda_split (line 211)
__global__ void executelrnNormCuda_split(float *Layer_InNeurons_GPU, float alpha, float beta,int local_size,int out,int fr,int fc,float *Layer_OutNeurons_GPU,int r_offset, int c_offset) {

        int nStart = 0, nEnd = 0;
        float value = 0.0;float sum = 0.0;
        int output = blockIdx.x;
        int row = threadIdx.x + r_offset;
        int col = threadIdx.y + c_offset;
        nStart=(output-2) > 1 ? (output-2) : 1 ;
        nEnd=(output+2) <  out ? (output+2) : out ;
        for(int i = (nStart-1); i < (nEnd-1) ; i++) // kernel convolution
        {
            sum += pow(( Layer_InNeurons_GPU[i*fr*fc + row*fc + col]),2);
        }
        value = (Layer_InNeurons_GPU[output*fr*fc + row*fc + col]) / (pow( 1 + ((alpha/local_size) *sum),beta));
        sum = 0;
        Layer_OutNeurons_GPU[output*fr*fc + row*fc + col] = value;

}

int main() {
    const int out = 96;
    const int fr = 27, fc = 27;
    const float alpha = 0.0001f;
    const float beta = 0.75f;
    const int local_size = 5;

    size_t in_size  = out * fr * fc;
    size_t out_size = out * fr * fc;

    float *h_in  = (float*)malloc(in_size * sizeof(float));
    float *h_out = (float*)malloc(out_size * sizeof(float));

    for (size_t i = 0; i < in_size; ++i) h_in[i] = (float)(i % 19) * 0.01f + 1.0f;

    float *d_in, *d_out;
    CHECK(cudaMalloc((void**)&d_in,  in_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out, out_size * sizeof(float)));

    CHECK(cudaMemcpy(d_in, h_in, in_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block(9, 9);

    for (int r = 0; r < fr; r += 9) {
        for (int c = 0; c < fc; c += 9) {
            executelrnNormCuda_split<<<grid, block>>>(
                d_in, alpha, beta, local_size, out, fr, fc, d_out, r, c
            );
            CHECK(cudaGetLastError());
        }
    }

    CHECK(cudaDeviceSynchronize());
    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executelrnNormCuda_split done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("lrn_split_out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);
    return 0;
}