// ===== Includes =====
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// ===== Macro Definitions =====
#define GAMMA 1.4f
#define block_length 192
#define NDIM 3
#define VAR_DENSITY 0
#define VAR_MOMENTUM 1
#define VAR_DENSITY_ENERGY (VAR_MOMENTUM+NDIM)
#define NVAR (VAR_DENSITY_ENERGY+1)

#define checkCuda(call) do { \
    cudaError_t e = call; \
    if(e != cudaSuccess){ fprintf(stderr,"CUDA %s:%d %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1); } \
} while(0)

// ===== Device Functions =====
__device__ float compute_speed_sqd(float3 velocity) {
    return velocity.x*velocity.x + velocity.y*velocity.y + velocity.z*velocity.z;
}
__device__ void compute_velocity(float density, float3 momentum, float3& velocity) {
    velocity.x = momentum.x / density;
    velocity.y = momentum.y / density;
    velocity.z = momentum.z / density;
}
__device__ float compute_pressure(float density, float density_energy, float speed_sqd) {
    return (GAMMA-1.0f)*(density_energy - 0.5f*density*speed_sqd);
}
__device__ float compute_speed_of_sound(float density, float pressure) {
    return sqrtf(GAMMA*pressure/density);
}

// ===== Kernel =====
__global__ void cuda_compute_step_factor(int nelr, float* variables, float* areas, float* step_factors) {
    const int i = blockDim.x*blockIdx.x + threadIdx.x;

    float density        = variables[i + VAR_DENSITY*nelr];
    float3 momentum      = {variables[i+(VAR_MOMENTUM+0)*nelr],
                             variables[i+(VAR_MOMENTUM+1)*nelr],
                             variables[i+(VAR_MOMENTUM+2)*nelr]};
    float density_energy = variables[i + VAR_DENSITY_ENERGY*nelr];

    float3 velocity;
    compute_velocity(density, momentum, velocity);
    float speed_sqd      = compute_speed_sqd(velocity);
    float pressure       = compute_pressure(density, density_energy, speed_sqd);
    float speed_of_sound = compute_speed_of_sound(density, pressure);

    step_factors[i] = 0.5f / (sqrtf(areas[i]) * (sqrtf(speed_sqd) + speed_of_sound));
}

// ===== Main =====
int main() {
    const int nelr = 960;

    float ff_mach_    = 1.2f;
    float ff_pressure = 1.0f;
    float ff_density  = GAMMA * ff_pressure;
    float ff_speed    = ff_mach_ * sqrtf(GAMMA * ff_pressure / ff_density);
    float ff_de       = ff_pressure/(GAMMA-1.0f) + 0.5f*ff_density*ff_speed*ff_speed;

    // 填充 host 数据
    float *h_var = (float*)malloc(nelr*NVAR*sizeof(float));
    float *h_areas = (float*)malloc(nelr*sizeof(float));
    for(int i = 0; i < nelr; i++){
        h_var[i + VAR_DENSITY*nelr]        = ff_density;
        h_var[i + (VAR_MOMENTUM+0)*nelr]   = ff_density * ff_speed;
        h_var[i + (VAR_MOMENTUM+1)*nelr]   = 0.0f;
        h_var[i + (VAR_MOMENTUM+2)*nelr]   = 0.0f;
        h_var[i + VAR_DENSITY_ENERGY*nelr] = ff_de;
        h_areas[i] = 1.0f;
    }

    float *d_var, *d_areas, *d_sf;
    checkCuda(cudaMalloc(&d_var,   nelr*NVAR*sizeof(float)));
    checkCuda(cudaMalloc(&d_areas, nelr*sizeof(float)));
    checkCuda(cudaMalloc(&d_sf,    nelr*sizeof(float)));
    checkCuda(cudaMemcpy(d_var,   h_var,   nelr*NVAR*sizeof(float), cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_areas, h_areas, nelr*sizeof(float),      cudaMemcpyHostToDevice));

    cuda_compute_step_factor<<<nelr/block_length, block_length>>>(nelr, d_var, d_areas, d_sf);
    checkCuda(cudaDeviceSynchronize());

    float h_sf0;
    checkCuda(cudaMemcpy(&h_sf0, d_sf, sizeof(float), cudaMemcpyDeviceToHost));
    printf("cuda_compute_step_factor OK. step_factors[0]=%.6f\n", h_sf0);

    free(h_var); free(h_areas);
    cudaFree(d_var); cudaFree(d_areas); cudaFree(d_sf);
    return 0;
}