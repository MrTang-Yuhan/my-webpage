// Standalone CUDA kernel file: __printEdges
// Smoke-test debug version

#include "pta_single_kernel_test_common.cuh"

__device__ const char* relName_debug_all(uint rel) {
    switch (rel) {
        case PTS: return "PTS";
        case NEXT_DIFF_PTS: return "NEXT_DIFF_PTS";
        case CURR_DIFF_PTS: return "CURR_DIFF_PTS";
        case COPY_INV: return "COPY_INV";
        case LOAD_INV: return "LOAD_INV";
        case STORE: return "STORE";
        default: return "UNKNOWN";
    }
}

__device__ void printEdges_debug_src_rel(uint src, uint rel) {
    uint head = getHeadIndex(src, rel);
    uint base = graphGet(head + BASE);

    if (threadIdx.x == 0) {
        printf("%u -> %s : ", src, relName_debug_all(rel));
    }

    if (base == NIL) {
        if (threadIdx.x == 0) printf("[]\n");
        return;
    }

    uint bits = graphGet(head + threadIdx.x);
    uint active = __ballot_sync(0xFFFFFFFF, bits != 0 && threadIdx.x < BASE);

    if (threadIdx.x == 0) printf("[");

    bool first = true;

    while (active) {
        uint lane = __ffs(active) - 1;
        active &= active - 1;
        uint wordBits = __shfl_sync(0xFFFFFFFF, bits, lane);

        for (uint b = 0; b < 32; b++) {
            if (wordBits & (1u << b)) {
                uint dst = base * ELEMENT_CARDINALITY + lane * 32 + b;
                if (threadIdx.x == 0) {
                    if (!first) printf(", ");
                    printf("%u", dst);
                    first = false;
                }
            }
        }
    }

    if (threadIdx.x == 0) printf("]\n");
}

__device__ void printEdges_debug_all(int rel) {
    if (threadIdx.x == 0) {
        printf("%s edges:\n", relName_debug_all(rel));
    }

    for (uint src = 0; src < __numVars__; src++) {
        printEdges_debug_src_rel(src, rel);
    }
}

__global__ void __printEdges(int rel) {
    printEdges_debug_all(rel);
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 16);

    uint elt0[ELEMENT_WIDTH];
    uint elt1[ELEMENT_WIDTH];

    for (uint i = 0; i < ELEMENT_WIDTH; i++) {
        elt0[i] = 0;
        elt1[i] = 0;
    }

    // src 1 -> {3,6}
    elt0[0] = (1u << 3) | (1u << 6);
    elt0[BASE] = 0;
    elt0[NEXT] = NIL;

    // src 2 -> {4}
    elt1[0] = (1u << 4);
    elt1[BASE] = 0;
    elt1[NEXT] = NIL;

    cudaMemcpy(env.d_graph + TEST_COPY_INV_START + 1 * ELEMENT_WIDTH,
               elt0, sizeof(elt0), cudaMemcpyHostToDevice);

    cudaMemcpy(env.d_graph + TEST_COPY_INV_START + 2 * ELEMENT_WIDTH,
               elt1, sizeof(elt1), cudaMemcpyHostToDevice);

    dim3 block(32, 1);
    dim3 grid(1);

    __printEdges<<<grid, block>>>(COPY_INV);
    checkCuda(cudaGetLastError(), "__printEdges launch failed");
    checkCuda(cudaDeviceSynchronize(), "__printEdges execution failed");

    destroyPTATestEnv(env);
    return 0;
}