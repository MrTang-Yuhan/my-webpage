// Auto-generated CUDA kernel file: ini
// Extracted from: pannotia/color/kernel_maxmin.cu
// Original line: 148

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Macro Definitions =====
#define BIG_NUM 999999  // from line 58

// ===== Kernel =====
// Kernel: ini (line 148)
__global__ void ini(int *max_d, int *min_d, const int num_nodes) {

    // Get my workitem id
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    // Initialize max: -1 and min: Big_num
    if (tid < num_nodes) {
        max_d[tid] = -1;
        min_d[tid] = BIG_NUM;
    }


}
