// Auto-generated CUDA kernel file: bucketprefixoffset
// Extracted from: rodinia-3.1/hybridsort/single_kernel_bucketprefixoffset.cu
// Original line: 19

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>

#ifndef DIVISIONS
#define DIVISIONS 1024
#endif
#ifndef BUCKET_WG_SIZE_1
#define BUCKET_WG_SIZE_1 256
#endif

// ===== Macro Definitions =====
#define _BUCKETSORT_KERNEL_H_  // from line 2  // from line 9
#define BUCKET_WARP_LOG_SIZE	5  // from line 6  // from line 10
#define BUCKET_WARP_N			1  // from line 7  // from line 11
#define BUCKET_THREAD_N BUCKET_WG_SIZE_1  // from line 9  // from line 12
#define BUCKET_THREAD_N			(BUCKET_WARP_N << BUCKET_WARP_LOG_SIZE)  // from line 11  // from line 13
#define BUCKET_BLOCK_MEMORY		(DIVISIONS * BUCKET_WARP_N)  // from line 13  // from line 14
#define BUCKET_BAND				128  // from line 14  // from line 15

// ===== Kernel =====
// Kernel: bucketprefixoffset (line 19)
__global__ void bucketprefixoffset(unsigned int *d_prefixoffsets, unsigned int *d_offsets, int blocks) {


	int tid = blockIdx.x * blockDim.x + threadIdx.x; 
	int size = blocks * BUCKET_BLOCK_MEMORY;   // [参数: blocks]  // [参数: blocks]
	int sum = 0; 

	for (int i = tid; i < size; i += DIVISIONS) {
		int x = d_prefixoffsets[i];   // [参数: d_prefixoffsets]  // [参数: d_prefixoffsets]
		d_prefixoffsets[i] = sum;   // [参数: d_prefixoffsets]  // [参数: d_prefixoffsets]
		sum += x; 
	}

	d_offsets[tid] = sum;   // [参数: d_offsets]  // [参数: d_offsets]


}

int main() {
    int blocks = 4;
    int totalSize = blocks * BUCKET_BLOCK_MEMORY;

    // Host allocations
    unsigned int *h_prefixoffsets = (unsigned int *)malloc(totalSize * sizeof(unsigned int));
    unsigned int *h_offsets = (unsigned int *)malloc(DIVISIONS * sizeof(unsigned int));
    for (int i = 0; i < totalSize; i++) {
        h_prefixoffsets[i] = rand() % 10;
    }

    // Device allocations
    unsigned int *d_prefixoffsets, *d_offsets;
    cudaMalloc(&d_prefixoffsets, totalSize * sizeof(unsigned int));
    cudaMalloc(&d_offsets, DIVISIONS * sizeof(unsigned int));
    cudaMemcpy(d_prefixoffsets, h_prefixoffsets, totalSize * sizeof(unsigned int), cudaMemcpyHostToDevice);

    // Launch kernel: one thread per division
    bucketprefixoffset<<<1, DIVISIONS>>>(d_prefixoffsets, d_offsets, blocks);
    cudaDeviceSynchronize();

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("CUDA error: %s\n", cudaGetErrorString(err));
    } else {
        printf("bucketprefixoffset kernel executed successfully.\n");
    }

    cudaMemcpy(h_offsets, d_offsets, DIVISIONS * sizeof(unsigned int), cudaMemcpyDeviceToHost);
    printf("First 10 offsets: ");
    for (int i = 0; i < 10 && i < DIVISIONS; i++) printf("%u ", h_offsets[i]);
    printf("\n");

    // Cleanup
    cudaFree(d_prefixoffsets);
    cudaFree(d_offsets);
    free(h_prefixoffsets);
    free(h_offsets);
    return 0;
}