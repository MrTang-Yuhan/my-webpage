// Auto-generated CUDA kernel file: drelax
// Standalone runnable version

#include "common.h"
#include "graph.h"
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXBLOCKSIZE 1024

// ===== Device/Helper Functions =====
__device__
bool processedge(foru *dist, Graph &graph, unsigned src, unsigned ii, unsigned &dst) {
    dst = graph.getDestination(src, ii);
    if (dst >= graph.nnodes) return false;

    foru wt = 1;
    foru altdist = dist[src] + wt;
    if (altdist < dist[dst]) {
        foru olddist = atomicMin(&dist[dst], altdist);
        if (altdist < olddist) {
            return true;
        }
    }
    return false;
}

__device__
bool processnode(foru *dist, Graph &graph, unsigned work) {
    unsigned nn = work;
    if (nn >= graph.nnodes) return false;

    bool changed = false;
    unsigned neighborsize = graph.getOutDegree(nn);
    for (unsigned ii = 0; ii < neighborsize; ++ii) {
        unsigned dst = graph.nnodes;
        bool updated = processedge(dist, graph, nn, ii, dst);
        if (updated) changed = true;
    }
    return changed;
}

// ===== Kernel =====
__global__
void drelax(foru *dist, Graph graph, bool *changed) {
    unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
    unsigned chunk = MAXBLOCKSIZE / blockDim.x;
    if (chunk == 0) chunk = 1;

    unsigned start = id * chunk;
    unsigned end = (id + 1) * chunk;

    for (unsigned ii = start; ii < end; ++ii) {
        if (processnode(dist, graph, ii)) {
            *changed = true;
        }
    }
}

static void build_test_graph(Graph &hg) {
    // 0 -> 1,2
    // 1 -> 3
    // 2 -> 3
    hg.nnodes = 4;
    hg.nedges = 4;
    hg.allocOnHost();

    for (unsigned i = 0; i < hg.nnodes; i++) hg.srcsrc[i] = i;

    hg.psrc[0] = 1;
    hg.psrc[1] = 3;
    hg.psrc[2] = 4;
    hg.psrc[3] = 5;

    hg.noutgoing[0] = 2;
    hg.noutgoing[1] = 1;
    hg.noutgoing[2] = 1;
    hg.noutgoing[3] = 0;

    hg.nincoming[0] = 0;
    hg.nincoming[1] = 1;
    hg.nincoming[2] = 1;
    hg.nincoming[3] = 2;

    hg.edgessrcdst[1] = 1; hg.edgessrcwt[1] = 1;
    hg.edgessrcdst[2] = 2; hg.edgessrcwt[2] = 1;
    hg.edgessrcdst[3] = 3; hg.edgessrcwt[3] = 1;
    hg.edgessrcdst[4] = 3; hg.edgessrcwt[4] = 1;

    hg.source = 0;
}

int main() {
    Graph hgraph;
    build_test_graph(hgraph);

    Graph dgraph;
    hgraph.cudaCopy(dgraph);

    foru h_dist[4] = {0, MYINFINITY, MYINFINITY, MYINFINITY};
    bool h_changed = false;

    foru *d_dist = NULL;
    bool *d_changed = NULL;

    cudaError_t err;
    err = cudaMalloc((void **)&d_dist, sizeof(foru) * hgraph.nnodes);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_dist failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void **)&d_changed, sizeof(bool));
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_changed failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(d_dist, h_dist, sizeof(foru) * hgraph.nnodes, cudaMemcpyHostToDevice);

    int block = 256;
    int grid = 1;

    int iter = 0;
    do {
        iter++;
        h_changed = false;
        cudaMemcpy(d_changed, &h_changed, sizeof(bool), cudaMemcpyHostToDevice);

        drelax<<<grid, block>>>(d_dist, dgraph, d_changed);

        err = cudaGetLastError();
        if (err != cudaSuccess) {
            fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
            return -1;
        }

        err = cudaDeviceSynchronize();
        if (err != cudaSuccess) {
            fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
            return -1;
        }

        cudaMemcpy(&h_changed, d_changed, sizeof(bool), cudaMemcpyDeviceToHost);
    } while (h_changed && iter < 16);

    cudaMemcpy(h_dist, d_dist, sizeof(foru) * hgraph.nnodes, cudaMemcpyDeviceToHost);

    printf("drelax finished after %d iterations\n", iter);
    for (unsigned i = 0; i < hgraph.nnodes; i++) {
        printf("dist[%u] = %u\n", i, h_dist[i]);
    }

    cudaFree(d_dist);
    cudaFree(d_changed);
    dgraph.deallocOnDevice();
    hgraph.deallocOnHost();

    return 0;
}