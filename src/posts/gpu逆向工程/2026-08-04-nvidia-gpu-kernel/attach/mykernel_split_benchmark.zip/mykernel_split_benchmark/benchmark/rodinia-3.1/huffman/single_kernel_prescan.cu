#include <stdio.h>

#define NUM_BANKS 16
#define LOG_NUM_BANKS 4
#define CONFLICT_FREE_OFFSET(index) ((index) >> LOG_NUM_BANKS)

// ---------- device helpers (来自 srad.cu) ----------
template <bool isNP2>
__device__ static void loadSharedChunkFromMem(unsigned int *s_data,
        const unsigned int *g_idata, int n, int baseIndex,
        int& ai, int& bi, int& mem_ai, int& mem_bi,
        int& bankOffsetA, int& bankOffsetB) {
    int thid = threadIdx.x;
    mem_ai = baseIndex + thid;
    mem_bi = mem_ai + blockDim.x;
    ai = thid; bi = thid + blockDim.x;
    bankOffsetA = CONFLICT_FREE_OFFSET(ai);
    bankOffsetB = CONFLICT_FREE_OFFSET(bi);
    s_data[ai + bankOffsetA] = g_idata[mem_ai];
    s_data[bi + bankOffsetB] = (isNP2 && bi >= n) ? 0 : g_idata[mem_bi];
}

template <bool isNP2>
__device__ static void storeSharedChunkToMem(unsigned int *g_odata,
        const unsigned int *s_data, int n,
        int ai, int bi, int mem_ai, int mem_bi,
        int bankOffsetA, int bankOffsetB) {
    __syncthreads();
    g_odata[mem_ai] = s_data[ai + bankOffsetA];
    if (!isNP2 || bi < n)
        g_odata[mem_bi] = s_data[bi + bankOffsetB];
}

template <bool storeSum>
__device__ static void clearLastElement(unsigned int *s_data,
        unsigned int *g_blockSums, int blockIndex) {
    if (threadIdx.x == 0) {
        int index = (blockDim.x << 1) - 1;
        index += CONFLICT_FREE_OFFSET(index);
        if (storeSum) g_blockSums[blockIndex] = s_data[index];
        s_data[index] = 0;
    }
}

__device__ static unsigned int buildSum(unsigned int *s_data) {
    unsigned int thid = threadIdx.x, stride = 1;
    for (int d = blockDim.x; d > 0; d >>= 1) {
        __syncthreads();
        if (thid < d) {
            int ai = stride * (2*thid+1) - 1 + CONFLICT_FREE_OFFSET(stride*(2*thid+1)-1);
            int bi = stride * (2*thid+2) - 1 + CONFLICT_FREE_OFFSET(stride*(2*thid+2)-1);
            s_data[bi] += s_data[ai];
        }
        stride *= 2;
    }
    return stride;
}

__device__ static void scanRootToLeaves(unsigned int *s_data, unsigned int stride) {
    unsigned int thid = threadIdx.x;
    for (int d = 1; d <= blockDim.x; d *= 2) {
        stride >>= 1;
        __syncthreads();
        if (thid < d) {
            int ai = stride*(2*thid+1)-1 + CONFLICT_FREE_OFFSET(stride*(2*thid+1)-1);
            int bi = stride*(2*thid+2)-1 + CONFLICT_FREE_OFFSET(stride*(2*thid+2)-1);
            unsigned int t = s_data[ai];
            s_data[ai] = s_data[bi];
            s_data[bi] += t;
        }
    }
}

template <bool storeSum>
__device__ static void prescanBlock(unsigned int *data, int blockIndex, unsigned int *blockSums) {
    int stride = buildSum(data);
    clearLastElement<storeSum>(data, blockSums,
                               (blockIndex == 0) ? blockIdx.x : blockIndex);
    scanRootToLeaves(data, stride);
}

// ---------- kernel ----------
template <bool storeSum, bool isNP2>
__global__ static void prescan(unsigned int *g_odata,
                                const unsigned int *g_idata,
                                unsigned int *g_blockSums,
                                int n, int blockIndex, int baseIndex) {
    int ai, bi, mem_ai, mem_bi, bankOffsetA, bankOffsetB;
    extern __shared__ unsigned int s_data[];

    loadSharedChunkFromMem<isNP2>(s_data, g_idata, n,
        (baseIndex == 0) ? blockIdx.x * (blockDim.x << 1) : baseIndex,
        ai, bi, mem_ai, mem_bi, bankOffsetA, bankOffsetB);
    prescanBlock<storeSum>(s_data, blockIndex, g_blockSums);
    storeSharedChunkToMem<isNP2>(g_odata, s_data, n,
        ai, bi, mem_ai, mem_bi, bankOffsetA, bankOffsetB);
}

// ---------- main ----------
int main() {
    const int N       = 512;   // 必须是 2 的幂且 <= 2*blockDim
    const int THREADS = N / 2;
    const int SMEM    = (N + N/NUM_BANKS) * sizeof(unsigned int);

    unsigned int h_in[N], h_out[N], h_sums[1] = {0};
    for (int i = 0; i < N; i++) h_in[i] = 1;

    unsigned int *d_in, *d_out, *d_sums;
    cudaMalloc(&d_in,   N * sizeof(unsigned int));
    cudaMalloc(&d_out,  N * sizeof(unsigned int));
    cudaMalloc(&d_sums, 1 * sizeof(unsigned int));
    cudaMemcpy(d_in, h_in, N*sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemset(d_out,  0, N * sizeof(unsigned int));
    cudaMemset(d_sums, 0, 1 * sizeof(unsigned int));

    // storeSum=true, isNP2=false
    prescan<true, false><<<1, THREADS, SMEM>>>(d_out, d_in, d_sums, N, 0, 0);
    cudaDeviceSynchronize();

    cudaMemcpy(h_out,  d_out,  N*sizeof(unsigned int), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_sums, d_sums, sizeof(unsigned int),   cudaMemcpyDeviceToHost);

    // exclusive scan: h_out[i] = sum(h_in[0..i-1])
    printf("out[0]=%u out[1]=%u out[%d]=%u blockSum=%u (expected 0,1,%d,%d)\n",
           h_out[0], h_out[1], N-1, h_out[N-1], h_sums[0], N-1, N);

    cudaFree(d_in); cudaFree(d_out); cudaFree(d_sums);
    return 0;
}