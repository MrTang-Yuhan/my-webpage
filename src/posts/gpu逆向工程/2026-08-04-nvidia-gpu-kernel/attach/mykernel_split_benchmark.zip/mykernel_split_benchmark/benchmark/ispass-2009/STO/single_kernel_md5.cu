// Auto-generated CUDA kernel file: md5
// Extracted from: ispass-2009/STO/md5_kernel.cu
// Original line: 927

// ===== Includes =====
#include "cust.h"
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ===== Macro Definitions =====
#define F(x,y,z) (y ^ (x | ~z))  // from line 871
#define FEATURE_REDUCED_HASH_SIZE  // from line 63 (from ispass-2009/STO/cust.h)
#define FEATURE_SHARED_MEMORY  // from line 56 (from ispass-2009/STO/cust.h)
#define GET_CACHED_INDEX(index) (x##index)  // from line 705
#define GET_UINT32_LE(n,b,i)                            \
{                                                       \
    (n) = ( (unsigned long) (b)[(i)    ]       )        \
        | ( (unsigned long) (b)[(i) + 1] <<  8 )        \
        | ( (unsigned long) (b)[(i) + 2] << 16 )        \
        | ( (unsigned long) (b)[(i) + 3] << 24 );       \
}  // from line 85
  #define MD5_HASH_SIZE    16  // from line 110 (from ispass-2009/STO/cust.h)
#define P(a,b,c,d,k,s,t) {						\
      a += F(b,c,d) + sharedMemory[GET_CACHED_INDEX(k)] + t; a = S(a,s) + b; \
    }									\
      // from line 797
#define PUT_UINT32_LE(n,b,i)                            \
{                                                       \
    (b)[(i)    ] = (unsigned char) ( (n)       );       \
    (b)[(i) + 1] = (unsigned char) ( (n) >>  8 );       \
    (b)[(i) + 2] = (unsigned char) ( (n) >> 16 );       \
    (b)[(i) + 3] = (unsigned char) ( (n) >> 24 );       \
}  // from line 95
#define S(x,n) ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n)))  // from line 795
#define SHARED_MEMORY_INDEX(index) (32 * (index) + (threadIdx.x & 0x1F))  // from line 106

// ===== Global Variables =====
int t = 1;  // global (from ispass-2009/RAY/rayTracing.cu:108)

// ===== Function Forward Declarations =====
__device__
static void md5_internal( unsigned int *input, unsigned int *sharedMemory, 
			  int chunkSize, unsigned char *output );

// ===== Device/Helper Functions =====
// Function: md5_internal (from ispass-2009/STO/md5_kernel.cu:439)
__device__
static void md5_internal( unsigned int *input, unsigned int *sharedMemory, 
			  int chunkSize, unsigned char *output ) {


  /* Number of passes (512 bit blocks) we have to do */
  int numberOfPasses = chunkSize / 64 + 1;
  /* Used during the hashing process */
  unsigned long A, B, C, D;
  /* Needed to do the little endian stuff */
  unsigned char *data = (unsigned char *)sharedMemory;

  /* Will hold the hash value through the 
     intermediate stages of MD5 algorithm */
  unsigned int state0 = 0x67452301;
  unsigned int state1 = 0xEFCDAB89;
  unsigned int state2 = 0x98BADCFE;
  unsigned int state3 = 0x10325476;


  /* Used to cache the shared memory index calculations, but testing showed 
     that it has no performance effect. */
  int x0 = SHARED_MEMORY_INDEX(0);
  int x1 = SHARED_MEMORY_INDEX(1);
  int x2 = SHARED_MEMORY_INDEX(2);
  int x3 = SHARED_MEMORY_INDEX(3);
  int x4 = SHARED_MEMORY_INDEX(4);
  int x5 = SHARED_MEMORY_INDEX(5);
  int x6 = SHARED_MEMORY_INDEX(6);
  int x7 = SHARED_MEMORY_INDEX(7);
  int x8 = SHARED_MEMORY_INDEX(8);
  int x9 = SHARED_MEMORY_INDEX(9);
  int x10 = SHARED_MEMORY_INDEX(10);
  int x11 = SHARED_MEMORY_INDEX(11);
  int x12 = SHARED_MEMORY_INDEX(12);
  int x13 = SHARED_MEMORY_INDEX(13);
  int x14 = SHARED_MEMORY_INDEX(14);
  int x15 = SHARED_MEMORY_INDEX(15);

#undef GET_CACHED_INDEX
#define GET_CACHED_INDEX(index) (x##index)


  for( int index = 0 ; index < (numberOfPasses) ; index++ ) {

    /* Move data to the thread's shared memory space */
    sharedMemory[GET_CACHED_INDEX(0)] = input[0 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(1)] = input[1 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(2)] = input[2 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(3)] = input[3 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(4)] = input[4 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(5)] = input[5 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(6)] = input[6 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(7)] = input[7 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(8)] = input[8 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(9)] = input[9 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(10)] = input[10 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(11)] = input[11 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(12)] = input[12 + 16 * index];

    /* Testing the code with and without this if statement shows that
       it has no effect on performance. */
    if(index == numberOfPasses -1 ) {
      /* The last pass will contain the size of the chunk size (according to
	 official MD5 algorithm). */
      sharedMemory[GET_CACHED_INDEX(13)] = 0x00000080;
      sharedMemory[GET_CACHED_INDEX(14)] = chunkSize << 3;
      sharedMemory[GET_CACHED_INDEX(15)] = chunkSize >> 29;
    } else {
      sharedMemory[GET_CACHED_INDEX(13)] = input[13 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(14)] = input[14 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(15)] = input[15 + 16 * index];
    }

	   /* Get the little endian stuff done. */
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(0)], 
		   data, GET_CACHED_INDEX(0) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(1)], 
		   data, GET_CACHED_INDEX(1) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(2)], 
		   data, GET_CACHED_INDEX(2) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(3)], 
		   data, GET_CACHED_INDEX(3) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(4)], 
		   data, GET_CACHED_INDEX(4) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(5)], 
		   data, GET_CACHED_INDEX(5) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(6)], 
		   data, GET_CACHED_INDEX(6) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(7)], 
		   data, GET_CACHED_INDEX(7) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(8)], 
		   data, GET_CACHED_INDEX(8) * 4 );
    GET_UINT32_LE( sharedMemory[ GET_CACHED_INDEX(9)], 
		   data, GET_CACHED_INDEX(9) * 4 );
    GET_UINT32_LE( sharedMemory[GET_CACHED_INDEX(10)], 
		   data, GET_CACHED_INDEX(10) * 4 );
    GET_UINT32_LE( sharedMemory[GET_CACHED_INDEX(11)], 
		   data, GET_CACHED_INDEX(11) * 4 );
    GET_UINT32_LE( sharedMemory[GET_CACHED_INDEX(12)], 
		   data, GET_CACHED_INDEX(12) * 4 );
    GET_UINT32_LE( sharedMemory[GET_CACHED_INDEX(13)], 
		   data, GET_CACHED_INDEX(13) * 4 );
    GET_UINT32_LE( sharedMemory[GET_CACHED_INDEX(14)], 
		   data, GET_CACHED_INDEX(14) * 4 );
    GET_UINT32_LE( sharedMemory[GET_CACHED_INDEX(15)], 
		   data, GET_CACHED_INDEX(15) * 4 );


    /* Start the MD5 permutations */
#undef S
#define S(x,n) ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n)))
#undef P  
#define P(a,b,c,d,k,s,t) {						\
      a += F(b,c,d) + sharedMemory[GET_CACHED_INDEX(k)] + t; a = S(a,s) + b; \
    }									\
    
    A = state0;
    B = state1;
    C = state2;
    D = state3;
    
#undef F
    
#define F(x,y,z) (z ^ (x & (y ^ z)))
    
    P( A, B, C, D,  0,  7, 0xD76AA478 );
    P( D, A, B, C,  1, 12, 0xE8C7B756 );
    P( C, D, A, B,  2, 17, 0x242070DB );
    P( B, C, D, A,  3, 22, 0xC1BDCEEE );
    P( A, B, C, D,  4,  7, 0xF57C0FAF );
    P( D, A, B, C,  5, 12, 0x4787C62A );
    P( C, D, A, B,  6, 17, 0xA8304613 );
    P( B, C, D, A,  7, 22, 0xFD469501 );
    P( A, B, C, D,  8,  7, 0x698098D8 );
    P( D, A, B, C,  9, 12, 0x8B44F7AF );
    P( C, D, A, B, 10, 17, 0xFFFF5BB1 );
    P( B, C, D, A, 11, 22, 0x895CD7BE );
    P( A, B, C, D, 12,  7, 0x6B901122 );
    P( D, A, B, C, 13, 12, 0xFD987193 );
    P( C, D, A, B, 14, 17, 0xA679438E );
    P( B, C, D, A, 15, 22, 0x49B40821 );
    
#undef F
    
#define F(x,y,z) (y ^ (z & (x ^ y)))
    
    P( A, B, C, D,  1,  5, 0xF61E2562 );
    P( D, A, B, C,  6,  9, 0xC040B340 );
    P( C, D, A, B, 11, 14, 0x265E5A51 );
    P( B, C, D, A,  0, 20, 0xE9B6C7AA );
    P( A, B, C, D,  5,  5, 0xD62F105D );
    P( D, A, B, C, 10,  9, 0x02441453 );
    P( C, D, A, B, 15, 14, 0xD8A1E681 );
    P( B, C, D, A,  4, 20, 0xE7D3FBC8 );
    P( A, B, C, D,  9,  5, 0x21E1CDE6 );
    P( D, A, B, C, 14,  9, 0xC33707D6 );
    P( C, D, A, B,  3, 14, 0xF4D50D87 );
    P( B, C, D, A,  8, 20, 0x455A14ED );
    P( A, B, C, D, 13,  5, 0xA9E3E905 );
    P( D, A, B, C,  2,  9, 0xFCEFA3F8 );
    P( C, D, A, B,  7, 14, 0x676F02D9 );
    P( B, C, D, A, 12, 20, 0x8D2A4C8A );
    
#undef F
    
#define F(x,y,z) (x ^ y ^ z)
    
    P( A, B, C, D,  5,  4, 0xFFFA3942 );
    P( D, A, B, C,  8, 11, 0x8771F681 );
    P( C, D, A, B, 11, 16, 0x6D9D6122 );
    P( B, C, D, A, 14, 23, 0xFDE5380C );
    P( A, B, C, D,  1,  4, 0xA4BEEA44 );
    P( D, A, B, C,  4, 11, 0x4BDECFA9 );
    P( C, D, A, B,  7, 16, 0xF6BB4B60 );
    P( B, C, D, A, 10, 23, 0xBEBFBC70 );
    P( A, B, C, D, 13,  4, 0x289B7EC6 );
    P( D, A, B, C,  0, 11, 0xEAA127FA );
    P( C, D, A, B,  3, 16, 0xD4EF3085 );
    P( B, C, D, A,  6, 23, 0x04881D05 );
    P( A, B, C, D,  9,  4, 0xD9D4D039 );
    P( D, A, B, C, 12, 11, 0xE6DB99E5 );
    P( C, D, A, B, 15, 16, 0x1FA27CF8 );
    P( B, C, D, A,  2, 23, 0xC4AC5665 );
    
#undef F
    
#define F(x,y,z) (y ^ (x | ~z))
    
    P( A, B, C, D,  0,  6, 0xF4292244 );
    P( D, A, B, C,  7, 10, 0x432AFF97 );
    P( C, D, A, B, 14, 15, 0xAB9423A7 );
    P( B, C, D, A,  5, 21, 0xFC93A039 );
    P( A, B, C, D, 12,  6, 0x655B59C3 );
    P( D, A, B, C,  3, 10, 0x8F0CCC92 );
    P( C, D, A, B, 10, 15, 0xFFEFF47D );
    P( B, C, D, A,  1, 21, 0x85845DD1 );
    P( A, B, C, D,  8,  6, 0x6FA87E4F );
    P( D, A, B, C, 15, 10, 0xFE2CE6E0 );
    P( C, D, A, B,  6, 15, 0xA3014314 );
    P( B, C, D, A, 13, 21, 0x4E0811A1 );
    P( A, B, C, D,  4,  6, 0xF7537E82 );
    P( D, A, B, C, 11, 10, 0xBD3AF235 );
    P( C, D, A, B,  2, 15, 0x2AD7D2BB );
    P( B, C, D, A,  9, 21, 0xEB86D391 );
    
#undef F
    
    state0 += A;
    state1 += B;
    state2 += C;
    state3 += D;
  }

  /* Got the hash, store it in the output buffer. */
  PUT_UINT32_LE( state0, output,  0 );
#ifndef FEATURE_REDUCED_HASH_SIZE
  PUT_UINT32_LE( state1, output,  4 );
  PUT_UINT32_LE( state2, output,  8 );
  PUT_UINT32_LE( state3, output, 12 );
#endif
  

}

// ===== Kernel =====
// Kernel: md5 (line 927)
__global__
void md5( unsigned char *input, int chunkSize, int totalThreads,
          int padSize, unsigned char *scratch) {

  
  int threadIndex = threadIdx.x + blockDim.x * blockIdx.x;
  int chunkIndex = threadIndex * chunkSize;
  int hashIndex  = threadIndex * MD5_HASH_SIZE;

  if(threadIndex >= totalThreads)
    return;
  
  if ((threadIndex == (totalThreads - 1)) && (padSize > 0)) {
    for(int i = 0 ; i < padSize ; i++)
      input[chunkIndex + chunkSize - padSize + i] = 0;
  }


#ifdef FEATURE_SHARED_MEMORY
  
  __shared__ unsigned int sharedMemory[4 * 1024 - 32];
  
  // 512 words are allocated for every warp of 32 threads
  unsigned int *sharedMemoryIndex = sharedMemory + ((threadIdx.x >> 5) * 512);
  unsigned int *inputIndex = (unsigned int *)(input + chunkIndex);
  
  md5_internal(inputIndex, sharedMemoryIndex, chunkSize, 
	       scratch + hashIndex );

#else
  md5_internal(input + chunkIndex, chunkSize, scratch + hashIndex );
#endif /* FEATURE_SHARED_MEMORY */


}

int main(int argc, char **argv) {
    int totalThreads = 64;
    int chunkSize = 52;
    int padSize = 0;

    if (argc >= 2) totalThreads = atoi(argv[1]);
    if (argc >= 3) chunkSize = atoi(argv[2]);

    if (totalThreads <= 0) {
        fprintf(stderr, "totalThreads must be > 0\n");
        return -1;
    }

    if (chunkSize <= 0 || chunkSize > 52) {
        fprintf(stderr, "For this standalone main, chunkSize should be in range 1..52\n");
        return -1;
    }

    size_t inputSize = (size_t)totalThreads * chunkSize;
    size_t outputSize = (size_t)totalThreads * MD5_HASH_SIZE;

    unsigned char *h_input = (unsigned char *)malloc(inputSize);
    unsigned char *h_output = (unsigned char *)malloc(outputSize);

    if (!h_input || !h_output) {
        fprintf(stderr, "host malloc failed\n");
        free(h_input);
        free(h_output);
        return -1;
    }

    for (size_t i = 0; i < inputSize; i++) {
        h_input[i] = (unsigned char)('a' + (i % 26));
    }

    memset(h_output, 0, outputSize);

    unsigned char *d_input = NULL;
    unsigned char *d_output = NULL;

    cudaError_t err;

    err = cudaMalloc((void **)&d_input, inputSize);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_input failed: %s\n", cudaGetErrorString(err));
        free(h_input);
        free(h_output);
        return -1;
    }

    err = cudaMalloc((void **)&d_output, outputSize);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_output failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_input);
        free(h_input);
        free(h_output);
        return -1;
    }

    cudaMemcpy(d_input, h_input, inputSize, cudaMemcpyHostToDevice);
    cudaMemset(d_output, 0, outputSize);

    dim3 block(128);
    dim3 grid((totalThreads + block.x - 1) / block.x);

    md5<<<grid, block>>>(d_input, chunkSize, totalThreads, padSize, d_output);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_input);
        cudaFree(d_output);
        free(h_input);
        free(h_output);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_input);
        cudaFree(d_output);
        free(h_input);
        free(h_output);
        return -1;
    }

    cudaMemcpy(h_output, d_output, outputSize, cudaMemcpyDeviceToHost);

    printf("MD5 output, first few hashes:\n");
    int printThreads = totalThreads < 4 ? totalThreads : 4;
    for (int i = 0; i < printThreads; i++) {
        printf("hash[%d] = ", i);
        for (int j = 0; j < MD5_HASH_SIZE; j++) {
            printf("%02x", h_output[i * MD5_HASH_SIZE + j]);
        }
        printf("\n");
    }

    cudaFree(d_input);
    cudaFree(d_output);
    free(h_input);
    free(h_output);

    return 0;
}