// Auto-generated CUDA kernel file: wsm5_gpu
// Corrected standalone version

#include "cublas.h"
#include <cuda.h>
#include <cuda_runtime.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef MKX
#define MKX 128
#endif

// ===== Macro Definitions =====
#define TtoP(i,a,b,c,d) ((i)+(a)*(b)+(c)-(d))

#define bi blockIdx.x
#define bj blockIdx.y
#define bx blockDim.x
#define by blockDim.y
#define ti threadIdx.x
#define tj threadIdx.y

#define ig (TtoP((ti)*4,bi,(bx)*4,ips,ims))
#define jg (TtoP(tj,bj,by,jps,jms))

#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))
#define MAX(x,y) max(x,y)
#define MIN(x,y) min(x,y)

#define CONDEN(a,b,c,d,e) ((MAX((b),qmin)-(c))/(1.+(d)*(d)/(rv*(e))*(c)/((a)*(a))))
#define CPMCAL(x) (cpd*(1.-max(x,qmin))+max(x,qmin)*cpv)
#define DIFFAC(a,b,c,d,e) ((d)*(a)*(a)/(XKA((c),(d))*rv*(c)*(c))+1./((e)*DIFFUS((c),(b))))
#define DIFFUS(x,y) (8.794e-5f * expf(logf(x)*(1.81f)) / (y))
#define LAMDAR(x,y) sqrtf(sqrtf(pidn0r/((x)*(y))))
#define LAMDAS(x,y,z) sqrtf(sqrtf(pidn0s*(z)/((x)*(y))))
#define VENFAC(a,b,c) (expf(logf((VISCOS((b),(c))/DIFFUS((b),(a))))*(0.3333333f))*rsqrtf(VISCOS((b),(c)))*sqrtf(sqrtf(den0/(c))))
#define VISCOS(x,y) (1.496e-6f * ((x)*sqrtf(x)) /((x)+120.f)/(y))
#define XKA(x,y) (1.414e3f*VISCOS((x),(y))*(y))
#define XLCAL(x)  (xlv0-xlv1*((x)-t0c))

#define alpha   0.120000000000000E+00
#define bvtr    0.800000000000000E+00
#define bvts    0.410000000000000E+00
#define cice    0.210600000000000E+04
#define cliq    0.419000000000000E+04
#define den0    0.127999997138977E+01
#define denr    0.100000000000000E+04
#define dicon   0.119000000000000E+02
#define dimax   0.500000000000000E-03
#define ep2     0.621750414371490E+00
#define n0r     0.800000000000000E+07
#define n0s     0.200000000000000E+07
#define n0smax  0.100000000000000E+12
#define pfrz1   0.100000000000000E+03
#define pfrz2   0.660000000000000E+00
#define pi      0.314159265358979E+01
#define psat    0.610780029296875E+03
#define qcrmin  0.100000000000000E-08
#define qmin    0.100000000362749E-14
#define r_v     0.461600006103516E+03
#define rv      r_v
#define t0c     0.273149993896484E+03
#define xlf0    0.350000000000000E+06
#define xls     0.285000000000000E+07
#define xlv0    0.250000000000000E+07
#define xncr    0.300000000000000E+09

// ===== Kernel =====
__global__ void wsm5_gpu(
    float *th, float *pii,
    float *q,
    float *qc, float *qi, float *qr, float *qs,
    float *den, float *p, float *delz,
#ifdef DEBUGAL_ARRAY
    float *debuggal,
#endif
    float *rain, float *rainncv,
    float *sr,
    float *snow, float *snowncv,
    float delt,
    float *retvals,
    int ids, int ide,  int jds, int jde,  int kds, int kde,
    int ims, int ime,  int jms, int jme,  int kms, int kme,
    int ips, int ipe,  int jps, int jpe,  int kps, int kpe
) {
    float xlf, xmi, acrfac, vt2i, vt2s, supice, diameter;
    float roqi0, xni0, qimax, value, source, factor, xlwork2;
    float t_k, q_k, qr_k, qc_k, qs_k, qi_k, qs1_k, qs2_k, cpm_k, xl_k, xni_k, w1_k, w2_k, w3_k;

#define hsub   xls
#define hvap   xlv0
#define cvap   cpv

    float ttp;
    float dldt;
    float xa;
    float xb;
    float dldti;
    float xai;
    float xbi;

#ifdef DEBUGAL_ARRAY
    debuggal[0] = 999.0f;
#endif

    if (ig < ide - ids + 1 && jg < jde - jds + 1) {

        if ((kpe - kps + 1) > MKX) return;

        int k;

        float t[MKX];
        float cpm[MKX];
        float xl[MKX];

        float qs1[MKX];
        float qs2[MKX];
        float rh1[MKX];
        float rh2[MKX];

        float xni[MKX];

        float rsloper[MKX];
        float rslopebr[MKX];
        float rslope2r[MKX];
        float rslope3r[MKX];

        float rslopes[MKX];
        float rslopebs[MKX];
        float rslope2s[MKX];
        float rslope3s[MKX];

        float denfac[MKX];
        float n0sfac[MKX];

        float w1[MKX];
        float w2[MKX];
        float w3[MKX];

        float prevp[MKX];
        float psdep[MKX];
        float praut[MKX];
        float psaut[MKX];
        float pracw[MKX];
        float psaci[MKX];
        float psacw[MKX];
        float pigen[MKX];
        float pidep[MKX];
        float pcond[MKX];
        float psmlt[MKX];
        float psevp[MKX];

#include "wsm5_constants.h"

        for (k = kps - 1; k <= kpe - 1; k++) {
            t[k] = th[k] * pii[k];
        }

        for (k = kps - 1; k <= kpe - 1; k++) {
            if (qc[k] < 0.f) qc[k] = 0.f;
            if (qi[k] < 0.f) qi[k] = 0.f;
            if (qr[k] < 0.f) qr[k] = 0.f;
            if (qs[k] < 0.f) qs[k] = 0.f;
        }

        for (k = kps - 1; k <= kpe - 1; k++) {
            cpm[k] = (float)CPMCAL(q[k]);
            xl[k] = (float)XLCAL(t[k]);
        }

        float dtcldcr = 120.f;
        int loops = (int)(delt / dtcldcr + .5f);
        loops = MAX(loops, 1);
        float dtcld = delt / loops;
        if (delt <= dtcldcr) dtcld = delt;

        for (int loop = 1; loop <= loops; loop++) {
            int mstep = 1;

            ttp = t0c + 0.01f;
            dldt = cvap - cliq;
            xa = -dldt / rv;
            xb = xa + hvap / (rv * ttp);
            dldti = cvap - cice;
            xai = -dldti / rv;
            xbi = xai + hsub / (rv * ttp);

            float tr, ltr, tt, pp, qq;

            for (k = kps - 1; k <= kpe - 1; k++) {
                pp = p[k];
                tt = t[k];
                tr = ttp / tt;
                ltr = logf(tr);

                qq = psat * expf(ltr * xa + xb * (1.f - tr));
                qq = ep2 * qq / (pp - qq);
                qs1[k] = MAX(qq, qmin);
                rh1[k] = MAX(q[k] / qs1[k], qmin);

                if (tt < ttp) {
                    qq = psat * expf(ltr * xai + xbi * (1.f - tr));
                } else {
                    qq = psat * expf(ltr * xa + xb * (1.f - tr));
                }
                qq = ep2 * qq / (pp - qq);
                qs2[k] = MAX(qq, qmin);
                rh2[k] = MAX(q[k] / qs2[k], qmin);
            }

            for (k = kps - 1; k <= kpe - 1; k++) {
                xni[k] = 1.e3f;
            }

            float w;
            float rmstep;
            int numdt;

            for (k = kps - 1; k <= kpe - 1; k++) {
                float supcol = t0c - t[k];
                n0sfac[k] = MAX(MIN(expf(alpha * supcol), n0smax / n0s), 1.f);

                if (qr[k] <= qcrmin) {
                    rsloper[k]  = (float)rslopermax;
                    rslopebr[k] = (float)rsloperbmax;
                    rslope2r[k] = (float)rsloper2max;
                    rslope3r[k] = (float)rsloper3max;
                } else {
                    rsloper[k]  = 1.f / LAMDAR(qr[k], den[k]);
                    rslopebr[k] = expf(logf(rsloper[k]) * bvtr);
                    rslope2r[k] = rsloper[k] * rsloper[k];
                    rslope3r[k] = rslope2r[k] * rsloper[k];
                }

                if (qs[k] <= qcrmin) {
                    rslopes[k]  = (float)rslopesmax;
                    rslopebs[k] = (float)rslopesbmax;
                    rslope2s[k] = (float)rslopes2max;
                    rslope3s[k] = (float)rslopes3max;
                } else {
                    rslopes[k] = 1.f / LAMDAS(qs[k], den[k], n0sfac[k]);
                    rslopebs[k] = expf(logf(rslopes[k]) * bvts);
                    rslope2s[k] = rslopes[k] * rslopes[k];
                    rslope3s[k] = rslope2s[k] * rslopes[k];
                }

                denfac[k] = sqrtf(den0 / den[k]);
                w1[k] = (float)pvtr * rslopebr[k] * denfac[k] / delz[k];
                w2[k] = (float)pvts * rslopebs[k] * denfac[k] / delz[k];

                w = MAX(w1[k], w2[k]);
                numdt = MAX((int)truncf(w * dtcld + 1.0f), 1);
                if (numdt >= mstep) mstep = numdt;

                float temp = den[k] * MAX(qi[k], qmin);
                temp = sqrtf(sqrtf(temp * temp * temp));
#ifdef DEBUGDEBUG
                xni[k] = 1.e3f;
#else
                xni[k] = MIN(MAX(5.38e7f * temp, 1.e3f), 1.e6f);
#endif
            }

            rmstep = 1.f / mstep;

            float dtcldden, coeres, rdelz;
            float den_k, falk1_k, falk1_kp1, fall1_k = 0.0f, fall1_kp1 = 0.0f, delz_k, delz_kp1;
            float falk2_k, falk2_kp1, fall2_k = 0.0f, fall2_kp1 = 0.0f;

            for (int n = 1; n <= mstep; n++) {
                k = kpe - 1;
                den_k = den[k];
                falk1_kp1 = den_k * qr[k] * w1[k] * rmstep;
                fall1_kp1 = falk1_kp1;
                falk2_kp1 = den_k * qs[k] * w2[k] * rmstep;
                fall2_kp1 = falk2_kp1;
                dtcldden = dtcld / den_k;

                qr[k] = MAX(qr[k] - falk1_kp1 * dtcldden, 0.0f);
                qs[k] = MAX(qs[k] - falk2_kp1 * dtcldden, 0.0f);
                delz_kp1 = delz[k];

                for (k = kpe - 2; k >= kps - 1; k--) {
                    den_k = den[k];
                    falk1_k = den_k * qr[k] * w1[k] * rmstep;
                    fall1_k = falk1_k;
                    falk2_k = den_k * qs[k] * w2[k] * rmstep;
                    fall2_k = falk2_k;
                    dtcldden = dtcld / den_k;
                    delz_k = delz[k];
                    rdelz = 1.f / delz_k;

                    qr[k] = MAX(qr[k] - (falk1_k - falk1_kp1 * delz_kp1 * rdelz) * dtcldden, 0.f);
                    qs[k] = MAX(qs[k] - (falk2_k - falk2_kp1 * delz_kp1 * rdelz) * dtcldden, 0.f);

                    delz_kp1 = delz_k;
                    falk1_kp1 = falk1_k;
                    fall1_kp1 = fall1_k;
                    falk2_kp1 = falk2_k;
                    fall2_kp1 = fall2_k;
                }

                for (k = kpe - 1; k >= kps - 1; k--) {
                    if (t[k] > t0c && qs[k] > 0.f) {
                        xlf = xlf0;
                        w3[k] = (float)VENFAC(p[k], t[k], den[k]);
                        coeres = rslope2s[k] * sqrtf(rslopes[k] * rslopebs[k]);
                        psmlt[k] = (float)XKA(t[k], den[k]) / xlf * (t0c - t[k]) * pi * 0.5f
                                 * n0sfac[k] * ((float)precs1 * rslope2s[k] + (float)precs2 * w3[k] * coeres);
                        psmlt[k] = MIN(MAX(psmlt[k] * dtcld * rmstep, -qs[k] * rmstep), 0.f);
                        qs[k] += psmlt[k];
                        qr[k] -= psmlt[k];
                        t[k] += xlf / (float)CPMCAL(q[k]) * psmlt[k];
                    }
                }
            }

            mstep = 1;
            numdt = 1;

            for (k = kpe - 1; k >= kps - 1; k--) {
                if (qi[k] <= 0.f) {
                    w2[k] = 0.f;
                } else {
                    xmi = den[k] * qi[k] / xni[k];
                    diameter = MAX(MIN(dicon * sqrtf(xmi), dimax), 1.e-25f);
                    w1[k] = 1.49e4f * expf(logf(diameter) * 1.31f);
                    w2[k] = w1[k] / delz[k];
                }
                numdt = MAX((int)truncf(w2[k] * dtcld + 1.0f), 1);
                if (numdt > mstep) mstep = numdt;
            }

            rmstep = 1.f / mstep;

            float falkc_k = 0.0f, falkc_kp1 = 0.0f, fallc_k = 0.0f, fallc_kp1 = 0.0f;
            for (int n = 1; n <= mstep; n++) {
                k = kpe - 1;
                den_k = den[k];
                falkc_kp1 = den_k * qi[k] * w2[k] * rmstep;
                fallc_kp1 = falkc_kp1;
                qi[k] = MAX(qi[k] - falkc_kp1 * dtcld / den_k, 0.f);
                delz_kp1 = delz[k];

                for (k = kpe - 2; k >= kps - 1; k--) {
                    den_k = den[k];
                    falkc_k = den_k * qi[k] * w2[k] * rmstep;
                    fallc_k = falkc_k;
                    delz_k = delz[k];
                    qi[k] = MAX(qi[k] - (falkc_k - falkc_kp1 * delz_kp1 / delz_k) * dtcld / den_k, 0.f);
                    delz_kp1 = delz_k;
                    falkc_kp1 = falkc_k;
                    fallc_kp1 = fallc_k;
                }
            }

            float fallsum = fall1_k + fall2_k + fallc_k;
            float fallsum_qsi = fall2_k + fallc_k;

            rainncv[0] = 0.0f;
            if (fallsum > 0.0f) {
                rainncv[0] = fallsum * delz[1] / denr * dtcld * 1000.0f;
                rain[0] = fallsum * delz[1] / denr * dtcld * 1000.0f + rain[0];
            }

            snowncv[0] = 0.0f;
            if (fallsum_qsi > 0.0f) {
                snowncv[0] = fallsum_qsi * delz[0] / denr * dtcld * 1000.0f;
                snow[0] = fallsum_qsi * delz[0] / denr * dtcld * 1000.0f + snow[0];
            }

            sr[0] = 0.0f;
            if (fallsum > 0.0f) {
                sr[0] = fallsum_qsi * delz[0] / denr * dtcld * 1000.0f / (rainncv[0] + 1.0e-12f);
            }

            for (k = kps - 1; k <= kpe - 1; k++) {
                prevp[k] = 0.f;
                psdep[k] = 0.f;
                praut[k] = 0.f;
                psaut[k] = 0.f;
                pracw[k] = 0.f;
                psaci[k] = 0.f;
                psacw[k] = 0.f;
                pigen[k] = 0.f;
                pidep[k] = 0.f;
                pcond[k] = 0.f;
                psevp[k] = 0.f;

                q_k = q[k];
                t_k = t[k];
                qr_k = qr[k];
                qc_k = qc[k];
                qs_k = qs[k];
                qi_k = qi[k];
                qs1_k = qs1[k];
                qs2_k = qs2[k];
                cpm_k = cpm[k];
                xl_k = xl[k];

                float supcol = t0c - t_k;
                xlf = xls - xl_k;
                if (supcol < 0.f) xlf = xlf0;

                if (supcol < 0.f && qi_k > 0.f) {
                    qc_k = qc_k + qi_k;
                    t_k = t_k - xlf / cpm_k * qi_k;
                    qi_k = 0.f;
                }

                if (supcol > 40.f && qc_k > 0.f) {
                    qi_k = qi_k + qc_k;
                    t_k = t_k + xlf / cpm_k * qc_k;
                    qc_k = 0.f;
                }

                if (supcol > 0.f && qc_k > 0.f) {
                    float pfrzdtc = MIN(
                        pfrz1 * (expf(pfrz2 * supcol) - 1.f) * den[k] / denr / xncr * qc_k * qc_k * dtcld,
                        qc_k
                    );
                    qi_k = qi_k + pfrzdtc;
                    t_k = t_k + xlf / cpm_k * pfrzdtc;
                    qc_k = qc_k - pfrzdtc;
                }

                if (supcol > 0.f && qr_k > 0.f) {
                    float temp = rsloper[k];
                    temp = temp * temp * temp * temp * temp * temp * temp;
                    float pfrzdtr = MIN(
                        20.f * (pi * pi) * pfrz1 * n0r * denr / den[k] * (expf(pfrz2 * supcol) - 1.f) * temp * dtcld,
                        qr_k
                    );
                    qs_k = qs_k + pfrzdtr;
                    t_k = t_k + xlf / cpm_k * pfrzdtr;
                    qr_k = qr_k - pfrzdtr;
                }

                n0sfac[k] = MAX(MIN(expf(alpha * supcol), n0smax / n0s), 1.f);

                if (qr_k <= qcrmin) {
                    rsloper[k]  = (float)rslopermax;
                    rslopebr[k] = (float)rsloperbmax;
                    rslope2r[k] = (float)rsloper2max;
                    rslope3r[k] = (float)rsloper3max;
                } else {
                    rsloper[k] = 1.f / sqrtf(sqrtf((float)pidn0r / (qr_k * den[k])));
                    rslopebr[k] = expf(logf(rsloper[k]) * bvtr);
                    rslope2r[k] = rsloper[k] * rsloper[k];
                    rslope3r[k] = rslope2r[k] * rsloper[k];
                }

                if (qs_k <= qcrmin) {
                    rslopes[k]  = (float)rslopesmax;
                    rslopebs[k] = (float)rslopesbmax;
                    rslope2s[k] = (float)rslopes2max;
                    rslope3s[k] = (float)rslopes3max;
                } else {
                    rslopes[k] = 1.f / sqrtf(sqrtf((float)pidn0s * n0sfac[k] / (qs_k * den[k])));
                    rslopebs[k] = expf(logf(rslopes[k]) * bvts);
                    rslope2s[k] = rslopes[k] * rslopes[k];
                    rslope3s[k] = rslope2s[k] * rslopes[k];
                }

                w1_k = (float)DIFFAC(xl_k, p[k], t_k, den[k], qs1_k);
                w2_k = (float)DIFFAC(xls, p[k], t_k, den[k], qs2_k);
                w3_k = (float)VENFAC(p[k], t_k, den[k]);

                float supsat = MAX(q_k, qmin) - qs1_k;
                float satdt = supsat / dtcld;

                if (qc_k > (float)qc0) {
                    praut[k] = (float)qck1 * expf(logf(qc_k) * (7.f / 3.f));
                    praut[k] = MIN(praut[k], qc_k / dtcld);
                }

                if (qr_k > qcrmin && qc_k > qmin) {
                    pracw[k] = MIN((float)pacrr * rslope3r[k] * rslopebr[k] * qc_k * denfac[k], qc_k / dtcld);
                }

                if (qr_k > 0.f) {
                    coeres = rslope2r[k] * sqrtf(rsloper[k] * rslopebr[k]);
                    prevp[k] = (rh1[k] - 1.f) * ((float)precr1 * rslope2r[k] + (float)precr2 * w3_k * coeres) / w1_k;
                    if (prevp[k] < 0.f) {
                        prevp[k] = MAX(prevp[k], -qr_k / dtcld);
                        prevp[k] = MAX(prevp[k], satdt / 2.f);
                    } else {
                        prevp[k] = MIN(prevp[k], satdt / 2.f);
                    }
                }

                float rdtcld = 1.f / dtcld;
                supsat = MAX(q_k, qmin) - qs2_k;
                satdt = supsat / dtcld;
                int ifsat = 0;

                float temp = den[k] * MAX(qi_k, qmin);
                temp = sqrtf(sqrtf(temp * temp * temp));
                xni[k] = MIN(MAX(5.38e7f * temp, 1.e3f), 1.e6f);
                float eacrs = expf(0.07f * (-supcol));

                if (qs_k > qcrmin && qc_k > qmin) {
                    psacw[k] = MIN((float)pacrc * n0sfac[k] * rslope3s[k] * rslopebs[k] * qc_k * denfac[k], qc_k * rdtcld);
                }

                if (supcol > 0.f) {
                    if (qs_k > qcrmin && qi_k > qmin) {
                        xmi = den[k] * qi_k / xni[k];
                        diameter = MIN(dicon * sqrtf(xmi), dimax);
                        vt2i = 1.49e4f * powf(diameter, 1.31f);
                        vt2s = (float)pvts * rslopebs[k] * denfac[k];
                        acrfac = 2.f * rslope3s[k] + 2.f * diameter * rslope2s[k] + diameter * diameter * rslopes[k];
                        psaci[k] = pi * qi_k * eacrs * n0s * n0sfac[k] * fabsf(vt2s - vt2i) * acrfac * 0.25f;
                    }

                    if (qi_k > 0.f && ifsat != 1) {
                        xmi = den[k] * qi_k / xni[k];
                        diameter = dicon * sqrtf(xmi);
                        pidep[k] = 4.f * diameter * xni[k] * (rh2[k] - 1.f) / w2_k;
                        supice = satdt - prevp[k];
                        if (pidep[k] < 0.f) {
                            pidep[k] = MAX(MAX(pidep[k], satdt * 0.5f), supice);
                            pidep[k] = MAX(pidep[k], -qi_k * rdtcld);
                        } else {
                            pidep[k] = MIN(MIN(pidep[k], satdt * 0.5f), supice);
                        }
                        if (fabsf(prevp[k] + pidep[k]) >= fabsf(satdt)) ifsat = 1;
                    }

                    if (qs_k > 0.f && ifsat != 1) {
                        coeres = rslope2s[k] * sqrtf(rslopes[k] * rslopebs[k]);
                        psdep[k] = (rh2[k] - 1.f) * n0sfac[k]
                                 * ((float)precs1 * rslope2s[k] + (float)precs2 * w3_k * coeres) / w2_k;
                        supice = satdt - prevp[k] - pidep[k];
                        if (psdep[k] < 0.f) {
                            psdep[k] = MAX(psdep[k], -qs_k * rdtcld);
                            psdep[k] = MAX(MAX(psdep[k], satdt * 0.5f), supice);
                        } else {
                            psdep[k] = MIN(MIN(psdep[k], satdt * 0.5f), supice);
                        }
                        if (fabsf(prevp[k] + pidep[k] + psdep[k]) >= fabsf(satdt)) ifsat = 1;
                    }

                    if (supsat > 0.f && ifsat != 1) {
                        supice = satdt - prevp[k] - pidep[k] - psdep[k];
                        xni0 = 1.e3f * expf(0.1f * supcol);
                        roqi0 = 4.92e-11f * expf(logf(xni0) * 1.33f);
                        pigen[k] = MAX(0.f, (roqi0 / den[k] - MAX(qi_k, 0.f)) * rdtcld);
                        pigen[k] = MIN(MIN(pigen[k], satdt), supice);
                    }

                    if (qi_k > 0.f) {
                        qimax = (float)roqimax / den[k];
                        psaut[k] = MAX(0.f, (qi_k - qimax) * rdtcld);
                    }
                }

                if (supcol < 0.f) {
                    if (qs_k > 0.f && rh1[k] < 1.f) {
                        psevp[k] = psdep[k] * w2_k / w1_k;
                    }
                    psevp[k] = MIN(MAX(psevp[k], -qs_k * rdtcld), 0.f);
                }

                if (t_k <= t0c) {
                    value = MAX(qmin, qc_k);
                    source = (praut[k] + pracw[k] + psacw[k]) * dtcld;
                    if (source > value) {
                        factor = value / source;
                        praut[k] *= factor;
                        pracw[k] *= factor;
                        psacw[k] *= factor;
                    }

                    value = MAX(qmin, qi_k);
                    source = (psaut[k] + psaci[k] - pigen[k] - pidep[k]) * dtcld;
                    if (source > value) {
                        factor = value / source;
                        psaut[k] *= factor;
                        psaci[k] *= factor;
                        pigen[k] *= factor;
                        pidep[k] *= factor;
                    }

                    value = MAX(qmin, qr_k);
                    source = (-praut[k] + pracw[k] - prevp[k]) * dtcld;
                    if (source > value) {
                        factor = value / source;
                        praut[k] *= factor;
                        pracw[k] *= factor;
                        prevp[k] *= factor;
                    }

                    value = MAX(qmin, qs_k);
                    source = (-psdep[k] + psaut[k] - psaci[k] - psacw[k]) * dtcld;
                    if (source > value) {
                        factor = value / source;
                        psdep[k] *= factor;
                        psaut[k] *= factor;
                        psaci[k] *= factor;
                        psacw[k] *= factor;
                    }

                    w3_k = -(prevp[k] + psdep[k] + pigen[k] + pidep[k]);
                    q_k = q_k + w3_k * dtcld;
                    qc_k = MAX(qc_k - (praut[k] + pracw[k] + psacw[k]) * dtcld, 0.f);
                    qr_k = MAX(qr_k + (praut[k] + pracw[k] + prevp[k]) * dtcld, 0.f);
                    qi_k = MAX(qi_k - (psaut[k] + psaci[k] - pigen[k] - pidep[k]) * dtcld, 0.f);
                    qs_k = MAX(qs_k + (psdep[k] + psaut[k] + psaci[k] + psacw[k]) * dtcld, 0.f);
                    xlf = xls - xl_k;
                    xlwork2 = -xls * (psdep[k] + pidep[k] + pigen[k]) - xl_k * prevp[k] - xlf * psacw[k];
                    t_k = t_k - xlwork2 / cpm_k * dtcld;
                } else {
                    value = MAX(qmin, qc_k);
                    source = (praut[k] + pracw[k] + psacw[k]) * dtcld;
                    if (source > value) {
                        factor = value / source;
                        praut[k] *= factor;
                        pracw[k] *= factor;
                        psacw[k] *= factor;
                    }

                    value = MAX(qmin, qr_k);
                    source = (-praut[k] - pracw[k] - prevp[k] - psacw[k]) * dtcld;
                    if (source > value) {
                        factor = value / source;
                        praut[k] *= factor;
                        pracw[k] *= factor;
                        prevp[k] *= factor;
                        psacw[k] *= factor;
                    }

                    value = MAX(qcrmin, qs_k);
                    source = (-psevp[k]) * dtcld;
                    if (source > value) {
                        factor = value / source;
                        psevp[k] *= factor;
                    }

                    w3_k = -(prevp[k] + psevp[k]);
                    q_k = q_k + w3_k * dtcld;
                    qc_k = MAX(qc_k - (praut[k] + pracw[k] + psacw[k]) * dtcld, 0.f);
                    qr_k = MAX(qr_k + (praut[k] + pracw[k] + prevp[k] + psacw[k]) * dtcld, 0.f);
                    qs_k = MAX(qs_k + psevp[k] * dtcld, 0.f);
                    xlf = xls - xl_k;
                    xlwork2 = -xl_k * (prevp[k] + psevp[k]);
                    t_k = t_k - xlwork2 / cpm_k * dtcld;
                }

                cvap = cpv;
                ttp = t0c + 0.01f;
                dldt = cvap - cliq;
                xa = -dldt / rv;
                xb = xa + hvap / (rv * ttp);
                dldti = cvap - cice;
                xai = -dldti / rv;
                xbi = xai + hsub / (rv * ttp);
                tr = ttp / t_k;
                qs1_k = psat * expf(logf(tr) * xa) * expf(xb * (1.f - tr));
                qs1_k = ep2 * qs1_k / (p[k] - qs1_k);
                qs1_k = MAX(qs1_k, qmin);

                w1_k = (MAX(q_k, qmin) - qs1_k) /
                       (1.f + xl_k * xl_k / (rv * cpm_k) * qs1_k / (t_k * t_k));

                pcond[k] = MIN(MAX(w1_k / dtcld, 0.f), MAX(q_k, 0.f) / dtcld);
                if (qc_k > 0.f && w1_k < 0.f) {
                    pcond[k] = MAX(w1_k, -qc_k) / dtcld;
                }

                q_k = q_k - pcond[k] * dtcld;
                qc_k = MAX(qc_k + pcond[k] * dtcld, 0.f);
                t_k = t_k + pcond[k] * xl_k / cpm_k * dtcld;

                if (qc_k <= qmin) qc_k = 0.0f;
                if (qi_k <= qmin) qi_k = 0.0f;

                q[k] = q_k;
                t[k] = t_k;
                qr[k] = qr_k;
                qc[k] = qc_k;
                qs[k] = qs_k;
                qi[k] = qi_k;
                qs1[k] = qs1_k;
            }
        }

        for (k = kps - 1; k <= kpe - 1; k++) {
            th[k] = t[k] / pii[k];
        }
    }
}

// ===== Main =====
int main(int argc, char **argv) {
    int K = 32;
    float delt = 1.0f;

    if (argc >= 2) K = atoi(argv[1]);
    if (argc >= 3) delt = (float)atof(argv[2]);

    if (K < 2 || K > MKX) {
        fprintf(stderr, "K must be in range 2..%d\n", MKX);
        return -1;
    }

    size_t kSize = (size_t)K * sizeof(float);
    size_t ijSize = sizeof(float);

    float *h_th   = (float *)malloc(kSize);
    float *h_pii  = (float *)malloc(kSize);
    float *h_q    = (float *)malloc(kSize);
    float *h_qc   = (float *)malloc(kSize);
    float *h_qi   = (float *)malloc(kSize);
    float *h_qr   = (float *)malloc(kSize);
    float *h_qs   = (float *)malloc(kSize);
    float *h_den  = (float *)malloc(kSize);
    float *h_p    = (float *)malloc(kSize);
    float *h_delz = (float *)malloc(kSize);

    float *h_rain    = (float *)malloc(ijSize);
    float *h_rainncv = (float *)malloc(ijSize);
    float *h_sr      = (float *)malloc(ijSize);
    float *h_snow    = (float *)malloc(ijSize);
    float *h_snowncv = (float *)malloc(ijSize);
    float *h_retvals = (float *)malloc(sizeof(float) * 16);

    if (!h_th || !h_pii || !h_q || !h_qc || !h_qi || !h_qr || !h_qs ||
        !h_den || !h_p || !h_delz || !h_rain || !h_rainncv || !h_sr ||
        !h_snow || !h_snowncv || !h_retvals) {
        fprintf(stderr, "host malloc failed\n");
        free(h_th); free(h_pii); free(h_q); free(h_qc); free(h_qi); free(h_qr);
        free(h_qs); free(h_den); free(h_p); free(h_delz);
        free(h_rain); free(h_rainncv); free(h_sr); free(h_snow); free(h_snowncv); free(h_retvals);
        return -1;
    }

    for (int k = 0; k < K; k++) {
        h_pii[k]  = 1.0f;
        h_th[k]   = 280.0f - 0.5f * k;
        h_q[k]    = 0.001f;
        h_qc[k]   = 1.0e-6f;
        h_qi[k]   = 1.0e-8f;
        h_qr[k]   = 1.0e-8f;
        h_qs[k]   = 1.0e-8f;
        h_den[k]  = 1.0f;
        h_p[k]    = 90000.0f - 100.0f * k;
        h_delz[k] = 100.0f;
    }

    h_rain[0] = 0.0f;
    h_rainncv[0] = 0.0f;
    h_sr[0] = 0.0f;
    h_snow[0] = 0.0f;
    h_snowncv[0] = 0.0f;

    for (int i = 0; i < 16; i++) h_retvals[i] = 0.0f;

    float *d_th = NULL, *d_pii = NULL, *d_q = NULL, *d_qc = NULL, *d_qi = NULL;
    float *d_qr = NULL, *d_qs = NULL, *d_den = NULL, *d_p = NULL, *d_delz = NULL;
    float *d_rain = NULL, *d_rainncv = NULL, *d_sr = NULL, *d_snow = NULL, *d_snowncv = NULL;
    float *d_retvals = NULL;

    cudaError_t err;

    err = cudaMalloc((void **)&d_th, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_th failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_pii, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_pii failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_q, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_q failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_qc, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_qc failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_qi, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_qi failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_qr, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_qr failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_qs, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_qs failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_den, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_den failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_p, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_p failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_delz, kSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_delz failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_rain, ijSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_rain failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_rainncv, ijSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_rainncv failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_sr, ijSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_sr failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_snow, ijSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_snow failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_snowncv, ijSize);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_snowncv failed: %s\n", cudaGetErrorString(err)); return -1; }

    err = cudaMalloc((void **)&d_retvals, sizeof(float) * 16);
    if (err != cudaSuccess) { fprintf(stderr, "cudaMalloc d_retvals failed: %s\n", cudaGetErrorString(err)); return -1; }

    cudaMemcpy(d_th, h_th, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_pii, h_pii, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_q, h_q, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_qc, h_qc, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_qi, h_qi, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_qr, h_qr, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_qs, h_qs, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_den, h_den, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_p, h_p, kSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_delz, h_delz, kSize, cudaMemcpyHostToDevice);

    cudaMemcpy(d_rain, h_rain, ijSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_rainncv, h_rainncv, ijSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_sr, h_sr, ijSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_snow, h_snow, ijSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_snowncv, h_snowncv, ijSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_retvals, h_retvals, sizeof(float) * 16, cudaMemcpyHostToDevice);

    int ids = 1, ide = 1, jds = 1, jde = 1, kds = 1, kde = K;
    int ims = 1, ime = 1, jms = 1, jme = 1, kms = 1, kme = K;
    int ips = 1, ipe = 1, jps = 1, jpe = 1, kps = 1, kpe = K;

    dim3 block(1, 1, 1);
    dim3 grid(1, 1, 1);

    wsm5_gpu<<<grid, block>>>(
        d_th, d_pii, d_q, d_qc, d_qi, d_qr, d_qs,
        d_den, d_p, d_delz,
        d_rain, d_rainncv, d_sr, d_snow, d_snowncv,
        delt, d_retvals,
        ids, ide, jds, jde, kds, kde,
        ims, ime, jms, jme, kms, kme,
        ips, ipe, jps, jpe, kps, kpe
    );

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_th, d_th, kSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_q, d_q, kSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_qc, d_qc, kSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_qi, d_qi, kSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_qr, d_qr, kSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_qs, d_qs, kSize, cudaMemcpyDeviceToHost);

    cudaMemcpy(h_rain, d_rain, ijSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_rainncv, d_rainncv, ijSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_sr, d_sr, ijSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_snow, d_snow, ijSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_snowncv, d_snowncv, ijSize, cudaMemcpyDeviceToHost);

    printf("wsm5_gpu finished\n");
    printf("K=%d delt=%f\n", K, delt);

    int printK = K < 8 ? K : 8;
    for (int k = 0; k < printK; k++) {
        printf("k=%d th=%f q=%e qc=%e qi=%e qr=%e qs=%e\n",
               k, h_th[k], h_q[k], h_qc[k], h_qi[k], h_qr[k], h_qs[k]);
    }

    printf("rain=%f rainncv=%f sr=%f snow=%f snowncv=%f\n",
           h_rain[0], h_rainncv[0], h_sr[0], h_snow[0], h_snowncv[0]);

    cudaFree(d_th);
    cudaFree(d_pii);
    cudaFree(d_q);
    cudaFree(d_qc);
    cudaFree(d_qi);
    cudaFree(d_qr);
    cudaFree(d_qs);
    cudaFree(d_den);
    cudaFree(d_p);
    cudaFree(d_delz);
    cudaFree(d_rain);
    cudaFree(d_rainncv);
    cudaFree(d_sr);
    cudaFree(d_snow);
    cudaFree(d_snowncv);
    cudaFree(d_retvals);

    free(h_th);
    free(h_pii);
    free(h_q);
    free(h_qc);
    free(h_qi);
    free(h_qr);
    free(h_qs);
    free(h_den);
    free(h_p);
    free(h_delz);
    free(h_rain);
    free(h_rainncv);
    free(h_sr);
    free(h_snow);
    free(h_snowncv);
    free(h_retvals);

    return 0;
}