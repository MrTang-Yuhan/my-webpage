// Auto-generated CUDA kernel file: dinitcs
// Extracted from: lonestargpu-2.0/include/component.h
// Original line: 89

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: dinitcs (line 89)
__global__ void dinitcs(unsigned nelements, unsigned *complen, unsigned *ele2comp) {

	unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
	if (id < nelements) {
		//elements[id] 	= id;
		complen[id]	= 1;
		ele2comp[id]	= id;
	}

}
