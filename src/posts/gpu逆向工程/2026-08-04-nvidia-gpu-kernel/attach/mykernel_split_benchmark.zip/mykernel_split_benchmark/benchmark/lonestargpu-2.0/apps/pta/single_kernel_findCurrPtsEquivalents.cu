#include "pta_single_kernel_test_common.cuh"

__device__ uint equalPtsLite(uint index1, uint index2) {
    uint b1 = graphGet(index1 + threadIdx.x);
    uint b2 = graphGet(index2 + threadIdx.x);

    uint same = __all_sync(0xFFFFFFFF, b1 == b2);
    return same;
}

__global__ void findCurrPtsEquivalents() {
    uint warp = blockIdx.x * blockDim.y + threadIdx.y;
    uint nwarps = gridDim.x * blockDim.y;

    uint to = __numKeys__;

    for (uint i = warp; i < to; i += nwarps) {
        uint var1 = __val__[i];
        if (var1 == NIL) continue;

        uint var1Head = getCurrDiffPtsHeadIndex(var1);
        uint chosen = var1Head;

        uint start = __key__[i];

        for (uint j = start; j < i; j++) {
            uint var2 = __val__[j];
            if (var2 == NIL) continue;

            uint var2Head = getCurrDiffPtsHeadIndex(var2);

            if (equalPtsLite(var1Head, var2Head)) {
                chosen = var2Head;
                break;
            }
        }

        if (threadIdx.x == 0) {
            __currPtsHead__[var1] = chosen;
        }
    }

    if (isFirstThreadOfBlock()) {
        __worklistIndex0__ = 0;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint e0[ELEMENT_WIDTH], e1[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) {
        e0[i] = 0;
        e1[i] = 0;
    }

    e0[0] = 0x3;
    e0[BASE] = 0;
    e0[NEXT] = NIL;

    e1[0] = 0x3;
    e1[BASE] = 0;
    e1[NEXT] = NIL;

    cudaMemcpy(env.d_graph + TEST_CURR_DIFF_PTS_START + 1 * ELEMENT_WIDTH,
               e0, sizeof(e0), cudaMemcpyHostToDevice);
    cudaMemcpy(env.d_graph + TEST_CURR_DIFF_PTS_START + 2 * ELEMENT_WIDTH,
               e1, sizeof(e1), cudaMemcpyHostToDevice);

    uint key[MAX_TEST_VARS], val[MAX_TEST_VARS];
    for (uint i = 0; i < MAX_TEST_VARS; i++) {
        key[i] = 0;
        val[i] = NIL;
    }

    key[0] = 0;
    val[0] = 1;

    key[1] = 0;
    val[1] = 2;

    cudaMemcpy(env.d_key, key, sizeof(key), cudaMemcpyHostToDevice);
    cudaMemcpy(env.d_val, val, sizeof(val), cudaMemcpyHostToDevice);

    uint numKeys = 2;
    cudaMemcpyToSymbol(__numKeys__, &numKeys, sizeof(uint));

    dim3 block(32, 4);
    dim3 grid(1);

    findCurrPtsEquivalents<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "findCurrPtsEquivalents launch failed");
    checkCuda(cudaDeviceSynchronize(), "findCurrPtsEquivalents execution failed");

    uint out[8];
    cudaMemcpy(out, env.d_currPtsHead, sizeof(out), cudaMemcpyDeviceToHost);

    printf("findCurrPtsEquivalents finished\n");
    printf("currPtsHead[1]=%u\n", out[1]);
    printf("currPtsHead[2]=%u\n", out[2]);

    destroyPTATestEnv(env);
    return 0;
}