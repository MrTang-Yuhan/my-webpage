#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <cuda.h>

// ===== Macro Definitions =====
#define MAX_THREADS_PER_BLOCK 512

// ===== Data Structure =====
typedef struct {
    int starting;
    int no_of_edges;
} Node;

// ===== Kernel =====
__global__ void Kernel(Node* g_graph_nodes, int* g_graph_edges, bool* g_graph_mask,
                       bool* g_updating_graph_mask, bool *g_graph_visited, int* g_cost,
                       int no_of_nodes) {
    int tid = blockIdx.x * MAX_THREADS_PER_BLOCK + threadIdx.x;
    if (tid < no_of_nodes && g_graph_mask[tid]) {
        g_graph_mask[tid] = false;
        for (int i = g_graph_nodes[tid].starting;
             i < (g_graph_nodes[tid].no_of_edges + g_graph_nodes[tid].starting);
             i++) {
            int id = g_graph_edges[i];
            if (!g_graph_visited[id]) {
                g_cost[id] = g_cost[tid] + 1;
                g_updating_graph_mask[id] = true;
            }
        }
    }
}

// ===== Main for Test =====
int main() {
    // ----------------------------
    // 构造一个简单图:
    // 0 -> 1, 2
    // 1 -> 3
    // 2 -> 3
    // 3 -> 无
    // ----------------------------
    const int no_of_nodes = 4;
    const int no_of_edges = 4;

    Node h_graph_nodes[no_of_nodes];
    int h_graph_edges[no_of_edges];
    bool h_graph_mask[no_of_nodes];
    bool h_updating_graph_mask[no_of_nodes];
    bool h_graph_visited[no_of_nodes];
    int h_cost[no_of_nodes];

    // 邻接表边数组
    // 节点 0: edges[0], edges[1] -> 1, 2
    // 节点 1: edges[2] -> 3
    // 节点 2: edges[3] -> 3
    // 节点 3: none
    h_graph_nodes[0].starting = 0;
    h_graph_nodes[0].no_of_edges = 2;

    h_graph_nodes[1].starting = 2;
    h_graph_nodes[1].no_of_edges = 1;

    h_graph_nodes[2].starting = 3;
    h_graph_nodes[2].no_of_edges = 1;

    h_graph_nodes[3].starting = 4;
    h_graph_nodes[3].no_of_edges = 0;

    h_graph_edges[0] = 1;
    h_graph_edges[1] = 2;
    h_graph_edges[2] = 3;
    h_graph_edges[3] = 3;

    // BFS 初始化：从节点 0 开始
    for (int i = 0; i < no_of_nodes; i++) {
        h_graph_mask[i] = false;
        h_updating_graph_mask[i] = false;
        h_graph_visited[i] = false;
        h_cost[i] = -1;
    }
    h_graph_mask[0] = true;
    h_graph_visited[0] = true;
    h_cost[0] = 0;

    // ----------------------------
    // 分配 GPU 内存
    // ----------------------------
    Node *d_graph_nodes;
    int *d_graph_edges;
    bool *d_graph_mask, *d_updating_graph_mask, *d_graph_visited;
    int *d_cost;

    cudaMalloc((void**)&d_graph_nodes, sizeof(Node) * no_of_nodes);
    cudaMalloc((void**)&d_graph_edges, sizeof(int) * no_of_edges);
    cudaMalloc((void**)&d_graph_mask, sizeof(bool) * no_of_nodes);
    cudaMalloc((void**)&d_updating_graph_mask, sizeof(bool) * no_of_nodes);
    cudaMalloc((void**)&d_graph_visited, sizeof(bool) * no_of_nodes);
    cudaMalloc((void**)&d_cost, sizeof(int) * no_of_nodes);

    // 拷贝到 GPU
    cudaMemcpy(d_graph_nodes, h_graph_nodes, sizeof(Node) * no_of_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_graph_edges, h_graph_edges, sizeof(int) * no_of_edges, cudaMemcpyHostToDevice);
    cudaMemcpy(d_graph_mask, h_graph_mask, sizeof(bool) * no_of_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_updating_graph_mask, h_updating_graph_mask, sizeof(bool) * no_of_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_graph_visited, h_graph_visited, sizeof(bool) * no_of_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_cost, h_cost, sizeof(int) * no_of_nodes, cudaMemcpyHostToDevice);

    // ----------------------------
    // 启动 kernel
    // ----------------------------
    int num_of_blocks = (no_of_nodes + MAX_THREADS_PER_BLOCK - 1) / MAX_THREADS_PER_BLOCK;
    Kernel<<<num_of_blocks, MAX_THREADS_PER_BLOCK>>>(
        d_graph_nodes, d_graph_edges, d_graph_mask,
        d_updating_graph_mask, d_graph_visited, d_cost,
        no_of_nodes
    );

    cudaDeviceSynchronize();

    // ----------------------------
    // 拷贝结果回主机
    // ----------------------------
    cudaMemcpy(h_graph_mask, d_graph_mask, sizeof(bool) * no_of_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_updating_graph_mask, d_updating_graph_mask, sizeof(bool) * no_of_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_graph_visited, d_graph_visited, sizeof(bool) * no_of_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_cost, d_cost, sizeof(int) * no_of_nodes, cudaMemcpyDeviceToHost);

    // ----------------------------
    // 打印结果
    // ----------------------------
    printf("Results after Kernel execution:\n");
    for (int i = 0; i < no_of_nodes; i++) {
        printf("Node %d: cost=%d, mask=%d, updating_mask=%d, visited=%d\n",
               i, h_cost[i], h_graph_mask[i], h_updating_graph_mask[i], h_graph_visited[i]);
    }

    // ----------------------------
    // 释放资源
    // ----------------------------
    cudaFree(d_graph_nodes);
    cudaFree(d_graph_edges);
    cudaFree(d_graph_mask);
    cudaFree(d_updating_graph_mask);
    cudaFree(d_graph_visited);
    cudaFree(d_cost);

    return 0;
}