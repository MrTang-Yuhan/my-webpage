// Auto-generated CUDA kernel file: needle_cuda_shared_1
// Extracted from: rodinia/2.0-ft/nw/needle_kernel.cu
// Original line: 26

// ===== Includes =====
#include "needle.h"
#include <stdio.h>

// ===== Macro Definitions =====
#define SDATA( index)      CUT_BANK_CHECKER(sdata, index)  // from line 6

// ===== Device Functions =====
// Function: maximum (line 8)
__device__ __host__ int 
maximum( int a,
		 int b,
		 int c) {


int k;
if( a <= b )  // [参数: a, b]
k = b;  // [参数: b]
else 
k = a;  // [参数: a]

if( k <=c )  // [参数: c]
return(c);  // [参数: c]
else
return(k);


}

// ===== Kernel =====
// Kernel: needle_cuda_shared_1 (line 26)
__global__ void
needle_cuda_shared_1(  int* referrence,
			  int* matrix_cuda, 
			  int* matrix_cuda_out, 
			  int cols,
			  int penalty,
			  int i,
			  int block_width) {

  int bx = blockIdx.x;  // [参数: i]
  int tx = threadIdx.x;  // [参数: i]

  int b_index_x = bx;  // [参数: i]
  int b_index_y = i - 1 - bx;  // [参数: i]

  int index   = cols * BLOCK_SIZE * b_index_y + BLOCK_SIZE * b_index_x + tx + ( cols + 1 );  // [参数: cols, i]
  int index_n   = cols * BLOCK_SIZE * b_index_y + BLOCK_SIZE * b_index_x + tx + ( 1 );  // [参数: cols, i]
  int index_w   = cols * BLOCK_SIZE * b_index_y + BLOCK_SIZE * b_index_x + ( cols );  // [参数: cols, i]
  int index_nw =  cols * BLOCK_SIZE * b_index_y + BLOCK_SIZE * b_index_x;  // [参数: cols, i]

  __shared__  int temp[BLOCK_SIZE+1][BLOCK_SIZE+1];  // [参数: i]
  __shared__  int ref[BLOCK_SIZE][BLOCK_SIZE];  // [参数: i]

   if (tx == 0)  // [参数: i]
		  temp[tx][0] = matrix_cuda[index_nw];  // [参数: matrix_cuda, i]


  for ( int ty = 0 ; ty < BLOCK_SIZE ; ty++)  // [参数: i]
  ref[ty][tx] = referrence[index + cols * ty];  // [参数: referrence, cols, i]

  __syncthreads();

  temp[tx + 1][0] = matrix_cuda[index_w + cols * tx];  // [参数: matrix_cuda, cols, i]

  __syncthreads();

  temp[0][tx + 1] = matrix_cuda[index_n];  // [参数: matrix_cuda, i]
  
  __syncthreads();
  

  for( int m = 0 ; m < BLOCK_SIZE ; m++){  // [参数: i]
   
	  if ( tx <= m ){  // [参数: i]

		  int t_index_x =  tx + 1;  // [参数: i]
		  int t_index_y =  m - tx + 1;  // [参数: i]

          temp[t_index_y][t_index_x] = maximum( temp[t_index_y-1][t_index_x-1] + ref[t_index_y-1][t_index_x-1],  // [参数: i]
		                                        temp[t_index_y][t_index_x-1]  - penalty,   // [参数: penalty, i]
												temp[t_index_y-1][t_index_x]  - penalty);  // [参数: penalty, i]

		  
	  
	  }

	  __syncthreads();
  
    }

 for( int m = BLOCK_SIZE - 2 ; m >=0 ; m--){  // [参数: i]
   
	  if ( tx <= m){  // [参数: i]

		  int t_index_x =  tx + BLOCK_SIZE - m ;  // [参数: i]
		  int t_index_y =  BLOCK_SIZE - tx;  // [参数: i]

          temp[t_index_y][t_index_x] = maximum( temp[t_index_y-1][t_index_x-1] + ref[t_index_y-1][t_index_x-1],  // [参数: i]
		                                        temp[t_index_y][t_index_x-1]  - penalty,   // [参数: penalty, i]
												temp[t_index_y-1][t_index_x]  - penalty);  // [参数: penalty, i]
	   
	  }

	  __syncthreads();
  }

  for ( int ty = 0 ; ty < BLOCK_SIZE ; ty++)  // [参数: i]
  matrix_cuda[index + ty * cols] = temp[ty+1][tx+1];  // [参数: matrix_cuda, cols, i]


}

// 在 single_kernel_needle_cuda_shared_1.cu 末尾追加

int main() {
    // ----------------------------
    // 参数设置
    // ----------------------------
    const int max_rows = 128;
    const int max_cols = 128;
    const int penalty = 10;
    const int block_width = max_cols / BLOCK_SIZE;
    
    // 第一阶段：处理对角线上半部分（i 从 1 到 block_width）
    const int i = 2;  // 测试第 2 轮迭代
    const int num_blocks = i;  // 该轮处理 i 个块

    // ----------------------------
    // 初始化数据
    // ----------------------------
    int total_size = (max_rows + 1) * (max_cols + 1);
    
    int *h_reference = (int*)malloc(total_size * sizeof(int));
    int *h_matrix = (int*)malloc(total_size * sizeof(int));
    
    // 初始化 reference（相似度矩阵）
    for (int j = 0; j < total_size; j++) {
        h_reference[j] = (rand() % 3) - 1;  // -1, 0, 1
    }
    
    // 初始化 matrix（DP 表，第一行/列为边界）
    memset(h_matrix, 0, total_size * sizeof(int));
    for (int j = 0; j <= max_cols; j++) {
        h_matrix[j] = -j * penalty;  // 第一行
    }
    for (int j = 0; j <= max_rows; j++) {
        h_matrix[j * (max_cols + 1)] = -j * penalty;  // 第一列
    }

    // ----------------------------
    // 拷贝到 GPU
    // ----------------------------
    int *d_reference, *d_matrix, *d_matrix_out;
    cudaMalloc(&d_reference, total_size * sizeof(int));
    cudaMalloc(&d_matrix, total_size * sizeof(int));
    cudaMalloc(&d_matrix_out, total_size * sizeof(int));
    
    cudaMemcpy(d_reference, h_reference, total_size * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_matrix, h_matrix, total_size * sizeof(int), cudaMemcpyHostToDevice);

    // ----------------------------
    // 启动 kernel
    // ----------------------------
    printf("Running needle_cuda_shared_1:\n");
    printf("  Matrix: %d x %d\n", max_rows, max_cols);
    printf("  Iteration: %d (processing %d blocks)\n", i, num_blocks);
    printf("  Penalty: %d\n", penalty);

    needle_cuda_shared_1<<<num_blocks, BLOCK_SIZE>>>(
        d_reference, d_matrix, d_matrix_out,
        max_cols + 1, penalty, i, block_width
    );

    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));

    // ----------------------------
    // 拷回结果
    // ----------------------------
    cudaMemcpy(h_matrix, d_matrix, total_size * sizeof(int), cudaMemcpyDeviceToHost);

    // 验证：检查处理过的块区域
    printf("\nSample DP values (block 0, starting at row 0, col 16):\n");
    int base_row = 1;
    int base_col = BLOCK_SIZE + 1;
    for (int r = 0; r < 3; r++) {
        for (int c = 0; c < 3; c++) {
            int idx = (base_row + r) * (max_cols + 1) + (base_col + c);
            printf("%4d ", h_matrix[idx]);
        }
        printf("\n");
    }

    // ----------------------------
    // 清理
    // ----------------------------
    cudaFree(d_reference);
    cudaFree(d_matrix);
    cudaFree(d_matrix_out);
    free(h_reference);
    free(h_matrix);

    return err == cudaSuccess ? 0 : 1;
}