// Standalone version for single_kernel_refine.cu

#include <cuda.h>
#include <cuda_runtime.h>
#include <cub/cub.cuh>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <limits.h>

typedef unsigned int uint;
#ifndef debug
#define debug 0
#endif

#include "cutil_subset.h"
#include "sharedptr.h"
#include "dmr.h"
#include "geomprim.h"
#include "gbar.cuh"
#include "worklistc.h"

#define BCLEN 1024
#define CAVLEN 256
#define LOADCG(x) cub::ThreadLoad<cub::LOAD_CG>((x))
#define STORECG(x, y) cub::ThreadStore<cub::STORE_CG>((x), (y))

// ===== Device helpers =====
__device__ void dump_mesh_element(Mesh &mesh, uint3 &ele, int element) {
    if (IS_SEGMENT(ele)) {
        printf("[ %.12f %.12f %.12f %.12f %d]\n",
               mesh.nodex[ele.x], mesh.nodey[ele.x],
               mesh.nodex[ele.y], mesh.nodey[ele.y], element);
    } else {
        printf("[ %.12f %.12f %.12f %.12f %.12f %.12f %d]\n",
               mesh.nodex[ele.x], mesh.nodey[ele.x],
               mesh.nodex[ele.y], mesh.nodey[ele.y],
               mesh.nodex[ele.z], mesh.nodey[ele.z], element);
    }
}

__device__ void dump_mesh_element(Mesh &mesh, int element) {
    dump_mesh_element(mesh, mesh.elements[element], element);
}

__device__ void add_to_cavity(uint cavity[], uint &cavlen, int element) {
    for (uint i = 0; i < cavlen; i++)
        if (cavity[i] == (uint)element)
            return;
    cavity[cavlen++] = element;
}

__device__ void add_to_boundary(uint boundary[], uint &boundarylen,
                                uint sn1, uint sn2, uint src, uint dst) {
    for (uint i = 0; i < boundarylen; i += 4) {
        if ((sn1 == boundary[i] && sn2 == boundary[i + 1]) ||
            (sn1 == boundary[i + 1] && sn2 == boundary[i])) {
            return;
        }
    }

    boundary[boundarylen++] = sn1;
    boundary[boundarylen++] = sn2;
    boundary[boundarylen++] = src;
    boundary[boundarylen++] = dst;
}

__device__ unsigned add_node(Mesh &mesh, FORD x, FORD y, uint ndx) {
    assert(ndx < mesh.maxnnodes);
    mesh.nodex[ndx] = x;
    mesh.nodey[ndx] = y;
    return ndx;
}

__device__ uint add_segment(Mesh &mesh, uint n1, uint n2, uint ndx) {
    uint3 ele;
    ele.x = n1; ele.y = n2; ele.z = INVALIDID;

    assert(ndx < mesh.maxnelements);

    mesh.isbad[ndx] = false;
    mesh.isdel[ndx] = false;
    mesh.elements[ndx] = ele;
    mesh.neighbours[ndx].x = mesh.neighbours[ndx].y = mesh.neighbours[ndx].z = INVALIDID;

    return ndx;
}

__device__ uint add_triangle(Mesh &mesh, uint n1, uint n2, uint n3, uint nb1, uint oldt, uint ndx) {
    uint3 ele;
    if (counterclockwise(mesh.nodex[n1], mesh.nodey[n1],
                         mesh.nodex[n2], mesh.nodey[n2],
                         mesh.nodex[n3], mesh.nodey[n3]) > 0) {
        ele.x = n1; ele.y = n2; ele.z = n3;
    } else {
        ele.x = n3; ele.y = n2; ele.z = n1;
    }

    assert(ndx < mesh.maxnelements);

    mesh.isbad[ndx] = false;
    mesh.isdel[ndx] = false;
    mesh.elements[ndx] = ele;
    mesh.neighbours[ndx].x = nb1;
    mesh.neighbours[ndx].y = mesh.neighbours[ndx].z = INVALIDID;

    uint3 *nb = &mesh.neighbours[nb1];

    if (mesh.neighbours[nb1].x == oldt)
        nb->x = ndx;
    else if (mesh.neighbours[nb1].y == oldt)
        nb->y = ndx;
    else {
        assert(mesh.neighbours[nb1].z == oldt);
        nb->z = ndx;
    }

    return ndx;
}

__device__ bool adjacent(uint3 &elem1, uint3 &elem2) {
    int sc = 0;
    if (elem1.x == elem2.x || elem1.x == elem2.y || elem1.x == elem2.z) sc++;
    if (elem1.y == elem2.x || elem1.y == elem2.y || elem1.y == elem2.z) sc++;
    if (!IS_SEGMENT(elem1) && (elem1.z == elem2.x || elem1.z == elem2.y || elem1.z == elem2.z)) sc++;
    return sc == 2;
}

__device__ void find_shared_edge(uint3 &elem1, uint3 &elem2, uint se[2]) {
    int sc = 0;
    if (elem1.x == elem2.x || elem1.x == elem2.y || elem1.x == elem2.z) se[sc++] = elem1.x;
    if (elem1.y == elem2.x || elem1.y == elem2.y || elem1.y == elem2.z) se[sc++] = elem1.y;
    if (!IS_SEGMENT(elem1) && (elem1.z == elem2.x || elem1.z == elem2.y || elem1.z == elem2.z)) se[sc++] = elem1.z;

    assert(sc == 2);
    assert(se[0] != INVALIDID);
    assert(se[1] != INVALIDID);
}

__device__ bool encroached(Mesh &mesh, int element, uint3 &celement, FORD centerx, FORD centery, bool &is_seg) {
    if (element == (int)INVALIDID)
        return false;

    assert(!mesh.isdel[element]);

    uint3 ele = LOADCG(&mesh.elements[element]);

    if (IS_SEGMENT(ele)) {
        FORD cx, cy, radsqr;
        uint nsp;

        is_seg = true;
        nsp = (celement.x == ele.x) ? ((celement.y == ele.y) ? celement.z : celement.y) : celement.x;

        if ((counterclockwise(mesh.nodex[ele.x], mesh.nodey[ele.x],
                              mesh.nodex[ele.y], mesh.nodey[ele.y],
                              mesh.nodex[nsp], mesh.nodey[nsp]) > 0) !=
            (counterclockwise(mesh.nodex[ele.x], mesh.nodey[ele.x],
                              mesh.nodex[ele.y], mesh.nodey[ele.y],
                              centerx, centery) > 0))
            return true;

        cx = (mesh.nodex[ele.x] + mesh.nodex[ele.y]) / 2;
        cy = (mesh.nodey[ele.x] + mesh.nodey[ele.y]) / 2;
        radsqr = distanceSquare(cx, cy, mesh.nodex[ele.x], mesh.nodey[ele.x]);

        return distanceSquare(centerx, centery, cx, cy) < radsqr;
    } else {
        return gincircle(mesh.nodex[ele.x], mesh.nodey[ele.x],
                         mesh.nodex[ele.y], mesh.nodey[ele.y],
                         mesh.nodex[ele.z], mesh.nodey[ele.z],
                         centerx, centery) > 0.0;
    }
}

__device__ bool build_cavity(Mesh &mesh, uint cavity[], uint &cavlen, int max_cavity,
                             uint boundary[], uint &boundarylen, FORD &cx, FORD &cy) {
    int ce = 0;
    uint3 ele = LOADCG(&mesh.elements[cavity[0]]);
    bool is_seg = false;

    if (IS_SEGMENT(ele)) {
        cx = (mesh.nodex[ele.x] + mesh.nodex[ele.y]) / 2;
        cy = (mesh.nodey[ele.x] + mesh.nodey[ele.y]) / 2;
    } else {
        circumcenter(mesh.nodex[ele.x], mesh.nodey[ele.x],
                     mesh.nodex[ele.y], mesh.nodey[ele.y],
                     mesh.nodex[ele.z], mesh.nodey[ele.z],
                     cx, cy);
    }

    while (ce < (int)cavlen) {
        assert(cavlen < (uint)max_cavity);
        assert(!mesh.isdel[cavity[ce]]);

        uint3 neighbours = LOADCG(&mesh.neighbours[cavity[ce]]);
        uint neighb[3] = {neighbours.x, neighbours.y, neighbours.z};

        for (int i = 0; i < 3; i++) {
            if (neighb[i] == cavity[0]) continue;
            if (neighb[i] == INVALIDID) continue;

            is_seg = false;
            if (!(IS_SEGMENT(ele) && IS_SEGMENT(LOADCG(&mesh.elements[neighb[i]]))) &&
                encroached(mesh, neighb[i], ele, cx, cy, is_seg)) {
                if (!is_seg) {
                    add_to_cavity(cavity, cavlen, neighb[i]);
                } else {
                    assert(!IS_SEGMENT(ele));
                    cavity[0] = neighb[i];
                    cavlen = 1;
                    boundarylen = 0;
                    return false;
                }
            } else {
                uint se[2];
                assert(boundarylen < BCLEN);
                find_shared_edge(mesh.elements[cavity[ce]], mesh.elements[neighb[i]], se);
                add_to_boundary(boundary, boundarylen, se[0], se[1], neighb[i], cavity[ce]);
            }
        }
        ce++;
    }

    return true;
}

__device__ void addneighbour(Mesh &mesh, uint3 &neigh, uint elem) {
    if (neigh.x == elem || neigh.y == elem || neigh.z == elem) return;

    assert(neigh.x == INVALIDID || neigh.y == INVALIDID || neigh.z == INVALIDID);

    if (neigh.x == INVALIDID) { neigh.x = elem; return; }
    if (neigh.y == INVALIDID) { neigh.y = elem; return; }
    if (neigh.z == INVALIDID) { neigh.z = elem; return; }
}

__device__ void setup_neighbours(Mesh &mesh, uint start, uint end) {
    for (uint i = start; i < end; i++) {
        uint3 &neigh = mesh.neighbours[i];
        for (uint j = i + 1; j < end; j++) {
            if (adjacent(mesh.elements[i], mesh.elements[j])) {
                addneighbour(mesh, neigh, j);
                addneighbour(mesh, mesh.neighbours[j], i);
            }
        }
    }
}

__device__ uint opposite(Mesh &mesh, uint element) {
    bool obtuse = false;
    int obNode = INVALIDID;
    uint3 el = mesh.elements[element];

    if (IS_SEGMENT(el))
        return element;

    if (angleOB(mesh, el.x, el.y, el.z)) {
        obtuse = true; obNode = el.z;
    } else if (angleOB(mesh, el.z, el.x, el.y)) {
        obtuse = true; obNode = el.y;
    } else if (angleOB(mesh, el.y, el.z, el.x)) {
        obtuse = true; obNode = el.x;
    }

    if (obtuse) {
        uint se_nodes[2];
        uint nobneigh;
        uint3 neigh = mesh.neighbours[element];

        assert(neigh.x != INVALIDID && neigh.y != INVALIDID && neigh.z != INVALIDID);

        nobneigh = neigh.x;
        find_shared_edge(el, mesh.elements[neigh.x], se_nodes);
        if (se_nodes[0] == (uint)obNode || se_nodes[1] == (uint)obNode) {
            nobneigh = neigh.y;
            find_shared_edge(el, mesh.elements[neigh.y], se_nodes);
            if (se_nodes[0] == (uint)obNode || se_nodes[1] == (uint)obNode) {
                nobneigh = neigh.z;
            }
        }

        return nobneigh;
    }

    return element;
}

// ===== Kernel =====
__global__ void refine(Mesh mesh, int debg, uint *nnodes, uint *nelements,
                       GlobalBarrier gb, Worklist2 wl, Worklist2 owl) {
    int id = threadIdx.x + blockDim.x * blockIdx.x;
    int threads = blockDim.x * gridDim.x;
    int ele, eleit, haselem;
    uint cavity[CAVLEN], nc = 0;
    uint boundary[BCLEN], bc = 0;
    uint ulimit = ((*wl.dindex + threads - 1) / threads) * threads;
    bool repush = false;
    const int perthread = (threads == 0) ? 0 : (ulimit / threads);
    int stage = 0;
    int x = 0;

    for (eleit = id * perthread; eleit < (id * perthread + perthread) && eleit < (int)ulimit; eleit++, x++) {
        haselem = wl.pop_id(eleit, ele);

        FORD cx, cy;
        nc = 0;
        bc = 0;
        repush = false;
        stage = 0;

        if (haselem && ele < (int)mesh.nelements && mesh.isbad[ele] && !mesh.isdel[ele]) {
            cavity[nc++] = ele;

            uint oldcav;
            do {
                oldcav = cavity[0];
                cavity[0] = opposite(mesh, ele);
            } while (cavity[0] != oldcav);

            if (!build_cavity(mesh, cavity, nc, CAVLEN, boundary, bc, cx, cy))
                build_cavity(mesh, cavity, nc, CAVLEN, boundary, bc, cx, cy);

            for (uint i = 0; i < nc; i++)
                STORECG(&mesh.owners[cavity[i]], id);

            for (uint i = 0; i < bc; i += 4)
                STORECG(&mesh.owners[boundary[i + 2]], id);

            stage = 1;
        }

        gb.Sync();

        if (stage == 1) {
            for (uint i = 0; i < nc; i++) {
                if (LOADCG(&mesh.owners[cavity[i]]) != id)
                    atomicMin((int *)&mesh.owners[cavity[i]], id);
            }

            for (uint i = 0; i < bc; i += 4) {
                if (LOADCG(&mesh.owners[boundary[i + 2]]) != id)
                    atomicMin((int *)&mesh.owners[boundary[i + 2]], id);
            }

            stage = 2;
        }

        gb.Sync();

        int elems_added = 0;
        if (stage == 2) {
            uint i;
            for (i = 0; i < nc; i++) {
                if (LOADCG(&mesh.owners[cavity[i]]) != id) {
                    repush = true;
                    break;
                }
            }

            if (!repush) {
                for (i = 0; i < bc; i += 4) {
                    if (LOADCG(&mesh.owners[boundary[i + 2]]) != id) {
                        repush = true;
                        break;
                    }
                }
            }

            if (!repush) {
                stage = 3;
                elems_added = (bc >> 2) + (IS_SEGMENT(mesh.elements[cavity[0]]) ? 2 : 0);
            }
        }

        if (stage == 3) {
            uint cnode = add_node(mesh, cx, cy, atomicAdd(nnodes, 1));
            uint nelements_added = elems_added;
            uint oldelements = atomicAdd(nelements, nelements_added);
            uint newelemndx = oldelements;

            if (IS_SEGMENT(mesh.elements[cavity[0]])) {
                add_segment(mesh, mesh.elements[cavity[0]].x, cnode, newelemndx++);
                add_segment(mesh, cnode, mesh.elements[cavity[0]].y, newelemndx++);
            }

            for (uint i = 0; i < bc; i += 4) {
                add_triangle(mesh, boundary[i], boundary[i + 1], cnode,
                             boundary[i + 2], boundary[i + 3], newelemndx++);
            }

            setup_neighbours(mesh, oldelements, newelemndx);

            repush = true;
            for (uint i = 0; i < nc; i++) {
                mesh.isdel[cavity[i]] = true;
                if (cavity[i] == (uint)ele) repush = false;
            }
        }

        if (repush) owl.push(ele);
        gb.Sync();
    }
}

// ===== Host helper =====
static void build_refine_test_mesh(ShMesh &mesh) {
    mesh.maxnnodes = 16;
    mesh.maxnelements = 16;

    mesh.nnodes = 3;
    mesh.nsegments = 3;
    mesh.ntriangles = 1;
    mesh.nelements = 4;

    mesh.nodex.alloc(mesh.maxnnodes);
    mesh.nodey.alloc(mesh.maxnnodes);
    mesh.elements.alloc(mesh.maxnelements);
    mesh.neighbours.alloc(mesh.maxnelements);
    mesh.isdel.alloc(mesh.maxnelements);
    mesh.isbad.alloc(mesh.maxnelements);
    mesh.owners.alloc(mesh.maxnelements);

    FORD *x = mesh.nodex.cpu_wr_ptr(true);
    FORD *y = mesh.nodey.cpu_wr_ptr(true);
    uint3 *e = mesh.elements.cpu_wr_ptr(true);
    uint3 *n = mesh.neighbours.cpu_wr_ptr(true);
    bool *isdel = mesh.isdel.cpu_wr_ptr(true);
    bool *isbad = mesh.isbad.cpu_wr_ptr(true);
    int *owners = mesh.owners.cpu_wr_ptr(true);

    // 3 个点，一个瘦三角形
    x[0] = 0.0; y[0] = 0.0;
    x[1] = 1.0; y[1] = 0.0;
    x[2] = 0.5; y[2] = 10.0;

    // 0,1,2 是边界 segment
    e[0].x = 0; e[0].y = 1; e[0].z = INVALIDID;
    e[1].x = 1; e[1].y = 2; e[1].z = INVALIDID;
    e[2].x = 2; e[2].y = 0; e[2].z = INVALIDID;
    // 3 是三角形
    e[3].x = 0; e[3].y = 1; e[3].z = 2;

    // 段各自只有这个三角形作邻居
    n[0].x = 3; n[0].y = INVALIDID; n[0].z = INVALIDID;
    n[1].x = 3; n[1].y = INVALIDID; n[1].z = INVALIDID;
    n[2].x = 3; n[2].y = INVALIDID; n[2].z = INVALIDID;
    // 三角形的三个邻居是三条边界段
    n[3].x = 0; n[3].y = 1; n[3].z = 2;

    for (unsigned i = 0; i < mesh.maxnelements; i++) {
        isdel[i] = false;
        isbad[i] = false;
        owners[i] = INT_MAX;
    }

    // 仅将三角形标记为 bad
    isbad[3] = true;
}

int main() {
    ShMesh mesh;
    build_refine_test_mesh(mesh);

    Mesh gmesh(mesh);

    Shared<uint> nnodes(1), nelements(1);
    *nnodes.cpu_wr_ptr(true) = mesh.nnodes;
    *nelements.cpu_wr_ptr(true) = mesh.nelements;

    Worklist2 wl(mesh.maxnelements);
    Worklist2 owl(mesh.maxnelements);

    // host 直接初始化 worklist：把 bad triangle(3) 塞进去
    int item = 3;
    int one = 1;
    CUDA_SAFE_CALL(cudaMemcpy(wl.dwl, &item, sizeof(int), cudaMemcpyHostToDevice));
    CUDA_SAFE_CALL(cudaMemcpy(wl.dindex, &one, sizeof(int), cudaMemcpyHostToDevice));
    owl.reset();

    GlobalBarrierLifetime gbl;
    gbl.Setup(1);

    int block = 64;
    int grid = 1;

    refine<<<grid, block>>>(gmesh, 0, nnodes.gpu_wr_ptr(), nelements.gpu_wr_ptr(), gbl, wl, owl);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    mesh.nnodes = *nnodes.cpu_rd_ptr();
    mesh.nelements = *nelements.cpu_rd_ptr();

    uint3 *elements = mesh.elements.cpu_rd_ptr();
    bool *isdel = mesh.isdel.cpu_rd_ptr();

    printf("refine finished\n");
    printf("nnodes = %u\n", mesh.nnodes);
    printf("nelements = %u\n", mesh.nelements);

    for (unsigned i = 0; i < mesh.nelements; i++) {
        printf("element[%u] = (%u, %u, %u), isdel=%d\n",
               i, elements[i].x, elements[i].y, elements[i].z, (int)isdel[i]);
    }

    printf("out worklist items = %d\n", owl.nitems());

    return 0;
}