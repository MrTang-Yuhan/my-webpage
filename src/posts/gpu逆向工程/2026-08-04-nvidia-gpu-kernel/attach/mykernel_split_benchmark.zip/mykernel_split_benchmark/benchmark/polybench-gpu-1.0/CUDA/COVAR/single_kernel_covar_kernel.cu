// Auto-generated CUDA kernel file: covar_kernel
// Extracted from: polybench-gpu-1.0/CUDA/COVAR/covariance.cu
// Original line: 165

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define M 2048  // from line 26
#define N 2048  // from line 27

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/COVAR/covariance.cu:47

// ===== Kernel =====
// Kernel: covar_kernel (line 165)
__global__ void covar_kernel(DATA_TYPE *symmat, DATA_TYPE *data) {

	int j1 = blockIdx.x * blockDim.x + threadIdx.x + 1;
	int i, j2;

	if ((j1 >= 1) && (j1 < (M+1)))
	{
		for (j2 = j1; j2 < (M+1); j2++)
		{		
			symmat[j1*(M+1) + j2] = 0.0;
			for(i = 1; i < (N+1); i++)
			{
				symmat[j1 * (M+1) + j2] += data[i *(M+1) + j1] * data[i *(M+1) + j2];
			}
			symmat[j2 * (M+1) + j1] = symmat[j1 * (M+1) + j2];
		}
	}

}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_symmat = (size_t)(M + 1) * (M + 1);
    const size_t size_data   = (size_t)(N + 1) * (M + 1);

    DATA_TYPE *h_symmat = (DATA_TYPE*)malloc(size_symmat * sizeof(DATA_TYPE));
    DATA_TYPE *h_data   = (DATA_TYPE*)malloc(size_data * sizeof(DATA_TYPE));
    DATA_TYPE *d_symmat = nullptr;
    DATA_TYPE *d_data   = nullptr;

    if (!h_symmat || !h_data) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_symmat; ++i) h_symmat[i] = 0.0f;
    for (size_t i = 0; i < size_data; ++i) h_data[i] = (DATA_TYPE)(i % 100) / 100.0f;

    err = cudaMalloc((void**)&d_symmat, size_symmat * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_symmat failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_data, size_data * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_data failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_symmat, h_symmat, size_symmat * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D symmat failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_data, h_data, size_data * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D data failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((M + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    covar_kernel<<<gridSize, blockSize>>>(d_symmat, d_data);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("covar_kernel execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_symmat, d_symmat, size_symmat * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H symmat failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("symmat[(M+1)+1] = %f\n", (double)h_symmat[(M + 1) + 1]);

    cudaFree(d_symmat);
    cudaFree(d_data);
    free(h_symmat);
    free(h_data);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}