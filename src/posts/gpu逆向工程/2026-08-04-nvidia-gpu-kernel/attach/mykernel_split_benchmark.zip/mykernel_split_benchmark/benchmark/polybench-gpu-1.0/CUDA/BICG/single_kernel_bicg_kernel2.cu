// Auto-generated CUDA kernel file: bicg_kernel2
// Extracted from: polybench-gpu-1.0/CUDA/BICG/bicg.cu
// Original line: 117

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

// ===== Macro Definitions =====
#define NX 4096  // from line 25
#define NY 4096  // from line 26

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/BICG/bicg.cu:37

// ===== Kernel =====
// Kernel: bicg_kernel2 (line 117)
__global__ void bicg_kernel2(DATA_TYPE *A, DATA_TYPE *p, DATA_TYPE *q) {

	int i = blockIdx.x * blockDim.x + threadIdx.x;
	
	if (i < NX)
	{
		q[i] = 0.0f;

		int j;
		for(j=0; j < NY; j++)
		{
			q[i] += A[i * NY + j] * p[j];
		}
	}

}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_A = (size_t)NX * NY;
    const size_t size_p = NY;
    const size_t size_q = NX;

    DATA_TYPE *h_A = (DATA_TYPE*)malloc(size_A * sizeof(DATA_TYPE));
    DATA_TYPE *h_p = (DATA_TYPE*)malloc(size_p * sizeof(DATA_TYPE));
    DATA_TYPE *h_q = (DATA_TYPE*)malloc(size_q * sizeof(DATA_TYPE));

    DATA_TYPE *d_A = nullptr;
    DATA_TYPE *d_p = nullptr;
    DATA_TYPE *d_q = nullptr;

    if (!h_A || !h_p || !h_q) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_A; ++i) h_A[i] = (DATA_TYPE)(i % 100) / 100.0f;
    for (size_t i = 0; i < size_p; ++i) h_p[i] = (DATA_TYPE)(i % 100) / 100.0f;
    for (size_t i = 0; i < size_q; ++i) h_q[i] = 0.0f;

    err = cudaMalloc((void**)&d_A, size_A * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_A failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_p, size_p * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_p failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_q, size_q * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_q failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_A, h_A, size_A * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D A failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_p, h_p, size_p * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D p failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_q, h_q, size_q * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D q failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((NX + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    bicg_kernel2<<<gridSize, blockSize>>>(d_A, d_p, d_q);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("bicg_kernel2 execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_q, d_q, size_q * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H q failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("q[0] = %f\n", (double)h_q[0]);

    cudaFree(d_A);
    cudaFree(d_p);
    cudaFree(d_q);
    free(h_A);
    free(h_p);
    free(h_q);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}