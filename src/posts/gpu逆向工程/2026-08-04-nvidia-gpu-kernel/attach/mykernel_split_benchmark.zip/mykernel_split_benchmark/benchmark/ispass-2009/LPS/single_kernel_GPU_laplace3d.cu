// Auto-generated CUDA kernel file: GPU_laplace3d
// Extracted from: ispass-2009/LPS/laplace3d_kernel.cu
// Original line: 26

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Macro Definitions =====
#define BLOCK_X 32  // from line 15 (from ispass-2009/LPS/laplace3d.cu)
#define BLOCK_Y 4  // from line 16 (from ispass-2009/LPS/laplace3d.cu)
#define INDEX(i,j,j_off)  (i +__mul24(j,j_off))  // from line 21
#define IOFF  1  // from line 41
#define JOFF (BLOCK_X+2)  // from line 42
#define KOFF (BLOCK_X+2)*(BLOCK_Y+2)  // from line 43

// ===== Kernel =====
// Kernel: GPU_laplace3d (line 26)
__global__ void GPU_laplace3d(int NX, int NY, int NZ, int pitch, 
                              float *d_u1, float *d_u2) {

  int   indg, indg_h, indg0;
  int   i, j, k, ind, ind_h, halo, active;
  float u2, sixth=1.0f/6.0f;

  int NXM1 = NX-1;
  int NYM1 = NY-1;
  int NZM1 = NZ-1;

  //
  // define local array offsets
  //

#define IOFF  1
#define JOFF (BLOCK_X+2)
#define KOFF (BLOCK_X+2)*(BLOCK_Y+2)
  __shared__ float u1[3*KOFF];


  //
  // first set up indices for halos
  //

  k    = threadIdx.x + threadIdx.y*BLOCK_X;
  halo = k < 2*(BLOCK_X+BLOCK_Y+2);

  if (halo) {
    if (threadIdx.y<2) {               // y-halos (coalesced)
      i = threadIdx.x;
      j = threadIdx.y*(BLOCK_Y+1) - 1;
    }
    else {                             // x-halos (not coalesced)
      i = (k%2)*(BLOCK_X+1) - 1;
      j =  k/2 - BLOCK_X - 1;
    }

    ind_h  = INDEX(i+1,j+1,JOFF) + KOFF;

    i      = INDEX(i,blockIdx.x,BLOCK_X);   // global indices
    j      = INDEX(j,blockIdx.y,BLOCK_Y);
    indg_h = INDEX(i,j,pitch);

    halo   =  (i>=0) && (i<NX) && (j>=0) && (j<NY);
  }

  //
  // then set up indices for main block
  //

  i    = threadIdx.x;
  j    = threadIdx.y;
  ind  = INDEX(i+1,j+1,JOFF) + KOFF;

  i    = INDEX(i,blockIdx.x,BLOCK_X);     // global indices
  j    = INDEX(j,blockIdx.y,BLOCK_Y);
  indg = INDEX(i,j,pitch);

  active = (i<NX) && (j<NY);

  //
  // read initial plane of u1 array
  //

  if (active) u1[ind+KOFF] = d_u1[indg];
  if (halo) u1[ind_h+KOFF] = d_u1[indg_h];

  //
  // loop over k-planes
  //

  for (k=0; k<NZ; k++) {

    // move two planes down and read in new plane k+1

    if (active) {
      indg0 = indg;
      indg  = INDEX(indg,NY,pitch);
      u1[ind-KOFF] = u1[ind];
      u1[ind]      = u1[ind+KOFF];
      if (k<NZM1)
        u1[ind+KOFF] = d_u1[indg];
    }

    if (halo) {
      indg_h = INDEX(indg_h,NY,pitch);
      u1[ind_h-KOFF] = u1[ind_h];
      u1[ind_h]      = u1[ind_h+KOFF];
      if (k<NZM1)
        u1[ind_h+KOFF] = d_u1[indg_h];
    }

    __syncthreads();

  //
  // perform Jacobi iteration to set values in u2
  //

    if (active) {
      if (i==0 || i==NXM1 || j==0 || j==NYM1 || k==0 || k==NZM1) {
        u2 = u1[ind];          // Dirichlet b.c.'s
      }
      else {
        u2 = ( u1[ind-IOFF] + u1[ind+IOFF]
             + u1[ind-JOFF] + u1[ind+JOFF]
             + u1[ind-KOFF] + u1[ind+KOFF] ) * sixth;
      }
      d_u2[indg0] = u2;
    }

    __syncthreads();

  }

}

int main(int argc, char **argv) {
  // 3D 网格尺寸，可按需修改
  int NX = 64;
  int NY = 64;
  int NZ = 64;

  if (argc == 4) {
    NX = atoi(argv[1]);
    NY = atoi(argv[2]);
    NZ = atoi(argv[3]);
  }

  printf("Running GPU_laplace3d with NX=%d, NY=%d, NZ=%d\n", NX, NY, NZ);

  // 这里 pitch 直接按“元素数”使用，而不是字节数
  int pitch = NX;
  size_t numElems = (size_t)NX * NY * NZ;
  size_t memSize = numElems * sizeof(float);

  float *h_u1 = (float *)malloc(memSize);
  float *h_u2 = (float *)malloc(memSize);
  float *d_u1 = NULL;
  float *d_u2 = NULL;

  if (!h_u1 || !h_u2) {
    fprintf(stderr, "Host memory allocation failed\n");
    free(h_u1);
    free(h_u2);
    return -1;
  }

  // 初始化输入数据
  // 边界设为 1.0，内部设为 0.0，便于观察 Jacobi 更新效果
  for (int k = 0; k < NZ; k++) {
    for (int j = 0; j < NY; j++) {
      for (int i = 0; i < NX; i++) {
        size_t idx = i + j * pitch + k * pitch * NY;
        if (i == 0 || i == NX - 1 ||
            j == 0 || j == NY - 1 ||
            k == 0 || k == NZ - 1) {
          h_u1[idx] = 1.0f;
        } else {
          h_u1[idx] = 0.0f;
        }
        h_u2[idx] = 0.0f;
      }
    }
  }

  cudaError_t err;

  err = cudaMalloc((void **)&d_u1, memSize);
  if (err != cudaSuccess) {
    fprintf(stderr, "cudaMalloc(d_u1) failed: %s\n", cudaGetErrorString(err));
    free(h_u1);
    free(h_u2);
    return -1;
  }

  err = cudaMalloc((void **)&d_u2, memSize);
  if (err != cudaSuccess) {
    fprintf(stderr, "cudaMalloc(d_u2) failed: %s\n", cudaGetErrorString(err));
    cudaFree(d_u1);
    free(h_u1);
    free(h_u2);
    return -1;
  }

  err = cudaMemcpy(d_u1, h_u1, memSize, cudaMemcpyHostToDevice);
  if (err != cudaSuccess) {
    fprintf(stderr, "cudaMemcpy H2D failed: %s\n", cudaGetErrorString(err));
    cudaFree(d_u1);
    cudaFree(d_u2);
    free(h_u1);
    free(h_u2);
    return -1;
  }

  err = cudaMemset(d_u2, 0, memSize);
  if (err != cudaSuccess) {
    fprintf(stderr, "cudaMemset(d_u2) failed: %s\n", cudaGetErrorString(err));
    cudaFree(d_u1);
    cudaFree(d_u2);
    free(h_u1);
    free(h_u2);
    return -1;
  }

  dim3 block(BLOCK_X, BLOCK_Y, 1);
  dim3 grid((NX + BLOCK_X - 1) / BLOCK_X,
            (NY + BLOCK_Y - 1) / BLOCK_Y,
            1);

  printf("Launch config: grid=(%u,%u,%u), block=(%u,%u,%u)\n",
         grid.x, grid.y, grid.z, block.x, block.y, block.z);

  GPU_laplace3d<<<grid, block>>>(NX, NY, NZ, pitch, d_u1, d_u2);

  err = cudaGetLastError();
  if (err != cudaSuccess) {
    fprintf(stderr, "Kernel launch failed: %s\n", cudaGetErrorString(err));
    cudaFree(d_u1);
    cudaFree(d_u2);
    free(h_u1);
    free(h_u2);
    return -1;
  }

  err = cudaDeviceSynchronize();
  if (err != cudaSuccess) {
    fprintf(stderr, "Kernel execution failed: %s\n", cudaGetErrorString(err));
    cudaFree(d_u1);
    cudaFree(d_u2);
    free(h_u1);
    free(h_u2);
    return -1;
  }

  err = cudaMemcpy(h_u2, d_u2, memSize, cudaMemcpyDeviceToHost);
  if (err != cudaSuccess) {
    fprintf(stderr, "cudaMemcpy D2H failed: %s\n", cudaGetErrorString(err));
    cudaFree(d_u1);
    cudaFree(d_u2);
    free(h_u1);
    free(h_u2);
    return -1;
  }

  // 打印 z=NZ/2 截面的前几项
  int kz = NZ / 2;
  printf("Sample output on z=%d plane:\n", kz);
  for (int j = 0; j < (NY < 4 ? NY : 4); j++) {
    for (int i = 0; i < (NX < 8 ? NX : 8); i++) {
      size_t idx = i + j * pitch + kz * pitch * NY;
      printf("%7.4f ", h_u2[idx]);
    }
    printf("\n");
  }

  cudaFree(d_u1);
  cudaFree(d_u2);
  free(h_u1);
  free(h_u2);

  return 0;
}