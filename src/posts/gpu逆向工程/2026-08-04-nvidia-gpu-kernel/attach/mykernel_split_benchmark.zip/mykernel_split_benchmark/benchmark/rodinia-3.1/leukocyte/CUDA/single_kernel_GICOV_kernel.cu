#include <cuda_runtime.h>
#include <stdio.h>
#include <cstdio>
#include <cstdlib>
#include <vector>

#define MAX_RAD 20
#define NPOINTS 150
#define NCIRCLES 7

#define CHECK_CUDA(call)                                                        \
    do {                                                                        \
        cudaError_t err = (call);                                               \
        if (err != cudaSuccess) {                                               \
            fprintf(stderr, "CUDA error at %s:%d: %s\n",                        \
                    __FILE__, __LINE__, cudaGetErrorString(err));               \
            exit(EXIT_FAILURE);                                                 \
        }                                                                       \
    } while (0)

// 自包含版本：
// 1. 不再依赖 c_tX/c_tY/c_cos_angle/c_sin_angle 常量内存
// 2. 不再依赖 t_grad_x/t_grad_y texture
// 3. 全部作为普通指针传入
__global__ void GICOV_kernel(const float *grad_x,
                             const float *grad_y,
                             const int *tX,
                             const int *tY,
                             const float *cos_angle,
                             const float *sin_angle,
                             int grad_m,
                             int grad_n,
                             float *gicov) {
    int i = blockIdx.x + MAX_RAD + 2;
    int j = threadIdx.x + MAX_RAD + 2;

    // 边界保护
    if (i >= grad_n - (MAX_RAD + 2) || j >= grad_m - (MAX_RAD + 2)) return;

    float max_GICOV = 0.0f;

    for (int k = 0; k < NCIRCLES; k++) {
        float sum = 0.0f, M2 = 0.0f, mean = 0.0f;

        for (int n = 0; n < NPOINTS; n++) {
            int y = j + tY[k * NPOINTS + n];
            int x = i + tX[k * NPOINTS + n];

            // 理论上 stencil 应保证不越界，保险起见再加保护
            if (x < 0 || x >= grad_n || y < 0 || y >= grad_m) continue;

            int addr = x * grad_m + y;
            float p = grad_x[addr] * cos_angle[n] +
                      grad_y[addr] * sin_angle[n];

            sum += p;

            float delta = p - mean;
            mean = mean + delta / (float)(n + 1);
            M2 = M2 + delta * (p - mean);
        }

        mean = sum / (float)NPOINTS;
        float var = M2 / (float)(NPOINTS - 1);

        // 防止除0
        if (var > 1e-12f) {
            float score = (mean * mean) / var;
            if (score > max_GICOV) max_GICOV = score;
        }
    }

    gicov[i * grad_m + j] = max_GICOV;
}

int main() {
    const int grad_m = 128;
    const int grad_n = 128;
    const int total = grad_m * grad_n;

    std::vector<float> h_grad_x(total, 0.0f);
    std::vector<float> h_grad_y(total, 0.0f);
    std::vector<float> h_gicov(total, 0.0f);

    for (int i = 0; i < total; ++i) {
        h_grad_x[i] = 0.1f * (i % 11);
        h_grad_y[i] = 0.2f * (i % 7);
    }

    std::vector<int> h_tX(NCIRCLES * NPOINTS, 0);
    std::vector<int> h_tY(NCIRCLES * NPOINTS, 0);
    std::vector<float> h_cos_angle(NPOINTS, 1.0f);
    std::vector<float> h_sin_angle(NPOINTS, 0.0f);

    // 简单初始化：所有 stencil 点偏移都为 0
    // 这样 kernel 至少能跑通；如果你要真实算法效果，需要填真实模板
    for (int k = 0; k < NCIRCLES; ++k) {
        for (int n = 0; n < NPOINTS; ++n) {
            h_tX[k * NPOINTS + n] = 0;
            h_tY[k * NPOINTS + n] = 0;
        }
    }

    float *d_grad_x = nullptr;
    float *d_grad_y = nullptr;
    float *d_gicov = nullptr;
    int *d_tX = nullptr;
    int *d_tY = nullptr;
    float *d_cos_angle = nullptr;
    float *d_sin_angle = nullptr;

    CHECK_CUDA(cudaMalloc((void**)&d_grad_x, total * sizeof(float)));
    CHECK_CUDA(cudaMalloc((void**)&d_grad_y, total * sizeof(float)));
    CHECK_CUDA(cudaMalloc((void**)&d_gicov, total * sizeof(float)));
    CHECK_CUDA(cudaMalloc((void**)&d_tX, h_tX.size() * sizeof(int)));
    CHECK_CUDA(cudaMalloc((void**)&d_tY, h_tY.size() * sizeof(int)));
    CHECK_CUDA(cudaMalloc((void**)&d_cos_angle, h_cos_angle.size() * sizeof(float)));
    CHECK_CUDA(cudaMalloc((void**)&d_sin_angle, h_sin_angle.size() * sizeof(float)));

    CHECK_CUDA(cudaMemcpy(d_grad_x, h_grad_x.data(), total * sizeof(float), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMemcpy(d_grad_y, h_grad_y.data(), total * sizeof(float), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMemcpy(d_tX, h_tX.data(), h_tX.size() * sizeof(int), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMemcpy(d_tY, h_tY.data(), h_tY.size() * sizeof(int), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMemcpy(d_cos_angle, h_cos_angle.data(), h_cos_angle.size() * sizeof(float), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMemcpy(d_sin_angle, h_sin_angle.data(), h_sin_angle.size() * sizeof(float), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMemset(d_gicov, 0, total * sizeof(float)));

    const int valid_i = grad_n - 2 * (MAX_RAD + 2);
    const int valid_j = grad_m - 2 * (MAX_RAD + 2);

    dim3 grid(valid_i);
    dim3 block(valid_j);

    GICOV_kernel<<<grid, block>>>(
        d_grad_x,
        d_grad_y,
        d_tX,
        d_tY,
        d_cos_angle,
        d_sin_angle,
        grad_m,
        grad_n,
        d_gicov
    );
    CHECK_CUDA(cudaGetLastError());
    CHECK_CUDA(cudaDeviceSynchronize());

    CHECK_CUDA(cudaMemcpy(h_gicov.data(), d_gicov, total * sizeof(float), cudaMemcpyDeviceToHost));

    printf("GICOV_kernel done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("h_gicov[%d] = %f\n", i, h_gicov[i]);
    }

    CHECK_CUDA(cudaFree(d_grad_x));
    CHECK_CUDA(cudaFree(d_grad_y));
    CHECK_CUDA(cudaFree(d_gicov));
    CHECK_CUDA(cudaFree(d_tX));
    CHECK_CUDA(cudaFree(d_tY));
    CHECK_CUDA(cudaFree(d_cos_angle));
    CHECK_CUDA(cudaFree(d_sin_angle));

    return 0;
}