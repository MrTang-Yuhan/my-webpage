#include "pta_single_kernel_test_common.cuh"

__device__ void insertKeyValLite(uint key, uint val) {
    uint pos = atomicAdd(&__numKeysCounter__, 1);
    __key__[pos] = key;
    __val__[pos] = val;
}

__device__ void decodeRelToKeysLite(uint src, uint rel) {
    uint head = getHeadIndex(src, rel);
    uint base = graphGet(head + BASE);

    if (base == NIL) return;

    uint bits = graphGet(head + threadIdx.x);

    uint active = __ballot_sync(0xFFFFFFFF, bits != 0 && threadIdx.x < BASE);

    while (active) {
        uint lane = __ffs(active) - 1;
        active &= active - 1;

        uint wordBits = __shfl_sync(0xFFFFFFFF, bits, lane);

        for (uint b = 0; b < 32; b++) {
            if (wordBits & (1u << b)) {
                uint dst = base * ELEMENT_CARDINALITY + lane * 32 + b;

                if (threadIdx.x == 0) {
                    insertKeyValLite(dst, getHeadIndex(src, STORE));
                }
            }
        }
    }
}

__global__ void copyInv_loadInv_store2storeInv() {
    uint warp = blockIdx.x * blockDim.y + threadIdx.y;
    uint nwarps = gridDim.x * blockDim.y;

    uint nvars = __numVars__;

    for (uint src = warp; src < nvars; src += nwarps) {
        decodeRelToKeysLite(src, COPY_INV);
        decodeRelToKeysLite(src, LOAD_INV);
    }

    uint nstore = __numStore__;
    for (uint i = warp; i < nstore; i += nwarps) {
        uint src = __storeConstraints__[i];
        if (src != NIL) {
            decodeRelToKeysLite(src, STORE);
        }
    }

    __syncthreads();

    if (isFirstThreadOfBlock()) {
        uint n = __numKeysCounter__;
        __key__[n] = NIL;
        __val__[n] = NIL;
        __numKeys__ = n + 1;
        __numKeysCounter__ = 0;
        __worklistIndex0__ = 0;
        __worklistIndex1__ = 0;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint elt[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) elt[i] = 0;
    elt[0] = 0x8;
    elt[BASE] = 0;
    elt[NEXT] = NIL;

    uint copyHead = TEST_COPY_INV_START + 2 * ELEMENT_WIDTH;
    cudaMemcpy(env.d_graph + copyHead, elt, sizeof(elt), cudaMemcpyHostToDevice);

    uint zero = 0;
    cudaMemcpyToSymbol(__numKeysCounter__, &zero, sizeof(uint));

    dim3 block(32, 4);
    dim3 grid(1);

    copyInv_loadInv_store2storeInv<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "copyInv_loadInv_store2storeInv launch failed");
    checkCuda(cudaDeviceSynchronize(), "copyInv_loadInv_store2storeInv execution failed");

    uint keys[8], vals[8], numKeys;
    cudaMemcpy(keys, env.d_key, sizeof(keys), cudaMemcpyDeviceToHost);
    cudaMemcpy(vals, env.d_val, sizeof(vals), cudaMemcpyDeviceToHost);
    cudaMemcpyFromSymbol(&numKeys, __numKeys__, sizeof(uint));

    printf("copyInv_loadInv_store2storeInv finished\n");
    printf("numKeys=%u\n", numKeys);
    for (int i = 0; i < 4; i++) {
        printf("key[%d]=%u val[%d]=%u\n", i, keys[i], i, vals[i]);
    }

    destroyPTATestEnv(env);
    return 0;
}