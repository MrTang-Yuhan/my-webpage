// Auto-generated CUDA kernel file: executeReLULayerCUDA_split
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 911

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeReLULayerCUDA_split (line 911)
__global__ void executeReLULayerCUDA_split(float *Layer_Neurons,int f_size,int tfactor) {

       	int output = blockIdx.x;
	int row_even = threadIdx.x * tfactor;
	int col_even = threadIdx.y * tfactor;
	if(row_even < f_size && col_even < f_size)
	{      
		for(int row= row_even; row < row_even + tfactor ; row++) 
		{	
			for(int col =col_even; col < col_even+ tfactor ;col++) 
			{
				{
					if(Layer_Neurons[output*f_size*f_size + row*f_size + col] < 0)
						Layer_Neurons[output*f_size*f_size + row*f_size + col] = 0;
				}
			}
		}
	}

}

int main() {
    const int out = 4;
    const int f_size = 8;
    const int tfactor = 2;

    size_t total_size = (size_t)out * f_size * f_size;

    float *h_data = (float*)malloc(total_size * sizeof(float));
    if (!h_data) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < total_size; ++i) {
        h_data[i] = (i % 5 == 0) ? -(float)(i % 7) : (float)(i % 11);
    }

    float *d_data = NULL;
    CHECK(cudaMalloc((void**)&d_data, total_size * sizeof(float)));
    CHECK(cudaMemcpy(d_data, h_data, total_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block((f_size + tfactor - 1) / tfactor, (f_size + tfactor - 1) / tfactor);

    executeReLULayerCUDA_split<<<grid, block>>>(d_data, f_size, tfactor);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_data, d_data, total_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeReLULayerCUDA_split done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("data[%d] = %f\n", i, h_data[i]);
    }

    cudaFree(d_data);
    free(h_data);

    return 0;
}