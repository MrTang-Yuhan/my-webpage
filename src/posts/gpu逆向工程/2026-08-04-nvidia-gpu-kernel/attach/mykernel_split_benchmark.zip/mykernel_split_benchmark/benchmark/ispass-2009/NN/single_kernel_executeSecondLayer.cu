// Auto-generated CUDA kernel file: executeSecondLayer
// Extracted from: ispass-2009/NN/single_kernel_executeSecondLayer.cu
// Original line: 12

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
__constant__ int kernelTemplate[25] = {
        0,  1,  2,  3,  4,
        29, 30, 31, 32, 33,
        58, 59, 60, 61, 62,
        87, 88, 89, 90, 91,
        116,117,118,119,120 };
__constant__ int kernelTemplate2[25] = {
        0,  1,  2,  3,  4,
        13, 14, 15, 16, 17, 
        26, 27, 28, 29, 30,
        39, 40, 41, 42, 43, 
        52, 53, 54, 55, 56   };
// ===== Kernel =====
// Kernel: executeSecondLayer (line 12)
__global__ void executeSecondLayer(float *Layer2_Neurons_GPU, float *Layer2_Weights_GPU,float *Layer3_Neurons_GPU) {


	int blockID=blockIdx.x;
	int pixelX=threadIdx.x;
	int pixelY=threadIdx.y;


	int weightBegin=blockID*26*6;
	int windowX=pixelX*2;
	int windowY=pixelY*2;
    
	float result=0;

	
	result+=Layer2_Weights_GPU[weightBegin];
	
	if(blockID==1 && pixelX==0 && pixelY==0)
	{
		result+=0;
	}

	++weightBegin;

	for (int i=0; i<25; ++i )
    {
        result+=Layer2_Neurons_GPU[(windowX + 13*windowY +kernelTemplate2[i])+(13*13*6*blockIdx.y)]*Layer2_Weights_GPU[weightBegin+i*6];
        result+=Layer2_Neurons_GPU[(169 + windowX + 13*windowY +kernelTemplate2[i])+(13*13*6*blockIdx.y)]*Layer2_Weights_GPU[weightBegin+i*6+1];
	result+=Layer2_Neurons_GPU[(338 + windowX + 13*windowY + kernelTemplate2[i])+(13*13*6*blockIdx.y)]*Layer2_Weights_GPU[weightBegin+i*6+2];
        result+=Layer2_Neurons_GPU[(507 + windowX + 13*windowY + kernelTemplate2[i])+(13*13*6*blockIdx.y)]*Layer2_Weights_GPU[weightBegin+i*6+3];
        result+=Layer2_Neurons_GPU[(676 + windowX + 13*windowY + kernelTemplate2[i])+(13*13*6*blockIdx.y)]*Layer2_Weights_GPU[weightBegin+i*6+4];
        result+=Layer2_Neurons_GPU[(845 + windowX + 13*windowY + kernelTemplate2[i])+(13*13*6*blockIdx.y)]*Layer2_Weights_GPU[weightBegin+i*6+5];
	}

	result=(1.7159*tanhf(0.66666667*result));

	Layer3_Neurons_GPU[(5*5*blockID+pixelY*5+pixelX)+(1250*blockIdx.y)]=result;


}

int main() {
    const int batch = 1;
    const int in_neurons = 13 * 13 * 6 * batch;
    const int out_neurons = 5 * 5 * 50 * batch;
    const int weights = 50 * 26 * 6;   // 50 feature maps, each has 1 bias + 25*6 weights

    float *h_in = (float*)malloc(sizeof(float) * in_neurons);
    float *h_w  = (float*)malloc(sizeof(float) * weights);
    float *h_out = (float*)malloc(sizeof(float) * out_neurons);

    for (int i = 0; i < in_neurons; i++) h_in[i] = 0.01f * (i % 29);
    for (int i = 0; i < weights; i++) h_w[i] = 0.001f * (i % 23);

    float *d_in = NULL, *d_w = NULL, *d_out = NULL;
    cudaMalloc((void**)&d_in, sizeof(float) * in_neurons);
    cudaMalloc((void**)&d_w,  sizeof(float) * weights);
    cudaMalloc((void**)&d_out, sizeof(float) * out_neurons);

    cudaMemcpy(d_in, h_in, sizeof(float) * in_neurons, cudaMemcpyHostToDevice);
    cudaMemcpy(d_w,  h_w,  sizeof(float) * weights, cudaMemcpyHostToDevice);
    cudaMemset(d_out, 0, sizeof(float) * out_neurons);

    dim3 grid(50, batch, 1);
    dim3 block(5, 5, 1);

    executeSecondLayer<<<grid, block>>>(d_in, d_w, d_out);
    cudaDeviceSynchronize();

    cudaMemcpy(h_out, d_out, sizeof(float) * out_neurons, cudaMemcpyDeviceToHost);

    for (int i = 0; i < 10; i++) {
        printf("Layer3[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_w);
    cudaFree(d_out);
    free(h_in);
    free(h_w);
    free(h_out);

    return 0;
}