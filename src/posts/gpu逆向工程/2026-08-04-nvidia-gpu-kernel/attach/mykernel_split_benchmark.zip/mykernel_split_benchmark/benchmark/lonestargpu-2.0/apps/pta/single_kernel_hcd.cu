// Standalone CUDA kernel file: hcd
// Smoke-test version for PTA hcd kernel

#include "pta_single_kernel_test_common.cuh"

__device__ uint getFirstPair(uint pair) {
    return pair >> 16;
}

__device__ uint getSecondPair(uint pair) {
    return pair & 0xFFFFu;
}

__device__ void mergeRepLite(uint root, uint var) {
    uint rep = getRepRec(var);

    if (rep != root) {
        setRep(rep, root);
        setRep(var, root);
    }

    unlockVar(var);
    unlockVar(rep);
}

__global__ void hcd() {
    uint tid = getThreadIdInBlock();
    uint num = __numHcdIndex__;

    for (uint item = blockIdx.x; item < num; item += gridDim.x) {
        uint pair = __hcdIndex__[item];
        uint start = getFirstPair(pair);
        uint end = getSecondPair(pair);

        if (end <= start) {
            continue;
        }

        uint root = __hcdTable__[start];

        __syncthreads();

        for (uint i = start + 1 + tid; i < end; i += blockDim.x * blockDim.y) {
            uint var = __hcdTable__[i];

            if (var != NIL && var < __numVars__) {
                mergeRepLite(root, var);
            }
        }

        __syncthreads();

        if (tid == 0) {
            uint currHead = getCurrDiffPtsHeadIndex(root);
            uint ptsHead = getPtsHeadIndex(root);

            for (uint i = 0; i < ELEMENT_WIDTH; i++) {
                uint v = graphGet(ptsHead + i);
                graphSet(currHead + i, v);
            }

            unlockVar(root);
        }

        __syncthreads();
    }

    if (isFirstThreadOfBlock()) {
        __worklistIndex0__ = 0;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint h_hcdIndex[MAX_TEST_VARS];
    uint h_hcdTable[MAX_TEST_VARS];

    for (uint i = 0; i < MAX_TEST_VARS; i++) {
        h_hcdIndex[i] = 0;
        h_hcdTable[i] = NIL;
    }

    // 一个简单 HCD 组：{0, 1, 2}
    // pair = (start << 16) | end
    h_hcdIndex[0] = (0u << 16) | 3u;
    h_hcdTable[0] = 0;
    h_hcdTable[1] = 1;
    h_hcdTable[2] = 2;

    uint numHcdIndex = 1;

    checkCuda(cudaMemcpy(env.d_hcdIndex,
                         h_hcdIndex,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy hcdIndex");

    checkCuda(cudaMemcpy(env.d_hcdTable,
                         h_hcdTable,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy hcdTable");

    checkCuda(cudaMemcpyToSymbol(__numHcdIndex__, &numHcdIndex, sizeof(uint)),
              "set numHcdIndex");

    dim3 block(32, 4);
    dim3 grid(1);

    hcd<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "hcd launch failed");
    checkCuda(cudaDeviceSynchronize(), "hcd execution failed");

    uint h_rep[8];

    checkCuda(cudaMemcpy(h_rep,
                         env.d_rep,
                         sizeof(h_rep),
                         cudaMemcpyDeviceToHost),
              "copy rep");

    printf("hcd finished\n");
    for (int i = 0; i < 8; i++) {
        printf("rep[%d]=%u\n", i, h_rep[i]);
    }

    printf("Expected roughly: rep[1] and rep[2] become 0\n");

    destroyPTATestEnv(env);
    return 0;
}