#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_THREADS_PER_BLOCK 512

typedef struct {
    int starting;
    int no_of_edges;
} Node;

__global__ void
Kernel(Node* g_graph_nodes,
       int* g_graph_edges,
       bool* g_graph_mask,
       bool* g_graph_visited,
       int* g_cost,
       bool* g_over,
       int no_of_nodes) {

    int tid = blockIdx.x * MAX_THREADS_PER_BLOCK + threadIdx.x;

    if (tid < no_of_nodes && g_graph_mask[tid]) {
        g_graph_mask[tid] = false;
        g_graph_visited[tid] = true;

        for (int i = g_graph_nodes[tid].starting;
             i < (g_graph_nodes[tid].no_of_edges + g_graph_nodes[tid].starting);
             i++) {
            int id = g_graph_edges[i];
            if (!g_graph_visited[id]) {
                g_cost[id] = g_cost[tid] + 1;
                g_graph_mask[id] = true;
                *g_over = true;
            }
        }
    }
}

static void checkCuda(cudaError_t err, const char* msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "CUDA Error: %s : %s\n", msg, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

int main() {
    const int no_of_nodes = 4;
    const int edge_list_size = 4;
    const int source = 0;

    Node h_graph_nodes[no_of_nodes];
    int  h_graph_edges[edge_list_size] = {
        1, 2,
        3,
        3
    };

    bool h_graph_mask[no_of_nodes];
    bool h_graph_visited[no_of_nodes];
    int  h_cost[no_of_nodes];
    bool h_over;

    // 图结构
    h_graph_nodes[0].starting = 0;
    h_graph_nodes[0].no_of_edges = 2;

    h_graph_nodes[1].starting = 2;
    h_graph_nodes[1].no_of_edges = 1;

    h_graph_nodes[2].starting = 3;
    h_graph_nodes[2].no_of_edges = 1;

    h_graph_nodes[3].starting = 4;
    h_graph_nodes[3].no_of_edges = 0;

    for (int i = 0; i < no_of_nodes; i++) {
        h_graph_mask[i] = false;
        h_graph_visited[i] = false;
        h_cost[i] = -1;
    }

    h_graph_mask[source] = true;
    h_graph_visited[source] = true;
    h_cost[source] = 0;

    Node* d_graph_nodes = NULL;
    int*  d_graph_edges = NULL;
    bool* d_graph_mask = NULL;
    bool* d_graph_visited = NULL;
    int*  d_cost = NULL;
    bool* d_over = NULL;

    checkCuda(cudaMalloc((void**)&d_graph_nodes, no_of_nodes * sizeof(Node)), "cudaMalloc d_graph_nodes");
    checkCuda(cudaMalloc((void**)&d_graph_edges, edge_list_size * sizeof(int)), "cudaMalloc d_graph_edges");
    checkCuda(cudaMalloc((void**)&d_graph_mask, no_of_nodes * sizeof(bool)), "cudaMalloc d_graph_mask");
    checkCuda(cudaMalloc((void**)&d_graph_visited, no_of_nodes * sizeof(bool)), "cudaMalloc d_graph_visited");
    checkCuda(cudaMalloc((void**)&d_cost, no_of_nodes * sizeof(int)), "cudaMalloc d_cost");
    checkCuda(cudaMalloc((void**)&d_over, sizeof(bool)), "cudaMalloc d_over");

    checkCuda(cudaMemcpy(d_graph_nodes, h_graph_nodes,
                         no_of_nodes * sizeof(Node),
                         cudaMemcpyHostToDevice),
              "Memcpy graph_nodes");

    checkCuda(cudaMemcpy(d_graph_edges, h_graph_edges,
                         edge_list_size * sizeof(int),
                         cudaMemcpyHostToDevice),
              "Memcpy graph_edges");

    checkCuda(cudaMemcpy(d_graph_mask, h_graph_mask,
                         no_of_nodes * sizeof(bool),
                         cudaMemcpyHostToDevice),
              "Memcpy graph_mask");

    checkCuda(cudaMemcpy(d_graph_visited, h_graph_visited,
                         no_of_nodes * sizeof(bool),
                         cudaMemcpyHostToDevice),
              "Memcpy graph_visited");

    checkCuda(cudaMemcpy(d_cost, h_cost,
                         no_of_nodes * sizeof(int),
                         cudaMemcpyHostToDevice),
              "Memcpy cost");

    dim3 block(MAX_THREADS_PER_BLOCK);
    dim3 grid((no_of_nodes + block.x - 1) / block.x);

    do {
        h_over = false;
        checkCuda(cudaMemcpy(d_over, &h_over, sizeof(bool), cudaMemcpyHostToDevice),
                  "Memcpy over H2D");

        Kernel<<<grid, block>>>(d_graph_nodes,
                                d_graph_edges,
                                d_graph_mask,
                                d_graph_visited,
                                d_cost,
                                d_over,
                                no_of_nodes);

        checkCuda(cudaGetLastError(), "Kernel launch");
        checkCuda(cudaDeviceSynchronize(), "Kernel sync");

        checkCuda(cudaMemcpy(&h_over, d_over, sizeof(bool), cudaMemcpyDeviceToHost),
                  "Memcpy over D2H");

    } while (h_over);

    checkCuda(cudaMemcpy(h_cost, d_cost,
                         no_of_nodes * sizeof(int),
                         cudaMemcpyDeviceToHost),
              "Memcpy result cost");

    printf("BFS result:\n");
    for (int i = 0; i < no_of_nodes; i++) {
        printf("node %d -> cost %d\n", i, h_cost[i]);
    }

    cudaFree(d_graph_nodes);
    cudaFree(d_graph_edges);
    cudaFree(d_graph_mask);
    cudaFree(d_graph_visited);
    cudaFree(d_cost);
    cudaFree(d_over);

    return 0;
}