// Auto-generated CUDA kernel file: normalize_weights_kernel
// Extracted from: rodinia-3.1/particlefilter/single_kernel_normalize_weights_kernel.cu
// Original line: 44

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>
#include <float.h>
#include <sys/time.h>

// ===== Device Functions =====
// Function: cdfCalc (line 18)
__device__ void cdfCalc(double * CDF, double * weights, int Nparticles) {


    int x;
    CDF[0] = weights[0];
    for (x = 1; x < Nparticles; x++) {
        CDF[x] = weights[x] + CDF[x - 1];
    }


}

// Function: d_randu (line 29)
__device__ double d_randu(int * seed, int index) {



    int M = INT_MAX;
    int A = 1103515245;
    int C = 12345;
    int num = A * seed[index] + C;
    seed[index] = num % M;

    return fabs(seed[index] / ((double) M));


}

// ===== Kernel =====
// Kernel: normalize_weights_kernel (line 44)
__global__ void normalize_weights_kernel(double * weights, int Nparticles, double* partial_sums, double * CDF, double * u, int * seed) {


    int block_id = blockIdx.x;
    int i = blockDim.x * block_id + threadIdx.x;
    __shared__ double u1, sumWeights;
    
    if(0 == threadIdx.x)
        sumWeights = partial_sums[0];
    
    __syncthreads();
    
    if (i < Nparticles) {
        weights[i] = weights[i] / sumWeights;
    }
    
    __syncthreads(); 
    
    if (i == 0) {
        cdfCalc(CDF, weights, Nparticles);
        u[0] = (1 / ((double) (Nparticles))) * d_randu(seed, i); // do this to allow all threads in all blocks to use the same u1
    }
    
    __syncthreads();
    
    if(0 == threadIdx.x) 
        u1 = u[0];
    
    __syncthreads();
        
    if (i < Nparticles) {
        u[i] = u1 + i / ((double) (Nparticles));
    }


}

#include <cuda_runtime.h>

static void checkCuda(cudaError_t err, const char* msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "CUDA error at %s: %s\n", msg, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

int main() {
    const int Nparticles = 1024;
    const int threads = 256;
    const int blocks = (Nparticles + threads - 1) / threads;

    double *h_weights = (double*)malloc(sizeof(double) * Nparticles);
    double *h_partial_sums = (double*)malloc(sizeof(double) * blocks);
    double *h_CDF = (double*)malloc(sizeof(double) * Nparticles);
    double *h_u = (double*)malloc(sizeof(double) * Nparticles);
    int *h_seed = (int*)malloc(sizeof(int) * Nparticles);

    double total = 0.0;
    for (int i = 0; i < Nparticles; i++) {
        h_weights[i] = 1.0 + (i % 5);
        total += h_weights[i];
        h_CDF[i] = 0.0;
        h_u[i] = 0.0;
        h_seed[i] = 1234 + i;
    }

    h_partial_sums[0] = total;
    for (int i = 1; i < blocks; i++) h_partial_sums[i] = 0.0;

    double *d_weights, *d_partial_sums, *d_CDF, *d_u;
    int *d_seed;

    checkCuda(cudaMalloc((void**)&d_weights, sizeof(double) * Nparticles), "cudaMalloc d_weights");
    checkCuda(cudaMalloc((void**)&d_partial_sums, sizeof(double) * blocks), "cudaMalloc d_partial_sums");
    checkCuda(cudaMalloc((void**)&d_CDF, sizeof(double) * Nparticles), "cudaMalloc d_CDF");
    checkCuda(cudaMalloc((void**)&d_u, sizeof(double) * Nparticles), "cudaMalloc d_u");
    checkCuda(cudaMalloc((void**)&d_seed, sizeof(int) * Nparticles), "cudaMalloc d_seed");

    checkCuda(cudaMemcpy(d_weights, h_weights, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "copy weights");
    checkCuda(cudaMemcpy(d_partial_sums, h_partial_sums, sizeof(double) * blocks, cudaMemcpyHostToDevice), "copy partial_sums");
    checkCuda(cudaMemcpy(d_CDF, h_CDF, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "copy CDF");
    checkCuda(cudaMemcpy(d_u, h_u, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "copy u");
    checkCuda(cudaMemcpy(d_seed, h_seed, sizeof(int) * Nparticles, cudaMemcpyHostToDevice), "copy seed");

    normalize_weights_kernel<<<blocks, threads>>>(d_weights, Nparticles, d_partial_sums, d_CDF, d_u, d_seed);

    checkCuda(cudaGetLastError(), "launch normalize_weights_kernel");
    checkCuda(cudaDeviceSynchronize(), "sync normalize_weights_kernel");

    checkCuda(cudaMemcpy(h_weights, d_weights, sizeof(double) * Nparticles, cudaMemcpyDeviceToHost), "copy back weights");
    checkCuda(cudaMemcpy(h_CDF, d_CDF, sizeof(double) * Nparticles, cudaMemcpyDeviceToHost), "copy back CDF");
    checkCuda(cudaMemcpy(h_u, d_u, sizeof(double) * Nparticles, cudaMemcpyDeviceToHost), "copy back u");

    printf("normalize_weights_kernel finished.\n");
    printf("weights[0] = %f\n", h_weights[0]);
    printf("CDF[last] = %f\n", h_CDF[Nparticles - 1]);
    printf("u[0] = %f, u[last] = %f\n", h_u[0], h_u[Nparticles - 1]);

    cudaFree(d_weights);
    cudaFree(d_partial_sums);
    cudaFree(d_CDF);
    cudaFree(d_u);
    cudaFree(d_seed);

    free(h_weights);
    free(h_partial_sums);
    free(h_CDF);
    free(h_u);
    free(h_seed);

    return 0;
}