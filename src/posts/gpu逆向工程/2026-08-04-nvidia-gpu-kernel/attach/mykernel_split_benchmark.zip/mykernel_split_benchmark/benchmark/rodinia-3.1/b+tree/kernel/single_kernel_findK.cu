// Auto-generated CUDA kernel file: findK
#include <stdio.h>
#include <stdlib.h>

// ===== 内联 common.h 所需类型 =====
#define DEFAULT_ORDER 256
#define ORDER DEFAULT_ORDER

typedef struct record {
    int value;
} record;

typedef struct knode {
    int keys[ORDER + 1];
    long indices[ORDER + 1];
} knode;

// ===== Kernel =====
__global__ void
findK(long height,
      knode *knodesD,
      long knodes_elem,
      record *recordsD,
      long *currKnodeD,
      long *offsetD,
      int *keysD,
      record *ansD) {

    int thid = threadIdx.x;
    int bid  = blockIdx.x;

    int i;
    for (i = 0; i < height; i++) {
        if ((knodesD[currKnodeD[bid]].keys[thid]) <= keysD[bid] &&
            (knodesD[currKnodeD[bid]].keys[thid+1] > keysD[bid])) {
            if (knodesD[offsetD[bid]].indices[thid] < knodes_elem) {
                offsetD[bid] = knodesD[offsetD[bid]].indices[thid];
            }
        }
        __syncthreads();
        if (thid == 0) {
            currKnodeD[bid] = offsetD[bid];
        }
        __syncthreads();
    }

    if (knodesD[currKnodeD[bid]].keys[thid] == keysD[bid]) {
        ansD[bid].value = recordsD[knodesD[currKnodeD[bid]].indices[thid]].value;
    }
}

// ===== Main =====
int main() {
    // 构造一棵高度为 1 的最简 B+ 树（只有 1 个叶节点）
    // ORDER=256，每个 knode 有 ORDER+1 个 key 槽，用 THREADS 个线程搜索
    const int THREADS = ORDER;   // 256 threads per block
    const int BLOCKS  = 1;       // 1 次查询
    const long HEIGHT = 1;

    // 叶节点：keys[0..ORDER-1] = 0,1,...,255；indices[i] 指向 records[i]
    knode h_knode;
    for (int i = 0; i <= ORDER; i++) {
        h_knode.keys[i]    = i;       // key i
        h_knode.indices[i] = i;       // 指向 records[i]
    }

    // records[i].value = i * 10
    record h_records[ORDER + 1];
    for (int i = 0; i <= ORDER; i++) h_records[i].value = i * 10;

    long  h_currKnode[BLOCKS] = {0};  // 当前节点索引 = 0
    long  h_offset[BLOCKS]    = {0};
    int   h_keys[BLOCKS]      = {42}; // 查询 key=42
    record h_ans[BLOCKS];
    h_ans[0].value = -1;

    // 设备内存
    knode  *d_knodes;
    record *d_records, *d_ans;
    long   *d_currKnode, *d_offset;
    int    *d_keys;

    cudaMalloc(&d_knodes,    1       * sizeof(knode));
    cudaMalloc(&d_records,   (ORDER+1)* sizeof(record));
    cudaMalloc(&d_currKnode, BLOCKS  * sizeof(long));
    cudaMalloc(&d_offset,    BLOCKS  * sizeof(long));
    cudaMalloc(&d_keys,      BLOCKS  * sizeof(int));
    cudaMalloc(&d_ans,       BLOCKS  * sizeof(record));

    cudaMemcpy(d_knodes,    &h_knode,      sizeof(knode),            cudaMemcpyHostToDevice);
    cudaMemcpy(d_records,   h_records,     (ORDER+1)*sizeof(record), cudaMemcpyHostToDevice);
    cudaMemcpy(d_currKnode, h_currKnode,   BLOCKS*sizeof(long),      cudaMemcpyHostToDevice);
    cudaMemcpy(d_offset,    h_offset,      BLOCKS*sizeof(long),      cudaMemcpyHostToDevice);
    cudaMemcpy(d_keys,      h_keys,        BLOCKS*sizeof(int),       cudaMemcpyHostToDevice);
    cudaMemcpy(d_ans,       h_ans,         BLOCKS*sizeof(record),    cudaMemcpyHostToDevice);

    findK<<<BLOCKS, THREADS>>>(HEIGHT, d_knodes, 1, d_records,
                                d_currKnode, d_offset, d_keys, d_ans);
    cudaError_t err = cudaDeviceSynchronize();
    if (err != cudaSuccess)
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(err));

    cudaMemcpy(h_ans, d_ans, BLOCKS * sizeof(record), cudaMemcpyDeviceToHost);
    printf("Query key=42, found value=%d (expected %d)\n", h_ans[0].value, 42 * 10);

    cudaFree(d_knodes); cudaFree(d_records); cudaFree(d_currKnode);
    cudaFree(d_offset); cudaFree(d_keys);    cudaFree(d_ans);
    return 0;
}