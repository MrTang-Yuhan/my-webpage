// Auto-generated CUDA kernel file: bfs_kernel
// Extracted from: pannotia/bc/kernel.cu
// Original line: 71

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: bfs_kernel (line 71)
__global__ void
bfs_kernel(int *row, int *col, int *d, float *rho, int *cont,
           const int num_nodes, const int num_edges, const int dist) {

    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    //navigate the current layer
    if (tid < num_nodes && d[tid] == dist) {

        //get the starting and ending pointers
        //of the neighbor list

        int start = row[tid];
        int end;
        if (tid + 1 < num_nodes)
            end = row[tid + 1];
        else
            end = num_edges;

        //navigate through the neighbor list
        for (int edge = start; edge < end; edge++) {
            int w = col[edge];
            if (d[w] < 0) {
                *cont = 1;
                //traverse another layer
                d[w] = dist + 1;
            }
            //transfer the rho value to the neighbor
            if (d[w] == (dist + 1)) {
                atomicAdd(&rho[w], rho[tid]);
            }
        }
    }

}


int main(int argc, char** argv) {
    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;
    const int source = 0;
    const int dist = 0;

    const size_t size_row = (size_t)num_nodes * sizeof(int);
    const size_t size_col = (size_t)num_edges * sizeof(int);
    const size_t size_d = (size_t)num_nodes * sizeof(int);
    const size_t size_rho = (size_t)num_nodes * sizeof(float);
    const size_t size_cont = sizeof(int);

    int *h_row = (int*)malloc(size_row);
    int *h_col = (int*)malloc(size_col);
    int *h_d = (int*)malloc(size_d);
    float *h_rho = (float*)malloc(size_rho);
    int *h_cont = (int*)malloc(size_cont);

    int *d_row = nullptr;
    int *d_col = nullptr;
    int *d_d = nullptr;
    float *d_rho = nullptr;
    int *d_cont = nullptr;

    if (!h_row || !h_col || !h_d || !h_rho || !h_cont) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_col);
        free(h_d);
        free(h_rho);
        free(h_cont);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        if (i < num_nodes - 1)
            h_row[i] = i;
        else
            h_row[i] = num_edges;
    }

    for (int i = 0; i < num_edges; ++i) {
        h_col[i] = i + 1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_d[i] = -1;
        h_rho[i] = 0.0f;
    }

    h_d[source] = 0;
    h_rho[source] = 1.0f;
    *h_cont = 0;

    cudaError_t err;

    cudaMalloc((void**)&d_row, size_row);
    cudaMalloc((void**)&d_col, size_col);
    cudaMalloc((void**)&d_d, size_d);
    cudaMalloc((void**)&d_rho, size_rho);
    cudaMalloc((void**)&d_cont, size_cont);

    cudaMemcpy(d_row, h_row, size_row, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col, h_col, size_col, cudaMemcpyHostToDevice);
    cudaMemcpy(d_d, h_d, size_d, cudaMemcpyHostToDevice);
    cudaMemcpy(d_rho, h_rho, size_rho, cudaMemcpyHostToDevice);
    cudaMemcpy(d_cont, h_cont, size_cont, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    bfs_kernel<<<gridSize, blockSize>>>(
        d_row,
        d_col,
        d_d,
        d_rho,
        d_cont,
        num_nodes,
        num_edges,
        dist
    );
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_col);
        cudaFree(d_d);
        cudaFree(d_rho);
        cudaFree(d_cont);
        free(h_row);
        free(h_col);
        free(h_d);
        free(h_rho);
        free(h_cont);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_col);
        cudaFree(d_d);
        cudaFree(d_rho);
        cudaFree(d_cont);
        free(h_row);
        free(h_col);
        free(h_d);
        free(h_rho);
        free(h_cont);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaEventSynchronize(stop);

    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("bfs_kernel execution time: %.3f ms\n", milliseconds);

    cudaMemcpy(h_d, d_d, size_d, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_rho, d_rho, size_rho, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_cont, d_cont, size_cont, cudaMemcpyDeviceToHost);

    printf("cont = %d\n", *h_cont);
    printf("d[0] = %d, rho[0] = %f\n", h_d[0], h_rho[0]);
    printf("d[1] = %d, rho[1] = %f\n", h_d[1], h_rho[1]);
    printf("d[2] = %d, rho[2] = %f\n", h_d[2], h_rho[2]);

    cudaFree(d_row);
    cudaFree(d_col);
    cudaFree(d_d);
    cudaFree(d_rho);
    cudaFree(d_cont);

    free(h_row);
    free(h_col);
    free(h_d);
    free(h_rho);
    free(h_cont);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}