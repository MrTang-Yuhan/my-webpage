// Auto-generated CUDA kernel file: vector_assign
// Extracted from: pannotia/sssp/kernel.cu
// Original line: 156

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: vector_assign (line 156)
__global__ void
vector_assign(int *vector1, int *vector2, const int num_nodes) {

    int tid = blockDim.x * blockIdx.x + threadIdx.x;

    if (tid < num_nodes) {
        vector1[tid] = vector2[tid];
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const size_t size_vec = (size_t)num_nodes * sizeof(int);

    int *h_vector1 = (int*)malloc(size_vec);
    int *h_vector2 = (int*)malloc(size_vec);

    int *d_vector1 = nullptr;
    int *d_vector2 = nullptr;

    if (!h_vector1 || !h_vector2) {
        printf("host malloc failed\n");
        free(h_vector1);
        free(h_vector2);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_vector1[i] = -1;
        h_vector2[i] = i;
    }

    err = cudaMalloc((void**)&d_vector1, size_vec);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_vector1 failed: %s\n", cudaGetErrorString(err));
        free(h_vector1);
        free(h_vector2);
        return -1;
    }

    err = cudaMalloc((void**)&d_vector2, size_vec);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_vector2 failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_vector1);
        free(h_vector1);
        free(h_vector2);
        return -1;
    }

    cudaMemcpy(d_vector1, h_vector1, size_vec, cudaMemcpyHostToDevice);
    cudaMemcpy(d_vector2, h_vector2, size_vec, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    vector_assign<<<gridSize, blockSize>>>(d_vector1, d_vector2, num_nodes);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_vector1, d_vector1, size_vec, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("vector_assign execution time: %.3f ms\n", ms);

    printf("vector1[0] = %d\n", h_vector1[0]);
    printf("vector1[1] = %d\n", h_vector1[1]);
    printf("vector1[2] = %d\n", h_vector1[2]);

    cudaFree(d_vector1);
    cudaFree(d_vector2);

    free(h_vector1);
    free(h_vector2);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}