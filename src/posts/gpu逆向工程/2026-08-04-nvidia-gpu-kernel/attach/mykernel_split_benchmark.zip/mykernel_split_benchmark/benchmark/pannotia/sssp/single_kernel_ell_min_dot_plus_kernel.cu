// Auto-generated CUDA kernel file: ell_min_dot_plus_kernel
// Extracted from: pannotia/sssp/kernel.cu
// Original line: 101

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: ell_min_dot_plus_kernel (line 101)
__global__ void
ell_min_dot_plus_kernel(const int num_nodes, const int height, int *col,
                        int *data, int *x, int *y) {

    // Get workitem id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;

    if (tid < num_nodes) {
        int mat_offset = tid;
        int min = x[tid];

        // The vertices process a row of matrix (col-major)
        for (int i = 0; i < height; i++) {
            int mat_elem = data[mat_offset];
            int vec_elem = x[col[mat_offset]];
            if (mat_elem + vec_elem < min) {
                min = mat_elem + vec_elem;
            }
            mat_offset += num_nodes;
        }
        y[tid] = min;
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int height = 2;

    const size_t size_mat = (size_t)num_nodes * height * sizeof(int);
    const size_t size_vec = (size_t)num_nodes * sizeof(int);

    int *h_col = (int*)malloc(size_mat);
    int *h_data = (int*)malloc(size_mat);
    int *h_x = (int*)malloc(size_vec);
    int *h_y = (int*)malloc(size_vec);

    int *d_col = nullptr;
    int *d_data = nullptr;
    int *d_x = nullptr;
    int *d_y = nullptr;

    if (!h_col || !h_data || !h_x || !h_y) {
        printf("host malloc failed\n");
        free(h_col);
        free(h_data);
        free(h_x);
        free(h_y);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_x[i] = 1000000;
        h_y[i] = 0;
    }
    h_x[0] = 0;

    for (int i = 0; i < num_nodes; ++i) {
        // 第 0 列元素
        h_col[i] = i;
        h_data[i] = 0;

        // 第 1 列元素
        h_col[num_nodes + i] = (i + 1 < num_nodes) ? (i + 1) : i;
        h_data[num_nodes + i] = (i + 1 < num_nodes) ? 1 : 0;
    }

    err = cudaMalloc((void**)&d_col, size_mat);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_col failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_data, size_mat);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_data failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_col);
        return -1;
    }

    err = cudaMalloc((void**)&d_x, size_vec);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_x failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_col);
        cudaFree(d_data);
        return -1;
    }

    err = cudaMalloc((void**)&d_y, size_vec);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_y failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_col);
        cudaFree(d_data);
        cudaFree(d_x);
        return -1;
    }

    cudaMemcpy(d_col, h_col, size_mat, cudaMemcpyHostToDevice);
    cudaMemcpy(d_data, h_data, size_mat, cudaMemcpyHostToDevice);
    cudaMemcpy(d_x, h_x, size_vec, cudaMemcpyHostToDevice);
    cudaMemcpy(d_y, h_y, size_vec, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    ell_min_dot_plus_kernel<<<gridSize, blockSize>>>(num_nodes, height, d_col, d_data, d_x, d_y);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_y, d_y, size_vec, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("ell_min_dot_plus_kernel execution time: %.3f ms\n", ms);

    printf("y[0] = %d\n", h_y[0]);
    printf("y[1] = %d\n", h_y[1]);
    printf("y[2] = %d\n", h_y[2]);
    printf("y[last] = %d\n", h_y[num_nodes - 1]);

    cudaFree(d_col);
    cudaFree(d_data);
    cudaFree(d_x);
    cudaFree(d_y);

    free(h_col);
    free(h_data);
    free(h_x);
    free(h_y);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}