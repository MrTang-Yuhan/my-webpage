// Auto-generated CUDA kernel file: clean_1d_array
// Extracted from: pannotia/bc/kernel.cu
// Original line: 187

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: clean_1d_array (line 187)
__global__ void
clean_1d_array(const int source, int *dist_array, float *sigma, float *rho,
               const int num_nodes) {

    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    if (tid < num_nodes) {

        sigma[tid] = 0;

        if (tid == source) {
            // If source vertex rho = 1, dist = 0
            rho[tid] = 1;
            dist_array[tid] = 0;
        } else {
            // If other vertices rho = 0, dist = -1
            rho[tid] = 0;
            dist_array[tid] = -1;
        }
    }

}


int main(int argc, char** argv) {
    const int num_nodes = 1024;
    const int source = 0;

    const size_t size_int = (size_t)num_nodes * sizeof(int);
    const size_t size_float = (size_t)num_nodes * sizeof(float);

    int *h_dist_array = (int*)malloc(size_int);
    float *h_sigma = (float*)malloc(size_float);
    float *h_rho = (float*)malloc(size_float);

    int *d_dist_array = nullptr;
    float *d_sigma = nullptr;
    float *d_rho = nullptr;

    if (!h_dist_array || !h_sigma || !h_rho) {
        printf("host malloc failed\n");
        free(h_dist_array);
        free(h_sigma);
        free(h_rho);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_dist_array[i] = 123;
        h_sigma[i] = 1.0f;
        h_rho[i] = 1.0f;
    }

    cudaError_t err;

    err = cudaMalloc((void**)&d_dist_array, size_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_dist_array: %s\n", cudaGetErrorString(err));
        free(h_dist_array);
        free(h_sigma);
        free(h_rho);
        return -1;
    }

    err = cudaMalloc((void**)&d_sigma, size_float);
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_sigma: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist_array);
        free(h_dist_array);
        free(h_sigma);
        free(h_rho);
        return -1;
    }

    err = cudaMalloc((void**)&d_rho, size_float);
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_rho: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist_array);
        cudaFree(d_sigma);
        free(h_dist_array);
        free(h_sigma);
        free(h_rho);
        return -1;
    }

    cudaMemcpy(d_dist_array, h_dist_array, size_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_sigma, h_sigma, size_float, cudaMemcpyHostToDevice);
    cudaMemcpy(d_rho, h_rho, size_float, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    clean_1d_array<<<gridSize, blockSize>>>(source, d_dist_array, d_sigma, d_rho, num_nodes);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist_array);
        cudaFree(d_sigma);
        cudaFree(d_rho);
        free(h_dist_array);
        free(h_sigma);
        free(h_rho);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist_array);
        cudaFree(d_sigma);
        cudaFree(d_rho);
        free(h_dist_array);
        free(h_sigma);
        free(h_rho);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaEventSynchronize(stop);

    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("clean_1d_array execution time: %.3f ms\n", milliseconds);

    cudaMemcpy(h_dist_array, d_dist_array, size_int, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_sigma, d_sigma, size_float, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_rho, d_rho, size_float, cudaMemcpyDeviceToHost);

    printf("source = %d\n", source);
    printf("dist_array[source] = %d\n", h_dist_array[source]);
    printf("rho[source] = %f\n", h_rho[source]);
    printf("sigma[source] = %f\n", h_sigma[source]);

    if (num_nodes > 1) {
        printf("dist_array[1] = %d\n", h_dist_array[1]);
        printf("rho[1] = %f\n", h_rho[1]);
        printf("sigma[1] = %f\n", h_sigma[1]);
    }

    cudaFree(d_dist_array);
    cudaFree(d_sigma);
    cudaFree(d_rho);

    free(h_dist_array);
    free(h_sigma);
    free(h_rho);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}