// Standalone version for single_kernel_check_triangles.cu

#include <cuda.h>
#include <cuda_runtime.h>
#include <cub/cub.cuh>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

typedef unsigned int uint;
#ifndef debug
#define debug 0
#endif

#include "cutil_subset.h"
#include "sharedptr.h"
#include "dmr.h"
#include "geomprim.h"
#include "worklistc.h"

// ===== Kernel =====
__global__ void check_triangles(Mesh mesh, uint *bad_triangles, Worklist2 wl, int start) {
    int id = threadIdx.x + blockDim.x * blockIdx.x;
    int threads = blockDim.x * gridDim.x;
    int ele;
    uint3 *el;
    int count = 0;
    int ulimit = mesh.nelements;
    bool push;

    if (debug && id == 0)
        printf("start %d nelements %d\n", start, mesh.nelements);

    for (ele = id + start; ele < ulimit; ele += threads) {
        push = false;

        if (ele < (int)mesh.nelements) {
            if (mesh.isdel[ele])
                goto next;

            if (IS_SEGMENT(mesh.elements[ele]))
                goto next;

            if (!mesh.isbad[ele]) {
                el = &mesh.elements[ele];
                mesh.isbad[ele] =
                    (angleLT(mesh, el->x, el->y, el->z) ||
                     angleLT(mesh, el->z, el->x, el->y) ||
                     angleLT(mesh, el->y, el->z, el->x));
            }

            if (mesh.isbad[ele]) {
                push = true;
                count++;
            }
        }

    next:
        if (push) wl.push(ele);
    }

    atomicAdd(bad_triangles, (uint)count);
}

// ===== Host helper =====
static void build_bad_triangle_mesh(ShMesh &mesh) {
    mesh.maxnnodes = 8;
    mesh.maxnelements = 8;

    mesh.nnodes = 3;
    mesh.ntriangles = 1;
    mesh.nsegments = 0;
    mesh.nelements = 1;

    mesh.nodex.alloc(mesh.maxnnodes);
    mesh.nodey.alloc(mesh.maxnnodes);
    mesh.elements.alloc(mesh.maxnelements);
    mesh.neighbours.alloc(mesh.maxnelements);
    mesh.isdel.alloc(mesh.maxnelements);
    mesh.isbad.alloc(mesh.maxnelements);
    mesh.owners.alloc(mesh.maxnelements);

    FORD *x = mesh.nodex.cpu_wr_ptr(true);
    FORD *y = mesh.nodey.cpu_wr_ptr(true);
    uint3 *elements = mesh.elements.cpu_wr_ptr(true);
    uint3 *neigh = mesh.neighbours.cpu_wr_ptr(true);
    bool *isdel = mesh.isdel.cpu_wr_ptr(true);
    bool *isbad = mesh.isbad.cpu_wr_ptr(true);
    int *owners = mesh.owners.cpu_wr_ptr(true);

    // 一个很瘦的三角形，最小角 < 30°
    x[0] = 0.0;  y[0] = 0.0;
    x[1] = 1.0;  y[1] = 0.0;
    x[2] = 0.5;  y[2] = 10.0;

    elements[0].x = 0;
    elements[0].y = 1;
    elements[0].z = 2;

    neigh[0].x = neigh[0].y = neigh[0].z = INVALIDID;
    isdel[0] = false;
    isbad[0] = false;
    owners[0] = 0;
}

int main() {
    ShMesh mesh;
    build_bad_triangle_mesh(mesh);

    Mesh gmesh(mesh);
    Shared<uint> bad_triangles(1);
    Worklist2 wl(mesh.maxnelements);

    *bad_triangles.cpu_wr_ptr(true) = 0;

    int block = 128;
    int grid = 1;

    check_triangles<<<grid, block>>>(gmesh, bad_triangles.gpu_wr_ptr(), wl, 0);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    uint bad = *bad_triangles.cpu_rd_ptr();
    wl.update_cpu();

    bool *isbad = mesh.isbad.cpu_rd_ptr();

    printf("check_triangles finished\n");
    printf("bad_triangles = %u\n", bad);
    printf("worklist items = %d\n", wl.nitems());
    for (int i = 0; i < wl.nitems(); i++) {
        printf("wl[%d] = %d\n", i, wl.wl[i]);
    }
    printf("mesh.isbad[0] = %d\n", (int)isbad[0]);

    return 0;
}