// Standalone version for single_kernel_verify_min_elem.cu

#include "common.h"
#include "graph.h"
#include "component.h"

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef MST_INFINITY
#define MST_INFINITY 100000000u
#endif

// ===== Kernel =====
// Original kernel: verify_min_elem
__global__ void verify_min_elem(unsigned *mstwt,
                                Graph graph,
                                ComponentSpace cs,
                                foru *eleminwts,
                                foru *minwtcomponent,
                                unsigned *partners,
                                unsigned *phore,
                                bool *processinnextiteration,
                                unsigned *goaheadnodeofcomponent,
                                unsigned inpid) {
    unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
    if (inpid < graph.nnodes) id = inpid;

    if (id < graph.nnodes) {
        if (cs.isBoss(id)) {
            if (goaheadnodeofcomponent[id] == graph.nnodes) {
                return;
            }

            unsigned minwt_node = goaheadnodeofcomponent[id];

            unsigned degree = graph.getOutDegree(minwt_node);
            foru minwt = minwtcomponent[id];

            if (minwt == MYINFINITY)
                return;

            bool minwt_found = false;

            for (unsigned ii = 0; ii < degree; ++ii) {
                foru wt = graph.getWeight(minwt_node, ii);

                if (wt == minwt) {
                    minwt_found = true;
                    unsigned dst = graph.getDestination(minwt_node, ii);
                    unsigned tempdstboss = cs.find(dst);

                    if (tempdstboss == partners[minwt_node] && tempdstboss != id) {
                        processinnextiteration[minwt_node] = true;
                        return;
                    }
                }
            }

            printf("component %d is wrong %d\n", id, minwt_found);
        }
    }
}

// ===== Host helper: build a small undirected weighted graph =====
static void build_test_graph(Graph &hg) {
    /*
        Undirected graph represented as directed edges:

          1
        0---1
         \  |
        4 \ | 2
           \|
            2

        Edges:
          0 -> 1 weight 1
          1 -> 0 weight 1

          1 -> 2 weight 2
          2 -> 1 weight 2

          0 -> 2 weight 4
          2 -> 0 weight 4
    */

    hg.nnodes = 3;
    hg.nedges = 6;
    hg.allocOnHost();

    for (unsigned i = 0; i < hg.nnodes; i++) {
        hg.srcsrc[i] = i;
    }

    // Edge indices are 1-based in this Graph implementation.
    hg.psrc[0] = 1;
    hg.psrc[1] = 3;
    hg.psrc[2] = 5;
    hg.psrc[3] = hg.nedges;

    hg.noutgoing[0] = 2;
    hg.noutgoing[1] = 2;
    hg.noutgoing[2] = 2;

    hg.nincoming[0] = 2;
    hg.nincoming[1] = 2;
    hg.nincoming[2] = 2;

    // node 0: edges 1,2
    hg.edgessrcdst[1] = 1;
    hg.edgessrcwt[1]  = 1;

    hg.edgessrcdst[2] = 2;
    hg.edgessrcwt[2]  = 4;

    // node 1: edges 3,4
    hg.edgessrcdst[3] = 0;
    hg.edgessrcwt[3]  = 1;

    hg.edgessrcdst[4] = 2;
    hg.edgessrcwt[4]  = 2;

    // node 2: edges 5,6
    hg.edgessrcdst[5] = 0;
    hg.edgessrcwt[5]  = 4;

    hg.edgessrcdst[6] = 1;
    hg.edgessrcwt[6]  = 2;

    hg.source = 0;
}

static void check_cuda(cudaError_t err, const char *msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

int main() {
    Graph hgraph;
    Graph dgraph;

    build_test_graph(hgraph);
    hgraph.cudaCopy(dgraph);

    const unsigned n = hgraph.nnodes;

    ComponentSpace cs(n);

    unsigned *d_mstwt = NULL;
    foru *d_eleminwts = NULL;
    foru *d_minwtcomponent = NULL;
    unsigned *d_partners = NULL;
    unsigned *d_phore = NULL;
    bool *d_processinnextiteration = NULL;
    unsigned *d_goaheadnodeofcomponent = NULL;

    unsigned h_mstwt = 0;

    /*
      测试输入含义：

      component 0:
        goaheadnodeofcomponent[0] = 0
        minwtcomponent[0] = 1
        partners[0] = 1

      verify_min_elem 会检查 node 0 的边里是否存在：
        weight == 1
        dst 的 component == partners[0] == 1
        dst component != current component 0

      因为 0 -> 1 权重为 1，所以应该通过，并设置：
        processinnextiteration[0] = true
    */
    foru h_eleminwts[3] = {
        1,
        MST_INFINITY,
        MST_INFINITY
    };

    foru h_minwtcomponent[3] = {
        1,
        MST_INFINITY,
        MST_INFINITY
    };

    unsigned h_partners[3] = {
        1,
        n,
        n
    };

    unsigned h_phore[3] = {
        0,
        0,
        0
    };

    bool h_processinnextiteration[3] = {
        false,
        false,
        false
    };

    unsigned h_goaheadnodeofcomponent[3] = {
        0,
        n,
        n
    };

    check_cuda(cudaMalloc((void **)&d_mstwt, sizeof(unsigned)),
               "cudaMalloc d_mstwt failed");

    check_cuda(cudaMalloc((void **)&d_eleminwts, n * sizeof(foru)),
               "cudaMalloc d_eleminwts failed");

    check_cuda(cudaMalloc((void **)&d_minwtcomponent, n * sizeof(foru)),
               "cudaMalloc d_minwtcomponent failed");

    check_cuda(cudaMalloc((void **)&d_partners, n * sizeof(unsigned)),
               "cudaMalloc d_partners failed");

    check_cuda(cudaMalloc((void **)&d_phore, n * sizeof(unsigned)),
               "cudaMalloc d_phore failed");

    check_cuda(cudaMalloc((void **)&d_processinnextiteration, n * sizeof(bool)),
               "cudaMalloc d_processinnextiteration failed");

    check_cuda(cudaMalloc((void **)&d_goaheadnodeofcomponent, n * sizeof(unsigned)),
               "cudaMalloc d_goaheadnodeofcomponent failed");

    check_cuda(cudaMemcpy(d_mstwt, &h_mstwt, sizeof(unsigned), cudaMemcpyHostToDevice),
               "cudaMemcpy d_mstwt failed");

    check_cuda(cudaMemcpy(d_eleminwts, h_eleminwts, n * sizeof(foru), cudaMemcpyHostToDevice),
               "cudaMemcpy d_eleminwts failed");

    check_cuda(cudaMemcpy(d_minwtcomponent, h_minwtcomponent, n * sizeof(foru), cudaMemcpyHostToDevice),
               "cudaMemcpy d_minwtcomponent failed");

    check_cuda(cudaMemcpy(d_partners, h_partners, n * sizeof(unsigned), cudaMemcpyHostToDevice),
               "cudaMemcpy d_partners failed");

    check_cuda(cudaMemcpy(d_phore, h_phore, n * sizeof(unsigned), cudaMemcpyHostToDevice),
               "cudaMemcpy d_phore failed");

    check_cuda(cudaMemcpy(d_processinnextiteration,
                          h_processinnextiteration,
                          n * sizeof(bool),
                          cudaMemcpyHostToDevice),
               "cudaMemcpy d_processinnextiteration failed");

    check_cuda(cudaMemcpy(d_goaheadnodeofcomponent,
                          h_goaheadnodeofcomponent,
                          n * sizeof(unsigned),
                          cudaMemcpyHostToDevice),
               "cudaMemcpy d_goaheadnodeofcomponent failed");

    int block = 128;
    int grid = (n + block - 1) / block;

    verify_min_elem<<<grid, block>>>(d_mstwt,
                                     dgraph,
                                     cs,
                                     d_eleminwts,
                                     d_minwtcomponent,
                                     d_partners,
                                     d_phore,
                                     d_processinnextiteration,
                                     d_goaheadnodeofcomponent,
                                     n);

    check_cuda(cudaGetLastError(), "verify_min_elem launch failed");
    check_cuda(cudaDeviceSynchronize(), "verify_min_elem execution failed");

    check_cuda(cudaMemcpy(h_processinnextiteration,
                          d_processinnextiteration,
                          n * sizeof(bool),
                          cudaMemcpyDeviceToHost),
               "cudaMemcpy process D2H failed");

    check_cuda(cudaMemcpy(h_goaheadnodeofcomponent,
                          d_goaheadnodeofcomponent,
                          n * sizeof(unsigned),
                          cudaMemcpyDeviceToHost),
               "cudaMemcpy goahead D2H failed");

    printf("verify_min_elem finished\n");
    for (unsigned i = 0; i < n; i++) {
        printf("node/component %u: goahead=%u, processinnextiteration=%d\n",
               i,
               h_goaheadnodeofcomponent[i],
               (int)h_processinnextiteration[i]);
    }

    printf("Expected: processinnextiteration[0] == 1\n");

    cudaFree(d_mstwt);
    cudaFree(d_eleminwts);
    cudaFree(d_minwtcomponent);
    cudaFree(d_partners);
    cudaFree(d_phore);
    cudaFree(d_processinnextiteration);
    cudaFree(d_goaheadnodeofcomponent);

    dgraph.deallocOnDevice();
    hgraph.deallocOnHost();

    return 0;
}