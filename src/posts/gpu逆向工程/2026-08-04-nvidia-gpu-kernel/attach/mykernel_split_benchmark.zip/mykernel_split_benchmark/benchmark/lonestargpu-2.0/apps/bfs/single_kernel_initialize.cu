// Auto-generated CUDA kernel file: initialize
// Standalone runnable version

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MYINFINITY 100000000
typedef unsigned foru;

// ===== Kernel =====
__global__
void initialize(foru *dist, unsigned int nv) {
    unsigned int ii = blockIdx.x * blockDim.x + threadIdx.x;
    if (ii < nv) {
        dist[ii] = MYINFINITY;
    }
}

int main(int argc, char **argv) {
    unsigned int nv = 16;
    if (argc >= 2) nv = (unsigned int)atoi(argv[1]);

    if (nv == 0) {
        fprintf(stderr, "nv must be > 0\n");
        return -1;
    }

    foru *h_dist = (foru *)malloc(sizeof(foru) * nv);
    foru *d_dist = NULL;

    if (!h_dist) {
        fprintf(stderr, "malloc h_dist failed\n");
        return -1;
    }

    cudaError_t err = cudaMalloc((void **)&d_dist, sizeof(foru) * nv);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_dist failed: %s\n", cudaGetErrorString(err));
        free(h_dist);
        return -1;
    }

    int block = 256;
    int grid = (nv + block - 1) / block;

    initialize<<<grid, block>>>(d_dist, nv);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        free(h_dist);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        free(h_dist);
        return -1;
    }

    err = cudaMemcpy(h_dist, d_dist, sizeof(foru) * nv, cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMemcpy D2H failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        free(h_dist);
        return -1;
    }

    printf("initialize finished, nv=%u\n", nv);
    for (unsigned int i = 0; i < (nv < 16 ? nv : 16); i++) {
        printf("dist[%u] = %u\n", i, h_dist[i]);
    }

    cudaFree(d_dist);
    free(h_dist);
    return 0;
}