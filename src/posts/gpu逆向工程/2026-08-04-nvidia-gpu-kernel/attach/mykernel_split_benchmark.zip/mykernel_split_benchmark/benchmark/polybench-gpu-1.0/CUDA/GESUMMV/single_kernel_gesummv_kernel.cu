// Auto-generated CUDA kernel file: gesummv_kernel
// Extracted from: polybench-gpu-1.0/CUDA/GESUMMV/gesummv.cu
// Original line: 104

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <cuda.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define ALPHA 43532.0f  // from line 34
#define BETA 12313.0f  // from line 35
#define N 4096  // from line 27

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/GESUMMV/gesummv.cu:38

// ===== Kernel =====
// Kernel: gesummv_kernel (line 104)
__global__ void gesummv_kernel(DATA_TYPE *a, DATA_TYPE *b, DATA_TYPE *x, DATA_TYPE *y, DATA_TYPE *tmp) {

	int i = blockIdx.x * blockDim.x + threadIdx.x;

	if (i < N)
	{
		int j;
		for(j = 0; j < N; j++)
		{	
			tmp[i] += a[i * N + j] * x[j];
			y[i] += b[i * N + j] * x[j];
		}
		y[i] = ALPHA * tmp[i] + BETA * y[i];
	}

}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_mat = (size_t)N * N;
    const size_t size_vec = N;

    DATA_TYPE *h_a   = (DATA_TYPE*)malloc(size_mat * sizeof(DATA_TYPE));
    DATA_TYPE *h_b   = (DATA_TYPE*)malloc(size_mat * sizeof(DATA_TYPE));
    DATA_TYPE *h_x   = (DATA_TYPE*)malloc(size_vec * sizeof(DATA_TYPE));
    DATA_TYPE *h_y   = (DATA_TYPE*)malloc(size_vec * sizeof(DATA_TYPE));
    DATA_TYPE *h_tmp = (DATA_TYPE*)malloc(size_vec * sizeof(DATA_TYPE));

    DATA_TYPE *d_a   = nullptr;
    DATA_TYPE *d_b   = nullptr;
    DATA_TYPE *d_x   = nullptr;
    DATA_TYPE *d_y   = nullptr;
    DATA_TYPE *d_tmp = nullptr;

    if (!h_a || !h_b || !h_x || !h_y || !h_tmp) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_mat; ++i) {
        h_a[i] = (DATA_TYPE)(i % 100) / 100.0f;
        h_b[i] = (DATA_TYPE)((i + 1) % 100) / 100.0f;
    }

    for (size_t i = 0; i < size_vec; ++i) {
        h_x[i] = (DATA_TYPE)(i % 100) / 100.0f;
        h_y[i] = 0.0f;
        h_tmp[i] = 0.0f;
    }

    err = cudaMalloc((void**)&d_a, size_mat * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_a failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_b, size_mat * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_b failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_x, size_vec * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_x failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_y, size_vec * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_y failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_tmp, size_vec * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_tmp failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_a, h_a, size_mat * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D a failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_b, h_b, size_mat * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D b failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_x, h_x, size_vec * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D x failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_y, h_y, size_vec * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D y failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_tmp, h_tmp, size_vec * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D tmp failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((N + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    gesummv_kernel<<<gridSize, blockSize>>>(d_a, d_b, d_x, d_y, d_tmp);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("gesummv_kernel execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_y, d_y, size_vec * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H y failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("y[0] = %f\n", (double)h_y[0]);

    cudaFree(d_a);
    cudaFree(d_b);
    cudaFree(d_x);
    cudaFree(d_y);
    cudaFree(d_tmp);

    free(h_a);
    free(h_b);
    free(h_x);
    free(h_y);
    free(h_tmp);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}