// Auto-generated CUDA kernel file: spmv_min_dot_plus_kernel
// Extracted from: pannotia/sssp/kernel.cu
// Original line: 69

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: spmv_min_dot_plus_kernel (line 69)
__global__ void
spmv_min_dot_plus_kernel(const int num_rows, int *row, int *col, int *data,
                         int *x, int *y) {

    // Get my workitem id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;

    if (tid < num_rows) {
        // Get the start and end pointers
        int row_start = row[tid];
        int row_end = row[tid + 1];

        // Perform + for each pair of elements and a reduction with min
        int min = x[tid];
        for (int i = row_start; i < row_end; i++) {
            if (data[i] + x[col[i]] < min) {
                min = data[i] + x[col[i]];
            }
        }
        y[tid] = min;
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_rows = 1024;
    const int num_edges = num_rows - 1;

    const size_t size_row = (size_t)(num_rows + 1) * sizeof(int);
    const size_t size_col = (size_t)num_edges * sizeof(int);
    const size_t size_data = (size_t)num_edges * sizeof(int);
    const size_t size_vec = (size_t)num_rows * sizeof(int);

    int *h_row = (int*)malloc(size_row);
    int *h_col = (int*)malloc(size_col);
    int *h_data = (int*)malloc(size_data);
    int *h_x = (int*)malloc(size_vec);
    int *h_y = (int*)malloc(size_vec);

    int *d_row = nullptr;
    int *d_col = nullptr;
    int *d_data = nullptr;
    int *d_x = nullptr;
    int *d_y = nullptr;

    if (!h_row || !h_col || !h_data || !h_x || !h_y) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_col);
        free(h_data);
        free(h_x);
        free(h_y);
        return -1;
    }

    for (int i = 0; i < num_rows; ++i) {
        h_row[i] = i;
        h_x[i] = 1000000;
        h_y[i] = 0;
    }
    h_row[num_rows] = num_edges;

    for (int i = 0; i < num_edges; ++i) {
        h_col[i] = i + 1;
        h_data[i] = 1;
    }

    h_x[0] = 0;

    err = cudaMalloc((void**)&d_row, size_row);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_row failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_col, size_col);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_col failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        return -1;
    }

    err = cudaMalloc((void**)&d_data, size_data);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_data failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_col);
        return -1;
    }

    err = cudaMalloc((void**)&d_x, size_vec);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_x failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_col);
        cudaFree(d_data);
        return -1;
    }

    err = cudaMalloc((void**)&d_y, size_vec);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_y failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_col);
        cudaFree(d_data);
        cudaFree(d_x);
        return -1;
    }

    cudaMemcpy(d_row, h_row, size_row, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col, h_col, size_col, cudaMemcpyHostToDevice);
    cudaMemcpy(d_data, h_data, size_data, cudaMemcpyHostToDevice);
    cudaMemcpy(d_x, h_x, size_vec, cudaMemcpyHostToDevice);
    cudaMemcpy(d_y, h_y, size_vec, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_rows + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    spmv_min_dot_plus_kernel<<<gridSize, blockSize>>>(num_rows, d_row, d_col, d_data, d_x, d_y);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_y, d_y, size_vec, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("spmv_min_dot_plus_kernel execution time: %.3f ms\n", ms);

    printf("y[0] = %d\n", h_y[0]);
    printf("y[1] = %d\n", h_y[1]);
    printf("y[2] = %d\n", h_y[2]);
    printf("y[last] = %d\n", h_y[num_rows - 1]);

    cudaFree(d_row);
    cudaFree(d_col);
    cudaFree(d_data);
    cudaFree(d_x);
    cudaFree(d_y);

    free(h_row);
    free(h_col);
    free(h_data);
    free(h_x);
    free(h_y);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}