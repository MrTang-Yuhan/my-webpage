// Auto-generated CUDA kernel file: Pathcalc_Portfolio_KernelGPU
// Extracted from: ispass-2009/LIB/libor.cu
// Original line: 198

// ===== Includes =====
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// ===== Macro Definitions =====
#define L2_SIZE 3280 //NN*(NMAT+1)  // from line 16
#define NMAT 40  // from line 15
#define NN 80  // from line 14
#define NPATH 4096  // from line 18
#define S(x,n) ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n)))  // from line 172 (from ispass-2009/STO/md5_cpu.cpp)
// #define r_v      0.461600006103516E+03  // from line 15 (from ispass-2009/WP/wsm5_constants.h)
// #define rv      r_v  // from line 16 (from ispass-2009/WP/wsm5_constants.h)

#define N 80
#define Nmat 40
#define Nopt 15

typedef struct {
    int dummy;
} pathblock;

// 设备常量
__device__ __constant__ float delta;
__device__ __constant__ float lambda[NN];
__device__ __constant__ int maturities[Nopt];
__device__ __constant__ float swaprates[Nopt];

// ===== Type Definitions =====
class Float4 {
     public:
       float x, y, z, w;

       __device__ const Float4
       operator+(const Float4& iv) const {
          Float4 rv ;
          rv.x = x + iv.x ;
          rv.y = y + iv.y ;
          rv.z = z + iv.z ;
          rv.w = w + iv.w ;
          return Float4( rv ) ;
       }
       __device__ const Float4
       operator*(const Float4& iv) const {
          Float4 rv ;
          rv.x = x * iv.x ;
          rv.y = y * iv.y ;
          rv.z = z * iv.z ;
          rv.w = w * iv.w ;
          return Float4( rv ) ;
       }
       __device__ const Float4
       operator/(const Float4& iv) const {
          Float4 rv ;
          rv.x = x / iv.x ;
          rv.y = y / iv.y ;
          rv.z = z / iv.z ;
          rv.w = w / iv.w ;
          return Float4( rv ) ;
       }
       __device__ const Float4
       operator-(const Float4& iv) const {
          Float4 rv ;
          rv.x = x - iv.x ;
          rv.y = y - iv.y ;
          rv.z = z - iv.z ;
          rv.w = w - iv.w ;
          return Float4( rv ) ;
       }

       __device__ const Float4
       operator+(const float iv) const {
          Float4 rv ;
          rv.x = x + iv ;
          rv.y = y + iv ;
          rv.z = z + iv ;
          rv.w = w + iv ;
          return Float4( rv ) ;
       }
       __device__ const Float4
       operator*(const float iv) const {
          Float4 rv ;
          rv.x = x * iv ;
          rv.y = y * iv ;
          rv.z = z * iv ;
          rv.w = w * iv ;
          return Float4( rv ) ;
       }
       __device__ const Float4
       operator/(const float iv) const {
          Float4 rv ;
          rv.x = x / iv ;
          rv.y = y / iv ;
          rv.z = z / iv ;
          rv.w = w / iv ;
          return Float4( rv ) ;
       }
       __device__ const Float4
       operator-(const float iv) const {
          Float4 rv ;
          rv.x = x - iv ;
          rv.y = y - iv ;
          rv.z = z - iv ;
          rv.w = w - iv ;
          return Float4( rv ) ;
       }
       __device__ const Float4
       operator-() const {
          Float4 rv ;
          rv.x = -x  ;
          rv.y = -y  ;
          rv.z = -z  ;
          rv.w = -w  ;
          return Float4( rv ) ;
       }

       __device__ void operator=(const float iv) {
           x = iv ;
           y = iv ;
           z = iv ;
           w = iv ;
       }

       __device__ void operator+=(const Float4 iv) {
           x += iv.x ;
           y += iv.y ;
           z += iv.z ;
           w += iv.w ;
       }
       __device__ void operator-=(const Float4 iv) {
           x -= iv.x ;
           y -= iv.y ;
           z -= iv.z ;
           w -= iv.w ;
       }

     }; // from ispass-2009/WP/util.h:1

// ===== Global Variables =====
pathblock path[8192];  // global (from ispass-2009/MUM/suffix-tree.cpp:1709)

// ===== Function Forward Declarations =====
__device__ void path_calc_b1(float *L, float *z, float *L2);
__device__ void path_calc_b2(float *L_b, float *z, float *L2);
__device__ float portfolio_b(float *L, float *L_b);
__device__ Float4 sqrt ( const Float4 a );

// ===== Device/Helper Functions =====
// Function: path_calc_b1 (from ispass-2009/LIB/libor.cu:52)
__device__ void path_calc_b1(float *L, float *z, float *L2) {

  int   i, n;
  float sqez, lam, con1, v, vrat;

  for (i=0; i<N; i++) L2[i] = L[i];
   
  for(n=0; n<Nmat; n++) {
    sqez = sqrt(delta)*z[n];
    v = 0.0;

    for (i=n+1; i<N; i++) {
      lam  = lambda[i-n-1];
      con1 = delta*lam;
      v   += __fdividef(con1*L[i],1.0+delta*L[i]);
      vrat = __expf(con1*v + lam*(sqez-0.5*con1));
      L[i] = L[i]*vrat;

      // store these values for reverse path //
      L2[i+(n+1)*N] = L[i];
    }
  }

}

// Function: path_calc_b2 (from ispass-2009/LIB/libor.cu:79)
__device__ void path_calc_b2(float *L_b, float *z, float *L2) {

  int   i, n;
  float faci, v1;

  for (n=Nmat-1; n>=0; n--) {
    v1 = 0.0;
    for (i=N-1; i>n; i--) {
      v1    += lambda[i-n-1]*L2[i+(n+1)*N]*L_b[i];
      faci   = __fdividef(delta,1.0+delta*L2[i+n*N]);
      L_b[i] = L_b[i]*__fdividef(L2[i+(n+1)*N],L2[i+n*N])
              + v1*lambda[i-n-1]*faci*faci;
 
    }
  }

}

// Function: portfolio_b (from ispass-2009/LIB/libor.cu:99)
__device__ float portfolio_b(float *L, float *L_b) {

  int   m, n;
  float b, s, swapval,v;
  float B[NMAT], S[NMAT], B_b[NMAT], S_b[NMAT];

  b = 1.0;
  s = 0.0;
  for (m=0; m<N-Nmat; m++) {
    n    = m + Nmat;
    b    = __fdividef(b,1.0+delta*L[n]);
    s    = s + delta*b;
    B[m] = b;
    S[m] = s;
  }

  v = 0.0;

  for (m=0; m<N-Nmat; m++) {
    B_b[m] = 0;
    S_b[m] = 0;
  }

  for (n=0; n<Nopt; n++){
    m = maturities[n] - 1;
    swapval = B[m] + swaprates[n]*S[m] - 1.0;
    if (swapval<0) {
      v     += -100*swapval;
      S_b[m] += -100*swaprates[n];
      B_b[m] += -100;
    }
  }

  for (m=N-Nmat-1; m>=0; m--) {
    n = m + Nmat;
    B_b[m] += delta*S_b[m];
    L_b[n]  = -B_b[m]*B[m]*__fdividef(delta,1.0+delta*L[n]);
    if (m>0) {
      S_b[m-1] += S_b[m];
      B_b[m-1] += __fdividef(B_b[m],1.+delta*L[n]);
    }
  }

  // apply discount //

  b = 1.0;
  for (n=0; n<Nmat; n++) b = b/(1.0+delta*L[n]);

  v = b*v;

  for (n=0; n<Nmat; n++){
    L_b[n] = -v*delta/(1.0+delta*L[n]);
  }

  for (n=Nmat; n<N; n++){
    L_b[n] = b*L_b[n];
  }

  return v;

}

// Function: sqrt (from ispass-2009/WP/util.h:231)
__device__ Float4 sqrt ( const Float4 a ) {

    Float4 c  ;
    c.x = sqrt(a.x) ; c.y = sqrt(a.y) ; c.z = sqrt(a.z) ; c.w = sqrt(a.w) ;
    return(c) ;

}

// ===== Kernel =====
// Kernel: Pathcalc_Portfolio_KernelGPU (line 198)
__global__ void Pathcalc_Portfolio_KernelGPU(float *d_v, float *d_Lb) {

  const int     tid = blockDim.x * blockIdx.x + threadIdx.x;
  const int threadN = blockDim.x * gridDim.x;

  int   i,path;
  float L[NN], L2[L2_SIZE], z[NN];
  float *L_b = L;
  
  /* Monte Carlo LIBOR path calculation*/

  for(path = tid; path < NPATH; path += threadN){
    // initialise the data for current thread
    for (i=0; i<N; i++) {
      // for real application, z should be randomly generated
      z[i] = 0.3;
      L[i] = 0.05;
    }
    path_calc_b1(L, z, L2);
    d_v[path] = portfolio_b(L,L_b);
    path_calc_b2(L_b, z, L2);
    d_Lb[path] = L_b[NN-1];
  }

}

int main() {
    float *d_v = NULL;
    float *d_Lb = NULL;

    float h_v[NPATH];
    float h_Lb[NPATH];

    // 初始化 host 侧参数
    float h_delta = 0.25f;
    float h_lambda[NN];
    int   h_maturities[Nopt];
    float h_swaprates[Nopt];

    for (int i = 0; i < NN; i++) {
        h_lambda[i] = 0.2f + 0.001f * i;
    }

    for (int i = 0; i < Nopt; i++) {
        h_maturities[i] = i + 1;
        h_swaprates[i] = 0.04f + 0.001f * i;
    }

    // 拷贝常量到 GPU
    cudaMemcpyToSymbol(delta, &h_delta, sizeof(float));
    cudaMemcpyToSymbol(lambda, h_lambda, sizeof(float) * NN);
    cudaMemcpyToSymbol(maturities, h_maturities, sizeof(int) * Nopt);
    cudaMemcpyToSymbol(swaprates, h_swaprates, sizeof(float) * Nopt);

    // 分配设备内存
    cudaError_t err = cudaMalloc((void**)&d_v, sizeof(float) * NPATH);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc(d_v) failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_Lb, sizeof(float) * NPATH);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc(d_Lb) failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_v);
        return -1;
    }

    // 可选：清零
    cudaMemset(d_v, 0, sizeof(float) * NPATH);
    cudaMemset(d_Lb, 0, sizeof(float) * NPATH);

    // kernel 配置
    dim3 block(256);
    dim3 grid((NPATH + block.x - 1) / block.x);

    // 启动 kernel
    Pathcalc_Portfolio_KernelGPU<<<grid, block>>>(d_v, d_Lb);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_v);
        cudaFree(d_Lb);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_v);
        cudaFree(d_Lb);
        return -1;
    }

    // 拷回结果
    err = cudaMemcpy(h_v, d_v, sizeof(float) * NPATH, cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMemcpy h_v failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_v);
        cudaFree(d_Lb);
        return -1;
    }

    err = cudaMemcpy(h_Lb, d_Lb, sizeof(float) * NPATH, cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMemcpy h_Lb failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_v);
        cudaFree(d_Lb);
        return -1;
    }

    // 打印前 10 个结果
    printf("Pathcalc_Portfolio_KernelGPU output (first 10):\n");
    for (int i = 0; i < 10; i++) {
        printf("h_v[%d] = %f, h_Lb[%d] = %f\n", i, h_v[i], i, h_Lb[i]);
    }

    cudaFree(d_v);
    cudaFree(d_Lb);
    return 0;
}