// Auto-generated CUDA kernel file: executeFCLayerCUDA
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 932

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeFCLayerCUDA (line 932)
__global__ void executeFCLayerCUDA(float *Layer_InNeurons_GPU,float *Layer_Weights_GPU,float *Layer_OutNeurons_GPU,int input) {

        float product = 0.0;
        int out = blockIdx.x; //* 32 + blockIdx.y;
	int weight =  out * input;
	//for(int out=0; out < 1000 ; out++)
	{
		for(int in = 0; in < input; in++)
		{
                     product += Layer_InNeurons_GPU[in] * Layer_Weights_GPU[weight+in];
		}
		Layer_OutNeurons_GPU[out] = product;
		product = 0.0;
	}



}



int main() {
    const int input = 128;
    const int out = 10;

    size_t in_size = input;
    size_t weight_size = (size_t)out * input;
    size_t out_size = out;

    float *h_in = (float*)malloc(in_size * sizeof(float));
    float *h_weight = (float*)malloc(weight_size * sizeof(float));
    float *h_out = (float*)malloc(out_size * sizeof(float));

    if (!h_in || !h_weight || !h_out) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (int i = 0; i < input; ++i) h_in[i] = (float)(i % 9) * 0.1f;
    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (float)(i % 7) * 0.01f;

    float *d_in = NULL, *d_weight = NULL, *d_out = NULL;
    CHECK(cudaMalloc((void**)&d_in, in_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out, out_size * sizeof(float)));

    CHECK(cudaMemcpy(d_in, h_in, in_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_out, 0, out_size * sizeof(float)));

    dim3 grid(out);
    dim3 block(1);

    executeFCLayerCUDA<<<grid, block>>>(d_in, d_weight, d_out, input);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeFCLayerCUDA done.\n");
    for (int i = 0; i < out; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_weight);
    cudaFree(d_out);

    free(h_in);
    free(h_weight);
    free(h_out);

    return 0;
}