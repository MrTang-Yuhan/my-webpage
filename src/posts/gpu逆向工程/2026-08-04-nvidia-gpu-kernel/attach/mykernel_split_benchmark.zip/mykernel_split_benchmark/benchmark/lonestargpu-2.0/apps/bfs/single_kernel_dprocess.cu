// Auto-generated CUDA kernel file: dprocess
// Corrected standalone runnable version

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MYINFINITY 100000000
typedef unsigned foru;

// ===== Kernel =====
__global__
void dprocess(float *matrix, foru *dist, unsigned int *prev, bool *relaxed, unsigned int nvertices) {
    __shared__ volatile unsigned int dNVERTICES;

    if (threadIdx.x == 0) dNVERTICES = nvertices;
    __syncthreads();

    unsigned int ii = blockIdx.x * blockDim.x + threadIdx.x;
    unsigned int v;
    unsigned int jj;

    if (ii < dNVERTICES) {
        unsigned int u = dNVERTICES;
        foru mm = MYINFINITY;

        for (jj = 0; jj < dNVERTICES; ++jj) {
            if (relaxed[jj] == false && dist[jj] < mm) {
                mm = dist[jj];
                u = jj;
            }
        }

        if (u != dNVERTICES && dist[u] != MYINFINITY) {
            relaxed[u] = true;
            for (v = 0; v < dNVERTICES; ++v) {
                if (matrix[u * dNVERTICES + v] > 0) {
                    foru alt = dist[u] + (foru)matrix[u * dNVERTICES + v];
                    if (alt < dist[v]) {
                        dist[v] = alt;
                        prev[v] = u;
                    }
                }
            }
        }
    }
}

int main(int argc, char **argv) {
    unsigned int n = 4;
    if (argc >= 2) n = (unsigned int)atoi(argv[1]);

    if (n == 0) {
        fprintf(stderr, "n must be > 0\n");
        return -1;
    }

    size_t matSize = (size_t)n * n * sizeof(float);
    size_t vecSize = (size_t)n * sizeof(foru);
    size_t prevSize = (size_t)n * sizeof(unsigned int);
    size_t boolSize = (size_t)n * sizeof(bool);

    float *h_matrix = (float *)malloc(matSize);
    foru *h_dist = (foru *)malloc(vecSize);
    unsigned int *h_prev = (unsigned int *)malloc(prevSize);
    bool *h_relaxed = (bool *)malloc(boolSize);

    float *d_matrix = NULL;
    foru *d_dist = NULL;
    unsigned int *d_prev = NULL;
    bool *d_relaxed = NULL;

    if (!h_matrix || !h_dist || !h_prev || !h_relaxed) {
        fprintf(stderr, "host malloc failed\n");
        free(h_matrix);
        free(h_dist);
        free(h_prev);
        free(h_relaxed);
        return -1;
    }

    for (unsigned int i = 0; i < n; i++) {
        for (unsigned int j = 0; j < n; j++) {
            h_matrix[i * n + j] = 0.0f;
        }
        h_dist[i] = (i == 0 ? 0 : MYINFINITY);
        h_prev[i] = (unsigned int)-1;
        h_relaxed[i] = false;
    }

    for (unsigned int i = 0; i + 1 < n; i++) {
        h_matrix[i * n + (i + 1)] = 1.0f;
    }

    cudaError_t err;

    err = cudaMalloc((void **)&d_matrix, matSize);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_matrix failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void **)&d_dist, vecSize);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_dist failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void **)&d_prev, prevSize);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_prev failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void **)&d_relaxed, boolSize);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_relaxed failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(d_matrix, h_matrix, matSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_dist, h_dist, vecSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_prev, h_prev, prevSize, cudaMemcpyHostToDevice);
    cudaMemcpy(d_relaxed, h_relaxed, boolSize, cudaMemcpyHostToDevice);

    int block = 256;
    int grid = (n + block - 1) / block;

    for (unsigned int iter = 0; iter < n; ++iter) {
        dprocess<<<grid, block>>>(d_matrix, d_dist, d_prev, d_relaxed, n);

        err = cudaGetLastError();
        if (err != cudaSuccess) {
            fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
            return -1;
        }

        err = cudaDeviceSynchronize();
        if (err != cudaSuccess) {
            fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
            return -1;
        }
    }

    cudaMemcpy(h_dist, d_dist, vecSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_prev, d_prev, prevSize, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_relaxed, d_relaxed, boolSize, cudaMemcpyDeviceToHost);

    printf("dprocess finished\n");
    for (unsigned int i = 0; i < n; i++) {
        printf("i=%u dist=%u prev=%u relaxed=%d\n",
               i, h_dist[i], h_prev[i], (int)h_relaxed[i]);
    }

    cudaFree(d_matrix);
    cudaFree(d_dist);
    cudaFree(d_prev);
    cudaFree(d_relaxed);

    free(h_matrix);
    free(h_dist);
    free(h_prev);
    free(h_relaxed);
    return 0;
}