// Auto-generated CUDA kernel file: backtrack_kernel
// Extracted from: pannotia/bc/kernel.cu
// Original line: 122

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: backtrack_kernel (line 122)
__global__ void
backtrack_kernel(int *row, int *col, int *d, float *rho, float *sigma,
                 const int num_nodes, const int num_edges, const int dist,
                 const int s, float* bc) {

    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    // Navigate the current layer
    if (tid < num_nodes && d[tid] == dist - 1) {

        int start = row[tid];
        int end;
        if (tid + 1 < num_nodes)
            end = row[tid + 1];
        else
            end = num_edges;

        // Get the starting and ending pointers
        // of the neighbor list in the reverse graph
        for (int edge = start; edge < end; edge++) {
            int w = col[edge];
            // Update the sigma value traversing back
            if (d[w] == dist - 2)
                atomicAdd(&sigma[w], rho[w] / rho[tid] * (1 + sigma[tid]));
        }

        // Update the BC value
        if (tid != s)
            bc[tid] = bc[tid] + sigma[tid];
    }


}

int main(int argc, char** argv) {
    const int num_nodes = 1024;
    const int num_edges = 1;
    const int s = 0;
    const int dist = 2;

    const size_t size_row = (size_t)num_nodes * sizeof(int);
    const size_t size_col = (size_t)num_edges * sizeof(int);
    const size_t size_int = (size_t)num_nodes * sizeof(int);
    const size_t size_float = (size_t)num_nodes * sizeof(float);

    int *h_row = (int*)malloc(size_row);
    int *h_col = (int*)malloc(size_col);
    int *h_d = (int*)malloc(size_int);
    float *h_rho = (float*)malloc(size_float);
    float *h_sigma = (float*)malloc(size_float);
    float *h_bc = (float*)malloc(size_float);

    int *d_row = nullptr;
    int *d_col = nullptr;
    int *d_d = nullptr;
    float *d_rho = nullptr;
    float *d_sigma = nullptr;
    float *d_bc = nullptr;

    if (!h_row || !h_col || !h_d || !h_rho || !h_sigma || !h_bc) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_col);
        free(h_d);
        free(h_rho);
        free(h_sigma);
        free(h_bc);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_row[i] = 1;
        h_d[i] = -1;
        h_rho[i] = 1.0f;
        h_sigma[i] = 0.0f;
        h_bc[i] = 0.0f;
    }

    h_row[0] = 0;
    h_row[1] = 0;
    for (int i = 2; i < num_nodes; ++i) {
        h_row[i] = 1;
    }

    h_col[0] = 0;

    h_d[0] = 0;
    h_d[1] = 1;

    h_rho[0] = 1.0f;
    h_rho[1] = 1.0f;

    h_sigma[0] = 0.0f;
    h_sigma[1] = 0.5f;

    cudaError_t err;

    cudaMalloc((void**)&d_row, size_row);
    cudaMalloc((void**)&d_col, size_col);
    cudaMalloc((void**)&d_d, size_int);
    cudaMalloc((void**)&d_rho, size_float);
    cudaMalloc((void**)&d_sigma, size_float);
    cudaMalloc((void**)&d_bc, size_float);

    cudaMemcpy(d_row, h_row, size_row, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col, h_col, size_col, cudaMemcpyHostToDevice);
    cudaMemcpy(d_d, h_d, size_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_rho, h_rho, size_float, cudaMemcpyHostToDevice);
    cudaMemcpy(d_sigma, h_sigma, size_float, cudaMemcpyHostToDevice);
    cudaMemcpy(d_bc, h_bc, size_float, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    backtrack_kernel<<<gridSize, blockSize>>>(
        d_row,
        d_col,
        d_d,
        d_rho,
        d_sigma,
        num_nodes,
        num_edges,
        dist,
        s,
        d_bc
    );
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_col);
        cudaFree(d_d);
        cudaFree(d_rho);
        cudaFree(d_sigma);
        cudaFree(d_bc);
        free(h_row);
        free(h_col);
        free(h_d);
        free(h_rho);
        free(h_sigma);
        free(h_bc);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_col);
        cudaFree(d_d);
        cudaFree(d_rho);
        cudaFree(d_sigma);
        cudaFree(d_bc);
        free(h_row);
        free(h_col);
        free(h_d);
        free(h_rho);
        free(h_sigma);
        free(h_bc);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaEventSynchronize(stop);

    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("backtrack_kernel execution time: %.3f ms\n", milliseconds);

    cudaMemcpy(h_sigma, d_sigma, size_float, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_bc, d_bc, size_float, cudaMemcpyDeviceToHost);

    printf("sigma[0] = %f\n", h_sigma[0]);
    printf("sigma[1] = %f\n", h_sigma[1]);
    printf("bc[0] = %f\n", h_bc[0]);
    printf("bc[1] = %f\n", h_bc[1]);

    cudaFree(d_row);
    cudaFree(d_col);
    cudaFree(d_d);
    cudaFree(d_rho);
    cudaFree(d_sigma);
    cudaFree(d_bc);

    free(h_row);
    free(h_col);
    free(h_d);
    free(h_rho);
    free(h_sigma);
    free(h_bc);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}