// Auto-generated CUDA kernel file: srad
// Extracted from: rodinia/2.0-ft/srad/srad_v1/srad_kernel.cu
// Original line: 4

// ===== Includes =====
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <cuda.h>
#include <stdio.h>
#include "define.c"
// #include "extract_kernel.cu"
// #include "prepare_kernel.cu"
// #include "reduce_kernel.cu"
// #include "srad_kernel.cu"
// #include "srad2_kernel.cu"
// #include "compress_kernel.cu"
// #include "graphics.c"
// #include "resize.c"
// #include "timer.c"

// #include "device.c"				// (in library path specified to compiler)	needed by for device functions
// ===== Kernel =====
// Kernel: srad (line 4)
__global__ void srad(	fp d_lambda, 
									 int d_Nr, 
									 int d_Nc, 
									 long d_Ne, 
									 int *d_iN, 
									 int *d_iS, 
									 int *d_jE, 
									 int *d_jW, 
									 fp *d_dN, 
									 fp *d_dS, 
									 fp *d_dE, 
									 fp *d_dW, 
									 fp d_q0sqr, 
									 fp *d_c, 
									 fp *d_I) {


	// indexes
    int bx = blockIdx.x;													// get current horizontal block index
	int tx = threadIdx.x;													// get current horizontal thread index
	int ei = bx*NUMBER_THREADS+tx;											// more threads than actual elements !!!
	int row;																// column, x position
	int col;																// row, y position

	// variables
	fp d_Jc;
	fp d_dN_loc, d_dS_loc, d_dW_loc, d_dE_loc;  // [参数: d_dN, d_dS, d_dE, d_dW]
	fp d_c_loc;  // [参数: d_c]
	fp d_G2,d_L,d_num,d_den,d_qsqr;
	
	// figure out row/col location in new matrix
	row = (ei+1) % d_Nr - 1;													// (0-n) row  // [参数: d_Nr]
	col = (ei+1) / d_Nr + 1 - 1;												// (0-n) column  // [参数: d_Nr]
	if((ei+1) % d_Nr == 0){  // [参数: d_Nr]
		row = d_Nr - 1;  // [参数: d_Nr]
		col = col - 1;
	}
	
	if(ei<d_Ne){															// make sure that only threads matching jobs run  // [参数: d_Ne]
		
		// directional derivatives, ICOV, diffusion coefficent
		d_Jc = d_I[ei];														// get value of the current element  // [参数: d_I]
		
		// directional derivates (every element of IMAGE)(try to copy to shared memory or temp files)
		d_dN_loc = d_I[d_iN[row] + d_Nr*col] - d_Jc;						// north direction derivative  // [参数: d_Nr, d_iN, d_dN, d_I]
		d_dS_loc = d_I[d_iS[row] + d_Nr*col] - d_Jc;						// south direction derivative  // [参数: d_Nr, d_iS, d_dS, d_I]
		d_dW_loc = d_I[row + d_Nr*d_jW[col]] - d_Jc;						// west direction derivative  // [参数: d_Nr, d_jW, d_dW, d_I]
		d_dE_loc = d_I[row + d_Nr*d_jE[col]] - d_Jc;						// east direction derivative  // [参数: d_Nr, d_jE, d_dE, d_I]
	         
		// normalized discrete gradient mag squared (equ 52,53)
		d_G2 = (d_dN_loc*d_dN_loc + d_dS_loc*d_dS_loc + d_dW_loc*d_dW_loc + d_dE_loc*d_dE_loc) / (d_Jc*d_Jc);	// gradient (based on derivatives)  // [参数: d_dN, d_dS, d_dE, d_dW]
		
		// normalized discrete laplacian (equ 54)
		d_L = (d_dN_loc + d_dS_loc + d_dW_loc + d_dE_loc) / d_Jc;			// laplacian (based on derivatives)  // [参数: d_dN, d_dS, d_dE, d_dW]

		// ICOV (equ 31/35)
		d_num  = (0.5*d_G2) - ((1.0/16.0)*(d_L*d_L)) ;						// num (based on gradient and laplacian)
		d_den  = 1 + (0.25*d_L);												// den (based on laplacian)
		d_qsqr = d_num/(d_den*d_den);										// qsqr (based on num and den)
	 
		// diffusion coefficent (equ 33) (every element of IMAGE)
		d_den = (d_qsqr-d_q0sqr) / (d_q0sqr * (1+d_q0sqr)) ;				// den (based on qsqr and q0sqr)  // [参数: d_q0sqr]
		d_c_loc = 1.0 / (1.0+d_den) ;										// diffusion coefficient (based on den)  // [参数: d_c]
	    
		// saturate diffusion coefficent to 0-1 range
		if (d_c_loc < 0){													// if diffusion coefficient < 0  // [参数: d_c]
			d_c_loc = 0;													// ... set to 0  // [参数: d_c]
		}
		else if (d_c_loc > 1){												// if diffusion coefficient > 1  // [参数: d_c]
			d_c_loc = 1;													// ... set to 1  // [参数: d_c]
		}

		// save data to global memory
		d_dN[ei] = d_dN_loc;   // [参数: d_dN]
		d_dS[ei] = d_dS_loc;   // [参数: d_dS]
		d_dW[ei] = d_dW_loc;   // [参数: d_dW]
		d_dE[ei] = d_dE_loc;  // [参数: d_dE]
		d_c[ei] = d_c_loc;  // [参数: d_c]
			
	}
	

}


// 在末尾追加
int main() {
    const int Nr = 512;  // 行数
    const int Nc = 512;  // 列数
    const long Ne = Nr * Nc;
    const fp lambda = 0.5;
    const fp q0sqr = 0.5;
    
    // 分配主机内存
    int *h_iN = (int*)malloc(Nr * sizeof(int));
    int *h_iS = (int*)malloc(Nr * sizeof(int));
    int *h_jE = (int*)malloc(Nc * sizeof(int));
    int *h_jW = (int*)malloc(Nc * sizeof(int));
    
    // 初始化邻居索引（边界处理）
    for (int i = 0; i < Nr; i++) {
        h_iN[i] = (i == 0) ? 0 : i - 1;
        h_iS[i] = (i == Nr - 1) ? Nr - 1 : i + 1;
    }
    for (int j = 0; j < Nc; j++) {
        h_jW[j] = (j == 0) ? 0 : j - 1;
        h_jE[j] = (j == Nc - 1) ? Nc - 1 : j + 1;
    }
    
    fp *h_I = (fp*)malloc(Ne * sizeof(fp));
    for (long i = 0; i < Ne; i++) {
        h_I[i] = exp((rand() % 255) / 255.0f);  // 模拟图像数据
    }
    
    // 分配 GPU 内存
    int *d_iN, *d_iS, *d_jE, *d_jW;
    fp *d_dN, *d_dS, *d_dE, *d_dW, *d_c, *d_I;
    
    cudaMalloc(&d_iN, Nr * sizeof(int));
    cudaMalloc(&d_iS, Nr * sizeof(int));
    cudaMalloc(&d_jE, Nc * sizeof(int));
    cudaMalloc(&d_jW, Nc * sizeof(int));
    cudaMalloc(&d_dN, Ne * sizeof(fp));
    cudaMalloc(&d_dS, Ne * sizeof(fp));
    cudaMalloc(&d_dE, Ne * sizeof(fp));
    cudaMalloc(&d_dW, Ne * sizeof(fp));
    cudaMalloc(&d_c, Ne * sizeof(fp));
    cudaMalloc(&d_I, Ne * sizeof(fp));
    
    cudaMemcpy(d_iN, h_iN, Nr * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_iS, h_iS, Nr * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_jE, h_jE, Nc * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_jW, h_jW, Nc * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_I, h_I, Ne * sizeof(fp), cudaMemcpyHostToDevice);
    
    printf("Running srad kernel (step 1):\n");
    printf("  Image: %d x %d\n", Nr, Nc);
    
    int num_blocks = (Ne + NUMBER_THREADS - 1) / NUMBER_THREADS;
    srad<<<num_blocks, NUMBER_THREADS>>>(
        lambda, Nr, Nc, Ne, d_iN, d_iS, d_jE, d_jW,
        d_dN, d_dS, d_dE, d_dW, q0sqr, d_c, d_I
    );
    
    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));
    
    // 清理
    cudaFree(d_iN); cudaFree(d_iS); cudaFree(d_jE); cudaFree(d_jW);
    cudaFree(d_dN); cudaFree(d_dS); cudaFree(d_dE); cudaFree(d_dW);
    cudaFree(d_c); cudaFree(d_I);
    free(h_iN); free(h_iS); free(h_jE); free(h_jW); free(h_I);
    
    return err == cudaSuccess ? 0 : 1;
}