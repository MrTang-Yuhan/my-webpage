// Auto-generated CUDA kernel file: floydwarshall_strip_blocks_y
// Extracted from: pannotia/fw/kernel_block.cu
// Original line: 145

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Macro Definitions =====
#define BLOCK_SIZE 16  // from line 58

// ===== Kernel =====
// Kernel: floydwarshall_strip_blocks_y (line 145)
__global__ void
floydwarshall_strip_blocks_y(int *dist, int blk_iter, int dim) {

    int by = blockIdx.y;

    int tx = threadIdx.x;
    int ty = threadIdx.y;

    __shared__ int dia_block[BLOCK_SIZE * BLOCK_SIZE];
    __shared__ int strip_block[BLOCK_SIZE * BLOCK_SIZE];

    if (by != blk_iter) {

        int base_x = blk_iter * BLOCK_SIZE;
        int base_y = blk_iter * BLOCK_SIZE;
        int base   = base_y * dim + base_x;

        dia_block[ty * BLOCK_SIZE + tx] = dist[base + ty * dim + tx];

        __syncthreads();

        int strip_base_x = blk_iter * BLOCK_SIZE;
        int strip_base   = strip_base_x;

        int index = strip_base + (by * BLOCK_SIZE + ty) * dim + tx;

        strip_block[ty * BLOCK_SIZE + tx] = dist[index];

        __syncthreads();

        for (int k = 0; k < BLOCK_SIZE; k++) {
            if (strip_block[ty * BLOCK_SIZE + k] + dia_block[k * BLOCK_SIZE + tx] < strip_block[ty * BLOCK_SIZE + tx])
                strip_block[ty * BLOCK_SIZE + tx] = strip_block[ty * BLOCK_SIZE + k] + dia_block[k * BLOCK_SIZE + tx];
            __syncthreads();
        }

        dist[index] = strip_block[ty * BLOCK_SIZE + tx];
    }

}


int main(int argc, char** argv) {
    cudaError_t err;

    const int dim = 512;
    const int blk_iter = 0;
    const int num_blocks = dim / BLOCK_SIZE;
    const size_t num_elements = (size_t)dim * dim;
    const size_t size_mat = num_elements * sizeof(int);

    int *h_dist = (int*)malloc(size_mat);
    int *d_dist = nullptr;

    if (!h_dist) {
        printf("host malloc failed\n");
        return -1;
    }

    for (int i = 0; i < dim; ++i) {
        for (int j = 0; j < dim; ++j) {
            if (i == j) h_dist[i * dim + j] = 0;
            else if (abs(i - j) == 1) h_dist[i * dim + j] = 1;
            else h_dist[i * dim + j] = 1000000;
        }
    }

    err = cudaMalloc((void**)&d_dist, size_mat);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_dist failed: %s\n", cudaGetErrorString(err));
        free(h_dist);
        return -1;
    }

    err = cudaMemcpy(d_dist, h_dist, size_mat, cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D dist failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        free(h_dist);
        return -1;
    }

    dim3 blockSize(BLOCK_SIZE, BLOCK_SIZE);
    dim3 gridSize(1, num_blocks);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    floydwarshall_strip_blocks_y<<<gridSize, blockSize>>>(d_dist, blk_iter, dim);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        free(h_dist);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        free(h_dist);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaMemcpy(h_dist, d_dist, size_mat, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("floydwarshall_strip_blocks_y execution time: %.3f ms\n", ms);

    printf("dist[0,0] = %d\n", h_dist[0]);
    printf("dist[%d,0] = %d\n", BLOCK_SIZE, h_dist[BLOCK_SIZE * dim]);
    printf("dist[%d,1] = %d\n", BLOCK_SIZE, h_dist[BLOCK_SIZE * dim + 1]);

    cudaFree(d_dist);
    free(h_dist);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}