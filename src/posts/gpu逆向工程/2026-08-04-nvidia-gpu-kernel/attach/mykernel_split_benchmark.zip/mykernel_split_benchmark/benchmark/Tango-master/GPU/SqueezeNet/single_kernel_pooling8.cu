// Auto-generated CUDA kernel file: pooling8
// Extracted from: Tango-master/GPU/SqueezeNet/SN.cu
// Original line: 1936

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

// ===== Kernel =====
// Kernel: pooling8 (line 1936)
__global__ void pooling8(double *Layer8_Neurons_GPU,double *Layer8_pool_GPU,int out,int out_fr,int out_fc,int kernel,int stride_width,int in_fr,int in_fc) {

    int row = threadIdx.x;
    int col = blockIdx.x;
    double max = 0.0;
    {
        for(int output =0;output < 512 ;output++)
        {
            if(row%2 != 0)
            { 
                if(col%2 != 0)
                {
                    for(int i = row-1; i <= row+1; i++)
                    {   
			if(i>26) break;        
                        for(int j = col-1; j <= col+1; j++)
                        {
			    if(j>26) break;
                            if(max < ((Layer8_Neurons_GPU[output*27*27+i*27+j])))
                                max =   ((Layer8_Neurons_GPU[output*27*27+i*27+j])) ;
 
                        }
                    }
                    Layer8_pool_GPU[output*13*13+((row-1)/2)*13+(col-1)/2] = max;
                    max = 0.0;   
                }
            }
        }
    }
    __syncthreads();
    //if(row == 1 && col == 1)
	//printf("Max pool 8 o/p: %.8f\n", Layer8_pool_GPU[5115]);

}

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    const int out = 512;
    const int in_fr = 27, in_fc = 27;
    const int out_fr = 13, out_fc = 13;
    const int kernel = 3;
    const int stride_width = 2;

    size_t input_size = (size_t)out * in_fr * in_fc;
    size_t output_size = (size_t)out * out_fr * out_fc;

    double *h_in  = (double*)malloc(input_size * sizeof(double));
    double *h_out = (double*)malloc(output_size * sizeof(double));

    if (!h_in || !h_out) return -1;

    for (size_t i = 0; i < input_size; ++i) h_in[i] = (double)(i % 17) * 0.01;

    double *d_in = nullptr, *d_out = nullptr;
    cudaMalloc(&d_in, input_size * sizeof(double));
    cudaMalloc(&d_out, output_size * sizeof(double));

    cudaMemcpy(d_in, h_in, input_size * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemset(d_out, 0, output_size * sizeof(double));

    dim3 grid(1);
    dim3 block(2);  // threadIdx.x ∈ {0,1}，但 kernel 中只用 row%2!=0（即 row=1），所以 block(2) 即可

    pooling8<<<grid, block>>>(d_in, d_out, out, out_fr, out_fc, kernel, stride_width, in_fr, in_fc);

    cudaDeviceSynchronize();
    if (cudaGetLastError() != cudaSuccess) {
        fprintf(stderr, "CUDA kernel launch failed.\n");
        return -1;
    }

    cudaMemcpy(h_out, d_out, output_size * sizeof(double), cudaMemcpyDeviceToHost);

    printf("pooling8 done. out[0] = %f\n", h_out[0]);

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);
    return 0;
}