// Standalone CUDA kernel file: remove_dups
// Fixed smoke-test version with main()

#include <cuda.h>
#include <cuda_runtime.h>
#include <cub/cub.cuh>

#include <stdio.h>
#include <stdlib.h>

static inline void checkCuda(cudaError_t err, const char* msg) {
  if (err != cudaSuccess) {
    fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
    exit(EXIT_FAILURE);
  }
}

// ============================================================
// Single-block smoke-test barrier
//
// 原版 GlobalBarrier 需要 gb.d_sync 指向 device memory。
// 上一版没有初始化 d_sync，导致 gb.Sync() 访问 NULL，触发 illegal memory access。
// 这里 smoke test 只用 grid=1，所以 Sync() 直接用 __syncthreads() 即可。
// ============================================================

class GlobalBarrier {
public:
  __host__ GlobalBarrier() {}

  __device__ __forceinline__ void Sync() const {
    __syncthreads();
  }
};

// ============================================================
// Minimal Worklist2
// ============================================================

struct Worklist2 {
  int *dwl;
  int *dindex;
  int *dnsize;

  __device__ int push(int item) {
    int lindex = atomicAdd((int*)dindex, 1);

    if (lindex >= *dnsize) {
      return 0;
    }

    dwl[lindex] = item;
    return 1;
  }

  __device__ int pop_id(int id, int &item) {
    if (id < *dindex) {
      item = cub::ThreadLoad<cub::LOAD_CG>(dwl + id);
      return 1;
    }

    return 0;
  }
};

// ============================================================
// Kernel: remove_dups
// ============================================================

__global__ void remove_dups(Worklist2 wl, int *node_owner, GlobalBarrier gb) {
  unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
  int nn;

  int total_inputs =
      (*wl.dindex + gridDim.x * blockDim.x - 1) /
      (gridDim.x * blockDim.x);

  while (total_inputs-- > 0) {
    if (wl.pop_id(id, nn)) {
      if (nn >= 0) {
        node_owner[nn] = id;
      }
    }

    id += gridDim.x * blockDim.x;
  }

  id = blockIdx.x * blockDim.x + threadIdx.x;

  total_inputs =
      (*wl.dindex + gridDim.x * blockDim.x - 1) /
      (gridDim.x * blockDim.x);

  gb.Sync();

  while (total_inputs-- > 0) {
    if (wl.pop_id(id, nn)) {
      if (nn >= 0) {
        if (node_owner[nn] != (int)id) {
          wl.dwl[id] = -1;
        }
      }
    }

    id += gridDim.x * blockDim.x;
  }
}

// ============================================================
// Host helpers
// ============================================================

static void initWorklist(Worklist2 &wl,
                         const int *h_items,
                         int n,
                         int capacity) {
  checkCuda(cudaMalloc((void**)&wl.dwl,
                       capacity * sizeof(int)),
            "malloc wl.dwl");

  checkCuda(cudaMalloc((void**)&wl.dindex,
                       sizeof(int)),
            "malloc wl.dindex");

  checkCuda(cudaMalloc((void**)&wl.dnsize,
                       sizeof(int)),
            "malloc wl.dnsize");

  checkCuda(cudaMemset(wl.dwl,
                       0xFF,
                       capacity * sizeof(int)),
            "memset wl.dwl");

  checkCuda(cudaMemcpy(wl.dwl,
                       h_items,
                       n * sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy wl items");

  checkCuda(cudaMemcpy(wl.dindex,
                       &n,
                       sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy wl index");

  checkCuda(cudaMemcpy(wl.dnsize,
                       &capacity,
                       sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy wl capacity");
}

static void freeWorklist(Worklist2 &wl) {
  if (wl.dwl) {
    cudaFree(wl.dwl);
  }

  if (wl.dindex) {
    cudaFree(wl.dindex);
  }

  if (wl.dnsize) {
    cudaFree(wl.dnsize);
  }

  wl.dwl = NULL;
  wl.dindex = NULL;
  wl.dnsize = NULL;
}

// ============================================================
// main
// ============================================================

int main() {
  Worklist2 wl;
  wl.dwl = NULL;
  wl.dindex = NULL;
  wl.dnsize = NULL;

  GlobalBarrier gb;

  const int nitems = 6;
  const int capacity = 16;
  const int numnodes = 8;

  // 有重复项：
  // node 3 出现两次
  // node 5 出现两次
  int h_items[nitems] = {3, 5, 3, 2, 5, 7};

  int *d_node_owner = NULL;

  int h_wl_out[capacity];
  int h_owner[numnodes];

  initWorklist(wl, h_items, nitems, capacity);

  checkCuda(cudaMalloc((void**)&d_node_owner,
                       numnodes * sizeof(int)),
            "malloc node_owner");

  checkCuda(cudaMemset(d_node_owner,
                       0xFF,
                       numnodes * sizeof(int)),
            "memset node_owner");

  // 注意：这个修正版 GlobalBarrier 是单 block smoke-test 版。
  // 所以这里保持 grid=1。
  dim3 block(128);
  dim3 grid(1);

  remove_dups<<<grid, block>>>(wl, d_node_owner, gb);

  checkCuda(cudaGetLastError(),
            "remove_dups launch failed");

  checkCuda(cudaDeviceSynchronize(),
            "remove_dups execution failed");

  checkCuda(cudaMemcpy(h_wl_out,
                       wl.dwl,
                       capacity * sizeof(int),
                       cudaMemcpyDeviceToHost),
            "copy wl out");

  checkCuda(cudaMemcpy(h_owner,
                       d_node_owner,
                       numnodes * sizeof(int),
                       cudaMemcpyDeviceToHost),
            "copy node owner");

  printf("remove_dups finished\n");

  printf("worklist before dedup:\n");
  for (int i = 0; i < nitems; i++) {
    printf("input[%d] = %d\n", i, h_items[i]);
  }

  printf("\nworklist after dedup:\n");
  for (int i = 0; i < nitems; i++) {
    printf("wl[%d] = %d\n", i, h_wl_out[i]);
  }

  printf("\nnode_owner:\n");
  for (int i = 0; i < numnodes; i++) {
    printf("owner[%d] = %d\n", i, h_owner[i]);
  }

  cudaFree(d_node_owner);
  freeWorklist(wl);

  return 0;
}