// Auto-generated CUDA kernel file: executeFirstLayerCUDA
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 427

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeFirstLayerCUDA (line 427)
__global__ void executeFirstLayerCUDA(float *bias,float *Layer1_Neurons_GPU,float *Layer1_Weights_GPU,float *Layer2_Neurons_GPU,int stride_width,int pad, int col_width,int feature_r,int feature_c,int out,int tfactor) {

	int stride = 0,colstride = 0;
	int output = blockIdx.x;
	int row_even = threadIdx.x * tfactor; 
	int col_even = threadIdx.y * tfactor;
	int kernel = 7;
        int x_pad,y_pad,loopc,loopr;
	float product = 0.0;
        //out = 1; feature_r = 1; feature_c = 112;
	{
		//for(int output =0;output < out ;output++)
                if(row_even < feature_r && col_even < feature_c)
		{
                        colstride = 0;
			for(int row =row_even; row < row_even+tfactor ;row++)
			{  
				stride = 0;
				colstride = 3 *(row*stride_width - pad)*col_width;
				colstride = colstride < 0 ? 0 : colstride;
				for(int col =col_even; col < col_even+tfactor ;col++)
				{
					stride = 3 * (col*stride_width - pad);
					stride = stride < 0 ? 0 : stride;
					
					product = 0;
					x_pad = 0; y_pad = 0;
					/* set the loops value */
					loopc = kernel;loopr = kernel;
					/* take care of padding in left hand side of image*/ 
					if(row*stride_width < pad)
					{
						x_pad = pad - row*stride_width;
						loopr = kernel - x_pad;
					} 
					/* take care of padding in upper side of image*/ 
					if( (col*stride_width)  < pad ) 
					{
						y_pad = pad - col*stride_width;
						loopc = kernel - y_pad;
					}
                                                 
					/* take care of padding in right side of image*/ 
					if((col) > (feature_c - pad))
					{
						loopc = col_width - (stride/3); 
					}  
					/* take care of padding in bottom of image */ 
					if(row > feature_r - pad)
					{
						loopr =  col_width - colstride/(3*col_width);
					}
					/* RGB weights and input 7*7*3 , kernel is 7*7 */
					for(int i = 0; i < loopr; i++)
					{			
						for(int j = 0; j < loopc; j++)
						{
							product +=        ((Layer1_Neurons_GPU[i*col_width*3 + j*3 + stride + colstride]    * Layer1_Weights_GPU[i*7 + j + (output * 7*7*3) + kernel*x_pad + y_pad])  
									+ (Layer1_Neurons_GPU[i*col_width*3 + j*3 + 1 + stride + colstride] * Layer1_Weights_GPU[i*7 + 7*7 + j+ (output * 7*7*3)+ kernel*x_pad + y_pad])
									+ (Layer1_Neurons_GPU[i*col_width*3 + j*3 + 2 + stride + colstride] * Layer1_Weights_GPU[i*7 + 7*7*2 + j+ (output * 7*7*3)+kernel*x_pad + y_pad]));
						}
					}
					Layer2_Neurons_GPU[output*feature_r*feature_c + row*feature_c + col] = product;
#ifdef LAYER1_DEBUG			
					printf("%f\n",product);
#endif		
					product = 0.0;

				}
			}
		}
	}

}


int main() {
    const int out = 8;
    const int col_width = 16;      // 输入图像宽高
    const int feature_r = 8;
    const int feature_c = 8;
    const int stride_width = 2;
    const int pad = 3;
    const int tfactor = 2;

    const int kernel = 7;

    size_t bias_size = out;
    size_t input_size = (size_t)3 * col_width * col_width;
    size_t weight_size = (size_t)out * 7 * 7 * 3;
    size_t output_size = (size_t)out * feature_r * feature_c;

    float *h_bias = (float*)malloc(bias_size * sizeof(float));
    float *h_input = (float*)malloc(input_size * sizeof(float));
    float *h_weight = (float*)malloc(weight_size * sizeof(float));
    float *h_output = (float*)malloc(output_size * sizeof(float));

    if (!h_bias || !h_input || !h_weight || !h_output) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < bias_size; ++i) h_bias[i] = 0.1f;
    for (size_t i = 0; i < input_size; ++i) h_input[i] = (float)(i % 17) * 0.01f;
    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (float)(i % 13) * 0.02f;

    float *d_bias = NULL, *d_input = NULL, *d_weight = NULL, *d_output = NULL;
    CHECK(cudaMalloc((void**)&d_bias, bias_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_input, input_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_output, output_size * sizeof(float)));

    CHECK(cudaMemcpy(d_bias, h_bias, bias_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_input, h_input, input_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_output, 0, output_size * sizeof(float)));

    dim3 grid(out);
    dim3 block((feature_r + tfactor - 1) / tfactor, (feature_c + tfactor - 1) / tfactor);

    executeFirstLayerCUDA<<<grid, block>>>(
        d_bias, d_input, d_weight, d_output,
        stride_width, pad, col_width, feature_r, feature_c, out, tfactor
    );
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_output, d_output, output_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeFirstLayerCUDA done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("output[%d] = %f\n", i, h_output[i]);
    }

    cudaFree(d_bias);
    cudaFree(d_input);
    cudaFree(d_weight);
    cudaFree(d_output);

    free(h_bias);
    free(h_input);
    free(h_weight);
    free(h_output);

    return 0;
}