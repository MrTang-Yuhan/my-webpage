// Standalone CUDA kernel file: initialize
// Smoke-test version for PTA initialize kernel

#include "pta_single_kernel_test_common.cuh"

__global__ void initialize() {
    uint nvars = __numVars__;

    if (isFirstThreadOfBlock()) {
        uint headerSize = nvars * ELEMENT_WIDTH;

        __ptsFreeList__ = headerSize;
        __currDiffPtsFreeList__ = TEST_CURR_DIFF_PTS_START + headerSize;
        __nextDiffPtsFreeList__ = TEST_NEXT_DIFF_PTS_START + headerSize;
        __otherFreeList__ = TEST_COPY_INV_START + headerSize * 4;
    }

    __syncthreads();

    uint tid = getThreadIdInGrid();
    uint stride = getThreadsPerGrid();

    for (uint var = tid; var < nvars; var += stride) {
        __rep__[var] = var;
        __lock__[var] = UNLOCKED;

        uint idx;

        idx = getHeadIndex(var, PTS);
        for (uint i = threadIdx.x; i < ELEMENT_WIDTH; i += blockDim.x) {
            graphSet(idx + i, NIL);
        }

        idx = getHeadIndex(var, NEXT_DIFF_PTS);
        for (uint i = threadIdx.x; i < ELEMENT_WIDTH; i += blockDim.x) {
            graphSet(idx + i, NIL);
        }

        idx = getHeadIndex(var, CURR_DIFF_PTS);
        for (uint i = threadIdx.x; i < ELEMENT_WIDTH; i += blockDim.x) {
            graphSet(idx + i, NIL);
        }

        idx = getHeadIndex(var, COPY_INV);
        for (uint i = threadIdx.x; i < ELEMENT_WIDTH; i += blockDim.x) {
            graphSet(idx + i, NIL);
        }

        idx = getHeadIndex(var, LOAD_INV);
        for (uint i = threadIdx.x; i < ELEMENT_WIDTH; i += blockDim.x) {
            graphSet(idx + i, NIL);
        }

        idx = getHeadIndex(var, STORE);
        for (uint i = threadIdx.x; i < ELEMENT_WIDTH; i += blockDim.x) {
            graphSet(idx + i, NIL);
        }
    }

    __syncthreads();

    uint numInitial = __numInitialRep__;
    for (uint i = tid; i < numInitial; i += stride) {
        uint nonRep = __initialNonRep__[i];
        uint rep = __initialRep__[i];
        __rep__[nonRep] = rep;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    dim3 block(32, 4);
    dim3 grid(1);

    initialize<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "initialize launch failed");
    checkCuda(cudaDeviceSynchronize(), "initialize execution failed");

    uint h_rep[8];
    uint h_lock[8];

    checkCuda(cudaMemcpy(h_rep, env.d_rep, sizeof(h_rep), cudaMemcpyDeviceToHost), "copy rep");
    checkCuda(cudaMemcpy(h_lock, env.d_lock, sizeof(h_lock), cudaMemcpyDeviceToHost), "copy lock");

    printf("initialize finished\n");
    for (int i = 0; i < 8; i++) {
        printf("rep[%d]=%u lock[%d]=%u\n", i, h_rep[i], i, h_lock[i]);
    }

    destroyPTATestEnv(env);
    return 0;
}