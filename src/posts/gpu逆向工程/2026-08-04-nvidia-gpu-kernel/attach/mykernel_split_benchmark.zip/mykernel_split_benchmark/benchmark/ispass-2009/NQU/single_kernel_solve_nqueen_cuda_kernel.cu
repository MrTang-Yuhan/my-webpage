// Auto-generated CUDA kernel file: solve_nqueen_cuda_kernel
// Extracted from: ispass-2009/NQU/single_kernel_solve_nqueen_cuda_kernel.cu
// Original line: 16

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Macro Definitions =====
#define THREAD_NUM		96  // from line 11  // from line 12

// ===== Kernel =====
// Kernel: solve_nqueen_cuda_kernel (line 16)
__global__ void solve_nqueen_cuda_kernel(int n, int mark, unsigned int* total_masks, unsigned int* total_l_masks, unsigned int* total_r_masks, unsigned int* results, int total_conditions) {


	const int tid = threadIdx.x;
	const int bid = blockIdx.x;
	const int idx = bid * blockDim.x + tid;

	__shared__ unsigned int mask[THREAD_NUM][10];
	__shared__ unsigned int l_mask[THREAD_NUM][10];
	__shared__ unsigned int r_mask[THREAD_NUM][10];
	__shared__ unsigned int m[THREAD_NUM][10];

	__shared__ unsigned int sum[THREAD_NUM];

	const unsigned int t_mask = (1 << n) - 1;
	int total = 0;
	int i = 0;
	unsigned int index;

	if(idx < total_conditions) {
		mask[tid][i] = total_masks[idx];
		l_mask[tid][i] = total_l_masks[idx];
		r_mask[tid][i] = total_r_masks[idx];
		m[tid][i] = mask[tid][i] | l_mask[tid][i] | r_mask[tid][i];

		while(i >= 0) {
			if((m[tid][i] & t_mask) == t_mask) {
				i--;
			}
			else {
				index = (m[tid][i] + 1) & ~m[tid][i];
				m[tid][i] |= index;
				if((index & t_mask) != 0) {
					if(i + 1 == mark) {
						total++;
						i--;
					}
					else {
						mask[tid][i + 1] = mask[tid][i] | index;
						l_mask[tid][i + 1] = (l_mask[tid][i] | index) << 1;
						r_mask[tid][i + 1] = (r_mask[tid][i] | index) >> 1;
						m[tid][i + 1] = (mask[tid][i + 1] | l_mask[tid][i + 1] | r_mask[tid][i + 1]);
						i++;
					}
				}
				else {
					i --;
				}
			}
		}

		sum[tid] = total;
	}
	else {
		sum[tid] = 0;
	}

	__syncthreads();

	// reduction
	if(tid < 64 && tid + 64 < THREAD_NUM) { sum[tid] += sum[tid + 64]; } __syncthreads();
	if(tid < 32) { sum[tid] += sum[tid + 32]; } __syncthreads();
	if(tid < 16) { sum[tid] += sum[tid + 16]; } __syncthreads();
	if(tid < 8) { sum[tid] += sum[tid + 8]; } __syncthreads();
	if(tid < 4) { sum[tid] += sum[tid + 4]; } __syncthreads();
	if(tid < 2) { sum[tid] += sum[tid + 2]; } __syncthreads();
	if(tid < 1) { sum[tid] += sum[tid + 1]; } __syncthreads();

	if(tid == 0) {
		results[bid] = sum[0];
	}


}
int main(int argc, char **argv) {
    int n = 8;
    int mark = 7;
    int total_conditions = 1;

    if (argc >= 2) n = atoi(argv[1]);
    if (argc >= 3) mark = atoi(argv[2]);
    if (argc >= 4) total_conditions = atoi(argv[3]);

    if (n <= 0 || n > 10) {
        fprintf(stderr, "n must be in range 1..10\n");
        return -1;
    }

    if (mark < 0 || mark >= 10) {
        fprintf(stderr, "mark must be in range 0..9\n");
        return -1;
    }

    if (total_conditions <= 0) {
        fprintf(stderr, "total_conditions must be > 0\n");
        return -1;
    }

    unsigned int *h_total_masks = (unsigned int *)malloc(sizeof(unsigned int) * total_conditions);
    unsigned int *h_total_l_masks = (unsigned int *)malloc(sizeof(unsigned int) * total_conditions);
    unsigned int *h_total_r_masks = (unsigned int *)malloc(sizeof(unsigned int) * total_conditions);

    if (!h_total_masks || !h_total_l_masks || !h_total_r_masks) {
        fprintf(stderr, "host malloc failed\n");
        free(h_total_masks);
        free(h_total_l_masks);
        free(h_total_r_masks);
        return -1;
    }

    for (int i = 0; i < total_conditions; i++) {
        h_total_masks[i] = 0;
        h_total_l_masks[i] = 0;
        h_total_r_masks[i] = 0;
    }

    unsigned int *d_total_masks = NULL;
    unsigned int *d_total_l_masks = NULL;
    unsigned int *d_total_r_masks = NULL;
    unsigned int *d_results = NULL;

    int blocks = (total_conditions + THREAD_NUM - 1) / THREAD_NUM;
    unsigned int *h_results = (unsigned int *)malloc(sizeof(unsigned int) * blocks);
    if (!h_results) {
        fprintf(stderr, "host malloc for results failed\n");
        free(h_total_masks);
        free(h_total_l_masks);
        free(h_total_r_masks);
        return -1;
    }

    cudaError_t err;
    err = cudaMalloc((void **)&d_total_masks, sizeof(unsigned int) * total_conditions);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_total_masks failed: %s\n", cudaGetErrorString(err));
        free(h_total_masks); free(h_total_l_masks); free(h_total_r_masks); free(h_results);
        return -1;
    }

    err = cudaMalloc((void **)&d_total_l_masks, sizeof(unsigned int) * total_conditions);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_total_l_masks failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_total_masks);
        free(h_total_masks); free(h_total_l_masks); free(h_total_r_masks); free(h_results);
        return -1;
    }

    err = cudaMalloc((void **)&d_total_r_masks, sizeof(unsigned int) * total_conditions);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_total_r_masks failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_total_masks);
        cudaFree(d_total_l_masks);
        free(h_total_masks); free(h_total_l_masks); free(h_total_r_masks); free(h_results);
        return -1;
    }

    err = cudaMalloc((void **)&d_results, sizeof(unsigned int) * blocks);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_results failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_total_masks);
        cudaFree(d_total_l_masks);
        cudaFree(d_total_r_masks);
        free(h_total_masks); free(h_total_l_masks); free(h_total_r_masks); free(h_results);
        return -1;
    }

    cudaMemcpy(d_total_masks, h_total_masks, sizeof(unsigned int) * total_conditions, cudaMemcpyHostToDevice);
    cudaMemcpy(d_total_l_masks, h_total_l_masks, sizeof(unsigned int) * total_conditions, cudaMemcpyHostToDevice);
    cudaMemcpy(d_total_r_masks, h_total_r_masks, sizeof(unsigned int) * total_conditions, cudaMemcpyHostToDevice);
    cudaMemset(d_results, 0, sizeof(unsigned int) * blocks);

    solve_nqueen_cuda_kernel<<<blocks, THREAD_NUM>>>(
        n, mark,
        d_total_masks,
        d_total_l_masks,
        d_total_r_masks,
        d_results,
        total_conditions
    );

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_total_masks);
        cudaFree(d_total_l_masks);
        cudaFree(d_total_r_masks);
        cudaFree(d_results);
        free(h_total_masks); free(h_total_l_masks); free(h_total_r_masks); free(h_results);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_total_masks);
        cudaFree(d_total_l_masks);
        cudaFree(d_total_r_masks);
        cudaFree(d_results);
        free(h_total_masks); free(h_total_l_masks); free(h_total_r_masks); free(h_results);
        return -1;
    }

    cudaMemcpy(h_results, d_results, sizeof(unsigned int) * blocks, cudaMemcpyDeviceToHost);

    unsigned long long total = 0;
    for (int i = 0; i < blocks; i++) {
        total += h_results[i];
    }

    printf("n=%d, mark=%d, total_conditions=%d\n", n, mark, total_conditions);
    printf("result = %llu\n", total);

    cudaFree(d_total_masks);
    cudaFree(d_total_l_masks);
    cudaFree(d_total_r_masks);
    cudaFree(d_results);
    free(h_total_masks);
    free(h_total_l_masks);
    free(h_total_r_masks);
    free(h_results);

    return 0;
}