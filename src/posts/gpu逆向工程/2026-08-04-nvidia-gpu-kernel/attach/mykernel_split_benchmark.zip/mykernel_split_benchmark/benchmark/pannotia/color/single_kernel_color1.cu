// Auto-generated CUDA kernel file: color1
// Extracted from: pannotia/color/kernel_maxmin.cu
// Original line: 73

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Macro Definitions =====
#define BIG_NUM 999999  // from line 58

// ===== Kernel =====
// Kernel: color1 (line 73)
__global__ void color1(int *row, int *col, int *node_value, int *color_array,
                       int *stop, int *max_d, int *min_d, const int color,
                       const int num_nodes, const int num_edges) {

    // Get my workitem id
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    if (tid < num_nodes) {
        // If the vertex is not colored
        if (color_array[tid] == -1) {

            // Get the start and end pointers for the neighbor list
            int start = row[tid];
            int end;
            if (tid + 1 < num_nodes)
                end = row[tid + 1];
            else
                end = num_edges;

            int maximum = -1;
            int minimum = BIG_NUM;
            // Navigate the neighborlist
            for (int edge = start; edge < end; edge++) {
                if (color_array[col[edge]] == -1 && start != end - 1) {
                    *stop = 1;
                    // Determine if the vertex value is the maximum/minimum in the neighborhood
                    if (node_value[col[edge]] > maximum)
                        maximum = node_value[col[edge]];
                    if (node_value[col[edge]] < minimum)
                        minimum = node_value[col[edge]];
                }
            }
            // Assign the maximum/miminum value to max/min array
            max_d[tid] = maximum;
            min_d[tid] = minimum;
        }
    }

}


int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;
    const int color = 0;

    const size_t size_nodes_int = (size_t)num_nodes * sizeof(int);
    const size_t size_edges_int = (size_t)num_edges * sizeof(int);
    const size_t size_stop = sizeof(int);

    int *h_row = (int*)malloc(size_nodes_int);
    int *h_col = (int*)malloc(size_edges_int);
    int *h_node_value = (int*)malloc(size_nodes_int);
    int *h_color_array = (int*)malloc(size_nodes_int);
    int *h_stop = (int*)malloc(size_stop);
    int *h_max_d = (int*)malloc(size_nodes_int);
    int *h_min_d = (int*)malloc(size_nodes_int);

    int *d_row = nullptr;
    int *d_col = nullptr;
    int *d_node_value = nullptr;
    int *d_color_array = nullptr;
    int *d_stop = nullptr;
    int *d_max_d = nullptr;
    int *d_min_d = nullptr;

    if (!h_row || !h_col || !h_node_value || !h_color_array || !h_stop || !h_max_d || !h_min_d) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_col);
        free(h_node_value);
        free(h_color_array);
        free(h_stop);
        free(h_max_d);
        free(h_min_d);
        return -1;
    }

    // 构造一个简单链式图: 0->1->2->...->num_nodes-1
    for (int i = 0; i < num_nodes; ++i) {
        if (i < num_nodes - 1) h_row[i] = i;
        else h_row[i] = num_edges;
    }

    for (int i = 0; i < num_edges; ++i) {
        h_col[i] = i + 1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_node_value[i] = i % 100;
        h_color_array[i] = -1;
        h_max_d[i] = -1;
        h_min_d[i] = BIG_NUM;
    }

    *h_stop = 0;

    err = cudaMalloc((void**)&d_row, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_row failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_col, size_edges_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_col failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_node_value, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_node_value failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_color_array, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_color_array failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_stop, size_stop);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_stop failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_max_d, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_max_d failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_min_d, size_nodes_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_min_d failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(d_row, h_row, size_nodes_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col, h_col, size_edges_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_node_value, h_node_value, size_nodes_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_color_array, h_color_array, size_nodes_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_stop, h_stop, size_stop, cudaMemcpyHostToDevice);
    cudaMemcpy(d_max_d, h_max_d, size_nodes_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_min_d, h_min_d, size_nodes_int, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop_evt;
    cudaEventCreate(&start);
    cudaEventCreate(&stop_evt);

    cudaEventRecord(start);
    color1<<<gridSize, blockSize>>>(
        d_row, d_col, d_node_value, d_color_array,
        d_stop, d_max_d, d_min_d,
        color, num_nodes, num_edges
    );
    cudaEventRecord(stop_evt);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop_evt);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop_evt);
    printf("color1 execution time: %.3f ms\n", milliseconds);

    cudaMemcpy(h_stop, d_stop, size_stop, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_max_d, d_max_d, size_nodes_int, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_min_d, d_min_d, size_nodes_int, cudaMemcpyDeviceToHost);

    printf("stop = %d\n", *h_stop);
    printf("max_d[0] = %d\n", h_max_d[0]);
    printf("min_d[0] = %d\n", h_min_d[0]);
    printf("max_d[1] = %d\n", h_max_d[1]);
    printf("min_d[1] = %d\n", h_min_d[1]);

    cudaFree(d_row);
    cudaFree(d_col);
    cudaFree(d_node_value);
    cudaFree(d_color_array);
    cudaFree(d_stop);
    cudaFree(d_max_d);
    cudaFree(d_min_d);

    free(h_row);
    free(h_col);
    free(h_node_value);
    free(h_color_array);
    free(h_stop);
    free(h_max_d);
    free(h_min_d);

    cudaEventDestroy(start);
    cudaEventDestroy(stop_evt);

    printf("Done!\n");
    return 0;
}