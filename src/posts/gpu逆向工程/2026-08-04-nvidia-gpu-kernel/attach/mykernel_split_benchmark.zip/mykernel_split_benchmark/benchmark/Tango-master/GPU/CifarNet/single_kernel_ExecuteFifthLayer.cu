// Auto-generated CUDA kernel file: ExecuteFifthLayer
// Extracted from: Tango-master/GPU/CifarNet/CN_cuda.cu
// Original line: 456

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: ExecuteFifthLayer (line 456)
__global__ void ExecuteFifthLayer(double *Layer5_Weights_CPU, double *Layer5_Features, double *Layer4_Features) {

	int n = threadIdx.x;
	if(n<9)
	{
		double result = 0;
		for(int f=0; f<64; f++)
		{
			result+= Layer4_Features[f] * Layer5_Weights_CPU[f+n*64];
		}
		Layer5_Features[n] = result;
		result = 0;
	}

}

int main() {
    const int IN_N = 64;
    const int OUT_N = 9;

    size_t input_size  = IN_N;
    size_t weight_size = OUT_N * IN_N;
    size_t output_size = OUT_N;

    double *h_weight = (double*)malloc(weight_size * sizeof(double));
    double *h_in = (double*)malloc(input_size * sizeof(double));
    double *h_out = (double*)malloc(output_size * sizeof(double));

    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (double)(i % 17) * 0.01;
    for (size_t i = 0; i < input_size;  ++i) h_in[i] = (double)(i % 13) * 0.1;

    double *d_weight = NULL, *d_in = NULL, *d_out = NULL;

    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_in, input_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_out, output_size * sizeof(double)));

    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(double), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_in, h_in, input_size * sizeof(double), cudaMemcpyHostToDevice));

    dim3 grid(1);
    dim3 block(OUT_N);

    ExecuteFifthLayer<<<grid, block>>>(d_weight, d_out, d_in);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, output_size * sizeof(double), cudaMemcpyDeviceToHost));

    printf("ExecuteFifthLayer done.\n");
    for (int i = 0; i < OUT_N; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_weight);
    cudaFree(d_in);
    cudaFree(d_out);

    free(h_weight);
    free(h_in);
    free(h_out);

    return 0;
}