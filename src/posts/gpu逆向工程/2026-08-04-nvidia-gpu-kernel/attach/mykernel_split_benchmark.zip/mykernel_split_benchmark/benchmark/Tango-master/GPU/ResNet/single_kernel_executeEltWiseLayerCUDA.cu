// Auto-generated CUDA kernel file: executeEltWiseLayerCUDA
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 873

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeEltWiseLayerCUDA (line 873)
__global__ void executeEltWiseLayerCUDA(float *Layer1_Neurons,float *Layer2_Neurons,float *Layer_Out_Neurons,int size) {

        /* By default its sum of 2 layers */
	int i = blockIdx.x * blockDim.x * blockDim.y + threadIdx.x * blockDim.x + threadIdx.y ; //for(int i=0;i < size;i++)
	//for(int i=0;i < size; i++)
	{
		Layer_Out_Neurons[i] = Layer1_Neurons[i] + Layer2_Neurons[i];
	}

}
int main() {
    const int size = 256;

    float *h_a = (float*)malloc(size * sizeof(float));
    float *h_b = (float*)malloc(size * sizeof(float));
    float *h_c = (float*)malloc(size * sizeof(float));

    if (!h_a || !h_b || !h_c) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (int i = 0; i < size; ++i) {
        h_a[i] = (float)(i % 13);
        h_b[i] = (float)(i % 7);
    }

    float *d_a = NULL, *d_b = NULL, *d_c = NULL;
    CHECK(cudaMalloc((void**)&d_a, size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_b, size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_c, size * sizeof(float)));

    CHECK(cudaMemcpy(d_a, h_a, size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_b, h_b, size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_c, 0, size * sizeof(float)));

    dim3 block(8, 8);
    dim3 grid(size / (block.x * block.y));

    executeEltWiseLayerCUDA<<<grid, block>>>(d_a, d_b, d_c, size);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_c, d_c, size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeEltWiseLayerCUDA done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("c[%d] = %f\n", i, h_c[i]);
    }

    cudaFree(d_a);
    cudaFree(d_b);
    cudaFree(d_c);

    free(h_a);
    free(h_b);
    free(h_c);

    return 0;
}