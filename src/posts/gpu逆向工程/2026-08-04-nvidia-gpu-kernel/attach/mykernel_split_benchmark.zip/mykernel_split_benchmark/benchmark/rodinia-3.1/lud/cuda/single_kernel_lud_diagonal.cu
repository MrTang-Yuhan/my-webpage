// Auto-generated CUDA kernel file: lud_diagonal
// Extracted from: rodinia-3.1/lud/cuda/lud_kernel.cu
// Original line: 15

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <cstdlib>
#include <vector>
// ===== Macro Definitions =====
#define BLOCK_SIZE 16  // from line 11

// ===== Kernel =====
// Kernel: lud_diagonal (line 15)
__global__ void 
lud_diagonal(float *m, int matrix_dim, int offset) {

  int i,j;
  __shared__ float shadow[BLOCK_SIZE][BLOCK_SIZE];

  int array_offset = offset*matrix_dim+offset;
  for(i=0; i < BLOCK_SIZE; i++){
    shadow[i][threadIdx.x]=m[array_offset+threadIdx.x];
    array_offset += matrix_dim;
  }
  __syncthreads();
  for(i=0; i < BLOCK_SIZE-1; i++) {

    if (threadIdx.x>i){
      for(j=0; j < i; j++)
        shadow[threadIdx.x][i] -= shadow[threadIdx.x][j]*shadow[j][i];
      shadow[threadIdx.x][i] /= shadow[i][i];
    }

    __syncthreads();
    if (threadIdx.x>i){

      for(j=0; j < i+1; j++)
        shadow[i+1][threadIdx.x] -= shadow[i+1][j]*shadow[j][threadIdx.x];
    }
    __syncthreads();
  }

  /* 
     The first row is not modified, it
     is no need to write it back to the
     global memory

   */
  array_offset = (offset+1)*matrix_dim+offset;
  for(i=1; i < BLOCK_SIZE; i++){
    m[array_offset+threadIdx.x]=shadow[i][threadIdx.x];
    array_offset += matrix_dim;
  }

}


 
#define CHECK_CUDA(call) do { \
    cudaError_t err = (call); \
    if (err != cudaSuccess) { \
        fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__, cudaGetErrorString(err)); \
        exit(EXIT_FAILURE); \
    } \
} while(0)

int main() {
    const int matrix_dim = 64;
    const int offset = 0;
    const int total = matrix_dim * matrix_dim;

    std::vector<float> h_m(total);
    // 初始化为单位矩阵，保证 LU 分解数值稳定
    for (int i = 0; i < matrix_dim; ++i)
        for (int j = 0; j < matrix_dim; ++j)
            h_m[i * matrix_dim + j] = (i == j) ? 2.0f : 0.1f;

    float *d_m = nullptr;
    CHECK_CUDA(cudaMalloc((void**)&d_m, total * sizeof(float)));
    CHECK_CUDA(cudaMemcpy(d_m, h_m.data(), total * sizeof(float), cudaMemcpyHostToDevice));

    // lud_diagonal 只用 1 个 block，threadIdx.x 覆盖 [0, BLOCK_SIZE)
    lud_diagonal<<<1, BLOCK_SIZE>>>(d_m, matrix_dim, offset);
    CHECK_CUDA(cudaGetLastError());
    CHECK_CUDA(cudaDeviceSynchronize());

    CHECK_CUDA(cudaMemcpy(h_m.data(), d_m, total * sizeof(float), cudaMemcpyDeviceToHost));

    printf("lud_diagonal done. 部分结果:\n");
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j)
            printf("%8.4f ", h_m[i * matrix_dim + j]);
        printf("\n");
    }

    CHECK_CUDA(cudaFree(d_m));
    return 0;
}