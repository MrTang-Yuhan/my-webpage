// Auto-generated CUDA kernel file: mm3_kernel3
// Extracted from: polybench-gpu-1.0/CUDA/3MM/3mm.cu
// Original line: 141

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
# define NI 512  // from line 26
# define NJ 512  // from line 27
# define NL 512  // from line 29

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/3MM/3mm.cu:37

// ===== Kernel =====
// Kernel: mm3_kernel3 (line 141)
__global__ void mm3_kernel3(DATA_TYPE *E, DATA_TYPE *F, DATA_TYPE *G) {

	int j = blockIdx.x * blockDim.x + threadIdx.x;
	int i = blockIdx.y * blockDim.y + threadIdx.y;

	if ((i < NI) && (j < NL))
	{
		int k;
		for(k=0; k < NJ; k++)
		{
			G[i * NL + j] += E[i * NJ + k] * F[k * NL + j];
		}
	}

}

// ===== Main Function =====
int main(int argc, char** argv) {
    cudaError_t err;

    const int width = NJ;
    const int height = NI;
    const size_t size = (size_t)width * height;

    // ===== Host/Device buffers =====
    // buffer: DATA_TYPE *E
    DATA_TYPE *h_E = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_E = nullptr;
    if (!h_E) {
        printf("malloc failed for h_E\n");
        return -1;
    }

    // buffer: DATA_TYPE *F
    DATA_TYPE *h_F = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_F = nullptr;
    if (!h_F) {
        printf("malloc failed for h_F\n");
        return -1;
    }

    // buffer: DATA_TYPE *G
    DATA_TYPE *h_G = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_G = nullptr;
    if (!h_G) {
        printf("malloc failed for h_G\n");
        return -1;
    }

    // ===== Initialize host data =====
    for (size_t i = 0; i < size; ++i) h_E[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_F[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_G[i] = (DATA_TYPE)(i % 100);

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_E, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_E: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_F, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_F: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_G, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_G: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_E, h_E, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for E: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_F, h_F, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for F: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_G, h_G, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for G: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((NJ + blockSize.x - 1) / blockSize.x,
                  (NI + blockSize.y - 1) / blockSize.y);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);
    mm3_kernel3<<<gridSize, blockSize>>>(d_E, d_F, d_G);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy one buffer back as example =====
    err = cudaMemcpy(h_G, d_G, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for G: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // TODO: verify results
    printf("Sample output: %f\n", (double)h_G[0]);

    // ===== Cleanup =====
    if (d_E) cudaFree(d_E);
    if (d_F) cudaFree(d_F);
    if (d_G) cudaFree(d_G);
    if (h_E) free(h_E);
    if (h_F) free(h_F);
    if (h_G) free(h_G);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}