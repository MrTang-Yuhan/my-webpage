// Auto-generated CUDA kernel file: mm3_kernel1
// Extracted from: polybench-gpu-1.0/CUDA/3MM/3mm.cu
// Original line: 109

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
# define NI 512  // from line 26
# define NJ 512  // from line 27
# define NK 512  // from line 28

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/3MM/3mm.cu:37

// ===== Kernel =====
// Kernel: mm3_kernel1 (line 109)
__global__ void mm3_kernel1(DATA_TYPE *A, DATA_TYPE *B, DATA_TYPE *E) {

	int j = blockIdx.x * blockDim.x + threadIdx.x;
	int i = blockIdx.y * blockDim.y + threadIdx.y;

	if ((i < NI) && (j < NJ))
	{
		int k;
		for(k=0; k < NK; k++)
		{
			E[i * NJ + j] += A[i * NK + k] * B[k * NJ + j];
		}
	}

}

// ===== Main Function =====
int main(int argc, char** argv) {
    cudaError_t err;

    const int width = NJ;
    const int height = NI;
    const size_t size = (size_t)width * height;

    // ===== Host/Device buffers =====
    // buffer: DATA_TYPE *A
    DATA_TYPE *h_A = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_A = nullptr;
    if (!h_A) {
        printf("malloc failed for h_A\n");
        return -1;
    }

    // buffer: DATA_TYPE *B
    DATA_TYPE *h_B = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_B = nullptr;
    if (!h_B) {
        printf("malloc failed for h_B\n");
        return -1;
    }

    // buffer: DATA_TYPE *E
    DATA_TYPE *h_E = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_E = nullptr;
    if (!h_E) {
        printf("malloc failed for h_E\n");
        return -1;
    }

    // ===== Initialize host data =====
    for (size_t i = 0; i < size; ++i) h_A[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_B[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_E[i] = (DATA_TYPE)(i % 100);

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_A, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_A: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_B, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_B: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_E, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_E: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_A, h_A, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for A: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_B, h_B, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for B: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_E, h_E, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for E: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((NJ + blockSize.x - 1) / blockSize.x,
                  (NI + blockSize.y - 1) / blockSize.y);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);
    mm3_kernel1<<<gridSize, blockSize>>>(d_A, d_B, d_E);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy one buffer back as example =====
    err = cudaMemcpy(h_E, d_E, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for E: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // TODO: verify results
    printf("Sample output: %f\n", (double)h_E[0]);

    // ===== Cleanup =====
    if (d_A) cudaFree(d_A);
    if (d_B) cudaFree(d_B);
    if (d_E) cudaFree(d_E);
    if (h_A) free(h_A);
    if (h_B) free(h_B);
    if (h_E) free(h_E);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}