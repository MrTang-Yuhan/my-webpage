// Auto-generated CUDA kernel file: extract
// Extracted from: rodinia/2.0-ft/srad/srad_v1/extract_kernel.cu
// Original line: 2

// ===== Includes =====
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <cuda.h>
#include <stdio.h>
#include "define.c"
// #include "extract_kernel.cu"
// #include "prepare_kernel.cu"
// #include "reduce_kernel.cu"
// #include "srad_kernel.cu"
// #include "srad2_kernel.cu"
// #include "compress_kernel.cu"
// #include "graphics.c"
// #include "resize.c"
// #include "timer.c"

// #include "device.c"				// (in library path specified to compiler)	needed by for device functions
// ===== Kernel =====
// Kernel: extract (line 2)
__global__ void extract(	long d_Ne,
											fp *d_I) {
										// pointer to input image (DEVICE GLOBAL MEMORY)

	// indexes
	int bx = blockIdx.x;													// get current horizontal block index
	int tx = threadIdx.x;													// get current horizontal thread index
	int ei = (bx*NUMBER_THREADS)+tx;						// unique thread id, more threads than actual elements !!!

	// copy input to output & log uncompress
	if(ei<d_Ne){															// do only for the number of elements, omit extra threads  // [参数: d_Ne]

		d_I[ei] = exp(d_I[ei]/255);												// exponentiate input IMAGE and copy to output image  // [参数: d_I]

	}


}


// 在末尾追加
int main() {
    const long Ne = 1024 * 1024;
    
    fp *h_I = (fp*)malloc(Ne * sizeof(fp));
    
    // 初始化为压缩后的值（log 域）
    for (long i = 0; i < Ne; i++) {
        h_I[i] = log(1.0f + (rand() % 255)) * 255;
    }
    
    fp *d_I;
    cudaMalloc(&d_I, Ne * sizeof(fp));
    cudaMemcpy(d_I, h_I, Ne * sizeof(fp), cudaMemcpyHostToDevice);
    
    printf("Running extract kernel (SRAD):\n");
    printf("  Elements: %ld\n", Ne);
    
    int num_blocks = (Ne + NUMBER_THREADS - 1) / NUMBER_THREADS;
    extract<<<num_blocks, NUMBER_THREADS>>>(Ne, d_I);
    
    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));
    
    cudaMemcpy(h_I, d_I, Ne * sizeof(fp), cudaMemcpyDeviceToHost);
    
    // 验证：解压后应恢复到 1-255 范围
    printf("\nSample extracted values:\n");
    for (int i = 0; i < 5; i++) {
        printf("  [%d]: %.2f\n", i, h_I[i]);
    }
    
    cudaFree(d_I);
    free(h_I);
    
    return err == cudaSuccess ? 0 : 1;
}