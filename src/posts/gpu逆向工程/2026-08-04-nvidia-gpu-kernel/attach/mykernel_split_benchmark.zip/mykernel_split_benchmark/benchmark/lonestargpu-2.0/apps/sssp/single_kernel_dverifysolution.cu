// Standalone CUDA kernel file: dverifysolution
// Smoke-test version with main()

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

typedef unsigned foru;

static inline void checkCuda(cudaError_t err, const char* msg) {
  if (err != cudaSuccess) {
    fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
    exit(EXIT_FAILURE);
  }
}

struct Graph {
  enum { NotAllocated, AllocatedOnHost, AllocatedOnDevice } memory;

  unsigned nnodes, nedges;
  unsigned *noutgoing, *nincoming, *srcsrc, *psrc, *edgessrcdst;
  foru *edgessrcwt;
  unsigned *levels;
  unsigned source;

  unsigned *maxOutDegree, *maxInDegree;
  unsigned diameter;
  bool foundStats;

  __device__ unsigned getOutDegree(unsigned src) {
    return psrc[src + 1] - psrc[src];
  }

  __device__ unsigned getInDegree(unsigned src) {
    return nincoming ? nincoming[src] : 0;
  }

  __device__ unsigned getDestination(unsigned src, unsigned nthedge) {
    return edgessrcdst[psrc[src] + nthedge];
  }

  __device__ foru getWeight(unsigned src, unsigned nthedge) {
    return edgessrcwt[psrc[src] + nthedge];
  }

  __device__ unsigned getMinEdge(unsigned src) {
    return psrc[src];
  }

  __device__ unsigned getFirstEdge(unsigned src) {
    return psrc[src];
  }
};

__global__ void dverifysolution(foru *dist, Graph graph, unsigned *nerr) {
  unsigned int nn = blockIdx.x * blockDim.x + threadIdx.x;
  if (nn < graph.nnodes) {
    unsigned int nsrcedges = graph.getOutDegree(nn);
    for (unsigned ii = 0; ii < nsrcedges; ++ii) {
      unsigned int u = nn;
      unsigned int v = graph.getDestination(u, ii);
      foru wt = graph.getWeight(u, ii);
      if (wt > 0 && dist[u] + wt < dist[v]) {
        atomicAdd(nerr, 1u);
      }
    }
  }
}

static void initTinyGraph(Graph &g) {
  // 0 -> 1 (1), 0 -> 2 (4), 1 -> 2 (2)
  const unsigned nnodes = 3;
  const unsigned nedges = 3;

  unsigned h_psrc[4] = {0, 2, 3, 3};
  unsigned h_dst[3] = {1, 2, 2};
  foru h_wt[3] = {1, 4, 2};

  g.nnodes = nnodes;
  g.nedges = nedges;
  g.noutgoing = NULL;
  g.nincoming = NULL;
  g.srcsrc = NULL;
  g.levels = NULL;
  g.source = 0;
  g.maxOutDegree = NULL;
  g.maxInDegree = NULL;
  g.diameter = 0;
  g.foundStats = false;

  checkCuda(cudaMalloc((void**)&g.psrc, (nnodes + 1) * sizeof(unsigned)), "malloc psrc");
  checkCuda(cudaMalloc((void**)&g.edgessrcdst, nedges * sizeof(unsigned)), "malloc dst");
  checkCuda(cudaMalloc((void**)&g.edgessrcwt, nedges * sizeof(foru)), "malloc wt");

  checkCuda(cudaMemcpy(g.psrc, h_psrc, sizeof(h_psrc), cudaMemcpyHostToDevice), "copy psrc");
  checkCuda(cudaMemcpy(g.edgessrcdst, h_dst, sizeof(h_dst), cudaMemcpyHostToDevice), "copy dst");
  checkCuda(cudaMemcpy(g.edgessrcwt, h_wt, sizeof(h_wt), cudaMemcpyHostToDevice), "copy wt");
}

static void freeTinyGraph(Graph &g) {
  if (g.psrc) cudaFree(g.psrc);
  if (g.edgessrcdst) cudaFree(g.edgessrcdst);
  if (g.edgessrcwt) cudaFree(g.edgessrcwt);
  g.psrc = NULL;
  g.edgessrcdst = NULL;
  g.edgessrcwt = NULL;
}

int main() {
  Graph g;
  initTinyGraph(g);

  foru h_dist[3] = {0, 1, 10};  // 故意给错，让 verifier 报错
  foru *d_dist = NULL;
  unsigned *d_nerr = NULL;
  unsigned h_nerr = 0;

  checkCuda(cudaMalloc((void**)&d_dist, 3 * sizeof(foru)), "malloc dist");
  checkCuda(cudaMalloc((void**)&d_nerr, sizeof(unsigned)), "malloc nerr");
  checkCuda(cudaMemcpy(d_dist, h_dist, sizeof(h_dist), cudaMemcpyHostToDevice), "copy dist");
  checkCuda(cudaMemset(d_nerr, 0, sizeof(unsigned)), "memset nerr");

  dim3 block(128);
  dim3 grid(1);

  dverifysolution<<<grid, block>>>(d_dist, g, d_nerr);
  checkCuda(cudaGetLastError(), "dverifysolution launch failed");
  checkCuda(cudaDeviceSynchronize(), "dverifysolution execution failed");

  checkCuda(cudaMemcpy(&h_nerr, d_nerr, sizeof(unsigned), cudaMemcpyDeviceToHost), "copy nerr");

  printf("dverifysolution finished\n");
  printf("nerr = %u\n", h_nerr);

  cudaFree(d_dist);
  cudaFree(d_nerr);
  freeTinyGraph(g);
  return 0;
}