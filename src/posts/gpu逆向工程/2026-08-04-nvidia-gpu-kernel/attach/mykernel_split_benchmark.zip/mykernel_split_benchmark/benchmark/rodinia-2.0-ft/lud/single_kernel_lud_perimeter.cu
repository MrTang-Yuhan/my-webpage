// Auto-generated CUDA kernel file: lud_perimeter
// Extracted from: rodinia/2.0-ft/lud/lud_kernel.cu
// Original line: 48

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>

// ===== Macro Definitions =====
#define BLOCK_SIZE 16  // from line 4

// ===== Kernel =====
// Kernel: lud_perimeter (line 48)
__global__ void
lud_perimeter(float *m, int matrix_dim, int offset) {

  __shared__ float dia[BLOCK_SIZE][BLOCK_SIZE];
  __shared__ float peri_row[BLOCK_SIZE][BLOCK_SIZE];
  __shared__ float peri_col[BLOCK_SIZE][BLOCK_SIZE];

  int i,j, array_offset;  // [参数: offset]
  int idx;

  if (threadIdx.x < BLOCK_SIZE) {
    idx = threadIdx.x;
    
    array_offset = offset*matrix_dim+offset;  // [参数: m, matrix_dim, offset]
    for (i=0; i < BLOCK_SIZE/2; i++){
      dia[i][idx]=m[array_offset+idx];  // [参数: m, offset]
      array_offset += matrix_dim;  // [参数: m, matrix_dim, offset]
    }
    
    array_offset = offset*matrix_dim+offset;  // [参数: m, matrix_dim, offset]
    for (i=0; i < BLOCK_SIZE; i++) {
      peri_row[i][idx]=m[array_offset+(blockIdx.x+1)*BLOCK_SIZE+idx];  // [参数: m, offset]
      array_offset += matrix_dim;  // [参数: m, matrix_dim, offset]
    }

  } else {
    idx = threadIdx.x-BLOCK_SIZE;
    
    array_offset = (offset+BLOCK_SIZE/2)*matrix_dim+offset;  // [参数: m, matrix_dim, offset]
    for (i=BLOCK_SIZE/2; i < BLOCK_SIZE; i++){
      dia[i][idx]=m[array_offset+idx];  // [参数: m, offset]
      array_offset += matrix_dim;  // [参数: m, matrix_dim, offset]
    }
    
    array_offset = (offset+(blockIdx.x+1)*BLOCK_SIZE)*matrix_dim+offset;  // [参数: m, matrix_dim, offset]
    for (i=0; i < BLOCK_SIZE; i++) {
      peri_col[i][idx] = m[array_offset+idx];  // [参数: m, offset]
      array_offset += matrix_dim;  // [参数: m, matrix_dim, offset]
    }
  
  }
  __syncthreads();

  if (threadIdx.x < BLOCK_SIZE) { //peri-row
    idx=threadIdx.x;
    for(i=1; i < BLOCK_SIZE; i++){
      for (j=0; j < i; j++)
        peri_row[i][idx]-=dia[i][j]*peri_row[j][idx];
    }
    
    array_offset = (offset+1)*matrix_dim+offset;  // [参数: m, matrix_dim, offset]
    for(i=1; i < BLOCK_SIZE; i++){
      m[array_offset+(blockIdx.x+1)*BLOCK_SIZE+idx] = peri_row[i][idx];  // [参数: m, offset]
      array_offset += matrix_dim;  // [参数: m, matrix_dim, offset]
    }
  } else { //peri-col
    idx=threadIdx.x - BLOCK_SIZE;
    for(i=0; i < BLOCK_SIZE; i++){
      for(j=0; j < i; j++)
        peri_col[idx][i]-=peri_col[idx][j]*dia[j][i];
      peri_col[idx][i] /= dia[i][i];
    }

    __syncthreads();
    
    array_offset = (offset+(blockIdx.x+1)*BLOCK_SIZE)*matrix_dim+offset;  // [参数: m, matrix_dim, offset]
    for(i=0; i < BLOCK_SIZE; i++){
      m[array_offset+idx] =  peri_col[i][idx];  // [参数: m, offset]
      array_offset += matrix_dim;  // [参数: m, matrix_dim, offset]
    }
  }


}


// 在 single_kernel_lud_perimeter.cu 末尾追加

int main() {
    const int matrix_dim = 64;
    const int offset = 0;
    const int total_elem = matrix_dim * matrix_dim;
    const int num_blocks = (matrix_dim / BLOCK_SIZE) - 1; // 去掉对角块

    // 初始化矩阵
    float *h_m = (float*)malloc(total_elem * sizeof(float));
    for (int i = 0; i < total_elem; i++) {
        h_m[i] = (float)(rand() % 100) / 10.0f;
    }
    // 对角块设为单位矩阵（模拟 lud_diagonal 已处理）
    for (int i = 0; i < BLOCK_SIZE; i++) {
        for (int j = 0; j < BLOCK_SIZE; j++) {
            h_m[i * matrix_dim + j] = (i == j) ? 1.0f : 0.0f;
        }
    }

    float *d_m;
    cudaMalloc(&d_m, total_elem * sizeof(float));
    cudaMemcpy(d_m, h_m, total_elem * sizeof(float), cudaMemcpyHostToDevice);

    // 启动 kernel（处理第一行/列的周边块）
    printf("Running lud_perimeter: matrix_dim=%d, offset=%d, blocks=%d\n", 
           matrix_dim, offset, num_blocks);
    lud_perimeter<<<num_blocks, BLOCK_SIZE*2>>>(d_m, matrix_dim, offset);
    
    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));

    cudaMemcpy(h_m, d_m, total_elem * sizeof(float), cudaMemcpyDeviceToHost);

    // 验证：第一行块应被更新
    printf("Sample perimeter block (row 0, col 1):\n");
    for (int i = 0; i < 3; i++) {
        for (int j = BLOCK_SIZE; j < BLOCK_SIZE + 3; j++) {
            printf("%.4f ", h_m[i * matrix_dim + j]);
        }
        printf("\n");
    }

    cudaFree(d_m);
    free(h_m);
    return err == cudaSuccess ? 0 : 1;
}