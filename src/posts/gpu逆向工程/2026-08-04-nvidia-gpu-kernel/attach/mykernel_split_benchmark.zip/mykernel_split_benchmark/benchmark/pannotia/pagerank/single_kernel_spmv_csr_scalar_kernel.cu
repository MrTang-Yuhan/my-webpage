// Auto-generated CUDA kernel file: spmv_csr_scalar_kernel
// Extracted from: pannotia/pagerank/kernel_spmv.cu
// Original line: 120

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: spmv_csr_scalar_kernel (line 120)
__global__ void
spmv_csr_scalar_kernel(const int num_nodes, int *row, int *col, float *data,
                       float *x, float *y) {

    // Get my workitem id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;
    if (tid < num_nodes) {
        // Get the start and end pointers
        int row_start = row[tid];
        int row_end = row[tid + 1];
        float sum = 0;
        //navigate one row and sum all the elements
        for (int j = row_start; j < row_end; j++) {
            sum += data[j] * x[col[j]];
        }
        y[tid] += sum;
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;

    const size_t size_row = (size_t)(num_nodes + 1) * sizeof(int);
    const size_t size_col = (size_t)num_edges * sizeof(int);
    const size_t size_data = (size_t)num_edges * sizeof(float);
    const size_t size_vec = (size_t)num_nodes * sizeof(float);

    int *h_row = (int*)malloc(size_row);
    int *h_col = (int*)malloc(size_col);
    float *h_data = (float*)malloc(size_data);
    float *h_x = (float*)malloc(size_vec);
    float *h_y = (float*)malloc(size_vec);

    int *d_row = nullptr;
    int *d_col = nullptr;
    float *d_data = nullptr;
    float *d_x = nullptr;
    float *d_y = nullptr;

    if (!h_row || !h_col || !h_data || !h_x || !h_y) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_col);
        free(h_data);
        free(h_x);
        free(h_y);
        return -1;
    }

    // 每行至多一个非零元的简单 CSR
    for (int i = 0; i < num_nodes; ++i) {
        h_row[i] = i;
        h_x[i] = 1.0f;
        h_y[i] = 0.0f;
    }
    h_row[num_nodes] = num_edges;

    for (int i = 0; i < num_edges; ++i) {
        h_col[i] = i + 1;
        h_data[i] = 1.0f;
    }

    cudaMalloc((void**)&d_row, size_row);
    cudaMalloc((void**)&d_col, size_col);
    cudaMalloc((void**)&d_data, size_data);
    cudaMalloc((void**)&d_x, size_vec);
    cudaMalloc((void**)&d_y, size_vec);

    cudaMemcpy(d_row, h_row, size_row, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col, h_col, size_col, cudaMemcpyHostToDevice);
    cudaMemcpy(d_data, h_data, size_data, cudaMemcpyHostToDevice);
    cudaMemcpy(d_x, h_x, size_vec, cudaMemcpyHostToDevice);
    cudaMemcpy(d_y, h_y, size_vec, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    spmv_csr_scalar_kernel<<<gridSize, blockSize>>>(
        num_nodes, d_row, d_col, d_data, d_x, d_y
    );
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_y, d_y, size_vec, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("spmv_csr_scalar_kernel execution time: %.3f ms\n", ms);

    printf("y[0] = %f\n", h_y[0]);
    printf("y[1] = %f\n", h_y[1]);
    printf("y[2] = %f\n", h_y[2]);
    printf("y[last] = %f\n", h_y[num_nodes - 1]);

    cudaFree(d_row);
    cudaFree(d_col);
    cudaFree(d_data);
    cudaFree(d_x);
    cudaFree(d_y);

    free(h_row);
    free(h_col);
    free(h_data);
    free(h_x);
    free(h_y);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}