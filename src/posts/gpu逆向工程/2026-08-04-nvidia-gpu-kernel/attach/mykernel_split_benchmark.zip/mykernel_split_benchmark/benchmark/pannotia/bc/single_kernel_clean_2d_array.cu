// Auto-generated CUDA kernel file: clean_2d_array
// Extracted from: pannotia/bc/kernel.cu
// Original line: 214

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: clean_2d_array (line 214)
__global__ void clean_2d_array(int *p, const int num_nodes) {

    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    if (tid < num_nodes * num_nodes)
        p[tid] = 0;

}


int main(int argc, char** argv) {
    const int num_nodes = 1024;
    const size_t num_elements = (size_t)num_nodes * num_nodes;
    const size_t size_p = num_elements * sizeof(int);

    int *h_p = (int*)malloc(size_p);
    int *d_p = nullptr;

    if (!h_p) {
        printf("malloc failed for h_p\n");
        return -1;
    }

    for (size_t i = 0; i < num_elements; ++i) {
        h_p[i] = (int)(i % 100 + 1);
    }

    cudaError_t err;

    err = cudaMalloc((void**)&d_p, size_p);
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_p: %s\n", cudaGetErrorString(err));
        free(h_p);
        return -1;
    }

    err = cudaMemcpy(d_p, h_p, size_p, cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for p: %s\n", cudaGetErrorString(err));
        cudaFree(d_p);
        free(h_p);
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((num_elements + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    clean_2d_array<<<gridSize, blockSize>>>(d_p, num_nodes);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_p);
        free(h_p);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_p);
        free(h_p);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaEventSynchronize(stop);

    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("clean_2d_array execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_p, d_p, size_p, cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for p: %s\n", cudaGetErrorString(err));
        cudaFree(d_p);
        free(h_p);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    printf("p[0] = %d\n", h_p[0]);
    printf("p[num_nodes * num_nodes - 1] = %d\n", h_p[num_elements - 1]);

    cudaFree(d_p);
    free(h_p);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}