// Auto-generated CUDA kernel file: inicsr
// Extracted from: pannotia/pagerank/kernel_spmv.cu
// Original line: 85

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: inicsr (line 85)
__global__ void
inicsr(int *row, int *col, float *data, int *col_cnt, int num_nodes,
       int num_edges) {

    // Get my workitem id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;
    if (tid < num_nodes) {
        // Get the starting and ending pointers
        int start = row[tid];
        int end;
        if (tid + 1 < num_nodes) {
            end = row[tid + 1] ;
        } else {
            end = num_edges;
        }

        int nid;
        // Navigate one row of data
        for (int edge = start; edge < end; edge++) {
            nid = col[edge];
            // Each neighbor will get equal amount of pagerank
            data[edge] = 1.0 / (float)col_cnt[nid];
        }
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;

    const size_t size_row = (size_t)num_nodes * sizeof(int);
    const size_t size_col = (size_t)num_edges * sizeof(int);
    const size_t size_data = (size_t)num_edges * sizeof(float);
    const size_t size_col_cnt = (size_t)num_nodes * sizeof(int);

    int *h_row = (int*)malloc(size_row);
    int *h_col = (int*)malloc(size_col);
    float *h_data = (float*)malloc(size_data);
    int *h_col_cnt = (int*)malloc(size_col_cnt);

    int *d_row = nullptr;
    int *d_col = nullptr;
    float *d_data = nullptr;
    int *d_col_cnt = nullptr;

    if (!h_row || !h_col || !h_data || !h_col_cnt) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_col);
        free(h_data);
        free(h_col_cnt);
        return -1;
    }

    // 简单链式图
    for (int i = 0; i < num_nodes; ++i) {
        h_row[i] = (i < num_nodes - 1) ? i : num_edges;
        h_col_cnt[i] = 1;
    }

    for (int i = 0; i < num_edges; ++i) {
        h_col[i] = i + 1;
        h_data[i] = 0.0f;
    }

    cudaMalloc((void**)&d_row, size_row);
    cudaMalloc((void**)&d_col, size_col);
    cudaMalloc((void**)&d_data, size_data);
    cudaMalloc((void**)&d_col_cnt, size_col_cnt);

    cudaMemcpy(d_row, h_row, size_row, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col, h_col, size_col, cudaMemcpyHostToDevice);
    cudaMemcpy(d_data, h_data, size_data, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col_cnt, h_col_cnt, size_col_cnt, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    inicsr<<<gridSize, blockSize>>>(d_row, d_col, d_data, d_col_cnt, num_nodes, num_edges);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_data, d_data, size_data, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("inicsr execution time: %.3f ms\n", ms);

    printf("data[0] = %f\n", h_data[0]);
    printf("data[1] = %f\n", h_data[1]);
    printf("data[2] = %f\n", h_data[2]);

    cudaFree(d_row);
    cudaFree(d_col);
    cudaFree(d_data);
    cudaFree(d_col_cnt);

    free(h_row);
    free(h_col);
    free(h_data);
    free(h_col_cnt);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}