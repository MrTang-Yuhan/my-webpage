// Auto-generated CUDA kernel file: back_sum_kernel
// Extracted from: pannotia/bc/kernel.cu
// Original line: 165

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: back_sum_kernel (line 165)
__global__ void
back_sum_kernel(const int s, const int dist, int *d, float *sigma, float *bc,
                const int num_nodes) {

    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    if (tid < num_nodes) {
        // If it is not the source
        if (s != tid && d[tid] == dist - 1) {
            bc[tid] = bc[tid] + sigma[tid];
        }
    }

}

int main(int argc, char** argv) {
    const int num_nodes = 1024;
    const int s = 0;
    const int dist = 2;

    const size_t size_int = (size_t)num_nodes * sizeof(int);
    const size_t size_float = (size_t)num_nodes * sizeof(float);

    int *h_d = (int*)malloc(size_int);
    float *h_sigma = (float*)malloc(size_float);
    float *h_bc = (float*)malloc(size_float);

    int *d_d = nullptr;
    float *d_sigma = nullptr;
    float *d_bc = nullptr;

    if (!h_d || !h_sigma || !h_bc) {
        printf("host malloc failed\n");
        free(h_d);
        free(h_sigma);
        free(h_bc);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_d[i] = -1;
        h_sigma[i] = 0.0f;
        h_bc[i] = 0.0f;
    }

    h_d[0] = 0;
    h_d[1] = 1;

    h_sigma[1] = 0.5f;
    h_bc[1] = 1.0f;

    cudaError_t err;

    err = cudaMalloc((void**)&d_d, size_int);
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_d: %s\n", cudaGetErrorString(err));
        free(h_d);
        free(h_sigma);
        free(h_bc);
        return -1;
    }

    err = cudaMalloc((void**)&d_sigma, size_float);
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_sigma: %s\n", cudaGetErrorString(err));
        cudaFree(d_d);
        free(h_d);
        free(h_sigma);
        free(h_bc);
        return -1;
    }

    err = cudaMalloc((void**)&d_bc, size_float);
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_bc: %s\n", cudaGetErrorString(err));
        cudaFree(d_d);
        cudaFree(d_sigma);
        free(h_d);
        free(h_sigma);
        free(h_bc);
        return -1;
    }

    cudaMemcpy(d_d, h_d, size_int, cudaMemcpyHostToDevice);
    cudaMemcpy(d_sigma, h_sigma, size_float, cudaMemcpyHostToDevice);
    cudaMemcpy(d_bc, h_bc, size_float, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    back_sum_kernel<<<gridSize, blockSize>>>(
        s,
        dist,
        d_d,
        d_sigma,
        d_bc,
        num_nodes
    );
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_d);
        cudaFree(d_sigma);
        cudaFree(d_bc);
        free(h_d);
        free(h_sigma);
        free(h_bc);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_d);
        cudaFree(d_sigma);
        cudaFree(d_bc);
        free(h_d);
        free(h_sigma);
        free(h_bc);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaEventSynchronize(stop);

    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("back_sum_kernel execution time: %.3f ms\n", milliseconds);

    cudaMemcpy(h_bc, d_bc, size_float, cudaMemcpyDeviceToHost);

    printf("bc[0] = %f\n", h_bc[0]);
    printf("bc[1] = %f\n", h_bc[1]);

    cudaFree(d_d);
    cudaFree(d_sigma);
    cudaFree(d_bc);

    free(h_d);
    free(h_sigma);
    free(h_bc);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}
