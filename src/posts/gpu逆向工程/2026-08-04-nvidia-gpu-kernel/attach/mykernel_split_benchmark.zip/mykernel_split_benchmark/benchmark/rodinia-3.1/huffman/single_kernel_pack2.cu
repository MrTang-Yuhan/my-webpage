#include <stdio.h>
#include <stdlib.h>

__global__ static void pack2(unsigned int *srcData, unsigned int *cindex,
                               unsigned int *cindex2, unsigned int *dstData,
                               unsigned int original_num_block_elements) {
    unsigned int tid    = blockDim.x * blockIdx.x + threadIdx.x;
    unsigned int offset = tid * original_num_block_elements;
    unsigned int bitsize = cindex[tid];
    unsigned int pos  = cindex2[tid];
    unsigned int dword = pos / 32, bit = pos % 32;

    unsigned int i, dw, tmp;
    dw  = srcData[offset];
    tmp = dw >> bit;
    atomicOr(&dstData[dword], tmp);
    tmp = dw << (32 - bit);
    for (i = 1; i < bitsize/32; i++) {
        dw = srcData[offset + i];
        tmp |= dw >> bit;
        dstData[dword + i] = tmp;
        tmp = dw << (32 - bit);
    }
    if (bit != 0 || bitsize % 32 != 0)
        atomicOr(&dstData[dword + i], tmp);
    if (bitsize % 32 != 0) {
        dw = srcData[offset + i];
        atomicOr(&dstData[dword + i],     dw >> bit);
        atomicOr(&dstData[dword + i + 1], dw << (32 - bit));
    }
}

int main() {
    const int THREADS = 4;
    const int DPE     = 2;   // original_num_block_elements（每线程处理的 dword 数）
    const int TOTAL   = THREADS * DPE;

    unsigned int h_src[TOTAL], h_ci[THREADS], h_ci2[THREADS];
    unsigned int h_dst[TOTAL * 2];
    memset(h_dst, 0, sizeof(h_dst));

    for (int i = 0; i < TOTAL; i++) h_src[i] = 0xAAAAAAAA;
    for (int i = 0; i < THREADS; i++) {
        h_ci[i]  = DPE * 32;   // bitsize = 64 bits
        h_ci2[i] = i * DPE * 32; // 目标起始 bit 位置
    }

    unsigned int *d_src, *d_ci, *d_ci2, *d_dst;
    cudaMalloc(&d_src, TOTAL    * sizeof(unsigned int));
    cudaMalloc(&d_ci,  THREADS  * sizeof(unsigned int));
    cudaMalloc(&d_ci2, THREADS  * sizeof(unsigned int));
    cudaMalloc(&d_dst, TOTAL*2  * sizeof(unsigned int));
    cudaMemcpy(d_src, h_src, TOTAL   *sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_ci,  h_ci,  THREADS *sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_ci2, h_ci2, THREADS *sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemset(d_dst, 0, TOTAL*2 * sizeof(unsigned int));

    pack2<<<1, THREADS>>>(d_src, d_ci, d_ci2, d_dst, DPE);
    cudaDeviceSynchronize();

    cudaMemcpy(h_dst, d_dst, TOTAL*2*sizeof(unsigned int), cudaMemcpyDeviceToHost);
    printf("dst[0]=0x%08X dst[1]=0x%08X (expected 0xAAAAAAAA)\n", h_dst[0], h_dst[1]);

    cudaFree(d_src); cudaFree(d_ci); cudaFree(d_ci2); cudaFree(d_dst);
    return 0;
}