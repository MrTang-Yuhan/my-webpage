// Auto-generated CUDA kernel file: executeBnNormLayerCUDA
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 803

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeBnNormLayerCUDA (line 803)
__global__ void executeBnNormLayerCUDA(float *Layer_Neurons,float *mean,float *var,int out,int f_size) {

           int output = blockIdx.x;
	   //for(int output = 0;output < out;output++)
	   {
                   int i = threadIdx.x * blockDim.x + threadIdx.y;
		   //for(int i=0;i < f_size;i++)
		   {
			   Layer_Neurons[output*f_size + i] = (Layer_Neurons[output*f_size + i] - mean[output])/(sqrt(var[output] + 1e-5));
		   }
	   }

}

#include <math.h>


int main() {
    const int out = 4;
    const int f_size = 64;

    size_t neuron_size = (size_t)out * f_size;
    size_t stat_size = out;

    float *h_neurons = (float*)malloc(neuron_size * sizeof(float));
    float *h_mean    = (float*)malloc(stat_size * sizeof(float));
    float *h_var     = (float*)malloc(stat_size * sizeof(float));

    for (size_t i = 0; i < neuron_size; ++i) h_neurons[i] = (float)(i % 21) * 0.1f;
    for (int i = 0; i < out; ++i) {
        h_mean[i] = 0.5f;
        h_var[i]  = 1.0f;
    }

    float *d_neurons = NULL, *d_mean = NULL, *d_var = NULL;
    CHECK(cudaMalloc((void**)&d_neurons, neuron_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_mean, stat_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_var, stat_size * sizeof(float)));

    CHECK(cudaMemcpy(d_neurons, h_neurons, neuron_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_mean, h_mean, stat_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_var, h_var, stat_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block(8, 8);

    executeBnNormLayerCUDA<<<grid, block>>>(d_neurons, d_mean, d_var, out, f_size);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_neurons, d_neurons, neuron_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeBnNormLayerCUDA done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("neurons[%d] = %f\n", i, h_neurons[i]);
    }

    cudaFree(d_neurons);
    cudaFree(d_mean);
    cudaFree(d_var);

    free(h_neurons);
    free(h_mean);
    free(h_var);

    return 0;
}