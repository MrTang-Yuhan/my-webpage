// Auto-generated CUDA kernel file: bpnn_adjust_weights_cuda
// Extracted from: rodinia/2.0-ft/backprop/backprop_cuda_kernel.cu
// Original line: 81

// ===== Includes =====
#include <stdio.h>
#include "backprop.h"
#include "math.h"
#include "cuda.h"

// ===== Macro Definitions =====
#define _BACKPROP_CUDA_KERNEL_H_  // from line 4

// ===== Kernel =====
// Kernel: bpnn_adjust_weights_cuda (line 81)
__global__ void bpnn_adjust_weights_cuda(float * delta,   
										 int hid,         
										 float * ly,      
										 int in,          
										 float * w,       
										 float * oldw) {

  
  
   int by = blockIdx.y;  // [参数: in]

   int tx = threadIdx.x;  // [参数: in]
   int ty = threadIdx.y;  // [参数: in]
	
   int index =  ( hid + 1 ) * HEIGHT * by + ( hid + 1 ) * ty + tx + 1 + ( hid + 1 ) ;    // [参数: hid, in]
   int index_y = HEIGHT * by + ty + 1;  // [参数: in]
   int index_x = tx + 1;  // [参数: in]
   //eta = 0.3;
   //momentum = 0.3;

   w[index] += ((ETA * delta[index_x] * ly[index_y]) + (MOMENTUM * oldw[index]));  // [参数: delta, ly, in, w, oldw]
   oldw[index] = ((ETA * delta[index_x] * ly[index_y]) + (MOMENTUM * oldw[index]));  // [参数: delta, ly, in, w, oldw]


   __syncthreads();

   if (ty == 0 && by ==0){
   w[index_x] += ((ETA * delta[index_x]) + (MOMENTUM * oldw[index_x]));  // [参数: delta, in, w, oldw]
   oldw[index_x] = ((ETA * delta[index_x]) + (MOMENTUM * oldw[index_x]));  // [参数: delta, in, w, oldw]
   }

}

int main() {
  int in = HEIGHT;
  int hid = WIDTH;
  size_t delta_size = (hid + 1) * sizeof(float);
  size_t ly_size    = (HEIGHT + 1) * sizeof(float);
  size_t w_size     = (hid + 1) * HEIGHT * sizeof(float);
  size_t oldw_size  = w_size;
  float *h_delta  = (float*)malloc(delta_size);
  float *h_ly     = (float*)malloc(ly_size);
  float *h_w      = (float*)malloc(w_size);
  float *h_oldw   = (float*)malloc(oldw_size);
  for (int i = 0; i < hid + 1; i++) h_delta[i] = 0.1f;
  for (int i = 0; i < HEIGHT + 1; i++) h_ly[i] = 0.2f;
  for (int i = 0; i < (hid + 1) * HEIGHT; i++) {
    h_w[i] = 0.0f;
    h_oldw[i] = 0.0f;
  }
  float *d_delta, *d_ly, *d_w, *d_oldw;
  cudaMalloc((void**)&d_delta, delta_size);
  cudaMalloc((void**)&d_ly, ly_size);
  cudaMalloc((void**)&d_w, w_size);
  cudaMalloc((void**)&d_oldw, oldw_size);
  cudaMemcpy(d_delta, h_delta, delta_size, cudaMemcpyHostToDevice);
  cudaMemcpy(d_ly, h_ly, ly_size, cudaMemcpyHostToDevice);
  cudaMemcpy(d_w, h_w, w_size, cudaMemcpyHostToDevice);
  cudaMemcpy(d_oldw, h_oldw, oldw_size, cudaMemcpyHostToDevice);
  dim3 block(WIDTH, HEIGHT);
  dim3 grid(1, 1);
  bpnn_adjust_weights_cuda<<<grid, block>>>(d_delta, hid, d_ly, in, d_w, d_oldw);
  cudaDeviceSynchronize();
  cudaMemcpy(h_w, d_w, w_size, cudaMemcpyDeviceToHost);
  printf("bpnn_adjust_weights_cuda finished. h_w[0]=%f\n", h_w[0]);
  cudaFree(d_delta);
  cudaFree(d_ly);
  cudaFree(d_w);
  cudaFree(d_oldw);
  free(h_delta);
  free(h_ly);
  free(h_w);
  free(h_oldw);
  return 0;
}