// Standalone CUDA kernel file: __printGepEdges
// Smoke-test debug version

#include "pta_single_kernel_test_common.cuh"

__device__ inline uint isFirstThreadOfWarp_debug_gep() {
    return !threadIdx.x;
}

__device__ void printGepEdges_debug() {
    uint numGepInv = __numGepInv__;

    if (isFirstThreadOfWarp_debug_gep()) {
        printf("GEP_INV edges:\n");
    }

    __shared__ uint sh[WARP_SIZE];

    for (uint i = 0; i < numGepInv * 2; i += WARP_SIZE) {
        uint idx = i + threadIdx.x;
        sh[threadIdx.x] = (idx < numGepInv * 2) ? __gepInv__[idx] : NIL;
        __syncwarp();

        if (threadIdx.x == 0) {
            for (int j = 0; j < WARP_SIZE && sh[j] != NIL; j += 2) {
                if (j + 1 >= WARP_SIZE || sh[j + 1] == NIL) break;

                uint dst = sh[j];
                uint srcOffset = sh[j + 1];
                printf("%u => %u (%u)\n", dst, gep_id(srcOffset), gep_offset(srcOffset));
            }
        }

        __syncwarp();
    }
}

__global__ void __printGepEdges() {
    printGepEdges_debug();
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint h_gep[MAX_TEST_VARS * 2];
    for (uint i = 0; i < MAX_TEST_VARS * 2; i++) h_gep[i] = NIL;

    // dst => src(offset)
    h_gep[0] = 10;
    h_gep[1] = (3u << OFFSET_BITS) | 1u;

    h_gep[2] = 11;
    h_gep[3] = (5u << OFFSET_BITS) | 4u;

    cudaMemcpy(env.d_gepInv, h_gep, sizeof(h_gep), cudaMemcpyHostToDevice);

    uint numGepInv = 2;
    cudaMemcpyToSymbol(__numGepInv__, &numGepInv, sizeof(uint));

    dim3 block(32, 1);
    dim3 grid(1);

    __printGepEdges<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "__printGepEdges launch failed");
    checkCuda(cudaDeviceSynchronize(), "__printGepEdges execution failed");

    destroyPTATestEnv(env);
    return 0;
}