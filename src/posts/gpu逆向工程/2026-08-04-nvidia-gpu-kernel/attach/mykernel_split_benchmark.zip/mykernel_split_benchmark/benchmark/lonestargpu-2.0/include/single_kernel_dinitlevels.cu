// Auto-generated CUDA kernel file: dinitlevels
// Extracted from: lonestargpu-2.0/include/graph.h
// Original line: 595

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Type Definitions =====
struct Graph {
	enum {NotAllocated, AllocatedOnHost, AllocatedOnDevice} memory;

	unsigned read(char file[]);
	long unsigned cudaCopy(struct Graph &copygraph);
	unsigned optimize();
	unsigned printStats();
	void     print();

	Graph();
	~Graph();
	unsigned init();
	unsigned allocOnHost();
	unsigned allocOnDevice();
	unsigned dealloc();
	unsigned deallocOnHost();
	unsigned deallocOnDevice();
	unsigned optimizeone();
	unsigned optimizetwo();
	void allocLevels();
	void freeLevels();
	void progressPrint(unsigned maxii, unsigned ii);
	unsigned readFromEdges(char file[]);
	unsigned readFromGR(char file[]);

	__device__ void printStats1x1();
	__device__ void print1x1();
	__device__ unsigned getOutDegree(unsigned src);
	__device__ unsigned getInDegree(unsigned src);
	__device__ unsigned getDestination(unsigned src, unsigned nthedge);
	__device__ foru    getWeight(unsigned src, unsigned nthedge);
	__device__ unsigned getMinEdge(unsigned src);

	__device__ unsigned getFirstEdge(unsigned src);
	__device__ unsigned findStats();
	__device__ void computeStats();
	__device__ bool computeLevels();
	__device__ unsigned findMaxLevel();
	__device__ void computeDiameter();
	__device__ void computeInOut();
	__device__ void initLevels();


	unsigned nnodes, nedges;
	unsigned *noutgoing, *nincoming, *srcsrc, *psrc, *edgessrcdst;
	foru *edgessrcwt;
	unsigned *levels;
	unsigned source;

	unsigned *maxOutDegree, *maxInDegree;
	unsigned diameter;
	bool foundStats;

} Graph; // from lonestargpu-2.0/include/graph.h:8
typedef unsigned foru; // from lonestargpu-2.0/include/header.h:22

// ===== Kernel =====
// Kernel: dinitlevels (line 595)
__global__ void dinitlevels(Graph graph) {

	graph.initLevels();

}
