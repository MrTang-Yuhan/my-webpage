#!/bin/bash

# 遍历当前目录下所有以 single_kernel_ 开头的文件
for file in single_kernel_*; do
    # 检查文件是否存在（防止通配符匹配不到任何文件时报错）
    # 并且检查它是否是一个可执行的普通文件
    if [ -f "$file" ] && [ -x "$file" ]; then
        echo "========================================"
        echo "正在运行: $file"
        echo "========================================"
        
        # 运行程序
        "./$file"
        
        # 检查上一个程序是否运行成功
        if [ $? -ne 0 ]; then
            echo "[错误] $file 运行失败，退出码: $?"
        fi
        
        echo "" # 输出一个空行，分隔不同程序的输出
    else
        # 如果匹配到的文件名存在但不可执行，或者根本没有匹配到文件
        if [ -e "$file" ]; then
            echo "[跳过] $file 不可执行"
        fi
    fi
done

echo "所有任务执行完毕。"