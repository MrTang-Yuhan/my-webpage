// Auto-generated CUDA kernel file: atax_kernel2
// Extracted from: polybench-gpu-1.0/CUDA/ATAX/single_kernel_atax_kernel2.cu
// Original line: 24

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define NX 4096  // from line 26  // from line 16
#define NY 4096  // from line 27  // from line 17

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/ATAX/single_kernel_atax_kernel2.cu:20

// ===== Kernel =====
// Kernel: atax_kernel2 (line 24)
__global__ void atax_kernel2(DATA_TYPE *A, DATA_TYPE *y, DATA_TYPE *tmp) {


	int j = blockIdx.x * blockDim.x + threadIdx.x;
	
	if (j < NY)
	{
		int i;
		for(i=0; i < NX; i++)
		{
			y[j] += A[i * NY + j] * tmp[i];
		}
	}


}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_A = (size_t)NX * NY;
    const size_t size_y = NY;
    const size_t size_tmp = NX;

    DATA_TYPE *h_A = (DATA_TYPE*)malloc(size_A * sizeof(DATA_TYPE));
    DATA_TYPE *h_y = (DATA_TYPE*)malloc(size_y * sizeof(DATA_TYPE));
    DATA_TYPE *h_tmp = (DATA_TYPE*)malloc(size_tmp * sizeof(DATA_TYPE));

    DATA_TYPE *d_A = nullptr;
    DATA_TYPE *d_y = nullptr;
    DATA_TYPE *d_tmp = nullptr;

    if (!h_A || !h_y || !h_tmp) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_A; ++i) h_A[i] = (DATA_TYPE)(i % 100) / 100.0f;
    for (size_t i = 0; i < size_y; ++i) h_y[i] = 0;
    for (size_t i = 0; i < size_tmp; ++i) h_tmp[i] = (DATA_TYPE)(i % 100) / 100.0f;

    err = cudaMalloc((void**)&d_A, size_A * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_A failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_y, size_y * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_y failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_tmp, size_tmp * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_tmp failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_A, h_A, size_A * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D A failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_y, h_y, size_y * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D y failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_tmp, h_tmp, size_tmp * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D tmp failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((NY + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    atax_kernel2<<<gridSize, blockSize>>>(d_A, d_y, d_tmp);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel2 execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_y, d_y, size_y * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H y failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("y[0] = %f\n", (double)h_y[0]);

    cudaFree(d_A);
    cudaFree(d_y);
    cudaFree(d_tmp);
    free(h_A);
    free(h_y);
    free(h_tmp);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}