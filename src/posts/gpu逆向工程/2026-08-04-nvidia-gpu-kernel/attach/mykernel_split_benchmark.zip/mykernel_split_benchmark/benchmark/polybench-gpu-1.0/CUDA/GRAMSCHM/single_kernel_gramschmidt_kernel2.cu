// Auto-generated CUDA kernel file: gramschmidt_kernel2
// Extracted from: polybench-gpu-1.0/CUDA/GRAMSCHM/gramschmidt.cu
// Original line: 136

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <cuda.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define M 2048  // from line 27
#define N 2048  // from line 28

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/GRAMSCHM/gramschmidt.cu:35

// ===== Kernel =====
// Kernel: gramschmidt_kernel2 (line 136)
__global__ void gramschmidt_kernel2(DATA_TYPE *a, DATA_TYPE *r, DATA_TYPE *q, int k) {

	int i = blockIdx.x * blockDim.x + threadIdx.x;
	
	if (i < M)
	{	
		q[i * N + k] = a[i * N + k] / r[k * N + k];
	}

}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_a = (size_t)M * N;
    const size_t size_r = (size_t)N * N;
    const size_t size_q = (size_t)M * N;

    int k = 0;

    DATA_TYPE *h_a = (DATA_TYPE*)malloc(size_a * sizeof(DATA_TYPE));
    DATA_TYPE *h_r = (DATA_TYPE*)malloc(size_r * sizeof(DATA_TYPE));
    DATA_TYPE *h_q = (DATA_TYPE*)malloc(size_q * sizeof(DATA_TYPE));

    DATA_TYPE *d_a = nullptr;
    DATA_TYPE *d_r = nullptr;
    DATA_TYPE *d_q = nullptr;

    if (!h_a || !h_r || !h_q) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_a; ++i)
        h_a[i] = (DATA_TYPE)((i % 100) + 1) / 100.0f;

    for (size_t i = 0; i < size_r; ++i)
        h_r[i] = 0.0f;

    for (size_t i = 0; i < size_q; ++i)
        h_q[i] = 0.0f;

    // 避免 r[k*N + k] 为 0，导致除零
    h_r[k * N + k] = 1.0f;

    err = cudaMalloc((void**)&d_a, size_a * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_a failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_r, size_r * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_r failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_q, size_q * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_q failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_a, h_a, size_a * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D a failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_r, h_r, size_r * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D r failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_q, h_q, size_q * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D q failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((M + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    gramschmidt_kernel2<<<gridSize, blockSize>>>(d_a, d_r, d_q, k);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("gramschmidt_kernel2 execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_q, d_q, size_q * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H q failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("q[0 * N + k] = %f\n", (double)h_q[0 * N + k]);
    printf("q[(M-1) * N + k] = %f\n", (double)h_q[(M - 1) * N + k]);

    cudaFree(d_a);
    cudaFree(d_r);
    cudaFree(d_q);

    free(h_a);
    free(h_r);
    free(h_q);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}