// Auto-generated CUDA kernel file: floydwarshall
// Extracted from: pannotia/fw/kernel.cu
// Original line: 65

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: floydwarshall (line 65)
__global__ void
floydwarshall(int *dist, int *next, int dim, int k) {

    // Get my workitem id x_dim
    int i = blockDim.x * blockIdx.x + threadIdx.x;
    // Get my workitem id y_dim
    int j = blockDim.y * blockIdx.y + threadIdx.y;

    if (i < dim && j < dim) {
        // if (dist i -> k + k -> j) update the dist i-> j
        if (dist[i * dim + k] + dist[k * dim + j] < dist[i * dim + j]) {
            dist[i * dim + j] = dist[i * dim + k] + dist[k * dim + j];
            next[i * dim + j] = k;
        }
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int dim = 512;
    const int k = 0;
    const size_t num_elements = (size_t)dim * dim;
    const size_t size_mat = num_elements * sizeof(int);

    int *h_dist = (int*)malloc(size_mat);
    int *h_next = (int*)malloc(size_mat);
    int *d_dist = nullptr;
    int *d_next = nullptr;

    if (!h_dist || !h_next) {
        printf("host malloc failed\n");
        free(h_dist);
        free(h_next);
        return -1;
    }

    for (int i = 0; i < dim; ++i) {
        for (int j = 0; j < dim; ++j) {
            if (i == j) {
                h_dist[i * dim + j] = 0;
                h_next[i * dim + j] = i;
            } else if (j == i + 1) {
                h_dist[i * dim + j] = 1;
                h_next[i * dim + j] = j;
            } else {
                h_dist[i * dim + j] = 1000000;
                h_next[i * dim + j] = -1;
            }
        }
    }

    err = cudaMalloc((void**)&d_dist, size_mat);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_dist failed: %s\n", cudaGetErrorString(err));
        free(h_dist);
        free(h_next);
        return -1;
    }

    err = cudaMalloc((void**)&d_next, size_mat);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_next failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        free(h_dist);
        free(h_next);
        return -1;
    }

    err = cudaMemcpy(d_dist, h_dist, size_mat, cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D dist failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        cudaFree(d_next);
        free(h_dist);
        free(h_next);
        return -1;
    }

    err = cudaMemcpy(d_next, h_next, size_mat, cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D next failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        cudaFree(d_next);
        free(h_dist);
        free(h_next);
        return -1;
    }

    dim3 blockSize(16, 16);
    dim3 gridSize((dim + blockSize.x - 1) / blockSize.x,
                  (dim + blockSize.y - 1) / blockSize.y);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    floydwarshall<<<gridSize, blockSize>>>(d_dist, d_next, dim, k);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        cudaFree(d_next);
        free(h_dist);
        free(h_next);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_dist);
        cudaFree(d_next);
        free(h_dist);
        free(h_next);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("floydwarshall execution time: %.3f ms\n", ms);

    cudaMemcpy(h_dist, d_dist, size_mat, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_next, d_next, size_mat, cudaMemcpyDeviceToHost);

    printf("dist[0,0] = %d\n", h_dist[0]);
    printf("dist[0,1] = %d\n", h_dist[1]);
    printf("next[0,1] = %d\n", h_next[1]);

    cudaFree(d_dist);
    cudaFree(d_next);
    free(h_dist);
    free(h_next);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}