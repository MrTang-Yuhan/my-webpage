// Auto-generated CUDA kernel file: executepoolingCuda
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 538

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executepoolingCuda (line 538)
__global__ void executepoolingCuda(float *Layer2_Neurons_GPU,float *Layer2_pool_GPU,int out,int out_fr,int out_fc,int kernel,int stride_width,int in_fr,int in_fc,int pad,int tfactor) {

	float max = 0.0;
	int stride = 0,colstride = 0;
        int output = blockIdx.x;
	int row_even = threadIdx.x * tfactor;
	int col_even = threadIdx.y * tfactor;
        int loopr = kernel, loopc = kernel;
	{
		//for(int output =0;output < out ;output++)
		if(row_even < out_fr && col_even < out_fc)
		{
			for(int row = row_even; row < row_even+tfactor;row++)
			{  
                                colstride = (row*stride_width -pad)*in_fr;	
				colstride = colstride < 0 ? 0: colstride; 
				stride = 0;
				for(int col = col_even; col < col_even +tfactor ;col++)
				{
					loopr = kernel; loopc = kernel;
					stride = col*stride_width - pad;	
                                        stride = stride < 0 ? 0: stride; 
                                        
					if(col < pad)
					{
						loopc = kernel - pad;
                                              //  printf("col %d loopc %d\n",col,loopc); 
					}
                                        if(row < pad)
					{
						loopr = kernel - pad; 
                                               // printf("row %d loopr %d\n",row,loopr); 
					}
                                        if(col > out_fc - pad)
					{
						loopc = in_fc - stride; 
                                               // printf("col %d loopc %d\n",col,loopc); 

					}
                                        if(row > out_fr - pad)
					{
						loopr = in_fr - colstride/in_fr; 
                                               // printf("row %d loopr %d\n",row,loopr); 

					}
					for(int i = 0; i < loopr; i++)
					{			
						for(int j = 0; j < loopc; j++)
						{
							if(max < ((Layer2_Neurons_GPU[(output*in_fr*in_fc) + i*in_fc + j + stride + colstride])))
								max =   ((Layer2_Neurons_GPU[(output*in_fr*in_fc) + i*in_fc + j + stride + colstride])) ;
					//		printf("%d %d %d %f\n",(output*in_fr*in_fc) + i*in_fc + j + stride + colstride,row,col,max);

						}
					}
					Layer2_pool_GPU[output*out_fr*out_fc + row*out_fc + col] = max;
					max = 0.0;
				}
			}
		}
	}

}


int main() {
    const int out = 4;
    const int in_fr = 8, in_fc = 8;
    const int out_fr = 4, out_fc = 4;
    const int kernel = 3;
    const int stride_width = 2;
    const int pad = 1;
    const int tfactor = 2;

    size_t in_size = (size_t)out * in_fr * in_fc;
    size_t out_size = (size_t)out * out_fr * out_fc;

    float *h_in = (float*)malloc(in_size * sizeof(float));
    float *h_out = (float*)malloc(out_size * sizeof(float));

    if (!h_in || !h_out) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < in_size; ++i) {
        h_in[i] = (float)(i % 23) * 0.1f;
    }

    float *d_in = NULL, *d_out = NULL;
    CHECK(cudaMalloc((void**)&d_in, in_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out, out_size * sizeof(float)));

    CHECK(cudaMemcpy(d_in, h_in, in_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_out, 0, out_size * sizeof(float)));

    dim3 grid(out);
    dim3 block((out_fr + tfactor - 1) / tfactor, (out_fc + tfactor - 1) / tfactor);

    executepoolingCuda<<<grid, block>>>(
        d_in, d_out, out, out_fr, out_fc,
        kernel, stride_width, in_fr, in_fc, pad, tfactor
    );
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executepoolingCuda done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);

    return 0;
}