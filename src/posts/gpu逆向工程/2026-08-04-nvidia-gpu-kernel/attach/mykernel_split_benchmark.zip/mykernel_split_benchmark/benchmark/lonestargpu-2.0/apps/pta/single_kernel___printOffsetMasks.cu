// Standalone CUDA kernel file: __printOffsetMasks
// Smoke-test debug version

#include "pta_single_kernel_test_common.cuh"

__device__ inline uint __offsetMaskGet__(const uint base, const uint col, const uint offset) {
    return __offsetMask__[mul32((offset - 1) * __offsetMaskRowsPerOffset__ + base) + col];
}

__device__ __host__ static inline int isBitActive_debug_offset(uint word, uint bit) {
    return word & (1u << bit);
}

__device__ inline uint decodeWord_debug_offset(const uint base, const uint word, const uint bits) {
    uint ret = base * ELEMENT_CARDINALITY + mul32(word);
    return isBitActive_debug_offset(bits, threadIdx.x) ? __rep__[ret + threadIdx.x] : NIL;
}

__device__ inline uint isFirstWarpOfGrid_debug_offset() {
    return !(blockIdx.x || threadIdx.y);
}

__device__ void printElementAsSet_debug_offset(const uint base, volatile uint myBits, bool& first) {
    for (int i = 0; i < (int)BASE; i++) {
        uint word = __shfl_sync(0xFFFFFFFF, myBits, i);
        uint myDst = decodeWord_debug_offset(base, i, word);

        for (int j = 0; j < WARP_SIZE; j++) {
            uint dst = __shfl_sync(0xFFFFFFFF, myDst, j);
            if (dst != NIL && threadIdx.x == 0) {
                if (first) {
                    printf("%u", dst);
                } else {
                    printf(", %u", dst);
                }
                first = false;
            }
        }
    }
}

__device__ void printOffsetMask_debug(uint numObjectVars, uint offset) {
    if (threadIdx.x == 0) {
        printf("MASK for offset %u: [", offset);
    }

    bool first = true;
    int to = __offsetMaskRowsPerOffset__;

    for (int base = 0; base < to; base++) {
        uint myBits = __offsetMaskGet__(base, threadIdx.x, offset);
        printElementAsSet_debug_offset(base, myBits, first);
    }

    if (threadIdx.x == 0) {
        printf("]\n");
    }
}

__device__ void printOffsetMasks_debug(uint numObjectVars, uint maxOffset) {
    if (!isFirstWarpOfGrid_debug_offset()) {
        return;
    }

    for (uint i = 1; i <= maxOffset; i++) {
        printOffsetMask_debug(numObjectVars, i);
    }
}

__global__ void __printOffsetMasks(uint numObjectsVars, uint maxOffset) {
    printOffsetMasks_debug(numObjectsVars, maxOffset);
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint h_rep[MAX_TEST_VARS];
    for (uint i = 0; i < MAX_TEST_VARS; i++) h_rep[i] = i;
    cudaMemcpy(env.d_rep, h_rep, MAX_TEST_VARS * sizeof(uint), cudaMemcpyHostToDevice);

    uint rowsPerOffset = 1;
    cudaMemcpyToSymbol(__offsetMaskRowsPerOffset__, &rowsPerOffset, sizeof(uint));

    uint h_mask[MAX_TEST_VARS * 32];
    for (uint i = 0; i < MAX_TEST_VARS * 32; i++) h_mask[i] = 0;

    // offset=1, base=0, col=0 -> vars 1,3,6
    h_mask[0] = (1u << 1) | (1u << 3) | (1u << 6);
    // offset=2, base=0, col=0 -> vars 2,4
    h_mask[32] = (1u << 2) | (1u << 4);

    cudaMemcpy(env.d_offsetMask, h_mask, sizeof(h_mask), cudaMemcpyHostToDevice);

    dim3 block(32, 1);
    dim3 grid(1);

    __printOffsetMasks<<<grid, block>>>(64, 2);
    checkCuda(cudaGetLastError(), "__printOffsetMasks launch failed");
    checkCuda(cudaDeviceSynchronize(), "__printOffsetMasks execution failed");

    destroyPTATestEnv(env);
    return 0;
}