#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <cuda.h>

// ===== Macro Definitions =====
#define MAX_THREADS_PER_BLOCK 512

// ===== Kernel2 =====
__global__ void Kernel2(bool* g_graph_mask, bool *g_updating_graph_mask,
                        bool* g_graph_visited, bool *g_over, int no_of_nodes) {
    int tid = blockIdx.x * MAX_THREADS_PER_BLOCK + threadIdx.x;
    if (tid < no_of_nodes && g_updating_graph_mask[tid]) {
        g_graph_mask[tid] = true;
        g_graph_visited[tid] = true;
        *g_over = true;
        g_updating_graph_mask[tid] = false;
    }
}

// ===== Main for Test =====
int main() {
    // ----------------------------
    // 模拟 Kernel 执行后的状态:
    // 节点 1, 2 被 Kernel 写入 updating_mask=true（下一轮 frontier）
    // 节点 0 已 visited，其余未 visited
    // ----------------------------
    const int no_of_nodes = 4;

    bool h_graph_mask[no_of_nodes];
    bool h_updating_graph_mask[no_of_nodes];
    bool h_graph_visited[no_of_nodes];
    bool h_over = false;

    // 初始化：模拟 Kernel 执行后的中间状态
    for (int i = 0; i < no_of_nodes; i++) {
        h_graph_mask[i] = false;
        h_updating_graph_mask[i] = false;
        h_graph_visited[i] = false;
    }
    // 节点 0 已处理完
    h_graph_visited[0] = true;
    // Kernel 扩展出节点 1, 2 作为下一轮 frontier
    h_updating_graph_mask[1] = true;
    h_updating_graph_mask[2] = true;

    printf("=== Before Kernel2 ===\n");
    for (int i = 0; i < no_of_nodes; i++) {
        printf("Node %d: mask=%d, updating_mask=%d, visited=%d\n",
               i, h_graph_mask[i], h_updating_graph_mask[i], h_graph_visited[i]);
    }
    printf("g_over = %d\n\n", h_over);

    // ----------------------------
    // 分配 GPU 内存
    // ----------------------------
    bool *d_graph_mask, *d_updating_graph_mask, *d_graph_visited, *d_over;

    cudaMalloc((void**)&d_graph_mask,          sizeof(bool) * no_of_nodes);
    cudaMalloc((void**)&d_updating_graph_mask, sizeof(bool) * no_of_nodes);
    cudaMalloc((void**)&d_graph_visited,       sizeof(bool) * no_of_nodes);
    cudaMalloc((void**)&d_over,                sizeof(bool));

    // 拷贝到 GPU
    cudaMemcpy(d_graph_mask,          h_graph_mask,          sizeof(bool) * no_of_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_updating_graph_mask, h_updating_graph_mask, sizeof(bool) * no_of_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_graph_visited,       h_graph_visited,       sizeof(bool) * no_of_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_over,                &h_over,               sizeof(bool),               cudaMemcpyHostToDevice);

    // ----------------------------
    // 启动 Kernel2
    // ----------------------------
    int num_of_blocks = (no_of_nodes + MAX_THREADS_PER_BLOCK - 1) / MAX_THREADS_PER_BLOCK;
    Kernel2<<<num_of_blocks, MAX_THREADS_PER_BLOCK>>>(
        d_graph_mask, d_updating_graph_mask,
        d_graph_visited, d_over,
        no_of_nodes
    );

    cudaDeviceSynchronize();

    // ----------------------------
    // 拷贝结果回主机
    // ----------------------------
    cudaMemcpy(h_graph_mask,          d_graph_mask,          sizeof(bool) * no_of_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_updating_graph_mask, d_updating_graph_mask, sizeof(bool) * no_of_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_graph_visited,       d_graph_visited,       sizeof(bool) * no_of_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(&h_over,               d_over,                sizeof(bool),               cudaMemcpyDeviceToHost);

    // ----------------------------
    // 打印结果
    // ----------------------------
    printf("=== After Kernel2 ===\n");
    for (int i = 0; i < no_of_nodes; i++) {
        printf("Node %d: mask=%d, updating_mask=%d, visited=%d\n",
               i, h_graph_mask[i], h_updating_graph_mask[i], h_graph_visited[i]);
    }
    printf("g_over = %d\n", h_over);

    // ----------------------------
    // 验证预期结果
    // ----------------------------
    printf("\n=== Validation ===\n");
    bool pass = true;

    // 节点 1, 2 应被提升为 mask=true, visited=true, updating_mask=false
    for (int i = 1; i <= 2; i++) {
        if (!h_graph_mask[i] || !h_graph_visited[i] || h_updating_graph_mask[i]) {
            printf("FAIL: Node %d state incorrect\n", i);
            pass = false;
        }
    }
    // 节点 0, 3 的 mask 应保持 false
    for (int i : {0, 3}) {
        if (h_graph_mask[i]) {
            printf("FAIL: Node %d mask should remain false\n", i);
            pass = false;
        }
    }
    // g_over 应被置为 true
    if (!h_over) {
        printf("FAIL: g_over should be true\n");
        pass = false;
    }

    printf("%s\n", pass ? "All checks PASSED" : "Some checks FAILED");

    // ----------------------------
    // 释放资源
    // ----------------------------
    cudaFree(d_graph_mask);
    cudaFree(d_updating_graph_mask);
    cudaFree(d_graph_visited);
    cudaFree(d_over);

    return pass ? 0 : 1;
}