// Auto-generated CUDA kernel file: cenergy
// Extracted from: ispass-2009/CP/benchmarks/cp/src/cuda_base/single_kernel_cenergy.cu
// Original line: 16

// ===== Includes =====
#include "cuenergy.h"
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>


// ===== Global Variables =====
__constant__ float4 atominfo[MAXATOMS];  // global (from ispass-2009/CP/benchmarks/cp/src/cuda_short/cuenergy_pre8_coalesce.cu:25)
static int
initatoms(float **atombuf, int count, dim3 volsize, float gridspacing) {
  dim3 size;
  int i;
  float *atoms;

  srand(54321);			// Ensure that atom placement is repeatable

  atoms = (float *) malloc(count * 4 * sizeof(float));
  *atombuf = atoms;

  // compute grid dimensions in angstroms
  size.x = gridspacing * volsize.x;
  size.y = gridspacing * volsize.y;
  size.z = gridspacing * volsize.z;

  for (i=0; i<count; i++) {
    int addr = i * 4;
    atoms[addr    ] = (rand() / (float) RAND_MAX) * size.x; 
    atoms[addr + 1] = (rand() / (float) RAND_MAX) * size.y; 
    atoms[addr + 2] = (rand() / (float) RAND_MAX) * size.z; 
    atoms[addr + 3] = ((rand() / (float) RAND_MAX) * 2.0) - 1.0;  // charge
  }  

  return 0;
}

/* writeenergy()
 * Write part of the energy array to an output file for verification.
 */
static int
writeenergy(char *filename, float *energy, dim3 volsize)
{
  FILE *outfile;
  int x, y;

  outfile = fopen(filename, "w");
  if (outfile == NULL) {
    fputs("Cannot open output file\n", stderr);
    return -1;
    }

  /* Print the execution parameters */
  fprintf(outfile, "%d %d %d %d\n", volsize.x, volsize.y, volsize.z, ATOMCOUNT);

  /* Print a checksum */
  {
    double sum = 0.0;

    for (y = 0; y < volsize.y; y++) {
      for (x = 0; x < volsize.x; x++) {
        double t = energy[y*volsize.x+x];
        t = fmax(-20.0, fmin(20.0, t));
    	sum += t;
      }
    }
    fprintf(outfile, "%.4g\n", sum);
  }
  
  /* Print several rows of the computed data */
  for (y = 0; y < 17; y++) {
    for (x = 0; x < volsize.x; x++) {
      int addr = y * volsize.x + x;
      fprintf(outfile, "%.4g ", energy[addr]);
    }
    fprintf(outfile, "\n");
  }

  fclose(outfile);

  return 0;
}
// ===== Kernel =====
// Kernel: cenergy (line 16)
__global__ void cenergy(int numatoms, float gridspacing, float * energygrid) {


  unsigned int xindex  = __umul24(blockIdx.x, blockDim.x) + threadIdx.x;
  unsigned int yindex  = __umul24(blockIdx.y, blockDim.y) + threadIdx.y;
  unsigned int outaddr = __umul24(gridDim.x, blockDim.x) * yindex + xindex;

  float coorx = gridspacing * xindex;
  float coory = gridspacing * yindex;

  int atomid;
  float energyval=0.0f;

  /* For each atom, compute and accumulate its contribution to energyval
   * for this thread's grid point */
  for (atomid=0; atomid<numatoms; atomid++) {
    float dx = coorx - atominfo[atomid].x;
    float dy = coory - atominfo[atomid].y;
    float r_1 = 1.0f / sqrtf(dx*dx + dy*dy + atominfo[atomid].z);
    energyval += atominfo[atomid].w * r_1;
  }

  energygrid[outaddr] += energyval;


}

int main(int argc, char **argv) {
  float *atoms = NULL;
  float *energy = NULL;
  float *d_output = NULL;

  dim3 volsize;
  dim3 Bsz;
  dim3 Gsz;

  const int atomcount = ATOMCOUNT;
  const float gridspacing = 0.1f;

  // 输出文件名，默认 output.txt
  const char *outfile = "output.txt";
  if (argc >= 2) {
    outfile = argv[1];
  }

  printf("CUDA accelerated coulombic potential microbenchmark\n");

  // 设置体数据大小
  volsize.x = VOLSIZEX;
  volsize.y = VOLSIZEY;
  volsize.z = 1;

  // 设置 block 大小
  Bsz.x = BLOCKSIZEX;
  Bsz.y = BLOCKSIZEY;
  Bsz.z = 1;

  // 由于当前 kernel 内没有越界判断，因此这里要求能整除
  if (volsize.x % Bsz.x != 0 || volsize.y % Bsz.y != 0) {
    fprintf(stderr, "Error: volsize must be divisible by block size.\n");
    return -1;
  }

  // 设置 grid 大小
  Gsz.x = volsize.x / Bsz.x;
  Gsz.y = volsize.y / Bsz.y;
  Gsz.z = 1;

  printf("Volume size: %u x %u x %u\n", volsize.x, volsize.y, volsize.z);
  printf("Block size : %u x %u x %u\n", Bsz.x, Bsz.y, Bsz.z);
  printf("Grid size  : %u x %u x %u\n", Gsz.x, Gsz.y, Gsz.z);
  printf("Atom count : %d\n", atomcount);

  // 初始化 atoms
  if (initatoms(&atoms, atomcount, volsize, gridspacing)) {
    fprintf(stderr, "Failed to initialize atoms.\n");
    return -1;
  }

  int volmemsz = sizeof(float) * volsize.x * volsize.y * volsize.z;

  // 分配 host 输出数组
  energy = (float *)malloc(volmemsz);
  if (!energy) {
    fprintf(stderr, "Failed to allocate host energy buffer.\n");
    free(atoms);
    return -1;
  }

  // 分配 device 输出数组
  cudaError_t err;

  err = cudaMalloc((void **)&d_output, volmemsz);
  if (err != cudaSuccess) {
    fprintf(stderr, "cudaMalloc failed: %s\n", cudaGetErrorString(err));
    free(atoms);
    free(energy);
    return -1;
  }

  err = cudaMemset(d_output, 0, volmemsz);
  if (err != cudaSuccess) {
    fprintf(stderr, "cudaMemset failed: %s\n", cudaGetErrorString(err));
    cudaFree(d_output);
    free(atoms);
    free(energy);
    return -1;
  }

  // 分批处理 atoms，每批最多 MAXATOMS 个，因为 atominfo 是 constant memory
  for (int atomstart = 0; atomstart < atomcount; atomstart += MAXATOMS) {
    int atomsremaining = atomcount - atomstart;
    int runatoms = atomsremaining > MAXATOMS ? MAXATOMS : atomsremaining;

    // 将当前批次 atoms 拷贝到 constant memory
    err = cudaMemcpyToSymbol(
        atominfo,
        atoms + 4 * atomstart,
        runatoms * sizeof(float4),
        0,
        cudaMemcpyHostToDevice
    );

    if (err != cudaSuccess) {
      fprintf(stderr, "cudaMemcpyToSymbol failed: %s\n", cudaGetErrorString(err));
      cudaFree(d_output);
      free(atoms);
      free(energy);
      return -1;
    }

    // 启动 kernel
    cenergy<<<Gsz, Bsz>>>(runatoms, gridspacing, d_output);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
      fprintf(stderr, "Kernel launch failed: %s\n", cudaGetErrorString(err));
      cudaFree(d_output);
      free(atoms);
      free(energy);
      return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
      fprintf(stderr, "Kernel execution failed: %s\n", cudaGetErrorString(err));
      cudaFree(d_output);
      free(atoms);
      free(energy);
      return -1;
    }
  }

  // 拷贝结果回 host
  err = cudaMemcpy(energy, d_output, volmemsz, cudaMemcpyDeviceToHost);
  if (err != cudaSuccess) {
    fprintf(stderr, "cudaMemcpy device to host failed: %s\n", cudaGetErrorString(err));
    cudaFree(d_output);
    free(atoms);
    free(energy);
    return -1;
  }

  // 写结果
  if (writeenergy((char *)outfile, energy, volsize) == -1) {
    fprintf(stderr, "Failed to write output file.\n");
    cudaFree(d_output);
    free(atoms);
    free(energy);
    return -1;
  }

  printf("Result written to %s\n", outfile);

  // 释放资源
  cudaFree(d_output);
  free(atoms);
  free(energy);

  return 0;
}