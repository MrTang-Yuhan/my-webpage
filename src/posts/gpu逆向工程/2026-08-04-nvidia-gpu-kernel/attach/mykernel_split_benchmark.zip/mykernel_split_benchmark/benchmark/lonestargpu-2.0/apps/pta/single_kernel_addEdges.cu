#include "pta_single_kernel_test_common.cuh"

__device__ uint addVirtualElementLite(uint index, uint fromBase, uint fromBits, uint rel) {
    uint toBase = graphGet(index + BASE);

    if (toBase == NIL || toBase == fromBase) {
        uint oldBits = graphGet(index + threadIdx.x);
        uint out = fromBits;

        if (toBase == fromBase && threadIdx.x < NEXT) {
            out = oldBits | fromBits;
        }

        graphSet(index + threadIdx.x, out);
        return index;
    }

    return index;
}

__device__ uint insertLite(uint index, uint var, uint rel) {
    uint base = BASE_OF(var);
    uint word = WORD_OF(var);
    uint bit = BIT_OF(var);

    uint myBits = 0;

    if (threadIdx.x == word) {
        myBits = 1u << bit;
    } else if (threadIdx.x == BASE) {
        myBits = base;
    } else if (threadIdx.x == NEXT) {
        myBits = NIL;
    }

    return addVirtualElementLite(index, base, myBits, rel);
}

__global__ void addEdges(uint* key, uint* keyAux, uint* val, const uint to, uint rel) {
    uint warp = blockIdx.x * blockDim.y + threadIdx.y;
    uint nwarps = gridDim.x * blockDim.y;

    for (uint i = warp; i < to; i += nwarps) {
        uint src = key[i];

        if (src == NIL) {
            continue;
        }

        uint index = getHeadIndex(src, rel);
        uint start = keyAux[i];
        uint end = keyAux[i + 1];

        for (uint j = start; j < end; j++) {
            uint dst = val[j];
            if (dst != NIL) {
                index = insertLite(index, dst, rel);
            }
        }
    }

    if (isFirstThreadOfBlock()) {
        __worklistIndex0__ = 0;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint h_key[MAX_TEST_VARS];
    uint h_keyAux[MAX_TEST_VARS + 1];
    uint h_val[MAX_TEST_VARS];

    for (uint i = 0; i < MAX_TEST_VARS; i++) {
        h_key[i] = NIL;
        h_val[i] = NIL;
    }
    for (uint i = 0; i <= MAX_TEST_VARS; i++) h_keyAux[i] = 0;

    h_key[0] = 2;
    h_keyAux[0] = 0;
    h_keyAux[1] = 2;
    h_val[0] = 5;
    h_val[1] = 7;

    cudaMemcpy(env.d_key, h_key, sizeof(h_key), cudaMemcpyHostToDevice);
    cudaMemcpy(env.d_keyAux, h_keyAux, sizeof(h_keyAux), cudaMemcpyHostToDevice);
    cudaMemcpy(env.d_val, h_val, sizeof(h_val), cudaMemcpyHostToDevice);

    dim3 block(32, 4);
    dim3 grid(1);

    addEdges<<<grid, block>>>(env.d_key, env.d_keyAux, env.d_val, 1, COPY_INV);
    checkCuda(cudaGetLastError(), "addEdges launch failed");
    checkCuda(cudaDeviceSynchronize(), "addEdges execution failed");

    uint out[ELEMENT_WIDTH];
    uint head = TEST_COPY_INV_START + 2 * ELEMENT_WIDTH;

    cudaMemcpy(out, env.d_graph + head, ELEMENT_WIDTH * sizeof(uint), cudaMemcpyDeviceToHost);

    printf("addEdges finished\n");
    printf("COPY_INV[2]: word0=%u base=%u next=%u\n", out[0], out[BASE], out[NEXT]);

    destroyPTATestEnv(env);
    return 0;
}