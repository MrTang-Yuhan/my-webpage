#include <cuda_runtime.h>
#include <stdio.h>
#include <cstdio>
#include <cstdlib>
#include <vector>

#define CHECK_CUDA(call)                                                        \
    do {                                                                        \
        cudaError_t err = (call);                                               \
        if (err != cudaSuccess) {                                               \
            fprintf(stderr, "CUDA error at %s:%d: %s\n",                        \
                    __FILE__, __LINE__, cudaGetErrorString(err));               \
            exit(EXIT_FAILURE);                                                 \
        }                                                                       \
    } while (0)

// 修复点：
// 1. 不再依赖 c_strel 常量内存
// 2. 不再依赖 t_img texture
// 3. 直接传入 img 和 strel 指针
__global__ void dilate_kernel(const float *img,
                              int img_m, int img_n,
                              const int *strel,
                              int strel_m, int strel_n,
                              float *dilated) {
    int thread_id = blockIdx.x * blockDim.x + threadIdx.x;
    int total = img_m * img_n;

    // 修复点：边界检查，防止越界
    if (thread_id >= total) return;

    // 原代码逻辑保留
    int el_center_i = strel_m / 2;
    int el_center_j = strel_n / 2;

    int i = thread_id % img_m;
    int j = thread_id / img_m;

    float max_val = 0.0f;

    int el_i, el_j, x, y;
    for (el_i = 0; el_i < strel_m; el_i++) {
        y = i - el_center_i + el_i;
        if ((y >= 0) && (y < img_m)) {
            for (el_j = 0; el_j < strel_n; el_j++) {
                x = j - el_center_j + el_j;
                if ((x >= 0) &&
                    (x < img_n) &&
                    (strel[(el_i * strel_n) + el_j] != 0)) {

                    int addr = (x * img_m) + y;
                    float temp = img[addr];
                    if (temp > max_val) max_val = temp;
                }
            }
        }
    }

    dilated[(i * img_n) + j] = max_val;
}

int main() {
    const int img_m = 64;
    const int img_n = 64;
    const int strel_m = 5;
    const int strel_n = 5;

    const int img_size = img_m * img_n;
    const int strel_size = strel_m * strel_n;

    std::vector<float> h_img(img_size, 0.0f);
    std::vector<float> h_dilated(img_size, 0.0f);
    std::vector<int> h_strel(strel_size, 1);

    // 初始化输入图像
    // 注意：这里按 kernel 的索引习惯填充，尽量保持一致
    for (int x = 0; x < img_n; ++x) {
        for (int y = 0; y < img_m; ++y) {
            h_img[x * img_m + y] = static_cast<float>((x + y) % 17);
        }
    }

    float *d_img = nullptr;
    float *d_dilated = nullptr;
    int *d_strel = nullptr;

    CHECK_CUDA(cudaMalloc((void**)&d_img, img_size * sizeof(float)));
    CHECK_CUDA(cudaMalloc((void**)&d_dilated, img_size * sizeof(float)));
    CHECK_CUDA(cudaMalloc((void**)&d_strel, strel_size * sizeof(int)));

    CHECK_CUDA(cudaMemcpy(d_img, h_img.data(), img_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMemcpy(d_strel, h_strel.data(), strel_size * sizeof(int), cudaMemcpyHostToDevice));

    const int total_threads = img_size;
    const int block_size = 256;
    const int grid_size = (total_threads + block_size - 1) / block_size;

    dilate_kernel<<<grid_size, block_size>>>(
        d_img, img_m, img_n,
        d_strel, strel_m, strel_n,
        d_dilated
    );

    CHECK_CUDA(cudaGetLastError());
    CHECK_CUDA(cudaDeviceSynchronize());

    CHECK_CUDA(cudaMemcpy(h_dilated.data(), d_dilated, img_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("dilate_kernel done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("h_dilated[%d] = %f\n", i, h_dilated[i]);
    }

    CHECK_CUDA(cudaFree(d_img));
    CHECK_CUDA(cudaFree(d_dilated));
    CHECK_CUDA(cudaFree(d_strel));

    return 0;
}