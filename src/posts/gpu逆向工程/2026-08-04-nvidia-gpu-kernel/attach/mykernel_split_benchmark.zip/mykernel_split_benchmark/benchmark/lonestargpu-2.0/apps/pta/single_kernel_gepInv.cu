#include "pta_single_kernel_test_common.cuh"

__device__ uint offsetMaskGetLite(uint base, uint col, uint off) {
    return __offsetMask__[mul32((off - 1) * __offsetMaskRowsPerOffset__ + base) + col];
}

__device__ void applyGepInvRuleLite(uint x, uint y, uint off) {
    uint yIndex = getCurrDiffPtsHeadIndex(y);
    uint xIndex = getNextDiffPtsHeadIndex(x);

    uint base = graphGet(yIndex + BASE);
    if (base == NIL) return;

    uint bits = graphGet(yIndex + threadIdx.x);
    bits &= offsetMaskGetLite(base, threadIdx.x, off);

    if (__all_sync(0xFFFFFFFF, bits == 0)) return;

    uint delta = off / 32;
    uint shift = off & 31;

    uint shifted = 0;
    if (threadIdx.x >= delta && threadIdx.x < BASE) {
        uint srcLane = threadIdx.x - delta;
        uint srcBits = __shfl_sync(0xFFFFFFFF, bits, srcLane);
        shifted |= srcBits << shift;

        if (shift && srcLane > 0) {
            uint prevBits = __shfl_sync(0xFFFFFFFF, bits, srcLane - 1);
            shifted |= prevBits >> (32 - shift);
        }
    }

    if (threadIdx.x == BASE) shifted = base;
    if (threadIdx.x == NEXT) shifted = NIL;

    graphSet(xIndex + threadIdx.x, shifted);
}

__global__ void gepInv() {
    uint warp = blockIdx.x * blockDim.y + threadIdx.y;
    uint nwarps = gridDim.x * blockDim.y;

    uint total = __numGepInv__;

    for (uint i = warp; i < total; i += nwarps) {
        uint x = __gepInv__[2 * i];
        uint val1 = __gepInv__[2 * i + 1];

        x = getRepRec(x);
        uint y = getRepRec(gep_id(val1));
        uint off = gep_offset(val1);

        if (off == 0) off = 1;

        if (isFirstThreadOfWarp()) {
            atomicCAS(__lock__ + x, UNLOCKED, LOCKED);
        }

        applyGepInvRuleLite(x, y, off);

        if (isFirstThreadOfWarp()) {
            __lock__[x] = UNLOCKED;
        }
    }

    if (isFirstThreadOfBlock()) {
        __done__ = true;
        __worklistIndex0__ = 0;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint y = 3;
    uint x = 4;

    uint curr[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) curr[i] = 0;
    curr[0] = 0x1;
    curr[BASE] = 0;
    curr[NEXT] = NIL;

    uint currHead = TEST_CURR_DIFF_PTS_START + y * ELEMENT_WIDTH;
    cudaMemcpy(env.d_graph + currHead, curr, sizeof(curr), cudaMemcpyHostToDevice);

    uint mask[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) mask[i] = 0xFFFFFFFFu;
    cudaMemcpy(env.d_offsetMask, mask, sizeof(mask), cudaMemcpyHostToDevice);

    uint gep[2];
    gep[0] = x;
    gep[1] = (y << OFFSET_BITS) | 1u;
    cudaMemcpy(env.d_gepInv, gep, sizeof(gep), cudaMemcpyHostToDevice);

    uint numGepInv = 1;
    cudaMemcpyToSymbol(__numGepInv__, &numGepInv, sizeof(uint));

    dim3 block(32, 4);
    dim3 grid(1);

    gepInv<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "gepInv launch failed");
    checkCuda(cudaDeviceSynchronize(), "gepInv execution failed");

    uint out[ELEMENT_WIDTH];
    uint nextHead = TEST_NEXT_DIFF_PTS_START + x * ELEMENT_WIDTH;
    cudaMemcpy(out, env.d_graph + nextHead, sizeof(out), cudaMemcpyDeviceToHost);

    printf("gepInv finished\n");
    printf("NEXT_DIFF_PTS[%u]: word0=%u base=%u next=%u\n", x, out[0], out[BASE], out[NEXT]);

    destroyPTATestEnv(env);
    return 0;
}