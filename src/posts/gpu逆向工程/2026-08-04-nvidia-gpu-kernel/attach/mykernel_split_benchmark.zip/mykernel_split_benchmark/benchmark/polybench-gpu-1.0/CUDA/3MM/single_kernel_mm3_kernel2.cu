// Auto-generated CUDA kernel file: mm3_kernel2
// Extracted from: polybench-gpu-1.0/CUDA/3MM/3mm.cu
// Original line: 125

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
# define NI 512  // from line 26
# define NJ 512  // from line 27
# define NL 512  // from line 29
# define NM 512  // from line 30

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/3MM/3mm.cu:37

// ===== Kernel =====
// Kernel: mm3_kernel2 (line 125)
__global__ void mm3_kernel2(DATA_TYPE *C, DATA_TYPE *D, DATA_TYPE *F) {

	int j = blockIdx.x * blockDim.x + threadIdx.x;
	int i = blockIdx.y * blockDim.y + threadIdx.y;

	if ((i < NJ) && (j < NL))
	{
		int k;
		for(k=0; k < NM; k++)
		{
			F[i * NL + j] += C[i * NM + k] * D[k * NL +j];
		}
	}

}

// ===== Main Function =====
int main(int argc, char** argv) {
    cudaError_t err;

    const int width = NJ;
    const int height = NI;
    const size_t size = (size_t)width * height;

    // ===== Host/Device buffers =====
    // buffer: DATA_TYPE *C
    DATA_TYPE *h_C = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_C = nullptr;
    if (!h_C) {
        printf("malloc failed for h_C\n");
        return -1;
    }

    // buffer: DATA_TYPE *D
    DATA_TYPE *h_D = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_D = nullptr;
    if (!h_D) {
        printf("malloc failed for h_D\n");
        return -1;
    }

    // buffer: DATA_TYPE *F
    DATA_TYPE *h_F = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_F = nullptr;
    if (!h_F) {
        printf("malloc failed for h_F\n");
        return -1;
    }

    // ===== Initialize host data =====
    for (size_t i = 0; i < size; ++i) h_C[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_D[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_F[i] = (DATA_TYPE)(i % 100);

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_C, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_C: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_D, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_D: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_F, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_F: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_C, h_C, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for C: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_D, h_D, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for D: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_F, h_F, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for F: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((NJ + blockSize.x - 1) / blockSize.x,
                  (NI + blockSize.y - 1) / blockSize.y);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);
    mm3_kernel2<<<gridSize, blockSize>>>(d_C, d_D, d_F);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy one buffer back as example =====
    err = cudaMemcpy(h_F, d_F, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for F: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // TODO: verify results
    printf("Sample output: %f\n", (double)h_F[0]);

    // ===== Cleanup =====
    if (d_C) cudaFree(d_C);
    if (d_D) cudaFree(d_D);
    if (d_F) cudaFree(d_F);
    if (h_C) free(h_C);
    if (h_D) free(h_D);
    if (h_F) free(h_F);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}