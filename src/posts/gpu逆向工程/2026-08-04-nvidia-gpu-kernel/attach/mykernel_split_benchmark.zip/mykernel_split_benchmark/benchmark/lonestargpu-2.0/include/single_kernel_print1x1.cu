// Auto-generated CUDA kernel file: print1x1
// Extracted from: lonestargpu-2.0/include/component.h
// Original line: 63

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Type Definitions =====
struct ComponentSpace {
	ComponentSpace(unsigned nelements);
	
	__device__ unsigned numberOfElements();
	__device__ unsigned numberOfComponents();
	__device__ bool isBoss(unsigned element);
	__device__ unsigned find(unsigned lelement, bool compresspath = true);
	__device__ bool unify(unsigned one, unsigned two);
	__device__ void print1x1();
	__host__   void print();
        __host__   void copy(ComponentSpace &two);
        void dump_to_file(const char *F);
	void allocate();
	void init();
	unsigned numberOfComponentsHost();

	unsigned nelements;
	unsigned *ncomponents,			// number of components.
		 *complen, 			// lengths of components.
		 *ele2comp;			// components of elements.
}; // from lonestargpu-2.0/include/component.h:1

// ===== Kernel =====
// Kernel: print1x1 (line 63)
__global__ void print1x1(ComponentSpace cs) {

	cs.print1x1();

}
