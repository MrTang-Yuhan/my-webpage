// Standalone CUDA kernel file: update_eta
// Smoke-test version with main()

#include <cuda.h>
#include <cuda_runtime.h>

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

typedef unsigned int uint;

static inline void checkCuda(cudaError_t err, const char* msg) {
  if (err != cudaSuccess) {
    fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
    exit(EXIT_FAILURE);
  }
}

struct GPUCSRGraph {
  int nnodes;
  int nedges;

  int *row_offsets;
  int *columns;

  bool *sat;
  float *bias;
  bool *value;

  __device__ __host__ int degree(int node) const {
    return row_offsets[node + 1] - row_offsets[node];
  }
};

struct Edge {
  int nedges;
  int *src;
  int *dst;
  bool *bar;
  float *eta;
  float *pi_0;
  float *pi_S;
  float *pi_U;

  bool alloc() {
    assert(nedges > 0);

    src  = (int*)   calloc(nedges, sizeof(*src));
    dst  = (int*)   calloc(nedges, sizeof(*dst));
    bar  = (bool*)  calloc(nedges, sizeof(*bar));
    eta  = (float*) calloc(nedges, sizeof(*eta));
    pi_0 = (float*) calloc(nedges, sizeof(*pi_0));
    pi_S = (float*) calloc(nedges, sizeof(*pi_S));
    pi_U = (float*) calloc(nedges, sizeof(*pi_U));

    return src && dst && bar && eta && pi_0 && pi_S && pi_U;
  }
};

__global__ void update_eta(GPUCSRGraph clauses,
                           GPUCSRGraph vars,
                           Edge ed,
                           float *max_eps) {
  int id = threadIdx.x + blockIdx.x * blockDim.x;
  int threads = blockDim.x * gridDim.x;
  float eps;
  float lmaxeps = 0.0f;

  for (int edndx = id; edndx < ed.nedges; edndx += threads) {
    int a = ed.src[edndx];
    int i = ed.dst[edndx];

    // as these are "removed"
    if (clauses.sat[a] || vars.sat[i]) {
      continue;
    }

    int clndx = clauses.row_offsets[a];
    int nlit = clauses.degree(a);

    float new_eta = 1.0f;

    for (int aedndx = 0; aedndx < nlit; aedndx++) {
      int jedndx = clauses.columns[clndx + aedndx];

      int j = ed.dst[jedndx];

      if (j == i) {
        continue;
      }

      if (vars.sat[j]) {
        continue;
      }

      float sum = ed.pi_0[jedndx] + ed.pi_S[jedndx] + ed.pi_U[jedndx];

      if (sum == 0.0f) {
        new_eta = 0.0f;
        break;
      }

      new_eta *= ed.pi_U[jedndx] / sum;
    }

    eps = fabsf(new_eta - ed.eta[edndx]);

    if (eps > lmaxeps) {
      lmaxeps = eps;
    }

    ed.eta[edndx] = new_eta;
  }

  if (lmaxeps) {
    atomicMax((int*)max_eps, __float_as_int(lmaxeps));
  }
}

// ============================================================
// Test helpers
// ============================================================

static void allocTinyGraph(GPUCSRGraph &g,
                           int nnodes,
                           int ncols,
                           const int *h_row_offsets,
                           const int *h_columns) {
  g.nnodes = nnodes;
  g.nedges = ncols;

  checkCuda(cudaMalloc((void**)&g.row_offsets, (nnodes + 1) * sizeof(int)),
            "malloc graph row_offsets");
  checkCuda(cudaMalloc((void**)&g.columns, ncols * sizeof(int)),
            "malloc graph columns");
  checkCuda(cudaMalloc((void**)&g.sat, nnodes * sizeof(bool)),
            "malloc graph sat");
  checkCuda(cudaMalloc((void**)&g.bias, nnodes * sizeof(float)),
            "malloc graph bias");
  checkCuda(cudaMalloc((void**)&g.value, nnodes * sizeof(bool)),
            "malloc graph value");

  checkCuda(cudaMemcpy(g.row_offsets,
                       h_row_offsets,
                       (nnodes + 1) * sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy row_offsets");

  checkCuda(cudaMemcpy(g.columns,
                       h_columns,
                       ncols * sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy columns");

  checkCuda(cudaMemset(g.sat, 0, nnodes * sizeof(bool)), "memset sat");
  checkCuda(cudaMemset(g.bias, 0, nnodes * sizeof(float)), "memset bias");
  checkCuda(cudaMemset(g.value, 0, nnodes * sizeof(bool)), "memset value");
}

static void freeTinyGraph(GPUCSRGraph &g) {
  if (g.row_offsets) cudaFree(g.row_offsets);
  if (g.columns) cudaFree(g.columns);
  if (g.sat) cudaFree(g.sat);
  if (g.bias) cudaFree(g.bias);
  if (g.value) cudaFree(g.value);

  g.row_offsets = NULL;
  g.columns = NULL;
  g.sat = NULL;
  g.bias = NULL;
  g.value = NULL;
}

static void allocTinyEdge(Edge &ed) {
  ed.nedges = 3;

  checkCuda(cudaMalloc((void**)&ed.src,  ed.nedges * sizeof(int)),   "malloc ed.src");
  checkCuda(cudaMalloc((void**)&ed.dst,  ed.nedges * sizeof(int)),   "malloc ed.dst");
  checkCuda(cudaMalloc((void**)&ed.bar,  ed.nedges * sizeof(bool)),  "malloc ed.bar");
  checkCuda(cudaMalloc((void**)&ed.eta,  ed.nedges * sizeof(float)), "malloc ed.eta");
  checkCuda(cudaMalloc((void**)&ed.pi_0, ed.nedges * sizeof(float)), "malloc ed.pi_0");
  checkCuda(cudaMalloc((void**)&ed.pi_S, ed.nedges * sizeof(float)), "malloc ed.pi_S");
  checkCuda(cudaMalloc((void**)&ed.pi_U, ed.nedges * sizeof(float)), "malloc ed.pi_U");

  // edges:
  // e0: clause0 -> var0
  // e1: clause0 -> var1
  // e2: clause1 -> var0
  int h_src[3] = {0, 0, 1};
  int h_dst[3] = {0, 1, 0};
  bool h_bar[3] = {false, true, false};

  float h_eta[3]  = {0.20f, 0.30f, 0.40f};
  float h_pi0[3]  = {0.60f, 0.50f, 0.70f};
  float h_piS[3]  = {0.20f, 0.20f, 0.10f};
  float h_piU[3]  = {0.20f, 0.30f, 0.20f};

  checkCuda(cudaMemcpy(ed.src, h_src, sizeof(h_src), cudaMemcpyHostToDevice), "copy ed.src");
  checkCuda(cudaMemcpy(ed.dst, h_dst, sizeof(h_dst), cudaMemcpyHostToDevice), "copy ed.dst");
  checkCuda(cudaMemcpy(ed.bar, h_bar, sizeof(h_bar), cudaMemcpyHostToDevice), "copy ed.bar");
  checkCuda(cudaMemcpy(ed.eta, h_eta, sizeof(h_eta), cudaMemcpyHostToDevice), "copy ed.eta");
  checkCuda(cudaMemcpy(ed.pi_0, h_pi0, sizeof(h_pi0), cudaMemcpyHostToDevice), "copy ed.pi_0");
  checkCuda(cudaMemcpy(ed.pi_S, h_piS, sizeof(h_piS), cudaMemcpyHostToDevice), "copy ed.pi_S");
  checkCuda(cudaMemcpy(ed.pi_U, h_piU, sizeof(h_piU), cudaMemcpyHostToDevice), "copy ed.pi_U");
}

static void freeTinyEdge(Edge &ed) {
  if (ed.src) cudaFree(ed.src);
  if (ed.dst) cudaFree(ed.dst);
  if (ed.bar) cudaFree(ed.bar);
  if (ed.eta) cudaFree(ed.eta);
  if (ed.pi_0) cudaFree(ed.pi_0);
  if (ed.pi_S) cudaFree(ed.pi_S);
  if (ed.pi_U) cudaFree(ed.pi_U);

  ed.src = NULL;
  ed.dst = NULL;
  ed.bar = NULL;
  ed.eta = NULL;
  ed.pi_0 = NULL;
  ed.pi_S = NULL;
  ed.pi_U = NULL;
}

static void initTinyGraphs(GPUCSRGraph &clauses, GPUCSRGraph &vars) {
  int h_clause_row_offsets[3] = {0, 2, 3};
  int h_clause_columns[3]     = {0, 1, 2};

  int h_var_row_offsets[3] = {0, 2, 3};
  int h_var_columns[3]     = {0, 2, 1};

  allocTinyGraph(clauses, 2, 3, h_clause_row_offsets, h_clause_columns);
  allocTinyGraph(vars,    2, 3, h_var_row_offsets,    h_var_columns);
}

static void destroyTinyGraphs(GPUCSRGraph &clauses, GPUCSRGraph &vars) {
  freeTinyGraph(clauses);
  freeTinyGraph(vars);
}

// ============================================================
// main
// ============================================================

int main() {
  GPUCSRGraph clauses;
  GPUCSRGraph vars;
  Edge ed;

  float *d_max_eps = NULL;
  float h_max_eps = 0.0f;

  initTinyGraphs(clauses, vars);
  allocTinyEdge(ed);

  checkCuda(cudaMalloc((void**)&d_max_eps, sizeof(float)), "malloc max_eps");
  checkCuda(cudaMemset(d_max_eps, 0, sizeof(float)), "memset max_eps");

  dim3 block(128);
  dim3 grid(1);

  update_eta<<<grid, block>>>(clauses, vars, ed, d_max_eps);
  checkCuda(cudaGetLastError(), "update_eta launch failed");
  checkCuda(cudaDeviceSynchronize(), "update_eta execution failed");

  checkCuda(cudaMemcpy(&h_max_eps, d_max_eps, sizeof(float), cudaMemcpyDeviceToHost),
            "copy max_eps");

  float h_eta[3];
  checkCuda(cudaMemcpy(h_eta, ed.eta, 3 * sizeof(float), cudaMemcpyDeviceToHost),
            "copy eta");

  printf("update_eta finished\n");
  printf("max_eps = %f\n", h_max_eps);
  printf("eta[0]=%f eta[1]=%f eta[2]=%f\n", h_eta[0], h_eta[1], h_eta[2]);

  cudaFree(d_max_eps);
  freeTinyEdge(ed);
  destroyTinyGraphs(clauses, vars);

  return 0;
}