// Auto-generated CUDA kernel file: compress
// Extracted from: lonestargpu-2.0/include/worklist.h
// Original line: 316

// ===== Includes =====
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>
#include <vector>

// ===== Macro Definitions =====
#define MAXBLOCKSIZE	1024  // from line 32 (from lonestargpu-2.0/include/common.h)
#define MAXSHARED	(48*1024)  // from line 33 (from lonestargpu-2.0/include/common.h)
#define MAXSHAREDUINT	(MAXSHARED / 4)  // from line 34 (from lonestargpu-2.0/include/common.h)
#define SHAREDPERTHREAD	(MAXSHAREDUINT / MAXBLOCKSIZE)  // from line 35 (from lonestargpu-2.0/include/common.h)
#define SWAPDEV(a, b)	{ unsigned tmp = a; a = b; b = tmp; }  // from line 314

// ===== Type Definitions =====
struct Worklist {
	enum {NotAllocated, AllocatedOnHost, AllocatedOnDevice} memory;

	__device__ unsigned pushRange(unsigned *start, unsigned nitems);
	__device__ unsigned push(unsigned work);
	__device__ unsigned popRange(unsigned *start, unsigned nitems);
	__device__ unsigned pop(unsigned &work);
	__device__ void clear();
	__device__ void myItems(unsigned &start, unsigned &end);
	__device__ unsigned getItem(unsigned at);
	__device__ unsigned getItemWithin(unsigned at, unsigned hsize);
	__device__ unsigned count();

	void init();
	void init(unsigned initialcapacity);
	void setSize(unsigned hsize);
	unsigned getSize();
	void setCapacity(unsigned hcapacity);
	unsigned getCapacity();
	void pushRangeHost(unsigned *start, unsigned nitems);
	void pushHost(unsigned work);
	void clearHost();
	void setInitialSize(unsigned hsize);
	unsigned calculateSize(unsigned hstart, unsigned hend);
	void setStartEnd(unsigned hstart, unsigned hend);
	void getStartEnd(unsigned &hstart, unsigned &hend);
	void copyOldToNew(unsigned *olditems, unsigned *newitems, unsigned oldsize, unsigned oldcapacity);
	void compressHost(unsigned wlsize, unsigned sentinel);
	void printHost();
	unsigned appendHost(Worklist *otherwl);

	Worklist();
	~Worklist();
	unsigned ensureSpace(unsigned space);
	unsigned *alloc(unsigned allocsize);
	unsigned realloc(unsigned space);
	unsigned dealloc();
	unsigned freeSize();

	unsigned *items;
	unsigned *start, *end, *capacity;	// since these change, we don't want their copies with threads, hence pointers.

	unsigned noverflows;


} Worklist; // from lonestargpu-2.0/include/worklist.h:17

// ===== Kernel =====
// Kernel: compress (line 316)
__global__ void compress(Worklist wl, unsigned wlsize, unsigned sentinel) {

	unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
	__shared__ unsigned shmem[MAXSHAREDUINT];

	// copy my elements to my ids in shmem.
	unsigned wlstart = MAXSHAREDUINT * blockIdx.x + SHAREDPERTHREAD * threadIdx.x;
	unsigned shstart = SHAREDPERTHREAD * threadIdx.x;

	for (unsigned ii = 0; ii < SHAREDPERTHREAD; ++ii) {
		if (wlstart + ii < wlsize && shstart + ii < MAXSHAREDUINT) {
			shmem[shstart + ii] = wl.getItemWithin(wlstart + ii, wlsize);
		}
	}
	__syncthreads();
	
	
	// sort in shmem.
	for (unsigned s = blockDim.x / 2; s; s >>= 1) {
		if (threadIdx.x < s) {
			if (shmem[threadIdx.x] > shmem[threadIdx.x + s]) {
				SWAPDEV(shmem[threadIdx.x], shmem[threadIdx.x + s]);
			}
		}
		__syncthreads();
	}
	__syncthreads();

	// uniq in shmem.
	// TODO: find out how to do uniq in a hierarchical manner.
	unsigned lastindex = 0;
	if (id == 0) {
		for (unsigned ii = 1; ii < MAXSHAREDUINT; ++ii) {
			if (shmem[ii] != shmem[lastindex]) {
				shmem[++lastindex] = shmem[ii];
			} else {
				shmem[ii] = sentinel;
			}
		}
	}
	__syncthreads();

	// copy back elements to the worklist.
	for (unsigned ii = 0; ii < SHAREDPERTHREAD; ++ii) {
		if (wlstart + ii < wlsize) {
			//shmem[shstart + ii] = getItem(wlstart + ii);
			wl.items[wlstart + ii] = shmem[shstart + ii];
		}
	}
	__syncthreads();

	// update worklist indices.
	if (id == 0) {
		*wl.start = 0;
		*wl.end = lastindex + 1;
	}

}
