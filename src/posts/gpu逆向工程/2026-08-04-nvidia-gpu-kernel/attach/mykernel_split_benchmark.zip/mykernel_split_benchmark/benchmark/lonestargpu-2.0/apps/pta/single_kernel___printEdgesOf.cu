// Standalone CUDA kernel file: __printEdgesOf
// Smoke-test debug version

#include "pta_single_kernel_test_common.cuh"

__device__ const char* relName_debug(uint rel) {
    switch (rel) {
        case PTS: return "PTS";
        case NEXT_DIFF_PTS: return "NEXT_DIFF_PTS";
        case CURR_DIFF_PTS: return "CURR_DIFF_PTS";
        case COPY_INV: return "COPY_INV";
        case LOAD_INV: return "LOAD_INV";
        case STORE: return "STORE";
        default: return "UNKNOWN";
    }
}

__device__ void printOneRelOf_debug(uint src, uint rel) {
    uint head = getHeadIndex(src, rel);
    uint base = graphGet(head + BASE);

    if (threadIdx.x == 0) {
        printf("%s of %u: ", relName_debug(rel), src);
    }

    if (base == NIL) {
        if (threadIdx.x == 0) printf("[]\n");
        return;
    }

    uint bits = graphGet(head + threadIdx.x);
    uint active = __ballot_sync(0xFFFFFFFF, bits != 0 && threadIdx.x < BASE);

    if (threadIdx.x == 0) printf("[");

    bool first = true;

    while (active) {
        uint lane = __ffs(active) - 1;
        active &= active - 1;

        uint wordBits = __shfl_sync(0xFFFFFFFF, bits, lane);

        for (uint b = 0; b < 32; b++) {
            if (wordBits & (1u << b)) {
                uint dst = base * ELEMENT_CARDINALITY + lane * 32 + b;
                if (threadIdx.x == 0) {
                    if (!first) printf(", ");
                    printf("%u", dst);
                    first = false;
                }
            }
        }
    }

    if (threadIdx.x == 0) printf("]\n");
}

__device__ void printEdgesOf_debug(uint src) {
    for (uint rel = 0; rel <= STORE; rel++) {
        printOneRelOf_debug(src, rel);
    }
}

__global__ void __printEdgesOf(uint src) {
    printEdgesOf_debug(src);
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint elt[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) elt[i] = 0;
    elt[0] = (1u << 2) | (1u << 7);  // dst 2,7
    elt[BASE] = 0;
    elt[NEXT] = NIL;

    uint head = TEST_COPY_INV_START + 4 * ELEMENT_WIDTH;
    cudaMemcpy(env.d_graph + head, elt, sizeof(elt), cudaMemcpyHostToDevice);

    dim3 block(32, 1);
    dim3 grid(1);

    __printEdgesOf<<<grid, block>>>(4);
    checkCuda(cudaGetLastError(), "__printEdgesOf launch failed");
    checkCuda(cudaDeviceSynchronize(), "__printEdgesOf execution failed");

    destroyPTATestEnv(env);
    return 0;
}