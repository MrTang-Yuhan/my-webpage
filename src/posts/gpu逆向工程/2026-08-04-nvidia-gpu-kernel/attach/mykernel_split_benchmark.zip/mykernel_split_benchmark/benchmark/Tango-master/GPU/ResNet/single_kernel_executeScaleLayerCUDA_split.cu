// Auto-generated CUDA kernel file: executeScaleLayerCUDA_split
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 851

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeScaleLayerCUDA_split (line 851)
__global__ void executeScaleLayerCUDA_split(float *Layer_Neurons,float *scale,float *bias,int out,int f_size,int tfactor) {


	int output = blockIdx.x;
	int row_even = threadIdx.x * tfactor;
	int col_even = threadIdx.y * tfactor;
	if(row_even < f_size && col_even < f_size)
	{      
		for(int row= row_even; row < row_even + tfactor ; row++) 
		{	
			for(int col =col_even; col < col_even+ tfactor;col++) 
			{
				{ 
					/* Scale Layer = input * scale + bias */
					Layer_Neurons[output*f_size*f_size + row*f_size + col]  = (Layer_Neurons[output*f_size*f_size + row*f_size + col]  * scale[output]) + bias[output];
				}
			}
		}
	}


}

int main() {
    const int out = 4;
    const int f_size = 8;
    const int tfactor = 2;

    size_t neuron_size = (size_t)out * f_size * f_size;
    size_t param_size = out;

    float *h_neurons = (float*)malloc(neuron_size * sizeof(float));
    float *h_scale   = (float*)malloc(param_size * sizeof(float));
    float *h_bias    = (float*)malloc(param_size * sizeof(float));

    if (!h_neurons || !h_scale || !h_bias) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < neuron_size; ++i) h_neurons[i] = (float)(i % 13) * 0.1f;
    for (int i = 0; i < out; ++i) {
        h_scale[i] = 2.0f;
        h_bias[i] = 0.5f;
    }

    float *d_neurons = NULL, *d_scale = NULL, *d_bias = NULL;
    CHECK(cudaMalloc((void**)&d_neurons, neuron_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_scale, param_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_bias, param_size * sizeof(float)));

    CHECK(cudaMemcpy(d_neurons, h_neurons, neuron_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_scale, h_scale, param_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_bias, h_bias, param_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block((f_size + tfactor - 1) / tfactor, (f_size + tfactor - 1) / tfactor);

    executeScaleLayerCUDA_split<<<grid, block>>>(
        d_neurons, d_scale, d_bias, out, f_size, tfactor
    );
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_neurons, d_neurons, neuron_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeScaleLayerCUDA_split done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("neurons[%d] = %f\n", i, h_neurons[i]);
    }

    cudaFree(d_neurons);
    cudaFree(d_scale);
    cudaFree(d_bias);

    free(h_neurons);
    free(h_scale);
    free(h_bias);

    return 0;
}