// Auto-generated CUDA kernel file: inibuffer
// Extracted from: pannotia/pagerank/kernel.cu
// Original line: 126

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: inibuffer (line 126)
__global__ void
inibuffer(int *row, float *page_rank1, float *page_rank2, const int num_nodes,
          const int num_edges) {

    // Get my thread id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;

    if (tid < num_nodes) {
        page_rank1[tid] = 1 / (float)num_nodes;
        page_rank2[tid] = 0.0f;
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;

    const size_t size_row = (size_t)num_nodes * sizeof(int);
    const size_t size_pr = (size_t)num_nodes * sizeof(float);

    int *h_row = (int*)malloc(size_row);
    float *h_page_rank1 = (float*)malloc(size_pr);
    float *h_page_rank2 = (float*)malloc(size_pr);

    int *d_row = nullptr;
    float *d_page_rank1 = nullptr;
    float *d_page_rank2 = nullptr;

    if (!h_row || !h_page_rank1 || !h_page_rank2) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_page_rank1);
        free(h_page_rank2);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_row[i] = (i < num_nodes - 1) ? i : num_edges;
        h_page_rank1[i] = -1.0f;
        h_page_rank2[i] = -1.0f;
    }

    err = cudaMalloc((void**)&d_row, size_row);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_row failed: %s\n", cudaGetErrorString(err));
        free(h_row);
        free(h_page_rank1);
        free(h_page_rank2);
        return -1;
    }

    err = cudaMalloc((void**)&d_page_rank1, size_pr);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_page_rank1 failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        free(h_row);
        free(h_page_rank1);
        free(h_page_rank2);
        return -1;
    }

    err = cudaMalloc((void**)&d_page_rank2, size_pr);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_page_rank2 failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_page_rank1);
        free(h_row);
        free(h_page_rank1);
        free(h_page_rank2);
        return -1;
    }

    cudaMemcpy(d_row, h_row, size_row, cudaMemcpyHostToDevice);
    cudaMemcpy(d_page_rank1, h_page_rank1, size_pr, cudaMemcpyHostToDevice);
    cudaMemcpy(d_page_rank2, h_page_rank2, size_pr, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    inibuffer<<<gridSize, blockSize>>>(d_row, d_page_rank1, d_page_rank2, num_nodes, num_edges);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_page_rank1);
        cudaFree(d_page_rank2);
        free(h_row);
        free(h_page_rank1);
        free(h_page_rank2);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_row);
        cudaFree(d_page_rank1);
        cudaFree(d_page_rank2);
        free(h_row);
        free(h_page_rank1);
        free(h_page_rank2);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaMemcpy(h_page_rank1, d_page_rank1, size_pr, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_page_rank2, d_page_rank2, size_pr, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("inibuffer execution time: %.3f ms\n", ms);

    printf("page_rank1[0] = %f\n", h_page_rank1[0]);
    printf("page_rank2[0] = %f\n", h_page_rank2[0]);
    printf("page_rank1[last] = %f\n", h_page_rank1[num_nodes - 1]);
    printf("page_rank2[last] = %f\n", h_page_rank2[num_nodes - 1]);

    cudaFree(d_row);
    cudaFree(d_page_rank1);
    cudaFree(d_page_rank2);
    free(h_row);
    free(h_page_rank1);
    free(h_page_rank2);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}