// Auto-generated CUDA kernel file: mean_kernel
// Extracted from: polybench-gpu-1.0/CUDA/COVAR/single_kernel_mean_kernel.cu
// Original line: 25

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define FLOAT_N 3214212.01  // from line 43  // from line 16
#define M 2048  // from line 26  // from line 17
#define N 2048  // from line 27  // from line 18

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/COVAR/single_kernel_mean_kernel.cu:21

// ===== Kernel =====
// Kernel: mean_kernel (line 25)
__global__ void mean_kernel(DATA_TYPE *mean, DATA_TYPE *data) {


	int j = blockIdx.x * blockDim.x + threadIdx.x + 1;

	if ((j >= 1) && (j < (M+1)))
	{
		mean[j] = 0.0;

		int i;
		for(i = 1; i < (N+1); i++)
		{
			mean[j] += data[i * (M+1) + j];
		}
		mean[j] /= (DATA_TYPE)FLOAT_N;
	}


}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_mean = (size_t)(M + 1);
    const size_t size_data = (size_t)(N + 1) * (M + 1);

    DATA_TYPE *h_mean = (DATA_TYPE*)malloc(size_mean * sizeof(DATA_TYPE));
    DATA_TYPE *h_data = (DATA_TYPE*)malloc(size_data * sizeof(DATA_TYPE));
    DATA_TYPE *d_mean = nullptr;
    DATA_TYPE *d_data = nullptr;

    if (!h_mean || !h_data) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_mean; ++i) h_mean[i] = 0.0f;
    for (size_t i = 0; i < size_data; ++i) h_data[i] = (DATA_TYPE)(i % 100) / 100.0f;

    err = cudaMalloc((void**)&d_mean, size_mean * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_mean failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_data, size_data * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_data failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_mean, h_mean, size_mean * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D mean failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_data, h_data, size_data * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D data failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((M + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    mean_kernel<<<gridSize, blockSize>>>(d_mean, d_data);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("mean_kernel execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_mean, d_mean, size_mean * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H mean failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("mean[1] = %f\n", (double)h_mean[1]);

    cudaFree(d_mean);
    cudaFree(d_data);
    free(h_mean);
    free(h_data);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}