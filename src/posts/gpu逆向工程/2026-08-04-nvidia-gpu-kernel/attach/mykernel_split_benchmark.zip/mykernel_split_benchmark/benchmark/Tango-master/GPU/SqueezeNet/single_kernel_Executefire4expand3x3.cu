// Auto-generated CUDA kernel file: Executefire4expand3x3
// Extracted from: Tango-master/GPU/SqueezeNet/SN.cu
// Original line: 1453

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: Executefire4expand3x3 (line 1453)
__global__ void Executefire4expand3x3(double *fire4expand3x3_Weights_GPU, double *fire4_Features, double *fire4squeeze1x1_Features) {

	double Features = 0;
	int x = threadIdx.x;
	int y = blockIdx.x;
	for(int f=0; f<128; f++)
	{
		Features = 0;
		for(int n=0; n<32; n++)
		{	double result = 0;
				for(int i = x-1; i<=x+1; i++)
				{
    					for(int j=y-1; j<=y+1; j++)
    					{
						int x_index = i-x+1;
						int y_index = j-y+1;
						int m = (y_index)+(x_index)*3;
         					if(i<0 || j<0)
						{
							result+=0;
						}
         					else if(j>54 || i>54)
						{
							result+=0;	
						}
         					else
						{
               						result+= fire4squeeze1x1_Features[n*55*55 + i*55 + j]*fire4expand3x3_Weights_GPU[m+f*9*32+n*9];			
						}
					}
				} 
				Features += result;
		}
		//ReLU activation function computation
		if(Features<0)
			Features = 0;
		fire4_Features[f*55*55 + x*55 + y] = Features;
	}
	__syncthreads();
	//if(x == 0 && y == 0)
		//printf("Fire 4 expand3x3: %.8f \n", fire4_Features[191520]);

}

int main() {
    const int in_channels = 32;
    const int out_channels = 128;
    const int H = 55, W = 55;

    size_t weight_size = (size_t)out_channels * in_channels * 3 * 3;
    size_t input_size  = (size_t)in_channels * H * W;
    size_t output_size = (size_t)out_channels * H * W;

    double *h_weight = (double*)malloc(weight_size * sizeof(double));
    double *h_input  = (double*)malloc(input_size * sizeof(double));
    double *h_output = (double*)malloc(output_size * sizeof(double));

    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (double)(i % 23) * 0.001;
    for (size_t i = 0; i < input_size; ++i)  h_input[i]  = (double)(i % 7) * 0.01;

    double *d_weight = NULL, *d_input = NULL, *d_output = NULL;
    cudaMalloc((void**)&d_weight, weight_size * sizeof(double));
    cudaMalloc((void**)&d_input,  input_size * sizeof(double));
    cudaMalloc((void**)&d_output, output_size * sizeof(double));

    cudaMemcpy(d_weight, h_weight, weight_size * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemcpy(d_input,  h_input,  input_size * sizeof(double),  cudaMemcpyHostToDevice);
    cudaMemset(d_output, 0, output_size * sizeof(double));

    dim3 grid(W);
    dim3 block(H);

    Executefire4expand3x3<<<grid, block>>>(d_weight, d_output, d_input);
    cudaDeviceSynchronize();

    cudaMemcpy(h_output, d_output, output_size * sizeof(double), cudaMemcpyDeviceToHost);

    printf("Executefire4expand3x3 done.\n");
    for (int i = 0; i < 10; ++i) printf("output[%d] = %f\n", i, h_output[i]);

    cudaFree(d_weight);
    cudaFree(d_input);
    cudaFree(d_output);
    free(h_weight);
    free(h_input);
    free(h_output);
    return 0;
}