// Auto-generated CUDA kernel file: corr_kernel
// Extracted from: polybench-gpu-1.0/CUDA/CORR/single_kernel_corr_kernel.cu
// Original line: 23

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

// ===== Macro Definitions =====
#define M 2048  // from line 25  // from line 15
#define N 2048  // from line 26  // from line 16

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/CORR/single_kernel_corr_kernel.cu:19

// ===== Kernel =====
// Kernel: corr_kernel (line 23)
__global__ void corr_kernel(DATA_TYPE *symmat, DATA_TYPE *data) {


	int j1 = blockIdx.x * blockDim.x + threadIdx.x + 1;

	int i, j2;
	if ((j1 >= 1) && (j1 < M))
	{
		symmat[j1*(M+1) + j1] = 1.0;

		for (j2 = (j1 + 1); j2 < (M+1); j2++)
		{
			symmat[j1*(M+1) + j2] = 0.0;

			for(i = 1; i < (N+1); i++)
			{
				symmat[j1*(M+1) + j2] += data[i*(M+1) + j1] * data[i*(M+1) + j2];
			}
			symmat[j2*(M+1) + j1] = symmat[j1*(M+1) + j2];
		}
	}


}

// ===== Main Function =====
int main(int argc, char** argv) {
    cudaError_t err;

    // TODO: set problem size
    const size_t size = 1024;

    // ===== Host/Device buffers =====
    // buffer: DATA_TYPE *symmat
    DATA_TYPE *h_symmat = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_symmat = nullptr;
    if (!h_symmat) {
        printf("malloc failed for h_symmat\n");
        return -1;
    }

    // buffer: DATA_TYPE *data
    DATA_TYPE *h_data = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_data = nullptr;
    if (!h_data) {
        printf("malloc failed for h_data\n");
        return -1;
    }

    // ===== Initialize host data =====
    for (size_t i = 0; i < size; ++i) h_symmat[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_data[i] = (DATA_TYPE)(i % 100);

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_symmat, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_symmat: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_data, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_data: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_symmat, h_symmat, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for symmat: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_data, h_data, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for data: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((size + blockSize.x - 1) / blockSize.x, 1);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);
    corr_kernel<<<gridSize, blockSize>>>(d_symmat, d_data);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy one buffer back as example =====
    err = cudaMemcpy(h_data, d_data, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for data: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // TODO: verify results
    printf("Sample output: %f\n", (double)h_data[0]);

    // ===== Cleanup =====
    if (d_symmat) cudaFree(d_symmat);
    if (d_data) cudaFree(d_data);
    if (h_symmat) free(h_symmat);
    if (h_data) free(h_data);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}