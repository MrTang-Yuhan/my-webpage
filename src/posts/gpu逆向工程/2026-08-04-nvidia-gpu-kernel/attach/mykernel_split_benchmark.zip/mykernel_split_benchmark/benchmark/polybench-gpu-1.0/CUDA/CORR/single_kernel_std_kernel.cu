// Auto-generated CUDA kernel file: std_kernel
// Extracted from: polybench-gpu-1.0/CUDA/CORR/single_kernel_std_kernel.cu
// Original line: 25

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

// ===== Macro Definitions =====
#define EPS 0.005f  // from line 47  // from line 15
#define FLOAT_N 3214212.01f  // from line 46  // from line 16
#define M 2048  // from line 25  // from line 17
#define N 2048  // from line 26  // from line 18

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/CORR/single_kernel_std_kernel.cu:21

// ===== Kernel =====
// Kernel: std_kernel (line 25)
__global__ void std_kernel(DATA_TYPE *mean, DATA_TYPE *std, DATA_TYPE *data) {


	int j = blockIdx.x * blockDim.x + threadIdx.x + 1;
	
	if ((j >= 1) && (j < (M+1)))
	{
		std[j] = 0.0;

		int i;
		for(i = 1; i < (N+1); i++)
		{
			std[j] += (data[i*(M+1) + j] - mean[j]) * (data[i*(M+1) + j] - mean[j]);
		}
		std[j] /= (FLOAT_N);
		std[j] = sqrt(std[j]);
		if(std[j] <= EPS) 
		{
			std[j] = 1.0;
		}
	}


}

// ===== Main Function =====
int main(int argc, char** argv) {
    cudaError_t err;

    // TODO: set problem size
    const size_t size = 1024;

    // ===== Host/Device buffers =====
    // buffer: DATA_TYPE *mean
    DATA_TYPE *h_mean = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_mean = nullptr;
    if (!h_mean) {
        printf("malloc failed for h_mean\n");
        return -1;
    }

    // buffer: DATA_TYPE *std
    DATA_TYPE *h_std = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_std = nullptr;
    if (!h_std) {
        printf("malloc failed for h_std\n");
        return -1;
    }

    // buffer: DATA_TYPE *data
    DATA_TYPE *h_data = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_data = nullptr;
    if (!h_data) {
        printf("malloc failed for h_data\n");
        return -1;
    }

    // ===== Initialize host data =====
    for (size_t i = 0; i < size; ++i) h_mean[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_std[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_data[i] = (DATA_TYPE)(i % 100);

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_mean, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_mean: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_std, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_std: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_data, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_data: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_mean, h_mean, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for mean: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_std, h_std, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for std: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_data, h_data, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for data: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((size + blockSize.x - 1) / blockSize.x, 1);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);
    std_kernel<<<gridSize, blockSize>>>(d_mean, d_std, d_data);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy one buffer back as example =====
    err = cudaMemcpy(h_data, d_data, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for data: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // TODO: verify results
    printf("Sample output: %f\n", (double)h_data[0]);

    // ===== Cleanup =====
    if (d_mean) cudaFree(d_mean);
    if (d_std) cudaFree(d_std);
    if (d_data) cudaFree(d_data);
    if (h_mean) free(h_mean);
    if (h_std) free(h_std);
    if (h_data) free(h_data);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}