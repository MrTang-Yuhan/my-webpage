#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ===== 内联 parameters.h =====
typedef unsigned int  uint;
typedef unsigned char uint8;
#define TESTING
#define DPT          4
#define CACHECWLUT
#define NUM_SYMBOLS  256
#define MEMSET0

// ===== 内联 pabio_kernels_v2.cu =====
__device__ static void put_bits_atomic2(unsigned int *out, unsigned int kc,
        unsigned int startbit, unsigned int numbits, unsigned int codeword) {
    unsigned int restbits = 32 - startbit - numbits;
#ifndef MEMSET0
    unsigned int mask = ((1<<numbits)-1) << restbits;
    atomicAnd(&out[kc], ~mask);
#endif
    atomicOr(&out[kc], codeword << restbits);
}

// ===== kernel =====
__global__ static void vlc_encode_kernel_sm64huff(
        unsigned int *data,
        const unsigned int *gm_codewords,
        const unsigned int *gm_codewordlens,
        unsigned int *cw32,        // TESTING 参数
        unsigned int *cw32len,
        unsigned int *cw32idx,
        unsigned int *out,
        unsigned int *outidx) {

    unsigned int kn = blockIdx.x * blockDim.x + threadIdx.x;
    unsigned int k  = threadIdx.x;
    unsigned int kc, startbit, wrbits;
    unsigned long long cw64 = 0;
    unsigned int val32, codewordlen = 0;
    unsigned char tmpbyte, tmpcwlen;
    unsigned int tmpcw32;

    extern __shared__ unsigned int sm[];
    __shared__ unsigned int kcmax;

    // CACHECWLUT 路径
    unsigned int *codewords    = (unsigned int*) sm;
    unsigned int *codewordlens = (unsigned int*)(sm + NUM_SYMBOLS);
    unsigned int *as           = (unsigned int*)(sm + 2*NUM_SYMBOLS);

    codewords[k]    = gm_codewords[k];
    codewordlens[k] = gm_codewordlens[k];
    val32           = data[kn];
    __syncthreads();

    for (unsigned int i = 0; i < 4; i++) {
        tmpbyte  = (unsigned char)(val32 >> ((3-i)*8));
        tmpcw32  = codewords[tmpbyte];
        tmpcwlen = codewordlens[tmpbyte];
        cw64     = (cw64 << tmpcwlen) | tmpcw32;
        codewordlen += tmpcwlen;
    }

    as[k] = codewordlen;
    __syncthreads();

    // prefix sum (Blelloch)
    unsigned int offset = 1;
    for (unsigned int d = blockDim.x >> 1; d > 0; d >>= 1) {
        __syncthreads();
        if (k < d) {
            unsigned char ai = offset*(2*k+1)-1;
            unsigned char bi = offset*(2*k+2)-1;
            as[bi] += as[ai];
        }
        offset *= 2;
    }
    if (k == 0) as[blockDim.x - 1] = 0;
    for (unsigned int d = 1; d < blockDim.x; d *= 2) {
        offset >>= 1;
        __syncthreads();
        if (k < d) {
            unsigned char ai = offset*(2*k+1)-1;
            unsigned char bi = offset*(2*k+2)-1;
            unsigned int t = as[ai];
            as[ai]  = as[bi];
            as[bi] += t;
        }
    }
    __syncthreads();

    if (k == blockDim.x - 1) {
        outidx[blockIdx.x] = as[k] + codewordlen;
        kcmax = (as[k] + codewordlen) / 32;
    }

    kc       = as[k] / 32;
    startbit = as[k] % 32;
    as[k]    = 0U;
    __syncthreads();

    wrbits  = codewordlen > (32-startbit) ? (32-startbit) : codewordlen;
    tmpcw32 = (unsigned int)(cw64 >> (codewordlen - wrbits));
    atomicOr(&as[kc], tmpcw32 << (32 - startbit - wrbits));
    codewordlen -= wrbits;

    if (codewordlen) {
        wrbits  = codewordlen > 32 ? 32 : codewordlen;
        tmpcw32 = (unsigned int)(cw64 >> (codewordlen - wrbits)) & ((1<<wrbits)-1);
        atomicOr(&as[kc+1], tmpcw32 << (32 - wrbits));
        codewordlen -= wrbits;
    }
    if (codewordlen) {
        tmpcw32 = (unsigned int)(cw64 & ((1<<codewordlen)-1));
        atomicOr(&as[kc+2], tmpcw32 << (32 - codewordlen));
    }
    __syncthreads();

    if (k <= kcmax) out[kn] = as[k];
}

// ===== main =====
int main() {
    // 使用 NUM_SYMBOLS=256 个线程，1 个 block
    const int THREADS = NUM_SYMBOLS;   // 256
    const int BLOCKS  = 1;
    const int N       = THREADS * BLOCKS;

    // 构造简单的均匀码本：每个符号 8 bit，codeword = 符号值本身
    unsigned int h_cw[NUM_SYMBOLS], h_cwlen[NUM_SYMBOLS];
    for (int i = 0; i < NUM_SYMBOLS; i++) {
        h_cw[i]    = i;
        h_cwlen[i] = 8;
    }

    // 输入数据：每个线程处理 1 个 uint32（含 4 字节）
    unsigned int h_data[N];
    for (int i = 0; i < N; i++) h_data[i] = 0x00010203;  // 4 个字节: 0,1,2,3

    unsigned int h_out[N]    = {0};
    unsigned int h_outidx[BLOCKS] = {0};
    // TESTING 缓冲（不使用，传 dummy）
    unsigned int h_cw32[N]={0}, h_cw32len[N]={0}, h_cw32idx[N]={0};

    unsigned int *d_data, *d_cw, *d_cwlen, *d_out, *d_outidx;
    unsigned int *d_cw32, *d_cw32len, *d_cw32idx;
    cudaMalloc(&d_data,    N          * sizeof(unsigned int));
    cudaMalloc(&d_cw,      NUM_SYMBOLS* sizeof(unsigned int));
    cudaMalloc(&d_cwlen,   NUM_SYMBOLS* sizeof(unsigned int));
    cudaMalloc(&d_out,     N          * sizeof(unsigned int));
    cudaMalloc(&d_outidx,  BLOCKS     * sizeof(unsigned int));
    cudaMalloc(&d_cw32,    N          * sizeof(unsigned int));
    cudaMalloc(&d_cw32len, N          * sizeof(unsigned int));
    cudaMalloc(&d_cw32idx, N          * sizeof(unsigned int));

    cudaMemcpy(d_data,  h_data, N          *sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_cw,    h_cw,   NUM_SYMBOLS*sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_cwlen, h_cwlen,NUM_SYMBOLS*sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemset(d_out,    0, N     *sizeof(unsigned int));
    cudaMemset(d_outidx, 0, BLOCKS*sizeof(unsigned int));

    // shared mem: codewords + codewordlens + as = 3 * NUM_SYMBOLS * 4 bytes
    size_t smem = 3 * NUM_SYMBOLS * sizeof(unsigned int);

    vlc_encode_kernel_sm64huff<<<BLOCKS, THREADS, smem>>>(
        d_data, d_cw, d_cwlen,
        d_cw32, d_cw32len, d_cw32idx,
        d_out, d_outidx);
    cudaError_t err = cudaDeviceSynchronize();
    if (err != cudaSuccess)
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(err));

    cudaMemcpy(h_out,    d_out,    N     *sizeof(unsigned int), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_outidx, d_outidx, BLOCKS*sizeof(unsigned int), cudaMemcpyDeviceToHost);

    printf("outidx[0]=%u (total bits encoded)\n", h_outidx[0]);
    printf("out[0]=0x%08X\n", h_out[0]);

    cudaFree(d_data); cudaFree(d_cw); cudaFree(d_cwlen);
    cudaFree(d_out);  cudaFree(d_outidx);
    cudaFree(d_cw32); cudaFree(d_cw32len); cudaFree(d_cw32idx);
    return 0;
}