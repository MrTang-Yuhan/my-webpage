// Standalone CUDA kernel file: updatePtsInformation
// Smoke-test version for PTA updatePtsInformation kernel

#include "pta_single_kernel_test_common.cuh"

__device__ bool updatePtsAndDiffPtsLite(uint var) {
    uint diffHead = getNextDiffPtsHeadIndex(var);
    uint ptsHead = getPtsHeadIndex(var);
    uint currHead = getCurrDiffPtsHeadIndex(var);

    uint diffBase = graphGet(diffHead + BASE);

    if (diffBase == NIL) {
        return false;
    }

    uint oldBits = graphGet(ptsHead + threadIdx.x);
    uint diffBits = graphGet(diffHead + threadIdx.x);

    uint newBits;

    if (threadIdx.x == NEXT) {
        newBits = NIL;
    } else {
        newBits = oldBits | diffBits;
    }

    graphSet(ptsHead + threadIdx.x, newBits);

    uint currBits;
    if (threadIdx.x == BASE) {
        currBits = diffBase;
    } else if (threadIdx.x == NEXT) {
        currBits = NIL;
    } else {
        currBits = diffBits & ~oldBits;
    }

    graphSet(currHead + threadIdx.x, currBits);

    graphSet(diffHead + threadIdx.x, NIL);

    uint changed = __any_sync(0xFFFFFFFF, currBits != NIL && threadIdx.x < BASE);
    return changed != 0;
}

__device__ inline uint getAndIncrementLite(uint* counter, uint delta) {
    __shared__ volatile uint shared[MAX_TEST_VARS];

    if (isFirstThreadOfWarp()) {
        shared[threadIdx.y] = atomicAdd(counter, delta);
    }

    return shared[threadIdx.y];
}

__global__ void updatePtsInformation() {
    bool newWork = false;
    uint nvars = __numVars__;
    const uint CHUNK_SIZE = 12;

    uint i = getAndIncrementLite(&__worklistIndex0__, CHUNK_SIZE);

    while (i < nvars) {
        for (uint var = i; var < min(i + CHUNK_SIZE, nvars); var++) {
            bool updated = updatePtsAndDiffPtsLite(var);
            newWork |= updated;

            if (!updated) {
                uint currHead = getCurrDiffPtsHeadIndex(var);
                graphSet(currHead + threadIdx.x, NIL);
            }
        }

        i = getAndIncrementLite(&__worklistIndex0__, CHUNK_SIZE);
    }

    if (newWork) {
        __done__ = false;
    }

    __syncthreads();

    if (isFirstThreadOfBlock()) {
        __worklistIndex0__ = 0;
        uint headerSize = nvars * ELEMENT_WIDTH;
        __currDiffPtsFreeList__ = TEST_CURR_DIFF_PTS_START + headerSize;
        __nextDiffPtsFreeList__ = TEST_NEXT_DIFF_PTS_START + headerSize;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint h_graph[TEST_GRAPH_SIZE > 1024 ? 1024 : TEST_GRAPH_SIZE];

    checkCuda(cudaMemcpy(h_graph,
                         env.d_graph,
                         sizeof(h_graph),
                         cudaMemcpyDeviceToHost),
              "copy partial graph");

    // 构造 var 0 的 NEXT_DIFF_PTS
    uint nextHead0 = TEST_NEXT_DIFF_PTS_START + 0 * ELEMENT_WIDTH;

    uint initVals[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) {
        initVals[i] = 0;
    }

    initVals[0] = 0x1;
    initVals[BASE] = 0;
    initVals[NEXT] = NIL;

    checkCuda(cudaMemcpy(env.d_graph + nextHead0,
                         initVals,
                         ELEMENT_WIDTH * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "set next diff pts for var 0");

    bool done = true;
    checkCuda(cudaMemcpyToSymbol(__done__, &done, sizeof(bool)), "set done");

    dim3 block(32, 4);
    dim3 grid(1);

    updatePtsInformation<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "updatePtsInformation launch failed");
    checkCuda(cudaDeviceSynchronize(), "updatePtsInformation execution failed");

    uint ptsOut[ELEMENT_WIDTH];
    uint currOut[ELEMENT_WIDTH];
    bool h_done = true;

    uint ptsHead0 = TEST_PTS_START;
    uint currHead0 = TEST_CURR_DIFF_PTS_START;

    checkCuda(cudaMemcpy(ptsOut,
                         env.d_graph + ptsHead0,
                         ELEMENT_WIDTH * sizeof(uint),
                         cudaMemcpyDeviceToHost),
              "copy pts out");

    checkCuda(cudaMemcpy(currOut,
                         env.d_graph + currHead0,
                         ELEMENT_WIDTH * sizeof(uint),
                         cudaMemcpyDeviceToHost),
              "copy curr out");

    checkCuda(cudaMemcpyFromSymbol(&h_done, __done__, sizeof(bool)),
              "copy done");

    printf("updatePtsInformation finished\n");
    printf("__done__=%d\n", (int)h_done);
    printf("PTS[0].word0=%u base=%u next=%u\n", ptsOut[0], ptsOut[BASE], ptsOut[NEXT]);
    printf("CURR_DIFF_PTS[0].word0=%u base=%u next=%u\n", currOut[0], currOut[BASE], currOut[NEXT]);

    destroyPTATestEnv(env);
    return 0;
}