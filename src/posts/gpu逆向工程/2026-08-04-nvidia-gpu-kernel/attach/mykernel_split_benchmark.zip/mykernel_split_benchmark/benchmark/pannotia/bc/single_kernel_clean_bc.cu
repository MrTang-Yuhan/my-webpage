// Auto-generated CUDA kernel file: clean_bc
// Extracted from: pannotia/bc/kernel.cu
// Original line: 227

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: clean_bc (line 227)
__global__ void clean_bc(float *bc_d, const int num_nodes) {

    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    if (tid < num_nodes)
        bc_d[tid] = 0;

}

int main(int argc, char** argv) {
    const int num_nodes = 1024;
    const size_t size_bc = (size_t)num_nodes * sizeof(float);

    float *h_bc = (float*)malloc(size_bc);
    float *d_bc = nullptr;

    if (!h_bc) {
        printf("malloc failed for h_bc\n");
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_bc[i] = (float)(i + 1);
    }

    cudaError_t err;

    err = cudaMalloc((void**)&d_bc, size_bc);
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_bc: %s\n", cudaGetErrorString(err));
        free(h_bc);
        return -1;
    }

    err = cudaMemcpy(d_bc, h_bc, size_bc, cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for bc: %s\n", cudaGetErrorString(err));
        cudaFree(d_bc);
        free(h_bc);
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    clean_bc<<<gridSize, blockSize>>>(d_bc, num_nodes);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_bc);
        free(h_bc);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_bc);
        free(h_bc);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaEventSynchronize(stop);

    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("clean_bc execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_bc, d_bc, size_bc, cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for bc: %s\n", cudaGetErrorString(err));
        cudaFree(d_bc);
        free(h_bc);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    printf("bc[0] = %f\n", h_bc[0]);
    printf("bc[num_nodes - 1] = %f\n", h_bc[num_nodes - 1]);

    cudaFree(d_bc);
    free(h_bc);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}