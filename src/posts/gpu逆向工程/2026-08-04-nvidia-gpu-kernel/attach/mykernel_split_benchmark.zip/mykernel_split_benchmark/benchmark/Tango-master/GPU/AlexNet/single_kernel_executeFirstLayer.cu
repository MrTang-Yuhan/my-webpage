// Auto-generated CUDA kernel file: executeFirstLayer
// Extracted from: Tango-master/GPU/AlexNet/an_kernel.cu
// Original line: 45

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: executeFirstLayer (line 45)
__global__ void executeFirstLayer(float *bias,float *Layer1_Neurons_GPU,float *Layer1_Weights_GPU,float *Layer2_Neurons_GPU,int r_offset, int c_offset) {

    float product = 0.0;
    int col_width = 227;
    int stride_width = 4;
    int stride = 0,colstride = 0;
    int output = blockIdx.x;
    int row = threadIdx.x + r_offset;
    int col = threadIdx.y + c_offset;
    colstride = 3*row*stride_width*col_width;
    stride = 0;
    product = 0;
    stride = col * 4 * 3;
    /* RGB weights and input 11*11*3 */
    for(int i = 0; i < 11; i++)
    {
        for(int j = 0; j < 11; j++)
        {
            product +=        ((Layer1_Neurons_GPU[i*227*3 + j*3 + stride + colstride]    * Layer1_Weights_GPU[i*11 + j + (output * 11*11*3)])
                    + (Layer1_Neurons_GPU[i*227*3 + j*3 + 1 + stride + colstride] * Layer1_Weights_GPU[i*11 + 11*11 + j+ (output * 11*11*3)])
                    + (Layer1_Neurons_GPU[i*227*3 + j*3 + 2 + stride + colstride] * Layer1_Weights_GPU[i*11 + 11*11*2 + j+ (output * 11*11*3)]));
        }
    }
    product += bias[output];
    if(product < 0) /* RELU Layer */
        product = 0; // max(0,x)
    Layer2_Neurons_GPU[output*55*55 + row*55 + col] = product;
    product = 0.0;

}


int main() {
    const int out_channels = 96;
    const int in_h = 227, in_w = 227, in_c = 3;
    const int out_h = 55, out_w = 55;
    const int kernel = 11;

    size_t input_size  = in_h * in_w * in_c;
    size_t weight_size = out_channels * kernel * kernel * in_c;
    size_t bias_size   = out_channels;
    size_t output_size = out_channels * out_h * out_w;

    float *h_input  = (float*)malloc(input_size * sizeof(float));
    float *h_weight = (float*)malloc(weight_size * sizeof(float));
    float *h_bias   = (float*)malloc(bias_size * sizeof(float));
    float *h_output = (float*)malloc(output_size * sizeof(float));

    for (size_t i = 0; i < input_size;  ++i) h_input[i]  = (float)(i % 13) * 0.01f;
    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (float)(i % 7) * 0.01f;
    for (size_t i = 0; i < bias_size;   ++i) h_bias[i]   = 0.1f;

    float *d_input, *d_weight, *d_bias, *d_output;
    CHECK(cudaMalloc((void**)&d_input,  input_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_bias,   bias_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_output, output_size * sizeof(float)));

    CHECK(cudaMemcpy(d_input,  h_input,  input_size * sizeof(float),  cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_bias,   h_bias,   bias_size * sizeof(float),   cudaMemcpyHostToDevice));

    dim3 grid(out_channels);
    dim3 block(11, 11);

    for (int r = 0; r < out_h; r += 11) {
        for (int c = 0; c < out_w; c += 11) {
            executeFirstLayer<<<grid, block>>>(d_bias, d_input, d_weight, d_output, r, c);
            CHECK(cudaGetLastError());
        }
    }

    CHECK(cudaDeviceSynchronize());
    CHECK(cudaMemcpy(h_output, d_output, output_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeFirstLayer done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("out[%d] = %f\n", i, h_output[i]);
    }

    cudaFree(d_input);
    cudaFree(d_weight);
    cudaFree(d_bias);
    cudaFree(d_output);
    free(h_input);
    free(h_weight);
    free(h_bias);
    free(h_output);
    return 0;
}