// ===== Includes =====
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// ===== Macro Definitions =====
#define GAMMA 1.4f
#define block_length 192
#define NDIM 3
#define VAR_DENSITY 0
#define VAR_MOMENTUM 1
#define VAR_DENSITY_ENERGY (VAR_MOMENTUM+NDIM)
#define NVAR (VAR_DENSITY_ENERGY+1)

#define checkCuda(call) do { \
    cudaError_t e = call; \
    if(e != cudaSuccess){ fprintf(stderr,"CUDA %s:%d %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1); } \
} while(0)

// ===== Device Functions =====
__device__ float compute_speed_sqd(float3 v) {
    return v.x*v.x + v.y*v.y + v.z*v.z;
}
__device__ void compute_velocity(float density, float3 momentum, float3& velocity) {
    velocity.x = momentum.x/density;
    velocity.y = momentum.y/density;
    velocity.z = momentum.z/density;
}
__device__ float compute_pressure(float density, float density_energy, float speed_sqd) {
    return (GAMMA-1.0f)*(density_energy - 0.5f*density*speed_sqd);
}
__device__ float compute_speed_of_sound(float density, float pressure) {
    return sqrtf(GAMMA*pressure/density);
}
__device__ void compute_flux_contribution(
    float density, float3 momentum, float density_energy,
    float pressure, float3 velocity,
    float3& fc_momentum_x, float3& fc_momentum_y, float3& fc_momentum_z,
    float3& fc_density_energy)
{
    fc_momentum_x = {velocity.x*momentum.x+pressure, velocity.x*momentum.y, velocity.x*momentum.z};
    fc_momentum_y = {fc_momentum_x.y, velocity.y*momentum.y+pressure, velocity.y*momentum.z};
    fc_momentum_z = {fc_momentum_x.z, fc_momentum_y.z, velocity.z*momentum.z+pressure};
    float de_p = density_energy + pressure;
    fc_density_energy = {velocity.x*de_p, velocity.y*de_p, velocity.z*de_p};
}

// ===== Kernel =====
__global__ void cuda_compute_flux_contributions(
    int nelr, float* variables,
    float* fc_momentum_x, float* fc_momentum_y, float* fc_momentum_z,
    float* fc_density_energy)
{
    const int i = blockDim.x*blockIdx.x + threadIdx.x;

    float density_i      = variables[i + VAR_DENSITY*nelr];
    float3 momentum_i    = {variables[i+(VAR_MOMENTUM+0)*nelr],
                             variables[i+(VAR_MOMENTUM+1)*nelr],
                             variables[i+(VAR_MOMENTUM+2)*nelr]};
    float density_energy_i = variables[i + VAR_DENSITY_ENERGY*nelr];

    float3 velocity_i;
    compute_velocity(density_i, momentum_i, velocity_i);
    float speed_sqd_i  = compute_speed_sqd(velocity_i);
    float pressure_i   = compute_pressure(density_i, density_energy_i, speed_sqd_i);

    float3 fc_mx, fc_my, fc_mz, fc_de;
    compute_flux_contribution(density_i, momentum_i, density_energy_i, pressure_i, velocity_i,
                              fc_mx, fc_my, fc_mz, fc_de);

    fc_momentum_x[i+0*nelr]=fc_mx.x; fc_momentum_x[i+1*nelr]=fc_mx.y; fc_momentum_x[i+2*nelr]=fc_mx.z;
    fc_momentum_y[i+0*nelr]=fc_my.x; fc_momentum_y[i+1*nelr]=fc_my.y; fc_momentum_y[i+2*nelr]=fc_my.z;
    fc_momentum_z[i+0*nelr]=fc_mz.x; fc_momentum_z[i+1*nelr]=fc_mz.y; fc_momentum_z[i+2*nelr]=fc_mz.z;
    fc_density_energy[i+0*nelr]=fc_de.x; fc_density_energy[i+1*nelr]=fc_de.y; fc_density_energy[i+2*nelr]=fc_de.z;
}

// ===== Main =====
int main() {
    const int nelr = 960;

    float ff_pressure = 1.0f;
    float ff_density  = GAMMA * ff_pressure;
    float ff_speed    = 1.2f * sqrtf(GAMMA * ff_pressure / ff_density);
    float ff_de       = ff_pressure/(GAMMA-1.0f) + 0.5f*ff_density*ff_speed*ff_speed;

    float *h_var = (float*)malloc(nelr*NVAR*sizeof(float));
    for(int i = 0; i < nelr; i++){
        h_var[i+VAR_DENSITY*nelr]        = ff_density;
        h_var[i+(VAR_MOMENTUM+0)*nelr]   = ff_density*ff_speed;
        h_var[i+(VAR_MOMENTUM+1)*nelr]   = 0.0f;
        h_var[i+(VAR_MOMENTUM+2)*nelr]   = 0.0f;
        h_var[i+VAR_DENSITY_ENERGY*nelr] = ff_de;
    }

    float *d_var, *d_fcmx, *d_fcmy, *d_fcmz, *d_fcde;
    checkCuda(cudaMalloc(&d_var,  nelr*NVAR*sizeof(float)));
    checkCuda(cudaMalloc(&d_fcmx, nelr*3*sizeof(float)));
    checkCuda(cudaMalloc(&d_fcmy, nelr*3*sizeof(float)));
    checkCuda(cudaMalloc(&d_fcmz, nelr*3*sizeof(float)));
    checkCuda(cudaMalloc(&d_fcde, nelr*3*sizeof(float)));
    checkCuda(cudaMemcpy(d_var, h_var, nelr*NVAR*sizeof(float), cudaMemcpyHostToDevice));

    cuda_compute_flux_contributions<<<nelr/block_length, block_length>>>(
        nelr, d_var, d_fcmx, d_fcmy, d_fcmz, d_fcde);
    checkCuda(cudaDeviceSynchronize());

    float h_out;
    checkCuda(cudaMemcpy(&h_out, d_fcmx, sizeof(float), cudaMemcpyDeviceToHost));
    printf("cuda_compute_flux_contributions OK. fc_momentum_x[0]=%.4f\n", h_out);

    free(h_var);
    cudaFree(d_var); cudaFree(d_fcmx); cudaFree(d_fcmy); cudaFree(d_fcmz); cudaFree(d_fcde);
    return 0;
}