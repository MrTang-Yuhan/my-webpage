// Auto-generated CUDA kernel file: euclid
// Extracted from: rodinia/2.0-ft/nn/nn_cuda.cu
// Original line: 27

// ===== Includes =====
#include <stdio.h>
#include <sys/time.h>
#include "cuda.h"
#include <string.h>

// ===== Macro Definitions =====
#define MAX_ARGS 10  // from line 6
#define REC_LENGTH 49 // size of a record in db  // from line 7
 #define REC_WINDOW 15000 // number of records to take in at a time  // from line 10
#define LATITUDE_POS 28	// character position of the latitude value in each record  // from line 13
#define OPEN 10000	// initial value of nearest neighbors  // from line 14

// ===== Kernel =====
// Kernel: euclid (line 27)
__global__ void euclid(char *data, float x2, float y2,float *z, int N, int W, int L_POS) {

	int idx=blockIdx.x*blockDim.x+threadIdx.x;
	float tmp_lat=0.0, tmp_long=0.0;
	int position = ( idx * W ) + L_POS - 1;	  // [参数: W, L_POS]
	
	if(idx < N) {  // [参数: N]
		char temp1[5];
		for( int i = 0 ; i < 5 ; i++ ) {
			temp1[i] = data[position+i];  // [参数: data]
		}
		char temp2[5];
		for( int i = 0 ; i < 5 ; i++ ) {
			temp2[i] = data[position+6+i];  // [参数: data]
		}
		
		int dig1, dig2, dig3, dig_1;
		if( temp1[0] == ' ' ) { dig1 = 0; }
		else {
			dig1 = temp1[0] - 48;
			tmp_lat += dig1 * 100;
		}
		if( temp1[1] == ' ' ) { dig2 = 0; }
		else {
			dig2 = temp1[1] - 48;
			tmp_lat += dig2 * 10;
		}
		if( temp1[2] == ' ' ) { dig3 = 0; }
		else {
			dig3 = temp1[2] - 48;
			tmp_lat += dig3 * 1;
		}
		dig_1 = temp1[4] - 48;
		tmp_lat += (float) dig_1 / 10;

		if( temp2[0] == ' ' ) { dig1 = 0; }
		else {
			dig1 = temp2[0] - 48;
			tmp_long += dig1 * 100;
		}
		if( temp2[1] == ' ' ) { dig2 = 0; }
		else {
			dig2 = temp2[1] - 48;
			tmp_long += dig2 * 10;
		}
		if( temp2[2] == ' ' ) { dig3 = 0; }
		else {
			dig3 = temp2[2] - 48;
			tmp_long += dig3 * 1;
		}
		dig_1 = temp2[4] - 48;
		tmp_long += (float) dig_1 / 10;

		z[idx]=sqrt(((tmp_lat-x2)*(tmp_lat-x2))+((tmp_long-y2)*(tmp_long-y2)));  // [参数: x2, y2, z]
	}

}

// 在 single_kernel_euclid.cu 末尾追加

int main() {
    // ----------------------------
    // 参数设置
    // ----------------------------
    const int N = 1000;           // 记录数量
    const int W = REC_LENGTH;     // 每条记录宽度 49
    const int L_POS = LATITUDE_POS; // 纬度起始位置 28
    const float target_lat  = 35.5f;  // 目标纬度
    const float target_long = 139.7f; // 目标经度

    // ----------------------------
    // 构造测试数据（模拟数据库记录）
    // ----------------------------
    // 格式：每条记录 49 字节，第 28-32 位是纬度（格式 "123.4"），第 34-38 位是经度
    char *h_data = (char*)malloc(N * W * sizeof(char));
    memset(h_data, ' ', N * W);  // 先填充空格

    for (int i = 0; i < N; i++) {
        int offset = i * W;
        // 生成随机纬度/经度（格式 "035.2" 和 "139.8"）
        int lat_int  = 30 + (rand() % 20);   // 30-49
        int lat_frac = rand() % 10;
        int lon_int  = 130 + (rand() % 20);  // 130-149
        int lon_frac = rand() % 10;

        // 写入纬度（位置 27-31，索引从0开始）
        snprintf(&h_data[offset + L_POS - 1], 6, "%03d.%d", lat_int, lat_frac);
        // 写入经度（位置 33-37）
        snprintf(&h_data[offset + L_POS + 5], 6, "%03d.%d", lon_int, lon_frac);
    }

    // ----------------------------
    // 分配 GPU 内存
    // ----------------------------
    char *d_data;
    float *d_z;
    cudaMalloc(&d_data, N * W * sizeof(char));
    cudaMalloc(&d_z, N * sizeof(float));

    cudaMemcpy(d_data, h_data, N * W * sizeof(char), cudaMemcpyHostToDevice);

    // ----------------------------
    // 启动 kernel
    // ----------------------------
    int threads_per_block = 256;
    int blocks = (N + threads_per_block - 1) / threads_per_block;

    printf("Running euclid kernel:\n");
    printf("  Records: %d\n", N);
    printf("  Target:  lat=%.1f, long=%.1f\n", target_lat, target_long);
    printf("  Grid:    %d blocks x %d threads\n", blocks, threads_per_block);

    euclid<<<blocks, threads_per_block>>>(
        d_data, target_lat, target_long, d_z, N, W, L_POS
    );

    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));

    // ----------------------------
    // 拷回结果并找最近邻
    // ----------------------------
    float *h_z = (float*)malloc(N * sizeof(float));
    cudaMemcpy(h_z, d_z, N * sizeof(float), cudaMemcpyDeviceToHost);

    // 找最小距离
    int min_idx = 0;
    float min_dist = h_z[0];
    for (int i = 1; i < N; i++) {
        if (h_z[i] < min_dist) {
            min_dist = h_z[i];
            min_idx = i;
        }
    }

    // 解析最近邻的坐标
    int offset = min_idx * W + L_POS - 1;
    char lat_str[6], lon_str[6];
    memcpy(lat_str, &h_data[offset], 5); lat_str[5] = '\0';
    memcpy(lon_str, &h_data[offset + 6], 5); lon_str[5] = '\0';

    printf("\nNearest neighbor:\n");
    printf("  Index:    %d\n", min_idx);
    printf("  Distance: %.4f\n", min_dist);
    printf("  Coords:   lat=%s, long=%s\n", lat_str, lon_str);

    // 验证：距离应该合理（0-20度范围内）
    int valid = (min_dist >= 0.0f && min_dist < 20.0f);
    printf("\nValidation: %s\n", valid ? "PASSED" : "FAILED");

    // ----------------------------
    // 清理
    // ----------------------------
    cudaFree(d_data);
    cudaFree(d_z);
    free(h_data);
    free(h_z);

    return (err == cudaSuccess && valid) ? 0 : 1;
}