// ===== Includes =====
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// ===== Macro Definitions =====
#define GAMMA 1.4f
#define block_length 192
#define NDIM 3
#define NNB 4
#define VAR_DENSITY 0
#define VAR_MOMENTUM 1
#define VAR_DENSITY_ENERGY (VAR_MOMENTUM+NDIM)
#define NVAR (VAR_DENSITY_ENERGY+1)

#define checkCuda(call) do { \
    cudaError_t e = call; \
    if(e != cudaSuccess){ fprintf(stderr,"CUDA %s:%d %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1); } \
} while(0)

// ===== far-field constants =====
__device__ __constant__ float  ff_variable[NVAR];
__device__ __constant__ float3 ff_fc_momentum_x[1];
__device__ __constant__ float3 ff_fc_momentum_y[1];
__device__ __constant__ float3 ff_fc_momentum_z[1];
__device__ __constant__ float3 ff_fc_density_energy[1];

// ===== Device Functions =====
__device__ float compute_speed_sqd(float3 v) {
    return v.x*v.x + v.y*v.y + v.z*v.z;
}
__device__ void compute_velocity(float density, float3 momentum, float3& velocity) {
    velocity.x = momentum.x/density;
    velocity.y = momentum.y/density;
    velocity.z = momentum.z/density;
}
__device__ float compute_pressure(float density, float density_energy, float speed_sqd) {
    return (GAMMA-1.0f)*(density_energy - 0.5f*density*speed_sqd);
}
__device__ float compute_speed_of_sound(float density, float pressure) {
    return sqrtf(GAMMA*pressure/density);
}

// ===== Kernel =====
__global__ void cuda_compute_flux(
    int nelr, int* elements_surrounding_elements, float* normals,
    float* variables,
    float* fc_momentum_x, float* fc_momentum_y, float* fc_momentum_z,
    float* fc_density_energy, float* fluxes)
{
    const float smoothing_coefficient = 0.2f;
    const int i = blockDim.x*blockIdx.x + threadIdx.x;

    int j, nb;
    float3 normal; float normal_len, factor;

    float density_i      = variables[i+VAR_DENSITY*nelr];
    float3 momentum_i    = {variables[i+(VAR_MOMENTUM+0)*nelr],
                             variables[i+(VAR_MOMENTUM+1)*nelr],
                             variables[i+(VAR_MOMENTUM+2)*nelr]};
    float density_energy_i = variables[i+VAR_DENSITY_ENERGY*nelr];

    float3 velocity_i;
    compute_velocity(density_i, momentum_i, velocity_i);
    float speed_sqd_i      = compute_speed_sqd(velocity_i);
    float speed_i          = sqrtf(speed_sqd_i);
    float pressure_i       = compute_pressure(density_i, density_energy_i, speed_sqd_i);
    float speed_of_sound_i = compute_speed_of_sound(density_i, pressure_i);

    float3 fc_i_mx = {fc_momentum_x[i+0*nelr], fc_momentum_x[i+1*nelr], fc_momentum_x[i+2*nelr]};
    float3 fc_i_my = {fc_momentum_y[i+0*nelr], fc_momentum_y[i+1*nelr], fc_momentum_y[i+2*nelr]};
    float3 fc_i_mz = {fc_momentum_z[i+0*nelr], fc_momentum_z[i+1*nelr], fc_momentum_z[i+2*nelr]};
    float3 fc_i_de = {fc_density_energy[i+0*nelr], fc_density_energy[i+1*nelr], fc_density_energy[i+2*nelr]};

    float flux_density = 0.0f, flux_de = 0.0f;
    float3 flux_momentum = {0.0f, 0.0f, 0.0f};

    #pragma unroll
    for(j = 0; j < NNB; j++) {
        nb       = elements_surrounding_elements[i + j*nelr];
        normal.x = normals[i + (j+0*NNB)*nelr];
        normal.y = normals[i + (j+1*NNB)*nelr];
        normal.z = normals[i + (j+2*NNB)*nelr];
        normal_len = sqrtf(normal.x*normal.x + normal.y*normal.y + normal.z*normal.z);

        if(nb >= 0) {
            float density_nb      = variables[nb+VAR_DENSITY*nelr];
            float3 momentum_nb    = {variables[nb+(VAR_MOMENTUM+0)*nelr],
                                     variables[nb+(VAR_MOMENTUM+1)*nelr],
                                     variables[nb+(VAR_MOMENTUM+2)*nelr]};
            float density_energy_nb = variables[nb+VAR_DENSITY_ENERGY*nelr];
            float3 velocity_nb;
            compute_velocity(density_nb, momentum_nb, velocity_nb);
            float speed_sqd_nb      = compute_speed_sqd(velocity_nb);
            float pressure_nb       = compute_pressure(density_nb, density_energy_nb, speed_sqd_nb);
            float speed_of_sound_nb = compute_speed_of_sound(density_nb, pressure_nb);

            float3 fc_nb_mx = {fc_momentum_x[nb+0*nelr], fc_momentum_x[nb+1*nelr], fc_momentum_x[nb+2*nelr]};
            float3 fc_nb_my = {fc_momentum_y[nb+0*nelr], fc_momentum_y[nb+1*nelr], fc_momentum_y[nb+2*nelr]};
            float3 fc_nb_mz = {fc_momentum_z[nb+0*nelr], fc_momentum_z[nb+1*nelr], fc_momentum_z[nb+2*nelr]};
            float3 fc_nb_de = {fc_density_energy[nb+0*nelr], fc_density_energy[nb+1*nelr], fc_density_energy[nb+2*nelr]};

            factor = -normal_len*smoothing_coefficient*0.5f*(speed_i+sqrtf(speed_sqd_nb)+speed_of_sound_i+speed_of_sound_nb);
            flux_density      += factor*(density_i-density_nb);
            flux_de           += factor*(density_energy_i-density_energy_nb);
            flux_momentum.x   += factor*(momentum_i.x-momentum_nb.x);
            flux_momentum.y   += factor*(momentum_i.y-momentum_nb.y);
            flux_momentum.z   += factor*(momentum_i.z-momentum_nb.z);

            factor = 0.5f*normal.x;
            flux_density    += factor*(momentum_nb.x+momentum_i.x);
            flux_de         += factor*(fc_nb_de.x+fc_i_de.x);
            flux_momentum.x += factor*(fc_nb_mx.x+fc_i_mx.x);
            flux_momentum.y += factor*(fc_nb_my.x+fc_i_my.x);
            flux_momentum.z += factor*(fc_nb_mz.x+fc_i_mz.x);

            factor = 0.5f*normal.y;
            flux_density    += factor*(momentum_nb.y+momentum_i.y);
            flux_de         += factor*(fc_nb_de.y+fc_i_de.y);
            flux_momentum.x += factor*(fc_nb_mx.y+fc_i_mx.y);
            flux_momentum.y += factor*(fc_nb_my.y+fc_i_my.y);
            flux_momentum.z += factor*(fc_nb_mz.y+fc_i_mz.y);

            factor = 0.5f*normal.z;
            flux_density    += factor*(momentum_nb.z+momentum_i.z);
            flux_de         += factor*(fc_nb_de.z+fc_i_de.z);
            flux_momentum.x += factor*(fc_nb_mx.z+fc_i_mx.z);
            flux_momentum.y += factor*(fc_nb_my.z+fc_i_my.z);
            flux_momentum.z += factor*(fc_nb_mz.z+fc_i_mz.z);
        }
        else if(nb == -1) {
            flux_momentum.x += normal.x*pressure_i;
            flux_momentum.y += normal.y*pressure_i;
            flux_momentum.z += normal.z*pressure_i;
        }
        else if(nb == -2) {
            factor = 0.5f*normal.x;
            flux_density    += factor*(ff_variable[VAR_MOMENTUM+0]+momentum_i.x);
            flux_de         += factor*(ff_fc_density_energy[0].x+fc_i_de.x);
            flux_momentum.x += factor*(ff_fc_momentum_x[0].x+fc_i_mx.x);
            flux_momentum.y += factor*(ff_fc_momentum_y[0].x+fc_i_my.x);
            flux_momentum.z += factor*(ff_fc_momentum_z[0].x+fc_i_mz.x);

            factor = 0.5f*normal.y;
            flux_density    += factor*(ff_variable[VAR_MOMENTUM+1]+momentum_i.y);
            flux_de         += factor*(ff_fc_density_energy[0].y+fc_i_de.y);
            flux_momentum.x += factor*(ff_fc_momentum_x[0].y+fc_i_mx.y);
            flux_momentum.y += factor*(ff_fc_momentum_y[0].y+fc_i_my.y);
            flux_momentum.z += factor*(ff_fc_momentum_z[0].y+fc_i_mz.y);

            factor = 0.5f*normal.z;
            flux_density    += factor*(ff_variable[VAR_MOMENTUM+2]+momentum_i.z);
            flux_de         += factor*(ff_fc_density_energy[0].z+fc_i_de.z);
            flux_momentum.x += factor*(ff_fc_momentum_x[0].z+fc_i_mx.z);
            flux_momentum.y += factor*(ff_fc_momentum_y[0].z+fc_i_my.z);
            flux_momentum.z += factor*(ff_fc_momentum_z[0].z+fc_i_mz.z);
        }
    }

    fluxes[i+VAR_DENSITY*nelr]        = flux_density;
    fluxes[i+(VAR_MOMENTUM+0)*nelr]   = flux_momentum.x;
    fluxes[i+(VAR_MOMENTUM+1)*nelr]   = flux_momentum.y;
    fluxes[i+(VAR_MOMENTUM+2)*nelr]   = flux_momentum.z;
    fluxes[i+VAR_DENSITY_ENERGY*nelr] = flux_de;
}

// ===== Helper: 初始化 far-field 常量 =====
static void init_ff(float ff_density, float ff_speed, float ff_pressure, float ff_de, float angle) {
    float h_ff[NVAR];
    h_ff[VAR_DENSITY]        = ff_density;
    h_ff[VAR_MOMENTUM+0]     = ff_density*ff_speed*cosf(angle);
    h_ff[VAR_MOMENTUM+1]     = ff_density*ff_speed*sinf(angle);
    h_ff[VAR_MOMENTUM+2]     = 0.0f;
    h_ff[VAR_DENSITY_ENERGY] = ff_de;
    checkCuda(cudaMemcpyToSymbol(ff_variable, h_ff, NVAR*sizeof(float)));

    float3 h_mx = {h_ff[VAR_MOMENTUM+0]*ff_speed+ff_pressure, h_ff[VAR_MOMENTUM+0]*ff_speed*sinf(angle), 0.0f};
    float3 h_my = {h_mx.y, h_ff[VAR_MOMENTUM+1]*ff_speed+ff_pressure, 0.0f};
    float3 h_mz = {0.0f, 0.0f, ff_pressure};
    float3 h_de = {ff_speed*(ff_de+ff_pressure), ff_speed*sinf(angle)*(ff_de+ff_pressure), 0.0f};
    checkCuda(cudaMemcpyToSymbol(ff_fc_momentum_x,    &h_mx, sizeof(float3)));
    checkCuda(cudaMemcpyToSymbol(ff_fc_momentum_y,    &h_my, sizeof(float3)));
    checkCuda(cudaMemcpyToSymbol(ff_fc_momentum_z,    &h_mz, sizeof(float3)));
    checkCuda(cudaMemcpyToSymbol(ff_fc_density_energy,&h_de, sizeof(float3)));
}

// ===== Main =====
int main() {
    const int nelr = 960;

    float ff_pressure = 1.0f;
    float ff_density  = GAMMA * ff_pressure;
    float ff_speed    = 1.2f * sqrtf(GAMMA * ff_pressure / ff_density);
    float ff_de       = ff_pressure/(GAMMA-1.0f) + 0.5f*ff_density*ff_speed*ff_speed;
    float angle       = 0.0f;
    init_ff(ff_density, ff_speed, ff_pressure, ff_de, angle);

    // 填充 variables（全场均匀 far-field 值）
    float *h_var = (float*)malloc(nelr*NVAR*sizeof(float));
    for(int i = 0; i < nelr; i++){
        h_var[i+VAR_DENSITY*nelr]        = ff_density;
        h_var[i+(VAR_MOMENTUM+0)*nelr]   = ff_density*ff_speed;
        h_var[i+(VAR_MOMENTUM+1)*nelr]   = 0.0f;
        h_var[i+(VAR_MOMENTUM+2)*nelr]   = 0.0f;
        h_var[i+VAR_DENSITY_ENERGY*nelr] = ff_de;
    }

    // elements_surrounding_elements：全部设为合法邻居（循环相邻）
    int *h_ese = (int*)malloc(nelr*NNB*sizeof(int));
    for(int i = 0; i < nelr; i++)
        for(int j = 0; j < NNB; j++)
            h_ese[i+j*nelr] = (i+j+1) % nelr;

    // normals：简单单位法向量
    float *h_normals = (float*)malloc(nelr*NNB*3*sizeof(float));
    for(int i = 0; i < nelr*NNB*3; i++) h_normals[i] = 0.1f;

    // fc arrays（先用 compute_flux_contributions 的结果填，这里直接手算均匀场）
    float fc_mx0 = ff_density*ff_speed*ff_speed + ff_pressure;
    float *h_fcmx = (float*)calloc(nelr*3, sizeof(float));
    float *h_fcmy = (float*)calloc(nelr*3, sizeof(float));
    float *h_fcmz = (float*)calloc(nelr*3, sizeof(float));
    float *h_fcde = (float*)calloc(nelr*3, sizeof(float));
    for(int i = 0; i < nelr; i++){
        h_fcmx[i+0*nelr] = fc_mx0;   // velocity.x*momentum.x + pressure
        h_fcde[i+0*nelr] = ff_speed*(ff_de+ff_pressure);
    }

    // GPU alloc & copy
    float *d_var, *d_fcmx, *d_fcmy, *d_fcmz, *d_fcde, *d_fluxes;
    int   *d_ese;
    float *d_normals;
    checkCuda(cudaMalloc(&d_var,     nelr*NVAR*sizeof(float)));
    checkCuda(cudaMalloc(&d_ese,     nelr*NNB*sizeof(int)));
    checkCuda(cudaMalloc(&d_normals, nelr*NNB*3*sizeof(float)));
    checkCuda(cudaMalloc(&d_fcmx,    nelr*3*sizeof(float)));
    checkCuda(cudaMalloc(&d_fcmy,    nelr*3*sizeof(float)));
    checkCuda(cudaMalloc(&d_fcmz,    nelr*3*sizeof(float)));
    checkCuda(cudaMalloc(&d_fcde,    nelr*3*sizeof(float)));
    checkCuda(cudaMalloc(&d_fluxes,  nelr*NVAR*sizeof(float)));

    checkCuda(cudaMemcpy(d_var,     h_var,     nelr*NVAR*sizeof(float),  cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_ese,     h_ese,     nelr*NNB*sizeof(int),     cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_normals, h_normals, nelr*NNB*3*sizeof(float), cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_fcmx,    h_fcmx,    nelr*3*sizeof(float),     cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_fcmy,    h_fcmy,    nelr*3*sizeof(float),     cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_fcmz,    h_fcmz,    nelr*3*sizeof(float),     cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_fcde,    h_fcde,    nelr*3*sizeof(float),     cudaMemcpyHostToDevice));

    cuda_compute_flux<<<nelr/block_length, block_length>>>(
        nelr, d_ese, d_normals, d_var,
        d_fcmx, d_fcmy, d_fcmz, d_fcde, d_fluxes);
    checkCuda(cudaDeviceSynchronize());

    float h_flux0;
    checkCuda(cudaMemcpy(&h_flux0, d_fluxes, sizeof(float), cudaMemcpyDeviceToHost));
    printf("cuda_compute_flux OK. fluxes[0]=%.6f\n", h_flux0);

    free(h_var); free(h_ese); free(h_normals);
    free(h_fcmx); free(h_fcmy); free(h_fcmz); free(h_fcde);
    cudaFree(d_var); cudaFree(d_ese); cudaFree(d_normals);
    cudaFree(d_fcmx); cudaFree(d_fcmy); cudaFree(d_fcmz); cudaFree(d_fcde);
    cudaFree(d_fluxes);
    return 0;
}