// Auto-generated CUDA kernel file: executeReLULayerCUDA
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 900

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeReLULayerCUDA (line 900)
__global__ void executeReLULayerCUDA(float *Layer_Neurons,int size) {

        
	int i = blockIdx.x * blockDim.x * blockDim.y + threadIdx.x * blockDim.x + threadIdx.y ; //for(int i=0;i < size;i++)
	{
		if(Layer_Neurons[i] < 0)
			Layer_Neurons[i] = 0;
	}


}

int main() {
    const int size = 256;

    float *h_data = (float*)malloc(size * sizeof(float));
    if (!h_data) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (int i = 0; i < size; ++i) {
        h_data[i] = (i % 3 == 0) ? -(float)(i % 9) : (float)(i % 7);
    }

    float *d_data = NULL;
    CHECK(cudaMalloc((void**)&d_data, size * sizeof(float)));
    CHECK(cudaMemcpy(d_data, h_data, size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 block(8, 8);
    dim3 grid(size / (block.x * block.y));

    executeReLULayerCUDA<<<grid, block>>>(d_data, size);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_data, d_data, size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeReLULayerCUDA done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("data[%d] = %f\n", i, h_data[i]);
    }

    cudaFree(d_data);
    free(h_data);

    return 0;
}