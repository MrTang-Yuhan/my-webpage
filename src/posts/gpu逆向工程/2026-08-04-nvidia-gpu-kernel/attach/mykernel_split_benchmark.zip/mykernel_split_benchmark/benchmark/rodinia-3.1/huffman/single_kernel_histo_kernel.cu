#include <iostream>
#include <stdio.h>

#define SIZE (100*1024*1024)

inline void gpuAssert(cudaError_t code, const char *file, int line) {
    if (code != cudaSuccess) {
        fprintf(stderr, "GPUassert: %s %s %d\n", cudaGetErrorString(code), file, line);
        exit(code);
    }
}
#define CHECK(ans) { gpuAssert((ans), __FILE__, __LINE__); }

__global__ void histo_kernel(unsigned char *buffer, long size, unsigned int *histo) {
    __shared__ unsigned int temp[256];
    temp[threadIdx.x] = 0;
    __syncthreads();

    int i = threadIdx.x + blockIdx.x * blockDim.x;
    int offset = blockDim.x * gridDim.x;
    while (i < size) {
        atomicAdd(&temp[buffer[i]], 1);
        i += offset;
    }
    __syncthreads();
    atomicAdd(&(histo[threadIdx.x]), temp[threadIdx.x]);
}

int main() {
    unsigned char *h_buf = (unsigned char*)malloc(SIZE);
    for (long i = 0; i < SIZE; i++) h_buf[i] = (unsigned char)(i % 256);

    unsigned char *d_buf;
    unsigned int  *d_histo;
    CHECK(cudaMalloc(&d_buf,   SIZE));
    CHECK(cudaMalloc(&d_histo, 256 * sizeof(unsigned int)));
    CHECK(cudaMemcpy(d_buf, h_buf, SIZE, cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_histo, 0, 256 * sizeof(unsigned int)));

    histo_kernel<<<SIZE/256, 256>>>(d_buf, SIZE, d_histo);
    CHECK(cudaDeviceSynchronize());

    unsigned int h_histo[256];
    CHECK(cudaMemcpy(h_histo, d_histo, 256*sizeof(unsigned int), cudaMemcpyDeviceToHost));

    long total = 0;
    for (int i = 0; i < 256; i++) total += h_histo[i];
    printf("Total: %ld (expected %d)\n", total, SIZE);

    cudaFree(d_buf); cudaFree(d_histo); free(h_buf);
    return 0;
}