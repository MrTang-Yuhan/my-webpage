// Auto-generated CUDA kernel file: vector_diff
// Extracted from: pannotia/sssp/kernel.cu
// Original line: 173

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: vector_diff (line 173)
__global__ void
vector_diff(int *vector1, int *vector2, int *stop, const int num_nodes) {

    int tid = blockDim.x * blockIdx.x + threadIdx.x;

    if (tid < num_nodes) {
        if (vector2[tid] != vector1[tid]) {
            *stop = 1;
        }
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const size_t size_vec = (size_t)num_nodes * sizeof(int);
    const size_t size_stop = sizeof(int);

    int *h_vector1 = (int*)malloc(size_vec);
    int *h_vector2 = (int*)malloc(size_vec);
    int *h_stop = (int*)malloc(size_stop);

    int *d_vector1 = nullptr;
    int *d_vector2 = nullptr;
    int *d_stop = nullptr;

    if (!h_vector1 || !h_vector2 || !h_stop) {
        printf("host malloc failed\n");
        free(h_vector1);
        free(h_vector2);
        free(h_stop);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_vector1[i] = i;
        h_vector2[i] = i;
    }
    h_vector2[1] = -123;  // 制造一个差异
    *h_stop = 0;

    err = cudaMalloc((void**)&d_vector1, size_vec);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_vector1 failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_vector2, size_vec);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_vector2 failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_vector1);
        return -1;
    }

    err = cudaMalloc((void**)&d_stop, size_stop);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_stop failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_vector1);
        cudaFree(d_vector2);
        return -1;
    }

    cudaMemcpy(d_vector1, h_vector1, size_vec, cudaMemcpyHostToDevice);
    cudaMemcpy(d_vector2, h_vector2, size_vec, cudaMemcpyHostToDevice);
    cudaMemcpy(d_stop, h_stop, size_stop, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop_evt;
    cudaEventCreate(&start);
    cudaEventCreate(&stop_evt);

    cudaEventRecord(start);
    vector_diff<<<gridSize, blockSize>>>(d_vector1, d_vector2, d_stop, num_nodes);
    cudaEventRecord(stop_evt);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_stop, d_stop, size_stop, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop_evt);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop_evt);
    printf("vector_diff execution time: %.3f ms\n", ms);

    printf("stop = %d\n", *h_stop);
    printf("vector1[1] = %d\n", h_vector1[1]);
    printf("vector2[1] = %d\n", h_vector2[1]);

    cudaFree(d_vector1);
    cudaFree(d_vector2);
    cudaFree(d_stop);

    free(h_vector1);
    free(h_vector2);
    free(h_stop);

    cudaEventDestroy(start);
    cudaEventDestroy(stop_evt);

    return 0;
}