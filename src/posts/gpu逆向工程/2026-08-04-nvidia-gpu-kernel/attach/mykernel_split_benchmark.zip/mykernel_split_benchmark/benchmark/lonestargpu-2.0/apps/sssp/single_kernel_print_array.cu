// Standalone CUDA kernel file: print_array
// Smoke-test version with main()

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

static inline void checkCuda(cudaError_t err, const char* msg) {
  if (err != cudaSuccess) {
    fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
    exit(EXIT_FAILURE);
  }
}

__global__ void print_array(int *a, int n) {
  int id = threadIdx.x + blockDim.x * blockIdx.x;
  if (id < n) {
    printf("%d %d\n", id, a[id]);
  }
}

int main() {
  const int n = 8;
  int h_a[n] = {10, 20, 30, 40, 50, 60, 70, 80};
  int *d_a = NULL;

  checkCuda(cudaMalloc((void**)&d_a, n * sizeof(int)), "malloc d_a");
  checkCuda(cudaMemcpy(d_a, h_a, n * sizeof(int), cudaMemcpyHostToDevice), "copy d_a");

  dim3 block(128);
  dim3 grid((n + block.x - 1) / block.x);

  print_array<<<grid, block>>>(d_a, n);
  checkCuda(cudaGetLastError(), "print_array launch failed");
  checkCuda(cudaDeviceSynchronize(), "print_array execution failed");

  cudaFree(d_a);
  return 0;
}