// Auto-generated CUDA kernel file: executeThirdLayer
// Extracted from: ispass-2009/NN/NN_kernel.cu
// Original line: 96

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

__constant__ int kernelTemplate[25] = {
        0,  1,  2,  3,  4,
        29, 30, 31, 32, 33,
        58, 59, 60, 61, 62,
        87, 88, 89, 90, 91,
        116,117,118,119,120 };
__constant__ int kernelTemplate2[25] = {
        0,  1,  2,  3,  4,
        13, 14, 15, 16, 17, 
        26, 27, 28, 29, 30,
        39, 40, 41, 42, 43, 
        52, 53, 54, 55, 56   };
// ===== Kernel =====
// Kernel: executeThirdLayer (line 96)
__global__ void executeThirdLayer(float *Layer3_Neurons_GPU, float *Layer3_Weights_GPU,float *Layer4_Neurons_GPU) {

	int blockID=blockIdx.x;
	//int pixelY=threadIdx.y;


	int weightBegin=blockID*1251;
 
	float result=0;

	result+=Layer3_Weights_GPU[weightBegin];

	++weightBegin;

    for (int i=0; i<1250; ++i )
    {
		result+=Layer3_Neurons_GPU[i+(1250*blockIdx.y)]*Layer3_Weights_GPU[weightBegin+i];
    }

	result=(1.7159*tanhf(0.66666667*result));

	Layer4_Neurons_GPU[blockID+(100*blockIdx.y)]=result;


}


int main() {
    const int batch = 1;
    const int in_neurons = 1250 * batch;
    const int out_neurons = 100 * batch;
    const int weights = 100 * 1251;   // 100 outputs, each has 1 bias + 1250 weights

    float *h_in = (float*)malloc(sizeof(float) * in_neurons);
    float *h_w  = (float*)malloc(sizeof(float) * weights);
    float *h_out = (float*)malloc(sizeof(float) * out_neurons);

    for (int i = 0; i < in_neurons; i++) h_in[i] = 0.01f * (i % 17);
    for (int i = 0; i < weights; i++) h_w[i] = 0.001f * (i % 23);

    float *d_in = NULL, *d_w = NULL, *d_out = NULL;
    cudaMalloc((void**)&d_in, sizeof(float) * in_neurons);
    cudaMalloc((void**)&d_w,  sizeof(float) * weights);
    cudaMalloc((void**)&d_out, sizeof(float) * out_neurons);

    cudaMemcpy(d_in, h_in, sizeof(float) * in_neurons, cudaMemcpyHostToDevice);
    cudaMemcpy(d_w,  h_w,  sizeof(float) * weights, cudaMemcpyHostToDevice);
    cudaMemset(d_out, 0, sizeof(float) * out_neurons);

    dim3 grid(100, batch, 1);
    dim3 block(1, 1, 1);

    executeThirdLayer<<<grid, block>>>(d_in, d_w, d_out);
    cudaDeviceSynchronize();

    cudaMemcpy(h_out, d_out, sizeof(float) * out_neurons, cudaMemcpyDeviceToHost);

    for (int i = 0; i < 10; i++) {
        printf("Layer4[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_w);
    cudaFree(d_out);
    free(h_in);
    free(h_w);
    free(h_out);

    return 0;
}