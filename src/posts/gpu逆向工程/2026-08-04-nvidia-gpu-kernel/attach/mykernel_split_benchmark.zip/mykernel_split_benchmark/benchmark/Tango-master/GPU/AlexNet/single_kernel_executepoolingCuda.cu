// Auto-generated CUDA kernel file: executepoolingCuda
// Extracted from: Tango-master/GPU/AlexNet/an_kernel.cu
// Original line: 84

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: executepoolingCuda (line 84)
__global__ void executepoolingCuda(float *Layer2_Neurons_GPU,float *Layer2_pool_GPU,int out,int out_fr,int out_fc,int kernel,int stride_width,int in_fr,int in_fc) {

    float max = 0.0;
    int stride = 0,colstride = 0;
    int output = blockIdx.x;
    int row = threadIdx.x;
    int col = threadIdx.y;
    colstride = row * stride_width*in_fc;
    stride = col * stride_width;
    for(int i = 0; i < kernel; i++)
    {
        for(int j = 0; j < kernel; j++)
        {
            if(max < ((Layer2_Neurons_GPU[(output*in_fr*in_fc) + i*in_fc + j + stride + colstride])))
                max =   ((Layer2_Neurons_GPU[(output*in_fr*in_fc) + i*in_fc + j + stride + colstride])) ;

        }
    }
    Layer2_pool_GPU[output*out_fr*out_fc + row*out_fc + col] = max;
    max = 0.0;
    stride+= stride_width;

}

int main() {
    const int out = 96;
    const int in_fr = 55, in_fc = 55;
    const int kernel = 3, stride_width = 2;
    const int out_fr = 27, out_fc = 27;

    size_t in_size  = out * in_fr * in_fc;
    size_t out_size = out * out_fr * out_fc;

    float *h_in  = (float*)malloc(in_size * sizeof(float));
    float *h_out = (float*)malloc(out_size * sizeof(float));

    for (size_t i = 0; i < in_size; ++i) h_in[i] = (float)(i % 17) * 0.1f;

    float *d_in, *d_out;
    CHECK(cudaMalloc((void**)&d_in,  in_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out, out_size * sizeof(float)));

    CHECK(cudaMemcpy(d_in, h_in, in_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block(out_fr, out_fc);  // 27x27 = 729 threads

    executepoolingCuda<<<grid, block>>>(d_in, d_out, out, out_fr, out_fc, kernel, stride_width, in_fr, in_fc);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executepoolingCuda done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("pool_out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);
    return 0;
}