// Standalone CUDA kernel file: update_bias
// Smoke-test version with main()

#include <cuda.h>
#include <cuda_runtime.h>
#include <cub/cub.cuh>

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

typedef unsigned int uint;

static inline void checkCuda(cudaError_t err, const char* msg) {
  if (err != cudaSuccess) {
    fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
    exit(EXIT_FAILURE);
  }
}

struct GPUCSRGraph {
  int nnodes;
  int nedges;

  int *row_offsets;
  int *columns;

  bool *sat;
  float *bias;
  bool *value;

  __device__ __host__ int degree(int node) const {
    return row_offsets[node + 1] - row_offsets[node];
  }
};

struct Edge {
  int nedges;
  int *src;
  int *dst;
  bool *bar;
  float *eta;
  float *pi_0;
  float *pi_S;
  float *pi_U;

  bool alloc() {
    assert(nedges > 0);

    src  = (int*)   calloc(nedges, sizeof(*src));
    dst  = (int*)   calloc(nedges, sizeof(*dst));
    bar  = (bool*)  calloc(nedges, sizeof(*bar));
    eta  = (float*) calloc(nedges, sizeof(*eta));
    pi_0 = (float*) calloc(nedges, sizeof(*pi_0));
    pi_S = (float*) calloc(nedges, sizeof(*pi_S));
    pi_U = (float*) calloc(nedges, sizeof(*pi_U));

    return src && dst && bar && eta && pi_0 && pi_S && pi_U;
  }
};

__global__ void update_bias(GPUCSRGraph clauses,
                            GPUCSRGraph vars,
                            Edge ed,
                            float *bias_list,
                            int *bias_list_vars,
                            int *bias_len,
                            float *g_summag) {
  int id = threadIdx.x + blockIdx.x * blockDim.x;
  int threads = blockDim.x * gridDim.x;
  float maxmag;
  float summag = 0.0f;

  for (int v = id; v < vars.nnodes; v += threads) {
    if (vars.sat[v]) {
      continue;
    }

    float pi_0_hat = 1.0f;
    float V_minus = 1.0f;
    float V_plus = 1.0f;
    float pi_P_hat;
    float pi_M_hat;

    int edoff = vars.row_offsets[v];
    int ncl = vars.degree(v);

    // a E v(i)
    for (int edndx = 0; edndx < ncl; edndx++) {
      int edge = vars.columns[edoff + edndx];
      int cl = ed.src[edge];

      if (clauses.sat[cl]) {
        continue;
      }

      pi_0_hat *= (1.0f - ed.eta[edge]);

      if (ed.bar[edge]) {
        V_minus *= (1.0f - ed.eta[edge]);
      } else {
        V_plus *= (1.0f - ed.eta[edge]);
      }
    }

    pi_P_hat = (1.0f - V_plus) * V_minus;
    pi_M_hat = (1.0f - V_minus) * V_plus;

    float W_plus;
    float W_minus;

    if ((pi_0_hat + pi_P_hat + pi_M_hat) == 0.0f) {
      W_plus = 0.0f;
      W_minus = 0.0f;
    } else {
      W_plus = pi_P_hat / (pi_0_hat + pi_P_hat + pi_M_hat);
      W_minus = pi_M_hat / (pi_0_hat + pi_P_hat + pi_M_hat);
    }

    vars.bias[v] = fabsf(W_plus - W_minus);
    vars.value[v] = (W_plus > W_minus);

    maxmag = W_plus > W_minus ? W_plus : W_minus;
    summag += maxmag;

    int ndx = atomicAdd(bias_len, 1);
    bias_list[ndx] = vars.bias[v];
    bias_list_vars[ndx] = v;
  }

  typedef cub::BlockReduce<float, 384> BlockReduce;
  __shared__ typename BlockReduce::TempStorage temp_storage;

  summag = BlockReduce(temp_storage).Sum(summag);

  if (threadIdx.x == 0) {
    atomicAdd(g_summag, summag);
  }
}

// ============================================================
// Test helpers
// ============================================================

static void allocTinyGraph(GPUCSRGraph &g,
                           int nnodes,
                           int ncols,
                           const int *h_row_offsets,
                           const int *h_columns) {
  g.nnodes = nnodes;
  g.nedges = ncols;

  checkCuda(cudaMalloc((void**)&g.row_offsets, (nnodes + 1) * sizeof(int)),
            "malloc graph row_offsets");
  checkCuda(cudaMalloc((void**)&g.columns, ncols * sizeof(int)),
            "malloc graph columns");
  checkCuda(cudaMalloc((void**)&g.sat, nnodes * sizeof(bool)),
            "malloc graph sat");
  checkCuda(cudaMalloc((void**)&g.bias, nnodes * sizeof(float)),
            "malloc graph bias");
  checkCuda(cudaMalloc((void**)&g.value, nnodes * sizeof(bool)),
            "malloc graph value");

  checkCuda(cudaMemcpy(g.row_offsets,
                       h_row_offsets,
                       (nnodes + 1) * sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy row_offsets");

  checkCuda(cudaMemcpy(g.columns,
                       h_columns,
                       ncols * sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy columns");

  checkCuda(cudaMemset(g.sat, 0, nnodes * sizeof(bool)), "memset sat");
  checkCuda(cudaMemset(g.bias, 0, nnodes * sizeof(float)), "memset bias");
  checkCuda(cudaMemset(g.value, 0, nnodes * sizeof(bool)), "memset value");
}

static void freeTinyGraph(GPUCSRGraph &g) {
  if (g.row_offsets) cudaFree(g.row_offsets);
  if (g.columns) cudaFree(g.columns);
  if (g.sat) cudaFree(g.sat);
  if (g.bias) cudaFree(g.bias);
  if (g.value) cudaFree(g.value);

  g.row_offsets = NULL;
  g.columns = NULL;
  g.sat = NULL;
  g.bias = NULL;
  g.value = NULL;
}

static void allocTinyEdge(Edge &ed) {
  ed.nedges = 3;

  checkCuda(cudaMalloc((void**)&ed.src,  ed.nedges * sizeof(int)),   "malloc ed.src");
  checkCuda(cudaMalloc((void**)&ed.dst,  ed.nedges * sizeof(int)),   "malloc ed.dst");
  checkCuda(cudaMalloc((void**)&ed.bar,  ed.nedges * sizeof(bool)),  "malloc ed.bar");
  checkCuda(cudaMalloc((void**)&ed.eta,  ed.nedges * sizeof(float)), "malloc ed.eta");
  checkCuda(cudaMalloc((void**)&ed.pi_0, ed.nedges * sizeof(float)), "malloc ed.pi_0");
  checkCuda(cudaMalloc((void**)&ed.pi_S, ed.nedges * sizeof(float)), "malloc ed.pi_S");
  checkCuda(cudaMalloc((void**)&ed.pi_U, ed.nedges * sizeof(float)), "malloc ed.pi_U");

  int h_src[3] = {0, 0, 1};
  int h_dst[3] = {0, 1, 0};
  bool h_bar[3] = {false, true, false};

  float h_eta[3]  = {0.20f, 0.30f, 0.40f};
  float h_pi0[3]  = {0.60f, 0.50f, 0.70f};
  float h_piS[3]  = {0.20f, 0.20f, 0.10f};
  float h_piU[3]  = {0.20f, 0.30f, 0.20f};

  checkCuda(cudaMemcpy(ed.src, h_src, sizeof(h_src), cudaMemcpyHostToDevice), "copy ed.src");
  checkCuda(cudaMemcpy(ed.dst, h_dst, sizeof(h_dst), cudaMemcpyHostToDevice), "copy ed.dst");
  checkCuda(cudaMemcpy(ed.bar, h_bar, sizeof(h_bar), cudaMemcpyHostToDevice), "copy ed.bar");
  checkCuda(cudaMemcpy(ed.eta, h_eta, sizeof(h_eta), cudaMemcpyHostToDevice), "copy ed.eta");
  checkCuda(cudaMemcpy(ed.pi_0, h_pi0, sizeof(h_pi0), cudaMemcpyHostToDevice), "copy ed.pi_0");
  checkCuda(cudaMemcpy(ed.pi_S, h_piS, sizeof(h_piS), cudaMemcpyHostToDevice), "copy ed.pi_S");
  checkCuda(cudaMemcpy(ed.pi_U, h_piU, sizeof(h_piU), cudaMemcpyHostToDevice), "copy ed.pi_U");
}

static void freeTinyEdge(Edge &ed) {
  if (ed.src) cudaFree(ed.src);
  if (ed.dst) cudaFree(ed.dst);
  if (ed.bar) cudaFree(ed.bar);
  if (ed.eta) cudaFree(ed.eta);
  if (ed.pi_0) cudaFree(ed.pi_0);
  if (ed.pi_S) cudaFree(ed.pi_S);
  if (ed.pi_U) cudaFree(ed.pi_U);

  ed.src = NULL;
  ed.dst = NULL;
  ed.bar = NULL;
  ed.eta = NULL;
  ed.pi_0 = NULL;
  ed.pi_S = NULL;
  ed.pi_U = NULL;
}

static void initTinyGraphs(GPUCSRGraph &clauses, GPUCSRGraph &vars) {
  int h_clause_row_offsets[3] = {0, 2, 3};
  int h_clause_columns[3]     = {0, 1, 2};

  int h_var_row_offsets[3] = {0, 2, 3};
  int h_var_columns[3]     = {0, 2, 1};

  allocTinyGraph(clauses, 2, 3, h_clause_row_offsets, h_clause_columns);
  allocTinyGraph(vars,    2, 3, h_var_row_offsets,    h_var_columns);
}

static void destroyTinyGraphs(GPUCSRGraph &clauses, GPUCSRGraph &vars) {
  freeTinyGraph(clauses);
  freeTinyGraph(vars);
}

// ============================================================
// main
// ============================================================

int main() {
  GPUCSRGraph clauses;
  GPUCSRGraph vars;
  Edge ed;

  float *d_bias_list = NULL;
  int *d_bias_list_vars = NULL;
  int *d_bias_len = NULL;
  float *d_g_summag = NULL;

  initTinyGraphs(clauses, vars);
  allocTinyEdge(ed);

  checkCuda(cudaMalloc((void**)&d_bias_list, 3 * sizeof(float)), "malloc bias_list");
  checkCuda(cudaMalloc((void**)&d_bias_list_vars, 3 * sizeof(int)), "malloc bias_list_vars");
  checkCuda(cudaMalloc((void**)&d_bias_len, sizeof(int)), "malloc bias_len");
  checkCuda(cudaMalloc((void**)&d_g_summag, sizeof(float)), "malloc g_summag");

  checkCuda(cudaMemset(d_bias_len, 0, sizeof(int)), "memset bias_len");
  checkCuda(cudaMemset(d_g_summag, 0, sizeof(float)), "memset g_summag");

  // update_bias 内部写死 cub::BlockReduce<float, 384>
  // 所以 blockDim.x 必须是 384。
  dim3 block(384);
  dim3 grid(1);

  update_bias<<<grid, block>>>(clauses,
                               vars,
                               ed,
                               d_bias_list,
                               d_bias_list_vars,
                               d_bias_len,
                               d_g_summag);

  checkCuda(cudaGetLastError(), "update_bias launch failed");
  checkCuda(cudaDeviceSynchronize(), "update_bias execution failed");

  int h_bias_len = 0;
  float h_summag = 0.0f;

  checkCuda(cudaMemcpy(&h_bias_len, d_bias_len, sizeof(int), cudaMemcpyDeviceToHost),
            "copy bias_len");
  checkCuda(cudaMemcpy(&h_summag, d_g_summag, sizeof(float), cudaMemcpyDeviceToHost),
            "copy g_summag");

  float h_bias[2];
  bool h_value[2];

  checkCuda(cudaMemcpy(h_bias, vars.bias, 2 * sizeof(float), cudaMemcpyDeviceToHost),
            "copy vars.bias");
  checkCuda(cudaMemcpy(h_value, vars.value, 2 * sizeof(bool), cudaMemcpyDeviceToHost),
            "copy vars.value");

  printf("update_bias finished\n");
  printf("bias_len = %d\n", h_bias_len);
  printf("g_summag = %f\n", h_summag);
  printf("vars.bias[0]=%f vars.bias[1]=%f\n", h_bias[0], h_bias[1]);
  printf("vars.value[0]=%d vars.value[1]=%d\n", (int)h_value[0], (int)h_value[1]);

  if (h_bias_len > 0) {
    float h_bias_list[3];
    int h_bias_list_vars[3];

    checkCuda(cudaMemcpy(h_bias_list,
                         d_bias_list,
                         3 * sizeof(float),
                         cudaMemcpyDeviceToHost),
              "copy bias_list");

    checkCuda(cudaMemcpy(h_bias_list_vars,
                         d_bias_list_vars,
                         3 * sizeof(int),
                         cudaMemcpyDeviceToHost),
              "copy bias_list_vars");

    for (int i = 0; i < h_bias_len && i < 3; i++) {
      printf("bias_list[%d]=%f var=%d\n",
             i,
             h_bias_list[i],
             h_bias_list_vars[i]);
    }
  }

  cudaFree(d_bias_list);
  cudaFree(d_bias_list_vars);
  cudaFree(d_bias_len);
  cudaFree(d_g_summag);

  freeTinyEdge(ed);
  destroyTinyGraphs(clauses, vars);

  return 0;
}