// Auto-generated CUDA kernel file: ExecuteFirstLayer
// Extracted from: Tango-master/GPU/SqueezeNet/SN.cu
// Original line: 1141

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: ExecuteFirstLayer (line 1141)
__global__ void ExecuteFirstLayer(double *Layer1_Weights_CPU, int *Data_Layer_CPU_R, int *Data_Layer_CPU_G, int *Data_Layer_CPU_B, double *Layer1_Features) {

	int x = (threadIdx.x)*2 + 3;
	int y = (blockIdx.x)*2 + 3;
	//int f=0;
	for(int f=0; f<96; f++)
	{
				double result = 0;
				for(int i = x-3; i<=x+3; i++)
				{
    					for(int j=y-3; j<=y+3; j++)
    					{
						int x_index = i-x+3;
						int y_index = j-y+3;
						int m = (y_index)+(x_index)*7;
         					if(i<0 || j<0)
						{
							result+= 0;
							//printf("Error %d\n",m);						
						}
         					else if(j>226 || i>226)
						{
							result+= 0;
							//printf("Error %d\n",m);
						}
         					else
						{
							double temp = Data_Layer_CPU_R[(y_index-3) + x*227 + y + (x_index-3)*227]*Layer1_Weights_CPU[m+f*147] + Data_Layer_CPU_G[(y_index-3) + x*227 + y + (x_index-3)*227]*Layer1_Weights_CPU[m+49+f*147] + Data_Layer_CPU_B[(y_index-3) + x*227 + y + (x_index-3)*227]*Layer1_Weights_CPU[m+98+f*147];			
							result+= temp;
							//printf("%.8f %d	",temp, m);
						}
					}
				} 
				if(result < 0)
					result = 0;
				Layer1_Features[f*111*111+((x-3)/2)*111+((y-3)/2)] = result;
				//printf("%0.8f ",result);
	}
	//if(x==4 && y==4)
	//	printf("%.8f ",Layer1_Features[1]);

}

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    const int out_channels = 96;
    const int in_h = 227, in_w = 227;  // input image
    const int out_h = 111, out_w = 111;

    size_t r_size = (size_t)in_h * in_w;
    size_t g_size = r_size;
    size_t b_size = r_size;
    size_t weights_size = (size_t)out_channels * 7 * 7 * 3;  // 96 × 147
    size_t features_size = (size_t)out_channels * out_h * out_w;

    int *h_r = (int*)malloc(r_size * sizeof(int));
    int *h_g = (int*)malloc(g_size * sizeof(int));
    int *h_b = (int*)malloc(b_size * sizeof(int));
    double *h_weights = (double*)malloc(weights_size * sizeof(double));
    double *h_features = (double*)malloc(features_size * sizeof(double));

    if (!h_r || !h_g || !h_b || !h_weights || !h_features) return -1;

    for (size_t i = 0; i < r_size; ++i) {
        h_r[i] = (int)(i % 256);
        h_g[i] = (int)(i % 256);
        h_b[i] = (int)(i % 256);
    }
    for (size_t i = 0; i < weights_size; ++i) h_weights[i] = (double)(i % 13) * 0.01;

    int *d_r = nullptr, *d_g = nullptr, *d_b = nullptr;
    double *d_weights = nullptr, *d_features = nullptr;

    cudaMalloc(&d_r, r_size * sizeof(int));
    cudaMalloc(&d_g, g_size * sizeof(int));
    cudaMalloc(&d_b, b_size * sizeof(int));
    cudaMalloc(&d_weights, weights_size * sizeof(double));
    cudaMalloc(&d_features, features_size * sizeof(double));

    cudaMemcpy(d_r, h_r, r_size * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_g, h_g, g_size * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_b, h_b, b_size * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_weights, h_weights, weights_size * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemset(d_features, 0, features_size * sizeof(double));

    // kernel: x = threadIdx.x*2+3, y = blockIdx.x*2+3
    // so to cover x∈[3,226], y∈[3,226] (since 227 image), we need:
    // threadIdx.x ∈ [0,111], blockIdx.x ∈ [0,111] → block(112), grid(112)
    dim3 block(112);
    dim3 grid(112);

    ExecuteFirstLayer<<<grid, block>>>(d_weights, d_r, d_g, d_b, d_features);

    cudaDeviceSynchronize();
    if (cudaGetLastError() != cudaSuccess) {
        fprintf(stderr, "CUDA error in ExecuteFirstLayer.\n");
        return -1;
    }

    cudaMemcpy(h_features, d_features, features_size * sizeof(double), cudaMemcpyDeviceToHost);

    printf("ExecuteFirstLayer done. features[0] = %f\n", h_features[0]);

    cudaFree(d_r);
    cudaFree(d_g);
    cudaFree(d_b);
    cudaFree(d_weights);
    cudaFree(d_features);
    free(h_r);
    free(h_g);
    free(h_b);
    free(h_weights);
    free(h_features);
    return 0;
}