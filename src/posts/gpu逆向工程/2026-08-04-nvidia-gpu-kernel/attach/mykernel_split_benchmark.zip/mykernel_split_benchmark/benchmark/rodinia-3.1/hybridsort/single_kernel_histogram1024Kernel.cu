// Auto-generated CUDA kernel file: histogram1024Kernel
// Extracted from: rodinia-3.1/hybridsort/single_kernel_histogram1024Kernel.cu
// Original line: 34

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>

#ifndef HISTO_WG_SIZE_0
#define HISTO_WG_SIZE_0 256
#endif
// ===== Macro Definitions =====
#define BIN_COUNT 1024 // Changed from 256  // from line 42  // from line 8
#define HISTOGRAM_SIZE (BIN_COUNT * sizeof(unsigned int))  // from line 43  // from line 9
#define WARP_LOG_SIZE 5  // from line 47  // from line 10
#define WARP_LOG_SIZE 0  // from line 51  // from line 11
#define  WARP_N 3  // from line 54  // from line 12
#define THREAD_N HISTO_WG_SIZE_0  // from line 57  // from line 13
#define     THREAD_N (WARP_N << WARP_LOG_SIZE)  // from line 59  // from line 14
#define BLOCK_MEMORY (WARP_N * BIN_COUNT)  // from line 63  // from line 15
#define IMUL(a, b) __mul24(a, b)  // from line 64  // from line 16
#define BLOCK_N 64  // from line 118  // from line 17

// ===== Device Functions =====
// Function: addData1024 (line 21)
__device__ void addData1024(volatile unsigned int *s_WarpHist, unsigned int data, unsigned int threadTag) {


    unsigned int count;
    do{
        count = s_WarpHist[data] & 0x07FFFFFFU;  // [参数: s_WarpHist, data]  // [参数: s_WarpHist, data]
        count = threadTag | (count + 1);  // [参数: threadTag]  // [参数: threadTag]
        s_WarpHist[data] = count;  // [参数: s_WarpHist, data]  // [参数: s_WarpHist, data]
    }while(s_WarpHist[data] != count);  // [参数: s_WarpHist, data]  // [参数: s_WarpHist, data]


}

// ===== Kernel =====
// Kernel: histogram1024Kernel (line 34)
__global__ void histogram1024Kernel(unsigned int *d_Result, float *d_Data, float minimum, float maximum, int dataN) {



    //Current global thread index
    const int    globalTid = IMUL(blockIdx.x, blockDim.x) + threadIdx.x;
    //Total number of threads in the compute grid
    const int   numThreads = IMUL(blockDim.x, gridDim.x);
    //WARP_LOG_SIZE higher bits of counter values are tagged 
    //by lower WARP_LOG_SIZE threadID bits
	// Will correctly issue warning when compiling for debug (x<<32-0)
    const unsigned int threadTag = threadIdx.x << (32 - WARP_LOG_SIZE);
	//Shared memory cache for each warp in current thread block
    //Declare as volatile to prevent incorrect compiler optimizations in addPixel()
    volatile __shared__ unsigned int s_Hist[BLOCK_MEMORY];
    //Current warp shared memory frame
    const int warpBase = IMUL(threadIdx.x >> WARP_LOG_SIZE, BIN_COUNT);
    
    //Clear shared memory buffer for current thread block before processing
    for(int pos = threadIdx.x; pos < BLOCK_MEMORY; pos += blockDim.x)
       s_Hist[pos] = 0;

    __syncthreads();
    //Cycle through the entire data set, update subhistograms for each warp
    //Since threads in warps always execute the same instruction,
    //we are safe with the addPixel trick
    for(int pos = globalTid; pos < dataN; pos += numThreads){  // [参数: dataN]  // [参数: dataN]
        unsigned int data4 = ((d_Data[pos] - minimum)/(maximum - minimum)) * BIN_COUNT;  // [参数: d_Data, minimum, maximum]  // [参数: d_Data, minimum, maximum]
		addData1024(s_Hist + warpBase, data4 & 0x3FFU, threadTag);
    }

    __syncthreads();
    //Merge per-warp histograms into per-block and write to global memory
    for(int pos = threadIdx.x; pos < BIN_COUNT; pos += blockDim.x){
        unsigned int sum = 0;

        for(int base = 0; base < BLOCK_MEMORY; base += BIN_COUNT)
            sum += s_Hist[base + pos] & 0x07FFFFFFU;
         atomicAdd(d_Result + pos, sum);  // [参数: d_Result]  // [参数: d_Result]
    }


}

int main() {
    int dataN = 4096;
    float minimum = 0.0f;
    float maximum = 1.0f;

    // Host data
    float *h_data = (float *)malloc(dataN * sizeof(float));
    unsigned int *h_result = (unsigned int *)calloc(BIN_COUNT, sizeof(unsigned int));
    for (int i = 0; i < dataN; i++) {
        h_data[i] = (float)(rand() % 1000) / 1000.0f;
    }

    // Device allocations
    float *d_data;
    unsigned int *d_result;
    cudaMalloc(&d_data, dataN * sizeof(float));
    cudaMalloc(&d_result, BIN_COUNT * sizeof(unsigned int));
    cudaMemcpy(d_data, h_data, dataN * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemset(d_result, 0, BIN_COUNT * sizeof(unsigned int));

    // Launch kernel
    int threadsPerBlock = THREAD_N;
    int numBlocks = 64;
    histogram1024Kernel<<<numBlocks, threadsPerBlock>>>(d_result, d_data, minimum, maximum, dataN);
    cudaDeviceSynchronize();

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("CUDA error: %s\n", cudaGetErrorString(err));
    } else {
        printf("histogram1024Kernel executed successfully.\n");
    }

    cudaMemcpy(h_result, d_result, BIN_COUNT * sizeof(unsigned int), cudaMemcpyDeviceToHost);

    // Verify: sum should equal dataN
    unsigned int total = 0;
    for (int i = 0; i < BIN_COUNT; i++) total += h_result[i];
    printf("Total count across all bins: %u (expected: %d)\n", total, dataN);

    // Cleanup
    cudaFree(d_data);
    cudaFree(d_result);
    free(h_data);
    free(h_result);
    return 0;
}