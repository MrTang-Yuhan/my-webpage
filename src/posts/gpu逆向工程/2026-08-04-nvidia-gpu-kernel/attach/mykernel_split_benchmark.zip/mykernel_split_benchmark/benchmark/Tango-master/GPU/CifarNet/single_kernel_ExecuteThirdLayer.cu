// Auto-generated CUDA kernel file: ExecuteThirdLayer
// Extracted from: Tango-master/GPU/CifarNet/CN_cuda.cu
// Original line: 384

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: ExecuteThirdLayer (line 384)
__global__ void ExecuteThirdLayer(double *Layer3_Weights_CPU, double *Layer3_Features, double *Layer3_pool_GPU) {

	double Features = 0;
	int x = threadIdx.x;
	int y = threadIdx.y;
	for(int f=0; f<64; f++)
	{
		Features = 0;
		for(int n=0; n<32; n++)
		{
			if(x<8)
			{
				if(y<8)
				{
					double result = 0;
					for(int i = x-2; i<=x+2; i++)
					{
    						for(int j=y-2; j<=y+2; j++)
    						{
							int x_index = i-x+2;
							int y_index = j-y+2;
							int m = (y_index)+(x_index)*5;
         						if(i<0 || j<0)
							{
								result+=0;
							}
         						else if(j>7 || i>7)
							{
								result+=0;
							}
         						else
							{
               							result+= Layer3_pool_GPU[n*8*8 + (x_index+x-2)*8 + (y_index+y-2)]*Layer3_Weights_CPU[m+f*25*32+n*25];			
							}
						}
					} 
					Features += result;
				}
			}
		}
		//ReLU activation function computation
		if(Features<0)
			Features = 0;
		Layer3_Features[f*8*8 + x*8 + y] = Features;
	}

}


int main() {
    const int IN_C = 32, OUT_C = 64;
    const int H = 8, W = 8, K = 5;

    size_t weight_size = OUT_C * IN_C * K * K;   // 64*32*25
    size_t input_size  = IN_C * H * W;           // 32*8*8
    size_t output_size = OUT_C * H * W;          // 64*8*8

    double *h_weight = (double*)malloc(weight_size * sizeof(double));
    double *h_in = (double*)malloc(input_size * sizeof(double));
    double *h_out = (double*)malloc(output_size * sizeof(double));

    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (double)(i % 19) * 0.01;
    for (size_t i = 0; i < input_size;  ++i) h_in[i] = (double)(i % 23) * 0.05;

    double *d_weight = NULL, *d_in = NULL, *d_out = NULL;

    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_in, input_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_out, output_size * sizeof(double)));

    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(double), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_in, h_in, input_size * sizeof(double), cudaMemcpyHostToDevice));

    dim3 grid(1);
    dim3 block(8, 8);

    ExecuteThirdLayer<<<grid, block>>>(d_weight, d_out, d_in);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, output_size * sizeof(double), cudaMemcpyDeviceToHost));

    printf("ExecuteThirdLayer done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_weight);
    cudaFree(d_in);
    cudaFree(d_out);

    free(h_weight);
    free(h_in);
    free(h_out);

    return 0;
}