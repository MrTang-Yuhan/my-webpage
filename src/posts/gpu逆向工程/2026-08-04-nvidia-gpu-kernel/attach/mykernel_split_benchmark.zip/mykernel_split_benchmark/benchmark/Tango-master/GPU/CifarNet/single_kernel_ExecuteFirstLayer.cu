// Auto-generated CUDA kernel file: ExecuteFirstLayer
// Extracted from: Tango-master/GPU/CifarNet/CN_cuda.cu
// Original line: 299

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: ExecuteFirstLayer (line 299)
__global__ void ExecuteFirstLayer(double *Layer1_Weights_CPU, int *Data_Layer_CPU_R, int *Data_Layer_CPU_G, int *Data_Layer_CPU_B, double *Layer1_Features) {

	int x = threadIdx.x;
	int y = threadIdx.y;
	for(int f=0; f<32; f++)
	{
				double result = 0;
				for(int i = x-2; i<=x+2; i++)
				{
    					for(int j=y-2; j<=y+2; j++)
    					{
						int x_index = i-x+2;
						int y_index = j-y+2;
						int m = (y_index)+(x_index)*5;
         					if(i<0 || j<0)
						{
							result+= 0;						
						}
         					else if(j>31 || i>31)
						{
							result+= 0;
						}
         					else
						{
							result += Data_Layer_CPU_R[(y_index-2) + x*32 + y + (x_index-2)*32]*Layer1_Weights_CPU[m+f*75] + Data_Layer_CPU_G[(y_index-2) + x*32 + y + (x_index-2)*32]*Layer1_Weights_CPU[m+25+f*75] + Data_Layer_CPU_B[(y_index-2) + x*32 + y + (x_index-2)*32]*Layer1_Weights_CPU[m+50+f*75];			
						}
					}
				} 
				Layer1_Features[f*32*32+x*32+y] = result;
	}

}


int main() {
    const int H = 32, W = 32, C = 3;
    const int OUT_C = 32;
    const int K = 5;

    size_t weight_size = OUT_C * C * K * K;   // 32 * 3 * 25 = 2400
    size_t input_size  = H * W;
    size_t output_size = OUT_C * H * W;

    double *h_weight = (double*)malloc(weight_size * sizeof(double));
    int *h_R = (int*)malloc(input_size * sizeof(int));
    int *h_G = (int*)malloc(input_size * sizeof(int));
    int *h_B = (int*)malloc(input_size * sizeof(int));
    double *h_out = (double*)malloc(output_size * sizeof(double));

    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (double)(i % 11) * 0.01;
    for (size_t i = 0; i < input_size;  ++i) {
        h_R[i] = i % 256;
        h_G[i] = (i * 2) % 256;
        h_B[i] = (i * 3) % 256;
    }

    double *d_weight = NULL, *d_out = NULL;
    int *d_R = NULL, *d_G = NULL, *d_B = NULL;

    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_out, output_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_R, input_size * sizeof(int)));
    CHECK(cudaMalloc((void**)&d_G, input_size * sizeof(int)));
    CHECK(cudaMalloc((void**)&d_B, input_size * sizeof(int)));

    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(double), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_R, h_R, input_size * sizeof(int), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_G, h_G, input_size * sizeof(int), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_B, h_B, input_size * sizeof(int), cudaMemcpyHostToDevice));

    dim3 grid(1);
    dim3 block(32, 32);

    ExecuteFirstLayer<<<grid, block>>>(d_weight, d_R, d_G, d_B, d_out);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, output_size * sizeof(double), cudaMemcpyDeviceToHost));

    printf("ExecuteFirstLayer done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_weight);
    cudaFree(d_out);
    cudaFree(d_R);
    cudaFree(d_G);
    cudaFree(d_B);

    free(h_weight);
    free(h_R);
    free(h_G);
    free(h_B);
    free(h_out);

    return 0;
}