// Auto-generated CUDA kernel file: pooling2
// Extracted from: Tango-master/GPU/CifarNet/CN_cuda.cu
// Original line: 511

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: pooling2 (line 511)
__global__ void pooling2(double *Layer2_Neurons_GPU,double *Layer2_pool_GPU,int out,int out_fr,int out_fc,int kernel,int stride_width,int in_fr,int in_fc) {

    double avg = 0.0;
    int count = 0;
    int row = threadIdx.x;
    int col = threadIdx.y;
    {
        for(int output =0;output < out ;output++)
        {
            if((row%2 != 0) && (row<16))
            { 
                if((col%2 != 0) && (col<16))
                {
                    for(int i = row-1; i <= row+1; i++)
                    {   
			if(i>15) break;        
                        for(int j = col-1; j <= col+1; j++)
                        {
			    if(j>15) break;
                            avg+= Layer2_Neurons_GPU[output*16*16 + i*16 + j];
			    count = count + 1;

                        }
                    }
                    Layer2_pool_GPU[output*8*8+(row-1)*4+(col-1)/2] = avg/count;    
                    avg = 0.0;   
		    count=0;
                }
            }
        }
    }

}

int main() {
    const int out = 32;
    const int in_fr = 16, in_fc = 16;
    const int out_fr = 8, out_fc = 8;
    const int kernel = 3;
    const int stride_width = 2;

    size_t in_size  = (size_t)out * in_fr * in_fc;
    size_t out_size = (size_t)out * out_fr * out_fc;

    double *h_in  = (double*)malloc(in_size * sizeof(double));
    double *h_out = (double*)malloc(out_size * sizeof(double));

    if (!h_in || !h_out) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < in_size; ++i) {
        h_in[i] = (double)(i % 19) * 0.05;
    }

    double *d_in = NULL, *d_out = NULL;
    CHECK(cudaMalloc((void**)&d_in,  in_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_out, out_size * sizeof(double)));

    CHECK(cudaMemcpy(d_in, h_in, in_size * sizeof(double), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_out, 0, out_size * sizeof(double)));

    dim3 grid(1);
    dim3 block(16, 16);

    pooling2<<<grid, block>>>(d_in, d_out, out, out_fr, out_fc, kernel, stride_width, in_fr, in_fc);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(double), cudaMemcpyDeviceToHost));

    printf("pooling2 done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);

    return 0;
}