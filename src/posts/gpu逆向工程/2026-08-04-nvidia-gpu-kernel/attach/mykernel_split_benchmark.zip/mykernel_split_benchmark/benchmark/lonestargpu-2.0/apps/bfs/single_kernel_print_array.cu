// Auto-generated CUDA kernel file: print_array
// Standalone runnable version

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
__global__ void print_array(int *a, int n) {
    int id = threadIdx.x + blockDim.x * blockIdx.x;
    if (id < n)
        printf("%d %d\n", id, a[id]);
}

int main(int argc, char **argv) {
    int n = 16;
    if (argc >= 2) n = atoi(argv[1]);

    if (n <= 0) {
        fprintf(stderr, "n must be > 0\n");
        return -1;
    }

    int *h_a = (int *)malloc(sizeof(int) * n);
    int *d_a = NULL;

    if (!h_a) {
        fprintf(stderr, "malloc h_a failed\n");
        return -1;
    }

    for (int i = 0; i < n; i++) {
        h_a[i] = i * 10;
    }

    cudaError_t err = cudaMalloc((void **)&d_a, sizeof(int) * n);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_a failed: %s\n", cudaGetErrorString(err));
        free(h_a);
        return -1;
    }

    err = cudaMemcpy(d_a, h_a, sizeof(int) * n, cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMemcpy H2D failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        free(h_a);
        return -1;
    }

    int block = 256;
    int grid = (n + block - 1) / block;

    print_array<<<grid, block>>>(d_a, n);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        free(h_a);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_a);
        free(h_a);
        return -1;
    }

    cudaFree(d_a);
    free(h_a);
    return 0;
}