// Auto-generated CUDA kernel file: execute3DconvolutionCuda
// Extracted from: Tango-master/GPU/AlexNet/an_kernel.cu
// Original line: 106

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: execute3DconvolutionCuda (line 106)
__global__ void execute3DconvolutionCuda(float *bias,float *Layer2_Neurons_GPU, float *Layer2_Weights_GPU,float *Layer3_Neurons_GPU,int out,int fr,int fc,int stride_width,int kernel,int pad,int in_output,int group) {

    float product = 0.0;
    int x_pad = 0, y_pad = 0, loopc = 0,loopr = 0;
    int stride = 0,colstride = 0;
    int output = blockIdx.x; // 128
    colstride = 0;
    int row = threadIdx.x;
    stride = 0;
    if(row > pad)
       colstride = (row - pad) * fr;
    int col = threadIdx.y;
    if(col >= pad)
        stride = col * stride_width;
    x_pad = 0; y_pad = 0;
    /* set the loops value */
    loopc = kernel;loopr = kernel;
    /* take care of padding in left hand side of image*/
    if( row < pad)
    {
        x_pad = pad - row;
        loopr = kernel - x_pad;
    }
    /* take care of padding in upper side of image*/
    if( col < pad )
    {
        y_pad = pad - col;
        loopc = kernel - y_pad;
    }
    /* take care of padding in right side of image*/
    if(col >= fc - pad)
        loopc =  fc + pad - col;
    /* take care of padding in bottom of image */
    if(row >= fr - pad)
        loopr =  fr + pad - row;
    for(int feature =0; feature < in_output ; feature++) // calculate the feature maps
    {
        for(int i =0; i < loopr ; i++) // kernel convolution
        {
            for(int j =0; j < loopc ; j++) // kernel convolution
            {
                product += ( Layer2_Neurons_GPU[feature*fr*fc + i*fc + j + stride + colstride] * Layer2_Weights_GPU[output*kernel*kernel*in_output + feature*kernel*kernel + i*kernel + j + kernel*x_pad + y_pad]);
            }
        }
    }
    product += bias[output];
    if(product < 0) /* ReLU Layer */
        product = 0;
    Layer3_Neurons_GPU[output*fr*fc + row*fc + col] = product;
    product = 0.0;
    if(col >= pad)
        stride+=stride_width;

}

int main() {
    const int out = 128;
    const int fr = 27, fc = 27;
    const int stride_width = 1;
    const int kernel = 5;
    const int pad = 2;
    const int in_output = 48;
    const int group = 1;

    size_t bias_size   = out;
    size_t in_size     = in_output * fr * fc;
    size_t weight_size = out * kernel * kernel * in_output;
    size_t out_size    = out * fr * fc;

    float *h_bias   = (float*)malloc(bias_size * sizeof(float));
    float *h_in     = (float*)malloc(in_size * sizeof(float));
    float *h_weight = (float*)malloc(weight_size * sizeof(float));
    float *h_out    = (float*)malloc(out_size * sizeof(float));

    for (size_t i = 0; i < bias_size;   ++i) h_bias[i]   = 0.1f;
    for (size_t i = 0; i < in_size;     ++i) h_in[i]     = (float)(i % 11) * 0.01f;
    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (float)(i % 5) * 0.02f;

    float *d_bias, *d_in, *d_weight, *d_out;
    CHECK(cudaMalloc((void**)&d_bias,   bias_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_in,     in_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out,    out_size * sizeof(float)));

    CHECK(cudaMemcpy(d_bias,   h_bias,   bias_size * sizeof(float),   cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_in,     h_in,     in_size * sizeof(float),     cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block(fr, fc);   // 27x27 = 729 threads

    execute3DconvolutionCuda<<<grid, block>>>(
        d_bias, d_in, d_weight, d_out,
        out, fr, fc, stride_width, kernel, pad, in_output, group
    );
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("execute3DconvolutionCuda done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("conv_out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_bias);
    cudaFree(d_in);
    cudaFree(d_weight);
    cudaFree(d_out);
    free(h_bias);
    free(h_in);
    free(h_weight);
    free(h_out);
    return 0;
}