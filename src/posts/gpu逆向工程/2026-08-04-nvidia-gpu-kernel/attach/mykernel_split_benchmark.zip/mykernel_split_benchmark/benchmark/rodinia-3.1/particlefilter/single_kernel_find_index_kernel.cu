// Auto-generated CUDA kernel file: find_index_kernel
// Extracted from: rodinia-3.1/particlefilter/single_kernel_find_index_kernel.cu
// Original line: 18

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>
#include <float.h>
#include <sys/time.h>

// ===== Kernel =====
// Kernel: find_index_kernel (line 18)
__global__ void find_index_kernel(double * arrayX, double * arrayY, double * CDF, double * u, double * xj, double * yj, double * weights, int Nparticles) {


    int block_id = blockIdx.x;
    int i = blockDim.x * block_id + threadIdx.x;

    if (i < Nparticles) {

        int index = -1;
        int x;

        for (x = 0; x < Nparticles; x++) {
            if (CDF[x] >= u[i]) {
                index = x;
                break;
            }
        }
        if (index == -1) {
            index = Nparticles - 1;
        }

        xj[i] = arrayX[index];
        yj[i] = arrayY[index];

        //weights[i] = 1 / ((double) (Nparticles)); //moved this code to the beginning of likelihood kernel

    }
    __syncthreads();


}


#include <cuda_runtime.h>

static void checkCuda(cudaError_t err, const char* msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "CUDA error at %s: %s\n", msg, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

int main() {
    const int Nparticles = 1024;
    const int threads = 256;
    const int blocks = (Nparticles + threads - 1) / threads;

    double *h_arrayX = (double*)malloc(sizeof(double) * Nparticles);
    double *h_arrayY = (double*)malloc(sizeof(double) * Nparticles);
    double *h_CDF = (double*)malloc(sizeof(double) * Nparticles);
    double *h_u = (double*)malloc(sizeof(double) * Nparticles);
    double *h_xj = (double*)malloc(sizeof(double) * Nparticles);
    double *h_yj = (double*)malloc(sizeof(double) * Nparticles);
    double *h_weights = (double*)malloc(sizeof(double) * Nparticles);

    for (int i = 0; i < Nparticles; i++) {
        h_arrayX[i] = i * 1.0;
        h_arrayY[i] = i * 2.0;
        h_CDF[i] = (double)(i + 1) / Nparticles;
        h_u[i] = ((double)i + 0.5) / Nparticles;
        h_xj[i] = 0.0;
        h_yj[i] = 0.0;
        h_weights[i] = 1.0 / Nparticles;
    }

    double *d_arrayX, *d_arrayY, *d_CDF, *d_u, *d_xj, *d_yj, *d_weights;
    checkCuda(cudaMalloc((void**)&d_arrayX, sizeof(double) * Nparticles), "cudaMalloc d_arrayX");
    checkCuda(cudaMalloc((void**)&d_arrayY, sizeof(double) * Nparticles), "cudaMalloc d_arrayY");
    checkCuda(cudaMalloc((void**)&d_CDF, sizeof(double) * Nparticles), "cudaMalloc d_CDF");
    checkCuda(cudaMalloc((void**)&d_u, sizeof(double) * Nparticles), "cudaMalloc d_u");
    checkCuda(cudaMalloc((void**)&d_xj, sizeof(double) * Nparticles), "cudaMalloc d_xj");
    checkCuda(cudaMalloc((void**)&d_yj, sizeof(double) * Nparticles), "cudaMalloc d_yj");
    checkCuda(cudaMalloc((void**)&d_weights, sizeof(double) * Nparticles), "cudaMalloc d_weights");

    checkCuda(cudaMemcpy(d_arrayX, h_arrayX, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "copy arrayX");
    checkCuda(cudaMemcpy(d_arrayY, h_arrayY, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "copy arrayY");
    checkCuda(cudaMemcpy(d_CDF, h_CDF, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "copy CDF");
    checkCuda(cudaMemcpy(d_u, h_u, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "copy u");
    checkCuda(cudaMemcpy(d_weights, h_weights, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "copy weights");

    find_index_kernel<<<blocks, threads>>>(d_arrayX, d_arrayY, d_CDF, d_u, d_xj, d_yj, d_weights, Nparticles);

    checkCuda(cudaGetLastError(), "launch find_index_kernel");
    checkCuda(cudaDeviceSynchronize(), "sync find_index_kernel");

    checkCuda(cudaMemcpy(h_xj, d_xj, sizeof(double) * Nparticles, cudaMemcpyDeviceToHost), "copy xj");
    checkCuda(cudaMemcpy(h_yj, d_yj, sizeof(double) * Nparticles, cudaMemcpyDeviceToHost), "copy yj");

    printf("find_index_kernel finished.\n");
    printf("xj[0]=%f yj[0]=%f\n", h_xj[0], h_yj[0]);

    cudaFree(d_arrayX); cudaFree(d_arrayY); cudaFree(d_CDF);
    cudaFree(d_u); cudaFree(d_xj); cudaFree(d_yj); cudaFree(d_weights);

    free(h_arrayX); free(h_arrayY); free(h_CDF); free(h_u);
    free(h_xj); free(h_yj); free(h_weights);

    return 0;
}