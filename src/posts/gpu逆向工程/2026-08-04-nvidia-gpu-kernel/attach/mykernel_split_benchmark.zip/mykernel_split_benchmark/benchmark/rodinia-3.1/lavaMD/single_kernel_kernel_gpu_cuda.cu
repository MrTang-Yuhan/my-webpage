// Auto-generated CUDA kernel file: kernel_gpu_cuda
// Extracted from: rodinia-3.1/lavaMD/kernel/single_kernel_kernel_gpu_cuda.cu
// Original line: 9

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cuda_runtime.h>

// ===== Type Definitions =====
#define fp double
#define NUMBER_PAR_PER_BOX 100
#define NUMBER_THREADS 128
#define DOT(A,B) ((A.x)*(B.x)+(A.y)*(B.y)+(A.z)*(B.z))

typedef struct { fp x, y, z; } THREE_VECTOR;
typedef struct { fp v, x, y, z; } FOUR_VECTOR;

typedef struct nei_str {
    int x, y, z;
    int number;
    long offset;
} nei_str;

typedef struct box_str {
    int x, y, z;
    int number;
    long offset;
    int nn;
    nei_str nei[26];
} box_str;

typedef struct { fp alpha; } par_str;

typedef struct {
    int cur_arg, arch_arg, cores_arg, boxes1d_arg;
    long number_boxes;
    long box_mem;
    long space_elem;
    long space_mem;
    long space_mem2;
} dim_str;

// ===== Kernel =====
__global__ void kernel_gpu_cuda(par_str d_par_gpu,
                                dim_str d_dim_gpu,
                                box_str* d_box_gpu,
                                FOUR_VECTOR* d_rv_gpu,
                                fp* d_qv_gpu,
                                FOUR_VECTOR* d_fv_gpu) {

    int bx = blockIdx.x;
    int tx = threadIdx.x;
    int wtx = tx;

    if(bx < d_dim_gpu.number_boxes) {

        fp a2 = 2.0*d_par_gpu.alpha*d_par_gpu.alpha;

        int first_i;
        FOUR_VECTOR* rA;
        FOUR_VECTOR* fA;
        __shared__ FOUR_VECTOR rA_shared[100];

        int pointer;
        int k = 0;
        int first_j;
        FOUR_VECTOR* rB;
        fp* qB;
        int j = 0;
        __shared__ FOUR_VECTOR rB_shared[100];
        __shared__ double qB_shared[100];

        fp r2, u2, vij, fs, fxij, fyij, fzij;
        THREE_VECTOR d;

        first_i = d_box_gpu[bx].offset;
        rA = &d_rv_gpu[first_i];
        fA = &d_fv_gpu[first_i];

        while(wtx < NUMBER_PAR_PER_BOX) {
            rA_shared[wtx] = rA[wtx];
            wtx = wtx + NUMBER_THREADS;
        }
        wtx = tx;
        __syncthreads();

        for (k = 0; k < (1 + d_box_gpu[bx].nn); k++) {

            if(k == 0) {
                pointer = bx;
            } else {
                pointer = d_box_gpu[bx].nei[k-1].number;
            }

            first_j = d_box_gpu[pointer].offset;
            rB = &d_rv_gpu[first_j];
            qB = &d_qv_gpu[first_j];

            while(wtx < NUMBER_PAR_PER_BOX) {
                rB_shared[wtx] = rB[wtx];
                qB_shared[wtx] = qB[wtx];
                wtx = wtx + NUMBER_THREADS;
            }
            wtx = tx;
            __syncthreads();

            while(wtx < NUMBER_PAR_PER_BOX) {
                for (j = 0; j < NUMBER_PAR_PER_BOX; j++) {
                    r2 = (fp)rA_shared[wtx].v + (fp)rB_shared[j].v
                         - DOT((fp)rA_shared[wtx], (fp)rB_shared[j]);
                    u2 = a2 * r2;
                    vij = exp(-u2);
                    fs = 2 * vij;

                    d.x = (fp)rA_shared[wtx].x - (fp)rB_shared[j].x;
                    fxij = fs * d.x;
                    d.y = (fp)rA_shared[wtx].y - (fp)rB_shared[j].y;
                    fyij = fs * d.y;
                    d.z = (fp)rA_shared[wtx].z - (fp)rB_shared[j].z;
                    fzij = fs * d.z;

                    fA[wtx].v += (double)((fp)qB_shared[j] * vij);
                    fA[wtx].x += (double)((fp)qB_shared[j] * fxij);
                    fA[wtx].y += (double)((fp)qB_shared[j] * fyij);
                    fA[wtx].z += (double)((fp)qB_shared[j] * fzij);
                }
                wtx = wtx + NUMBER_THREADS;
            }
            wtx = tx;
            __syncthreads();
        }
    }
}

// ===== Helper =====
static void checkCuda(cudaError_t err, const char* msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "CUDA Error [%s]: %s\n", msg, cudaGetErrorString(err));
        exit(1);
    }
}

// ===== Main =====
int main(int argc, char* argv[]) {

    int boxes1d = (argc > 1) ? atoi(argv[1]) : 2;

    par_str par_cpu;
    par_cpu.alpha = 0.5;

    dim_str dim_cpu;
    dim_cpu.boxes1d_arg  = boxes1d;
    dim_cpu.number_boxes = (long)boxes1d * boxes1d * boxes1d;
    dim_cpu.space_elem   = dim_cpu.number_boxes * NUMBER_PAR_PER_BOX;
    dim_cpu.space_mem    = dim_cpu.space_elem * sizeof(FOUR_VECTOR);
    dim_cpu.space_mem2   = dim_cpu.space_elem * sizeof(fp);
    dim_cpu.box_mem      = dim_cpu.number_boxes * sizeof(box_str);

    printf("Configuration: boxes1d=%d, total_boxes=%ld, particles=%ld\n",
           boxes1d, dim_cpu.number_boxes, dim_cpu.space_elem);

    box_str*     box_cpu = (box_str*)    malloc(dim_cpu.box_mem);
    FOUR_VECTOR* rv_cpu  = (FOUR_VECTOR*)malloc(dim_cpu.space_mem);
    fp*          qv_cpu  = (fp*)         malloc(dim_cpu.space_mem2);
    FOUR_VECTOR* fv_cpu  = (FOUR_VECTOR*)malloc(dim_cpu.space_mem);

    // Initialize box structure with neighbors
    for (int i = 0; i < boxes1d; i++) {
        for (int j = 0; j < boxes1d; j++) {
            for (int k = 0; k < boxes1d; k++) {
                int idx = i * boxes1d * boxes1d + j * boxes1d + k;
                box_cpu[idx].x      = i;
                box_cpu[idx].y      = j;
                box_cpu[idx].z      = k;
                box_cpu[idx].number = idx;
                box_cpu[idx].offset = (long)idx * NUMBER_PAR_PER_BOX;
                box_cpu[idx].nn     = 0;

                // Find 26 neighbors
                for (int di = -1; di <= 1; di++) {
                    for (int dj = -1; dj <= 1; dj++) {
                        for (int dk = -1; dk <= 1; dk++) {
                            if (di == 0 && dj == 0 && dk == 0) continue;
                            int ni = i + di, nj = j + dj, nk = k + dk;
                            if (ni < 0 || ni >= boxes1d) continue;
                            if (nj < 0 || nj >= boxes1d) continue;
                            if (nk < 0 || nk >= boxes1d) continue;
                            int nidx = ni * boxes1d * boxes1d + nj * boxes1d + nk;
                            int nn = box_cpu[idx].nn;
                            box_cpu[idx].nei[nn].x      = ni;
                            box_cpu[idx].nei[nn].y      = nj;
                            box_cpu[idx].nei[nn].z      = nk;
                            box_cpu[idx].nei[nn].number = nidx;
                            box_cpu[idx].nei[nn].offset = (long)nidx * NUMBER_PAR_PER_BOX;
                            box_cpu[idx].nn++;
                        }
                    }
                }
            }
        }
    }

    // Initialize particle data
    srand(123);
    for (long i = 0; i < dim_cpu.space_elem; i++) {
        rv_cpu[i].v = (fp)(rand() % 10 + 1);
        rv_cpu[i].x = (fp)(rand() % 100) / 10.0;
        rv_cpu[i].y = (fp)(rand() % 100) / 10.0;
        rv_cpu[i].z = (fp)(rand() % 100) / 10.0;
        qv_cpu[i]   = (fp)(rand() % 10 + 1) / 10.0;
        fv_cpu[i].v = fv_cpu[i].x = fv_cpu[i].y = fv_cpu[i].z = 0.0;
    }

    // Allocate GPU memory
    box_str*     d_box_gpu;
    FOUR_VECTOR* d_rv_gpu;
    fp*          d_qv_gpu;
    FOUR_VECTOR* d_fv_gpu;

    checkCuda(cudaMalloc(&d_box_gpu, dim_cpu.box_mem),    "malloc box");
    checkCuda(cudaMalloc(&d_rv_gpu,  dim_cpu.space_mem),  "malloc rv");
    checkCuda(cudaMalloc(&d_qv_gpu,  dim_cpu.space_mem2), "malloc qv");
    checkCuda(cudaMalloc(&d_fv_gpu,  dim_cpu.space_mem),  "malloc fv");

    checkCuda(cudaMemcpy(d_box_gpu, box_cpu, dim_cpu.box_mem,    cudaMemcpyHostToDevice), "copy box");
    checkCuda(cudaMemcpy(d_rv_gpu,  rv_cpu,  dim_cpu.space_mem,  cudaMemcpyHostToDevice), "copy rv");
    checkCuda(cudaMemcpy(d_qv_gpu,  qv_cpu,  dim_cpu.space_mem2, cudaMemcpyHostToDevice), "copy qv");
    checkCuda(cudaMemcpy(d_fv_gpu,  fv_cpu,  dim_cpu.space_mem,  cudaMemcpyHostToDevice), "copy fv");

    // Launch kernel
    dim3 threads(NUMBER_THREADS, 1);
    dim3 blocks(dim_cpu.number_boxes, 1);

    printf("Launching kernel with %ld blocks, %d threads/block\n", 
           dim_cpu.number_boxes, NUMBER_THREADS);

    kernel_gpu_cuda<<<blocks, threads>>>(par_cpu, dim_cpu,
                                         d_box_gpu, d_rv_gpu,
                                         d_qv_gpu,  d_fv_gpu);

    checkCuda(cudaDeviceSynchronize(), "kernel execution");

    // Copy results back
    checkCuda(cudaMemcpy(fv_cpu, d_fv_gpu, dim_cpu.space_mem, cudaMemcpyDeviceToHost), "copy fv back");

    printf("\nKernel executed successfully!\n");
    printf("Sample results (first 5 particles):\n");
    for (int i = 0; i < 5 && i < dim_cpu.space_elem; i++) {
        printf("  particle[%d]: v=%.6f x=%.6f y=%.6f z=%.6f\n",
               i, fv_cpu[i].v, fv_cpu[i].x, fv_cpu[i].y, fv_cpu[i].z);
    }

    // Cleanup
    cudaFree(d_box_gpu);
    cudaFree(d_rv_gpu);
    cudaFree(d_qv_gpu);
    cudaFree(d_fv_gpu);
    free(box_cpu);
    free(rv_cpu);
    free(qv_cpu);
    free(fv_cpu);

    return 0;
}