// Auto-generated CUDA kernel file: bucketsort
// Extracted from: rodinia-3.1/hybridsort/bucketsort_kernel.cu
// Original line: 82

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>

#ifndef DIVISIONS
#define DIVISIONS 1024
#endif
#ifndef LOG_DIVISIONS
#define LOG_DIVISIONS 10
#endif
#ifndef BUCKET_WG_SIZE_1
#define BUCKET_WG_SIZE_1 256
#endif
// ===== Macro Definitions =====
#define _BUCKETSORT_KERNEL_H_  // from line 2
#define BUCKET_WARP_LOG_SIZE	5  // from line 6
#define BUCKET_WARP_N			1  // from line 7
#define BUCKET_THREAD_N BUCKET_WG_SIZE_1  // from line 9
#define BUCKET_THREAD_N			(BUCKET_WARP_N << BUCKET_WARP_LOG_SIZE)  // from line 11
#define BUCKET_BLOCK_MEMORY		(DIVISIONS * BUCKET_WARP_N)  // from line 13
#define BUCKET_BAND				128  // from line 14

// ===== Kernel =====
// Kernel: bucketsort (line 82)
__global__ void
bucketsort(float *input, int *indice, float *output, int size, unsigned int *d_prefixoffsets, 
		   unsigned int *l_offsets) {

	volatile __shared__ unsigned int s_offset[BUCKET_BLOCK_MEMORY]; 

	int prefixBase = blockIdx.x * BUCKET_BLOCK_MEMORY; 
    const int warpBase = (threadIdx.x >> BUCKET_WARP_LOG_SIZE) * DIVISIONS; 
    const int numThreads = blockDim.x * gridDim.x;
	for (int i = threadIdx.x; i < BUCKET_BLOCK_MEMORY; i += blockDim.x)
		s_offset[i] = l_offsets[i & (DIVISIONS - 1)] + d_prefixoffsets[prefixBase + i];   // [参数: d_prefixoffsets, l_offsets]

	__syncthreads(); 

	for (int tid = blockIdx.x * blockDim.x + threadIdx.x; tid < size; tid += numThreads) {  // [参数: size]

		float elem = input[tid];   // [参数: input]
		int id = indice[tid];   // [参数: indice]

		output[s_offset[warpBase + (id & (DIVISIONS - 1))] + (id >> LOG_DIVISIONS)] = elem;  // [参数: output]
		int test = s_offset[warpBase + (id & (DIVISIONS - 1))] + (id >> LOG_DIVISIONS);

	}

}

int main() {
    int size = 1024;
    int blocks = 4;
    int threadsPerBlock = BUCKET_THREAD_N;

    // Host allocations
    float *h_input = (float *)malloc(size * sizeof(float));
    int *h_indice = (int *)malloc(size * sizeof(int));
    float *h_output = (float *)malloc(size * sizeof(float));
    unsigned int *h_prefixoffsets = (unsigned int *)calloc(blocks * BUCKET_BLOCK_MEMORY, sizeof(unsigned int));
    unsigned int *h_offsets = (unsigned int *)calloc(DIVISIONS, sizeof(unsigned int));

    for (int i = 0; i < size; i++) {
        h_input[i] = (float)(rand() % 1000) / 1000.0f;
        h_indice[i] = (i % DIVISIONS) | ((i / DIVISIONS) << LOG_DIVISIONS); // synthetic indices
    }

    // Device allocations
    float *d_input, *d_output;
    int *d_indice;
    unsigned int *d_prefixoffsets, *d_offsets;
    cudaMalloc(&d_input, size * sizeof(float));
    cudaMalloc(&d_indice, size * sizeof(int));
    cudaMalloc(&d_output, size * sizeof(float));
    cudaMalloc(&d_prefixoffsets, blocks * BUCKET_BLOCK_MEMORY * sizeof(unsigned int));
    cudaMalloc(&d_offsets, DIVISIONS * sizeof(unsigned int));

    cudaMemcpy(d_input, h_input, size * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(d_indice, h_indice, size * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_prefixoffsets, h_prefixoffsets, blocks * BUCKET_BLOCK_MEMORY * sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_offsets, h_offsets, DIVISIONS * sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemset(d_output, 0, size * sizeof(float));

    // Launch kernel
    bucketsort<<<blocks, threadsPerBlock>>>(d_input, d_indice, d_output, size, d_prefixoffsets, d_offsets);
    cudaDeviceSynchronize();

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("CUDA error: %s\n", cudaGetErrorString(err));
    } else {
        printf("bucketsort kernel executed successfully.\n");
    }

    cudaMemcpy(h_output, d_output, size * sizeof(float), cudaMemcpyDeviceToHost);
    printf("First 10 output values: ");
    for (int i = 0; i < 10 && i < size; i++) printf("%.4f ", h_output[i]);
    printf("\n");

    // Cleanup
    cudaFree(d_input);
    cudaFree(d_indice);
    cudaFree(d_output);
    cudaFree(d_prefixoffsets);
    cudaFree(d_offsets);
    free(h_input);
    free(h_indice);
    free(h_output);
    free(h_prefixoffsets);
    free(h_offsets);
    return 0;
}