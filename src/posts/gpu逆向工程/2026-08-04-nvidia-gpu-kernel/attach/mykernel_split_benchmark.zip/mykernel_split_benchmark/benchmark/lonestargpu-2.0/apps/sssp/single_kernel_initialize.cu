// Standalone CUDA kernel file: initialize
// Smoke-test version with main()

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MYINFINITY 100000000
typedef unsigned foru;

static inline void checkCuda(cudaError_t err, const char* msg) {
  if (err != cudaSuccess) {
    fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
    exit(EXIT_FAILURE);
  }
}

__global__ void initialize(foru *dist, unsigned int nv) {
  unsigned int ii = blockIdx.x * blockDim.x + threadIdx.x;
  if (ii < nv) {
    dist[ii] = MYINFINITY;
  }
}

int main() {
  const unsigned nv = 10;
  foru *d_dist = NULL;
  foru h_dist[nv];

  checkCuda(cudaMalloc((void**)&d_dist, nv * sizeof(foru)), "malloc d_dist");

  dim3 block(128);
  dim3 grid((nv + block.x - 1) / block.x);

  initialize<<<grid, block>>>(d_dist, nv);
  checkCuda(cudaGetLastError(), "initialize launch failed");
  checkCuda(cudaDeviceSynchronize(), "initialize execution failed");

  checkCuda(cudaMemcpy(h_dist, d_dist, nv * sizeof(foru), cudaMemcpyDeviceToHost), "copy dist");

  for (unsigned i = 0; i < nv; i++) {
    printf("dist[%u] = %u\n", i, h_dist[i]);
  }

  cudaFree(d_dist);
  return 0;
}