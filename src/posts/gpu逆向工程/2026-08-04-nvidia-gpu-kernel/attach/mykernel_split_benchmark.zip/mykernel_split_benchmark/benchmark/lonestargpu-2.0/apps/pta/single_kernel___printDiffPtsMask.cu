// Standalone CUDA kernel file: __printDiffPtsMask
// Smoke-test debug version

#include "pta_single_kernel_test_common.cuh"
#include <math.h>

__device__ inline uint __diffPtsMaskGet__(const uint base, const uint col) {
    return __diffPtsMask__[mul32(base) + col];
}

__device__ __host__ static inline int isBitActive_debug_diff(uint word, uint bit) {
    return word & (1u << bit);
}

__device__ inline uint decodeWord_debug_diff(const uint base, const uint word, const uint bits) {
    uint ret = base * ELEMENT_CARDINALITY + mul32(word);
    return isBitActive_debug_diff(bits, threadIdx.x) ? __rep__[ret + threadIdx.x] : NIL;
}

__device__ void printElementAsSet_debug_diff(const uint base, volatile uint myBits, bool& first) {
    for (int i = 0; i < (int)BASE; i++) {
        uint word = __shfl_sync(0xFFFFFFFF, myBits, i);
        uint myDst = decodeWord_debug_diff(base, i, word);

        for (int j = 0; j < WARP_SIZE; j++) {
            uint dst = __shfl_sync(0xFFFFFFFF, myDst, j);
            if (dst != NIL && threadIdx.x == 0) {
                if (first) {
                    printf("%u", dst);
                } else {
                    printf(", %u", dst);
                }
                first = false;
            }
        }
    }
}

__device__ void printDiffPtsMask_debug() {
    uint numVars = __numVars__;

    if (threadIdx.x == 0) {
        printf("DIFF_PTS_MASK: [");
    }

    bool first = true;
    int to = (numVars + ELEMENT_CARDINALITY - 1) / ELEMENT_CARDINALITY;

    for (int base = 0; base < to; base++) {
        uint myBits = __diffPtsMaskGet__(base, threadIdx.x);
        printElementAsSet_debug_diff(base, myBits, first);
    }

    if (threadIdx.x == 0) {
        printf("]\n");
    }
}

__global__ void __printDiffPtsMask() {
    printDiffPtsMask_debug();
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint h_rep[MAX_TEST_VARS];
    uint h_mask[MAX_TEST_VARS];

    for (uint i = 0; i < MAX_TEST_VARS; i++) {
        h_rep[i] = i;
        h_mask[i] = 0;
    }

    // base = 0, word 0: bits 0,2,5 -> vars 0,2,5
    h_mask[0] = (1u << 0) | (1u << 2) | (1u << 5);

    cudaMemcpy(env.d_rep, h_rep, MAX_TEST_VARS * sizeof(uint), cudaMemcpyHostToDevice);
    cudaMemcpy(env.d_diffPtsMask, h_mask, MAX_TEST_VARS * sizeof(uint), cudaMemcpyHostToDevice);

    dim3 block(32, 1);
    dim3 grid(1);

    __printDiffPtsMask<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "__printDiffPtsMask launch failed");
    checkCuda(cudaDeviceSynchronize(), "__printDiffPtsMask execution failed");

    destroyPTATestEnv(env);
    return 0;
}