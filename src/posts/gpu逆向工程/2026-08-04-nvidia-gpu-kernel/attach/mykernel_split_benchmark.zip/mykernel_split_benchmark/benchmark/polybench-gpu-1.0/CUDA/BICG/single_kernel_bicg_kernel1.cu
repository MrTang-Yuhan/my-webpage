// Auto-generated CUDA kernel file: bicg_kernel1
// Extracted from: polybench-gpu-1.0/CUDA/BICG/bicg.cu
// Original line: 99

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

// ===== Macro Definitions =====
#define NX 4096  // from line 25
#define NY 4096  // from line 26

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/BICG/bicg.cu:37

// ===== Kernel =====
// Kernel: bicg_kernel1 (line 99)
__global__ void bicg_kernel1(DATA_TYPE *A, DATA_TYPE *r, DATA_TYPE *s) {

	int j = blockIdx.x * blockDim.x + threadIdx.x;
	
	if (j < NY)
	{
		s[j] = 0.0f;

		int i;
		for(i = 0; i < NX; i++)
		{
			s[j] += A[i * NY + j] * r[i];
		}
	}	

}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_A = (size_t)NX * NY;
    const size_t size_r = NX;
    const size_t size_s = NY;

    DATA_TYPE *h_A = (DATA_TYPE*)malloc(size_A * sizeof(DATA_TYPE));
    DATA_TYPE *h_r = (DATA_TYPE*)malloc(size_r * sizeof(DATA_TYPE));
    DATA_TYPE *h_s = (DATA_TYPE*)malloc(size_s * sizeof(DATA_TYPE));

    DATA_TYPE *d_A = nullptr;
    DATA_TYPE *d_r = nullptr;
    DATA_TYPE *d_s = nullptr;

    if (!h_A || !h_r || !h_s) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_A; ++i) h_A[i] = (DATA_TYPE)(i % 100) / 100.0f;
    for (size_t i = 0; i < size_r; ++i) h_r[i] = (DATA_TYPE)(i % 100) / 100.0f;
    for (size_t i = 0; i < size_s; ++i) h_s[i] = 0.0f;

    err = cudaMalloc((void**)&d_A, size_A * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_A failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_r, size_r * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_r failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_s, size_s * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_s failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_A, h_A, size_A * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D A failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_r, h_r, size_r * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D r failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_s, h_s, size_s * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D s failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((NY + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    bicg_kernel1<<<gridSize, blockSize>>>(d_A, d_r, d_s);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("bicg_kernel1 execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_s, d_s, size_s * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H s failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("s[0] = %f\n", (double)h_s[0]);

    cudaFree(d_A);
    cudaFree(d_r);
    cudaFree(d_s);
    free(h_A);
    free(h_r);
    free(h_s);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}