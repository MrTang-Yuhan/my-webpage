// Auto-generated CUDA kernel file: mergepack
// Extracted from: rodinia-3.1/hybridsort/single_kernel_mergepack.cu
// Original line: 13

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>

#ifndef DIVISIONS
#define DIVISIONS 1024
#endif

__constant__ int finalStartAddr[DIVISIONS + 1];
__constant__ int constStartAddr[DIVISIONS + 1];
__constant__ int nullElems[DIVISIONS];
// ===== Macro Definitions =====
#define _MATRIXMUL_KERNEL_H_  // from line 2  // from line 9

// ===== Kernel =====
// Kernel: mergepack (line 13)
__global__ void
mergepack(float *orig, float *result) {


	int idx = (blockIdx.x * blockDim.x) + threadIdx.x; 
	int division = blockIdx.y; 

	if((finalStartAddr[division] + idx) >= finalStartAddr[division + 1]) return; 
	result[finalStartAddr[division] + idx] = orig[constStartAddr[division]*4 + nullElems[division] + idx];   // [参数: orig, result]  // [参数: orig, result]


}

int main() {
    // Simple test: 1 division with 256 elements
    int numElems = 256;

    int h_finalStart[DIVISIONS + 1];
    int h_constStart[DIVISIONS + 1];
    int h_nullElems[DIVISIONS];

    h_finalStart[0] = 0;
    h_finalStart[1] = numElems;
    for (int i = 2; i <= DIVISIONS; i++) h_finalStart[i] = numElems;

    h_constStart[0] = 0;
    h_constStart[1] = numElems; // *4 float4 -> but we use float here
    for (int i = 2; i <= DIVISIONS; i++) h_constStart[i] = numElems;

    memset(h_nullElems, 0, sizeof(h_nullElems));

    cudaMemcpyToSymbol(finalStartAddr, h_finalStart, (DIVISIONS + 1) * sizeof(int));
    cudaMemcpyToSymbol(constStartAddr, h_constStart, (DIVISIONS + 1) * sizeof(int));
    cudaMemcpyToSymbol(nullElems, h_nullElems, DIVISIONS * sizeof(int));

    // Host data
    int origSize = numElems * 4 + numElems; // generous
    float *h_orig = (float *)malloc(origSize * sizeof(float));
    float *h_result = (float *)malloc(numElems * sizeof(float));
    for (int i = 0; i < origSize; i++) h_orig[i] = (float)i;

    // Device allocations
    float *d_orig, *d_result;
    cudaMalloc(&d_orig, origSize * sizeof(float));
    cudaMalloc(&d_result, numElems * sizeof(float));
    cudaMemcpy(d_orig, h_orig, origSize * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemset(d_result, 0, numElems * sizeof(float));

    // Launch: grid.x covers elements, grid.y covers divisions
    int threadsPerBlock = 256;
    dim3 grid((numElems + threadsPerBlock - 1) / threadsPerBlock, 1);
    mergepack<<<grid, threadsPerBlock>>>(d_orig, d_result);
    cudaDeviceSynchronize();

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("CUDA error: %s\n", cudaGetErrorString(err));
    } else {
        printf("mergepack kernel executed successfully.\n");
    }

    cudaMemcpy(h_result, d_result, numElems * sizeof(float), cudaMemcpyDeviceToHost);
    printf("First 10 results: ");
    for (int i = 0; i < 10 && i < numElems; i++) printf("%.1f ", h_result[i]);
    printf("\n");

    // Cleanup
    cudaFree(d_orig);
    cudaFree(d_result);
    free(h_orig);
    free(h_result);
    return 0;
}