// Auto-generated CUDA kernel file: fdtd_step2_kernel
// Extracted from: polybench-gpu-1.0/CUDA/FDTD-2D/single_kernel_fdtd_step2_kernel.cu
// Original line: 24

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define NX 2048  // from line 27  // from line 16
#define NY 2048  // from line 28  // from line 17

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/FDTD-2D/single_kernel_fdtd_step2_kernel.cu:20

// ===== Kernel =====
// Kernel: fdtd_step2_kernel (line 24)
__global__ void fdtd_step2_kernel(DATA_TYPE *ex, DATA_TYPE *ey, DATA_TYPE *hz, int t) {


	int j = blockIdx.x * blockDim.x + threadIdx.x;
	int i = blockIdx.y * blockDim.y + threadIdx.y;
	
	if ((i < NX) && (j < NY) && (j > 0))
	{
		ex[i * (NY+1) + j] = ex[i * (NY+1) + j] - 0.5f*(hz[i * NY + j] - hz[i * NY + (j-1)]);
	}


}

// ===== Main Function =====
int main(int argc, char** argv) {
    cudaError_t err;

    // TODO: set problem size
    const size_t size = 1024;

    // ===== Host/Device buffers =====
    // buffer: DATA_TYPE *ex
    DATA_TYPE *h_ex = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_ex = nullptr;
    if (!h_ex) {
        printf("malloc failed for h_ex\n");
        return -1;
    }

    // buffer: DATA_TYPE *ey
    DATA_TYPE *h_ey = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_ey = nullptr;
    if (!h_ey) {
        printf("malloc failed for h_ey\n");
        return -1;
    }

    // buffer: DATA_TYPE *hz
    DATA_TYPE *h_hz = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_hz = nullptr;
    if (!h_hz) {
        printf("malloc failed for h_hz\n");
        return -1;
    }

    // scalar param: int t
    // TODO: initialize scalar parameter `t`
    auto t = 0;

    // ===== Initialize host data =====
    for (size_t i = 0; i < size; ++i) h_ex[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_ey[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_hz[i] = (DATA_TYPE)(i % 100);

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_ex, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_ex: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_ey, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_ey: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_hz, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_hz: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_ex, h_ex, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for ex: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_ey, h_ey, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for ey: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_hz, h_hz, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for hz: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((size + blockSize.x - 1) / blockSize.x, 1);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);
    fdtd_step2_kernel<<<gridSize, blockSize>>>(d_ex, d_ey, d_hz, t);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy one buffer back as example =====
    err = cudaMemcpy(h_hz, d_hz, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for hz: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // TODO: verify results
    printf("Sample output: %f\n", (double)h_hz[0]);

    // ===== Cleanup =====
    if (d_ex) cudaFree(d_ex);
    if (d_ey) cudaFree(d_ey);
    if (d_hz) cudaFree(d_hz);
    if (h_ex) free(h_ex);
    if (h_ey) free(h_ey);
    if (h_hz) free(h_hz);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}