// Auto-generated CUDA kernel file: dverifysolution
// Standalone runnable version

#include "common.h"
#include "graph.h"
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
__global__
void dverifysolution(foru *dist, Graph graph, unsigned *nerr) {
    unsigned int nn = (blockIdx.x * blockDim.x + threadIdx.x);
    if (nn < graph.nnodes) {
        unsigned int nsrcedges = graph.getOutDegree(nn);
        for (unsigned ii = 0; ii < nsrcedges; ++ii) {
            unsigned int u = nn;
            unsigned int v = graph.getDestination(u, ii);
            foru wt = 1;

            if (wt > 0 && dist[u] + wt < dist[v]) {
                atomicAdd(nerr, 1u);
            }
        }
    }
}

static void build_test_graph(Graph &hg) {
    hg.nnodes = 4;
    hg.nedges = 4;
    hg.allocOnHost();

    for (unsigned i = 0; i < hg.nnodes; i++) hg.srcsrc[i] = i;

    hg.psrc[0] = 1;
    hg.psrc[1] = 3;
    hg.psrc[2] = 4;
    hg.psrc[3] = 5;

    hg.noutgoing[0] = 2;
    hg.noutgoing[1] = 1;
    hg.noutgoing[2] = 1;
    hg.noutgoing[3] = 0;

    hg.nincoming[0] = 0;
    hg.nincoming[1] = 1;
    hg.nincoming[2] = 1;
    hg.nincoming[3] = 2;

    hg.edgessrcdst[1] = 1; hg.edgessrcwt[1] = 1;
    hg.edgessrcdst[2] = 2; hg.edgessrcwt[2] = 1;
    hg.edgessrcdst[3] = 3; hg.edgessrcwt[3] = 1;
    hg.edgessrcdst[4] = 3; hg.edgessrcwt[4] = 1;

    hg.source = 0;
}

int main() {
    Graph hgraph;
    build_test_graph(hgraph);

    Graph dgraph;
    hgraph.cudaCopy(dgraph);

    foru h_dist[4] = {0, 1, 1, 2};
    unsigned h_nerr = 0;

    foru *d_dist = NULL;
    unsigned *d_nerr = NULL;

    cudaError_t err;
    err = cudaMalloc((void **)&d_dist, sizeof(foru) * hgraph.nnodes);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_dist failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void **)&d_nerr, sizeof(unsigned));
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_nerr failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(d_dist, h_dist, sizeof(foru) * hgraph.nnodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_nerr, &h_nerr, sizeof(unsigned), cudaMemcpyHostToDevice);

    int block = 256;
    int grid = (hgraph.nnodes + block - 1) / block;

    dverifysolution<<<grid, block>>>(d_dist, dgraph, d_nerr);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(&h_nerr, d_nerr, sizeof(unsigned), cudaMemcpyDeviceToHost);

    printf("dverifysolution finished\n");
    printf("nerr = %u\n", h_nerr);

    cudaFree(d_dist);
    cudaFree(d_nerr);
    dgraph.deallocOnDevice();
    hgraph.deallocOnHost();

    return 0;
}