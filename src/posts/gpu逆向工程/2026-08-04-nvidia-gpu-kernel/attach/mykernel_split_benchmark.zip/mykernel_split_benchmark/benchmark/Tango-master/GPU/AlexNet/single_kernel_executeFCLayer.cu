// Auto-generated CUDA kernel file: executeFCLayer
// Extracted from: Tango-master/GPU/AlexNet/an_kernel.cu
// Original line: 245

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: executeFCLayer (line 245)
__global__ void executeFCLayer(float *bias,float *Layer_InNeurons_GPU,float *Layer_Weights_GPU,float *Layer_OutNeurons_GPU,int output, int input,bool reLU,bool dropout) {

    float product = 0.0;
    int out = blockIdx.x;
    int weight = out * input;
    {
        for(int in = 0; in < input; in++)
        {
               product += Layer_InNeurons_GPU[in] * Layer_Weights_GPU[weight+in];
        }
        product += bias[out];
        if(reLU == true)
        {
            if(product < 0) /* ReLU Layer */
                product = 0;
        }

        Layer_OutNeurons_GPU[out] = product;
        product = 0.0;
    }

}


int main() {
    const int output = 100;
    const int input = 1250;
    const bool reLU = true;
    const bool dropout = false;

    size_t bias_size   = output;
    size_t in_size     = input;
    size_t weight_size = output * input;
    size_t out_size    = output;

    float *h_bias   = (float*)malloc(bias_size * sizeof(float));
    float *h_in     = (float*)malloc(in_size * sizeof(float));
    float *h_weight = (float*)malloc(weight_size * sizeof(float));
    float *h_out    = (float*)malloc(out_size * sizeof(float));

    for (size_t i = 0; i < bias_size; ++i)   h_bias[i] = 0.1f;
    for (size_t i = 0; i < in_size; ++i)     h_in[i] = (float)(i % 17) * 0.01f;
    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (float)(i % 9) * 0.01f;

    float *d_bias, *d_in, *d_weight, *d_out;
    CHECK(cudaMalloc((void**)&d_bias,   bias_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_in,     in_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out,    out_size * sizeof(float)));

    CHECK(cudaMemcpy(d_bias,   h_bias,   bias_size * sizeof(float),   cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_in,     h_in,     in_size * sizeof(float),     cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(output);
    dim3 block(1);

    executeFCLayer<<<grid, block>>>(
        d_bias, d_in, d_weight, d_out,
        output, input, reLU, dropout
    );
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeFCLayer done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("fc_out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_bias);
    cudaFree(d_in);
    cudaFree(d_weight);
    cudaFree(d_out);
    free(h_bias);
    free(h_in);
    free(h_weight);
    free(h_out);
    return 0;
}