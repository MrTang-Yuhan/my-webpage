// Auto-generated CUDA kernel file: calculate_temp
// Extracted from: rodinia/2.0-ft/hotspot/hotspot.cu
// Original line: 95

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
// #include "timer.h"

// ===== Macro Definitions =====
#define BLOCK_SIZE 16  // from line 7
#define STR_SIZE 256  // from line 8
#define MAX_PD	(3.0e6)  // from line 11
#define PRECISION	0.001  // from line 13
#define SPEC_HEAT_SI 1.75e6  // from line 14
#define K_SI 100  // from line 15
#define FACTOR_CHIP	0.5  // from line 17
#define pin_stats_reset()   startCycle()  // from line 29
#define pin_stats_pause(cycles)   stopCycle(cycles)  // from line 30
#define pin_stats_dump(cycles)    printf("timer: %Lu\n", cycles)  // from line 31
#define IN_RANGE(x, min, max)   ((x)>=(min) && (x)<=(max))  // from line 91
#define CLAMP_RANGE(x, min, max) x = (x<(min)) ? min : ((x>(max)) ? max : x )  // from line 92
#define MIN(a, b) ((a)<=(b) ? (a) : (b))  // from line 93
    # define EXPAND_RATE 2// add one iteration will extend the pyramid base by 2 per each borderline  // from line 277

// ===== Global Variables =====
float amb_temp = 80.0;  // [来源: 全局作用域定义, line 24]

// ===== Kernel =====
// Kernel: calculate_temp (line 95)
__global__ void calculate_temp(int iteration,  //number of iteration
                               float *power,   //power input
                               float *temp,    //temperature input/output
                               int grid_cols,  //Col of grid
                               int grid_rows,  //Row of grid
							   int border_cols,  // border offset 
							   int border_rows,  // border offset
                               float Cap,      //Capacitance
                               float Rx, 
                               float Ry, 
                               float Rz, 
                               float step, 
                               float time_elapsed) {

	
        __shared__ float temp_on_cuda[BLOCK_SIZE][BLOCK_SIZE];  // [参数: temp]
        __shared__ float power_on_cuda[BLOCK_SIZE][BLOCK_SIZE];  // [参数: power]
        __shared__ float temp_t[BLOCK_SIZE][BLOCK_SIZE]; // saving temparary temperature result  // [参数: temp]

	float amb_temp = 80.0;  // [参数: temp]
        float step_div_Cap;  // [参数: Cap, step]
        float Rx_1,Ry_1,Rz_1;  // [参数: Rx, Ry, Rz]
        
	int bx = blockIdx.x;
        int by = blockIdx.y;

	int tx=threadIdx.x;
	int ty=threadIdx.y;
	
	step_div_Cap=step/Cap;  // [参数: Cap, step]
	
	Rx_1=1/Rx;  // [参数: Rx]
	Ry_1=1/Ry;  // [参数: Ry]
	Rz_1=1/Rz;  // [参数: Rz]
	
        // each block finally computes result for a small block
        // after N iterations. 
        // it is the non-overlapping small blocks that cover 
        // all the input data

        // calculate the small block size
	int small_block_rows = BLOCK_SIZE-iteration*2;//EXPAND_RATE  // [参数: iteration]
	int small_block_cols = BLOCK_SIZE-iteration*2;//EXPAND_RATE  // [参数: iteration]

        // calculate the boundary for the block according to 
        // the boundary of its small block
        int blkY = small_block_rows*by-border_rows;  // [参数: border_rows]
        int blkX = small_block_cols*bx-border_cols;  // [参数: border_cols]
        int blkYmax = blkY+BLOCK_SIZE-1;
        int blkXmax = blkX+BLOCK_SIZE-1;

        // calculate the global thread coordination
	int yidx = blkY+ty;
	int xidx = blkX+tx;

        // load data if it is within the valid input range
	int loadYidx=yidx, loadXidx=xidx;
        int index = grid_rows*loadYidx+loadXidx;  // [参数: grid_rows]
       
	if(IN_RANGE(loadYidx, 0, grid_rows-1) && IN_RANGE(loadXidx, 0, grid_cols-1)){  // [参数: grid_cols, grid_rows]
            temp_on_cuda[ty][tx] = temp[index];  // Load the temperature data from global memory to shared memory  // [参数: temp]
            power_on_cuda[ty][tx] = power[index];// Load the power data from global memory to shared memory  // [参数: power]
	}
	__syncthreads();

        // effective range within this block that falls within 
        // the valid range of the input data
        // used to rule out computation outside the boundary.
        int validYmin = (blkY < 0) ? -blkY : 0;
        int validYmax = (blkYmax > grid_rows-1) ? BLOCK_SIZE-1-(blkYmax-grid_rows+1) : BLOCK_SIZE-1;  // [参数: grid_rows]
        int validXmin = (blkX < 0) ? -blkX : 0;
        int validXmax = (blkXmax > grid_cols-1) ? BLOCK_SIZE-1-(blkXmax-grid_cols+1) : BLOCK_SIZE-1;  // [参数: grid_cols]

        int N = ty-1;
        int S = ty+1;
        int W = tx-1;
        int E = tx+1;
        
        N = (N < validYmin) ? validYmin : N;
        S = (S > validYmax) ? validYmax : S;
        W = (W < validXmin) ? validXmin : W;
        E = (E > validXmax) ? validXmax : E;

        bool computed;
        for (int i=0; i<iteration ; i++){   // [参数: iteration]
            computed = false;
            if( IN_RANGE(tx, i+1, BLOCK_SIZE-i-2) &&  \
                  IN_RANGE(ty, i+1, BLOCK_SIZE-i-2) &&  \
                  IN_RANGE(tx, validXmin, validXmax) && \
                  IN_RANGE(ty, validYmin, validYmax) ) {
                  computed = true;
                  temp_t[ty][tx] =   temp_on_cuda[ty][tx] + step_div_Cap * (power_on_cuda[ty][tx] +   // [参数: power, temp, Cap, step]
	       	         (temp_on_cuda[S][tx] + temp_on_cuda[N][tx] - 2.0*temp_on_cuda[ty][tx]) * Ry_1 +   // [参数: temp, Ry]
		             (temp_on_cuda[ty][E] + temp_on_cuda[ty][W] - 2.0*temp_on_cuda[ty][tx]) * Rx_1 +   // [参数: temp, Rx]
		             (amb_temp - temp_on_cuda[ty][tx]) * Rz_1);  // [参数: temp, Rz]
	
            }
            __syncthreads();
            if(i==iteration-1)  // [参数: iteration]
                break;
            if(computed)	 //Assign the computation range
                temp_on_cuda[ty][tx]= temp_t[ty][tx];  // [参数: temp]
            __syncthreads();
          }

      // update the global memory
      // after the last iteration, only threads coordinated within the 
      // small block perform the calculation and switch on ``computed''
      if (computed){
          temp[index]= temp_t[ty][tx];		  // [参数: temp]
      }

}

// 在 single_kernel_calculate_temp.cu 末尾追加

int main() {
    // ----------------------------
    // 参数设置
    // ----------------------------
    const int grid_rows   = 64;
    const int grid_cols   = 64;
    const int iteration   = 1;
    const int total_elem  = grid_rows * grid_cols;

    // 物理参数（来自 Rodinia hotspot 默认值）
    const float chip_height = 0.016f;
    const float chip_width  = 0.016f;
    const float t_chip      = 0.0005f;
    const float thermal_conductivity = 100.0f;
    const float dx = chip_height / grid_rows;
    const float dy = chip_width  / grid_cols;
    const float Cap   = FACTOR_CHIP * SPEC_HEAT_SI * t_chip * dx * dy;
    const float Rx    = dy / (2.0f * thermal_conductivity * t_chip * dx);
    const float Ry    = dx / (2.0f * thermal_conductivity * t_chip * dy);
    const float Rz    = t_chip / (thermal_conductivity * dx * dy);
    const float step  = 0.001f;
    const float time_elapsed = 0.001f;

    // border 偏移（iteration 层）
    const int border_rows = iteration;
    const int border_cols = iteration;

    // ----------------------------
    // 初始化 host 数据
    // ----------------------------
    float *h_temp  = (float*)malloc(total_elem * sizeof(float));
    float *h_power = (float*)malloc(total_elem * sizeof(float));

    for (int i = 0; i < total_elem; i++) {
        h_temp[i]  = 80.0f + (float)(rand() % 20);  // 80~100 °C
        h_power[i] = (float)(rand() % 100) / 10.0f; // 0~10 W
    }

    // 保存初始温度用于对比
    float *h_temp_ref = (float*)malloc(total_elem * sizeof(float));
    memcpy(h_temp_ref, h_temp, total_elem * sizeof(float));

    // ----------------------------
    // 分配 GPU 内存
    // ----------------------------
    float *d_temp, *d_power;
    cudaMalloc(&d_temp,  total_elem * sizeof(float));
    cudaMalloc(&d_power, total_elem * sizeof(float));

    cudaMemcpy(d_temp,  h_temp,  total_elem * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(d_power, h_power, total_elem * sizeof(float), cudaMemcpyHostToDevice);

    // ----------------------------
    // 配置 grid / block
    // ----------------------------
    int small_block_rows = BLOCK_SIZE - iteration * 2;
    int small_block_cols = BLOCK_SIZE - iteration * 2;
    int grid_dim_x = (int)ceil((float)grid_cols / small_block_cols);
    int grid_dim_y = (int)ceil((float)grid_rows / small_block_rows);

    dim3 dimGrid(grid_dim_x, grid_dim_y);
    dim3 dimBlock(BLOCK_SIZE, BLOCK_SIZE);

    printf("Grid:  %d x %d blocks\n", grid_dim_x, grid_dim_y);
    printf("Block: %d x %d threads\n", BLOCK_SIZE, BLOCK_SIZE);

    // ----------------------------
    // 启动 kernel
    // ----------------------------
    calculate_temp<<<dimGrid, dimBlock>>>(
        iteration, d_power, d_temp,
        grid_cols, grid_rows,
        border_cols, border_rows,
        Cap, Rx, Ry, Rz,
        step, time_elapsed
    );

    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));

    // ----------------------------
    // 拷回结果
    // ----------------------------
    cudaMemcpy(h_temp, d_temp, total_elem * sizeof(float), cudaMemcpyDeviceToHost);

    // ----------------------------
    // 简单验证：温度应发生变化，且在合理范围内
    // ----------------------------
    int changed = 0, out_of_range = 0;
    for (int i = 0; i < total_elem; i++) {
        if (h_temp[i] != h_temp_ref[i]) changed++;
        if (h_temp[i] < 0.0f || h_temp[i] > 1000.0f) out_of_range++;
    }
    printf("Changed cells:     %d / %d\n", changed, total_elem);
    printf("Out-of-range cells: %d\n", out_of_range);
    printf("Sample temp[0]: before=%.4f  after=%.4f\n", h_temp_ref[0], h_temp[0]);

    // ----------------------------
    // 清理
    // ----------------------------
    cudaFree(d_temp);
    cudaFree(d_power);
    free(h_temp);
    free(h_power);
    free(h_temp_ref);

    return (err == cudaSuccess && out_of_range == 0) ? 0 : 1;
}