// Auto-generated CUDA kernel file: convolution3D_kernel
// Extracted from: polybench-gpu-1.0/CUDA/3DCONV/single_kernel_convolution3D_kernel.cu
// Original line: 26

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <cuda.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define NI 256  // from line 27  // from line 17
#define NJ 256  // from line 28  // from line 18
#define NK 256  // from line 29  // from line 19

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/3DCONV/single_kernel_convolution3D_kernel.cu:22

// ===== Kernel =====
// Kernel: convolution3D_kernel (line 26)
__global__ void convolution3D_kernel(DATA_TYPE *A, DATA_TYPE *B, int i) {


	int k = blockIdx.x * blockDim.x + threadIdx.x;
	int j = blockIdx.y * blockDim.y + threadIdx.y;

	DATA_TYPE c11, c12, c13, c21, c22, c23, c31, c32, c33;

	c11 = +2;  c21 = +5;  c31 = -8;
	c12 = -3;  c22 = +6;  c32 = -9;
	c13 = +4;  c23 = +7;  c33 = +10;


	if ((i < (NI-1)) && (j < (NJ-1)) &&  (k < (NK-1)) && (i > 0) && (j > 0) && (k > 0))
	{
		B[i*(NK * NJ) + j*NK + k] = c11 * A[(i - 1)*(NK * NJ) + (j - 1)*NK + (k - 1)]  +  c13 * A[(i + 1)*(NK * NJ) + (j - 1)*NK + (k - 1)]
					     +   c21 * A[(i - 1)*(NK * NJ) + (j - 1)*NK + (k - 1)]  +  c23 * A[(i + 1)*(NK * NJ) + (j - 1)*NK + (k - 1)]
					     +   c31 * A[(i - 1)*(NK * NJ) + (j - 1)*NK + (k - 1)]  +  c33 * A[(i + 1)*(NK * NJ) + (j - 1)*NK + (k - 1)]
					     +   c12 * A[(i + 0)*(NK * NJ) + (j - 1)*NK + (k + 0)]  +  c22 * A[(i + 0)*(NK * NJ) + (j + 0)*NK + (k + 0)]   
					     +   c32 * A[(i + 0)*(NK * NJ) + (j + 1)*NK + (k + 0)]  +  c11 * A[(i - 1)*(NK * NJ) + (j - 1)*NK + (k + 1)]  
					     +   c13 * A[(i + 1)*(NK * NJ) + (j - 1)*NK + (k + 1)]  +  c21 * A[(i - 1)*(NK * NJ) + (j + 0)*NK + (k + 1)]  
					     +   c23 * A[(i + 1)*(NK * NJ) + (j + 0)*NK + (k + 1)]  +  c31 * A[(i - 1)*(NK * NJ) + (j + 1)*NK + (k + 1)]  
					     +   c33 * A[(i + 1)*(NK * NJ) + (j + 1)*NK + (k + 1)];
	}


}

// ===== Main Function =====
int main(int argc, char** argv) {
    cudaError_t err;

    const int width = NJ;
    const int height = NI;
    const size_t size = (size_t)width * height;

    // ===== Host/Device buffers =====
    // buffer: DATA_TYPE *A
    DATA_TYPE *h_A = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_A = nullptr;
    if (!h_A) {
        printf("malloc failed for h_A\n");
        return -1;
    }

    // buffer: DATA_TYPE *B
    DATA_TYPE *h_B = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_B = nullptr;
    if (!h_B) {
        printf("malloc failed for h_B\n");
        return -1;
    }

    // scalar param: int i
    // TODO: initialize scalar parameter `i`
    auto i = 0;

    // ===== Initialize host data =====
    for (size_t i = 0; i < size; ++i) h_A[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_B[i] = (DATA_TYPE)(i % 100);

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_A, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_A: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_B, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_B: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_A, h_A, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for A: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_B, h_B, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for B: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((NJ + blockSize.x - 1) / blockSize.x,
                  (NI + blockSize.y - 1) / blockSize.y);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);
    convolution3D_kernel<<<gridSize, blockSize>>>(d_A, d_B, i);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy one buffer back as example =====
    err = cudaMemcpy(h_B, d_B, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for B: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // TODO: verify results
    printf("Sample output: %f\n", (double)h_B[0]);

    // ===== Cleanup =====
    if (d_A) cudaFree(d_A);
    if (d_B) cudaFree(d_B);
    if (h_A) free(h_A);
    if (h_B) free(h_B);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}