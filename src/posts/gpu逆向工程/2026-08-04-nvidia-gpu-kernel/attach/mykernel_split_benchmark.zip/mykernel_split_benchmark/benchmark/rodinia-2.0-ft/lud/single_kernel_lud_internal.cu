// Auto-generated CUDA kernel file: lud_internal
// Extracted from: rodinia/2.0-ft/lud/lud_kernel.cu
// Original line: 122

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>

// ===== Macro Definitions =====
#define BLOCK_SIZE 16  // from line 4

// ===== Kernel =====
// Kernel: lud_internal (line 122)
__global__ void
lud_internal(float *m, int matrix_dim, int offset) {

  __shared__ float peri_row[BLOCK_SIZE][BLOCK_SIZE];
  __shared__ float peri_col[BLOCK_SIZE][BLOCK_SIZE];

  int i;
  float sum;  // [参数: m]

  int global_row_id = offset + (blockIdx.y+1)*BLOCK_SIZE;  // [参数: offset]
  int global_col_id = offset + (blockIdx.x+1)*BLOCK_SIZE;  // [参数: offset]

  peri_row[threadIdx.y][threadIdx.x] = m[(offset+threadIdx.y)*matrix_dim+global_col_id+threadIdx.x];  // [参数: m, matrix_dim, offset]
  peri_col[threadIdx.y][threadIdx.x] = m[(global_row_id+threadIdx.y)*matrix_dim+offset+threadIdx.x];  // [参数: m, matrix_dim, offset]

  __syncthreads();

  sum = 0;  // [参数: m]
  for (i=0; i < BLOCK_SIZE; i++)
    sum += peri_col[threadIdx.y][i] * peri_row[i][threadIdx.x];  // [参数: m]
  m[(global_row_id+threadIdx.y)*matrix_dim+global_col_id+threadIdx.x] -= sum;  // [参数: m, matrix_dim]



}

// 在 single_kernel_lud_internal.cu 末尾追加

int main() {
    const int matrix_dim = 64;
    const int offset = 0;
    const int total_elem = matrix_dim * matrix_dim;
    const int num_blocks = (matrix_dim / BLOCK_SIZE) - 1;

    // 初始化矩阵
    float *h_m = (float*)malloc(total_elem * sizeof(float));
    for (int i = 0; i < total_elem; i++) {
        h_m[i] = (float)(rand() % 100) / 10.0f;
    }

    float *d_m;
    cudaMalloc(&d_m, total_elem * sizeof(float));
    cudaMemcpy(d_m, h_m, total_elem * sizeof(float), cudaMemcpyHostToDevice);

    // 启动 kernel（处理内部块，2D grid）
    dim3 dimGrid(num_blocks, num_blocks);
    dim3 dimBlock(BLOCK_SIZE, BLOCK_SIZE);
    
    printf("Running lud_internal: matrix_dim=%d, offset=%d, grid=(%d,%d)\n", 
           matrix_dim, offset, num_blocks, num_blocks);
    lud_internal<<<dimGrid, dimBlock>>>(d_m, matrix_dim, offset);
    
    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));

    cudaMemcpy(h_m, d_m, total_elem * sizeof(float), cudaMemcpyDeviceToHost);

    // 验证：内部块 (1,1) 应被更新
    printf("Sample internal block (row 1, col 1):\n");
    for (int i = BLOCK_SIZE; i < BLOCK_SIZE + 3; i++) {
        for (int j = BLOCK_SIZE; j < BLOCK_SIZE + 3; j++) {
            printf("%.4f ", h_m[i * matrix_dim + j]);
        }
        printf("\n");
    }

    cudaFree(d_m);
    free(h_m);
    return err == cudaSuccess ? 0 : 1;
}