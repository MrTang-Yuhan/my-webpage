// Auto-generated CUDA kernel file: executeThirdLayer
// Extracted from: Tango-master/GPU/AlexNet/an_kernel.cu
// Original line: 266

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: executeThirdLayer (line 266)
__global__ void executeThirdLayer(float *Layer3_Neurons_GPU, float *Layer3_Weights_GPU,float *Layer4_Neurons_GPU) {

    int blockID=blockIdx.x;
    //int pixelY=threadIdx.y;


    int weightBegin=blockID*1251;

    float result=0;

    result+=Layer3_Weights_GPU[weightBegin];

    ++weightBegin;

    for (int i=0; i<1250; ++i )
    {
        result+=Layer3_Neurons_GPU[i+(1250*blockIdx.y)]*Layer3_Weights_GPU[weightBegin+i];
    }

    result=(1.7159*tanhf(0.66666667*result));

    Layer4_Neurons_GPU[blockID+(100*blockIdx.y)]=result;


}

int main() {
    const int batch = 4;
    const int input_dim = 1250;
    const int output_dim = 100;
    const int weights_per_out = 1251;  // 1 bias + 1250 weights

    size_t in_size     = batch * input_dim;
    size_t weight_size = output_dim * weights_per_out;
    size_t out_size    = batch * output_dim;

    float *h_in     = (float*)malloc(in_size * sizeof(float));
    float *h_weight = (float*)malloc(weight_size * sizeof(float));
    float *h_out    = (float*)malloc(out_size * sizeof(float));

    for (size_t i = 0; i < in_size; ++i)     h_in[i] = (float)(i % 23) * 0.01f;
    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (float)(i % 11) * 0.01f;

    float *d_in, *d_weight, *d_out;
    CHECK(cudaMalloc((void**)&d_in,     in_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out,    out_size * sizeof(float)));

    CHECK(cudaMemcpy(d_in,     h_in,     in_size * sizeof(float),     cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(output_dim, batch);
    dim3 block(1);

    executeThirdLayer<<<grid, block>>>(d_in, d_weight, d_out);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeThirdLayer done.\n");
    for (int b = 0; b < batch; ++b) {
        printf("batch %d:\n", b);
        for (int i = 0; i < 5; ++i) {
            printf("  out[%d] = %f\n", i, h_out[b * output_dim + i]);
        }
    }

    cudaFree(d_in);
    cudaFree(d_weight);
    cudaFree(d_out);
    free(h_in);
    free(h_weight);
    free(h_out);
    return 0;
}