// Auto-generated CUDA kernel file: gemm_kernel
// Extracted from: polybench-gpu-1.0/CUDA/GEMM/single_kernel_gemm_kernel.cu
// Original line: 28

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <cuda.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define ALPHA 32412.0f  // from line 36  // from line 17
#define BETA 2123.0f  // from line 37  // from line 18
#define NI 512  // from line 27  // from line 19
#define NJ 512  // from line 28  // from line 20
#define NK 512  // from line 29  // from line 21

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/GEMM/single_kernel_gemm_kernel.cu:24

// ===== Kernel =====
// Kernel: gemm_kernel (line 28)
__global__ void gemm_kernel(DATA_TYPE *a, DATA_TYPE *b, DATA_TYPE *c) {


	int j = blockIdx.x * blockDim.x + threadIdx.x;
	int i = blockIdx.y * blockDim.y + threadIdx.y;

	if ((i < NI) && (j < NJ))
	{	
		c[i * NJ + j] *= BETA;
		int k;
		for(k=0; k < NK; k++)
		{
			c[i * NJ + j] += ALPHA * a[i * NK + k] * b[k * NJ +j];
		}
	}


}

// ===== Main Function =====
int main(int argc, char** argv) {
    cudaError_t err;

    const int width = NJ;
    const int height = NI;
    const size_t size = (size_t)width * height;

    // ===== Host/Device buffers =====
    // buffer: DATA_TYPE *a
    DATA_TYPE *h_a = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_a = nullptr;
    if (!h_a) {
        printf("malloc failed for h_a\n");
        return -1;
    }

    // buffer: DATA_TYPE *b
    DATA_TYPE *h_b = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_b = nullptr;
    if (!h_b) {
        printf("malloc failed for h_b\n");
        return -1;
    }

    // buffer: DATA_TYPE *c
    DATA_TYPE *h_c = (DATA_TYPE*)malloc(size * sizeof(DATA_TYPE));
    DATA_TYPE *d_c = nullptr;
    if (!h_c) {
        printf("malloc failed for h_c\n");
        return -1;
    }

    // ===== Initialize host data =====
    for (size_t i = 0; i < size; ++i) h_a[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_b[i] = (DATA_TYPE)(i % 100);
    for (size_t i = 0; i < size; ++i) h_c[i] = (DATA_TYPE)(i % 100);

    // ===== Allocate device memory =====
    err = cudaMalloc((void**)&d_a, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_a: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_b, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_b: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMalloc((void**)&d_c, size * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc failed for d_c: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Copy inputs to device =====
    err = cudaMemcpy(d_a, h_a, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for a: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_b, h_b, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for b: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaMemcpy(d_c, h_c, size * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("cudaMemcpy H2D failed for c: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // ===== Launch configuration =====
    dim3 blockSize(16, 16);
    dim3 gridSize((NJ + blockSize.x - 1) / blockSize.x,
                  (NI + blockSize.y - 1) / blockSize.y);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    // ===== Launch kernel =====
    cudaEventRecord(start);
    gemm_kernel<<<gridSize, blockSize>>>(d_a, d_b, d_c);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel execution time: %.3f ms\n", milliseconds);

    // ===== Copy one buffer back as example =====
    err = cudaMemcpy(h_c, d_c, size * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("cudaMemcpy D2H failed for c: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // TODO: verify results
    printf("Sample output: %f\n", (double)h_c[0]);

    // ===== Cleanup =====
    if (d_a) cudaFree(d_a);
    if (d_b) cudaFree(d_b);
    if (d_c) cudaFree(d_c);
    if (h_a) free(h_a);
    if (h_b) free(h_b);
    if (h_c) free(h_c);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    printf("Done!\n");
    return 0;
}