#include <stdio.h>

#define NUM_BANKS 16
#define LOG_NUM_BANKS 4
#define CONFLICT_FREE_OFFSET(index) ((index) >> LOG_NUM_BANKS)

__global__ static void uniformAdd(unsigned int *g_data,
                                   unsigned int *uniforms,
                                   int n,
                                   int blockOffset,
                                   int baseIndex) {
    __shared__ unsigned int uni;
    if (threadIdx.x == 0)
        uni = uniforms[blockIdx.x + blockOffset];

    unsigned int address = blockIdx.x * (blockDim.x << 1) + baseIndex + threadIdx.x;

    __syncthreads();

    g_data[address]              += uni;
    g_data[address + blockDim.x] += (threadIdx.x + blockDim.x < (unsigned int)n) * uni;
}

int main() {
    const int THREADS = 128;
    const int BLOCKS  = 4;
    const int n       = BLOCKS * THREADS * 2;  // 每个 block 处理 2*THREADS 个元素

    unsigned int *h_data     = (unsigned int*)calloc(n, sizeof(unsigned int));
    unsigned int *h_uniforms = (unsigned int*)malloc(BLOCKS * sizeof(unsigned int));
    for (int i = 0; i < BLOCKS; i++) h_uniforms[i] = 10;  // 每块加 10

    unsigned int *d_data, *d_uniforms;
    cudaMalloc(&d_data,     n      * sizeof(unsigned int));
    cudaMalloc(&d_uniforms, BLOCKS * sizeof(unsigned int));
    cudaMemcpy(d_data,     h_data,     n      * sizeof(unsigned int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_uniforms, h_uniforms, BLOCKS * sizeof(unsigned int), cudaMemcpyHostToDevice);

    uniformAdd<<<BLOCKS, THREADS>>>(d_data, d_uniforms, n, 0, 0);
    cudaDeviceSynchronize();

    cudaMemcpy(h_data, d_data, n * sizeof(unsigned int), cudaMemcpyDeviceToHost);
    printf("h_data[0]=%u, h_data[%d]=%u (expected 10)\n", h_data[0], n-1, h_data[n-1]);

    cudaFree(d_data); cudaFree(d_uniforms);
    free(h_data); free(h_uniforms);
    return 0;
}