// Standalone version for single_kernel_dinit.cu

#include "common.h"
#include "graph.h"
#include "component.h"
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MYINFINITY 100000000

// ===== Kernel =====
__global__ void dinit(unsigned *mstwt, Graph graph, ComponentSpace cs,
                      foru *eleminwts, foru *minwtcomponent,
                      unsigned *partners, unsigned *phores,
                      bool *processinnextiteration,
                      unsigned *goaheadnodeofcomponent,
                      unsigned inpid) {
    unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
    if (inpid < graph.nnodes) id = inpid;

    if (id < graph.nnodes) {
        eleminwts[id] = MYINFINITY;
        minwtcomponent[id] = MYINFINITY;
        goaheadnodeofcomponent[id] = graph.nnodes;
        phores[id] = 0;
        partners[id] = id;
        processinnextiteration[id] = false;
    }
}

static void build_test_graph(Graph &hg) {
    hg.nnodes = 3;
    hg.nedges = 6;
    hg.allocOnHost();

    for (unsigned i = 0; i < hg.nnodes; i++) hg.srcsrc[i] = i;

    hg.psrc[0] = 1;
    hg.psrc[1] = 3;
    hg.psrc[2] = 5;

    hg.noutgoing[0] = 2;
    hg.noutgoing[1] = 2;
    hg.noutgoing[2] = 2;

    hg.nincoming[0] = 2;
    hg.nincoming[1] = 2;
    hg.nincoming[2] = 2;

    hg.edgessrcdst[1] = 1; hg.edgessrcwt[1] = 1;
    hg.edgessrcdst[2] = 2; hg.edgessrcwt[2] = 4;
    hg.edgessrcdst[3] = 0; hg.edgessrcwt[3] = 1;
    hg.edgessrcdst[4] = 2; hg.edgessrcwt[4] = 2;
    hg.edgessrcdst[5] = 0; hg.edgessrcwt[5] = 4;
    hg.edgessrcdst[6] = 1; hg.edgessrcwt[6] = 2;

    hg.source = 0;
}

int main() {
    Graph hgraph, graph;
    build_test_graph(hgraph);
    hgraph.cudaCopy(graph);

    ComponentSpace cs(graph.nnodes);

    unsigned *mstwt = NULL;
    foru *eleminwts = NULL, *minwtcomponent = NULL;
    unsigned *partners = NULL, *phores = NULL, *goahead = NULL;
    bool *process = NULL;

    unsigned hmstwt = 0;

    cudaMalloc((void **)&mstwt, sizeof(unsigned));
    cudaMemcpy(mstwt, &hmstwt, sizeof(unsigned), cudaMemcpyHostToDevice);

    cudaMalloc((void **)&eleminwts, graph.nnodes * sizeof(foru));
    cudaMalloc((void **)&minwtcomponent, graph.nnodes * sizeof(foru));
    cudaMalloc((void **)&partners, graph.nnodes * sizeof(unsigned));
    cudaMalloc((void **)&phores, graph.nnodes * sizeof(unsigned));
    cudaMalloc((void **)&process, graph.nnodes * sizeof(bool));
    cudaMalloc((void **)&goahead, graph.nnodes * sizeof(unsigned));

    dinit<<<1, 128>>>(mstwt, graph, cs, eleminwts, minwtcomponent, partners, phores, process, goahead, graph.nnodes);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    foru h_eleminwts[3], h_minwtcomponent[3];
    unsigned h_partners[3], h_phores[3], h_goahead[3];
    bool h_process[3];

    cudaMemcpy(h_eleminwts, eleminwts, 3 * sizeof(foru), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_minwtcomponent, minwtcomponent, 3 * sizeof(foru), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_partners, partners, 3 * sizeof(unsigned), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_phores, phores, 3 * sizeof(unsigned), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_goahead, goahead, 3 * sizeof(unsigned), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_process, process, 3 * sizeof(bool), cudaMemcpyDeviceToHost);

    printf("dinit finished\n");
    for (int i = 0; i < 3; i++) {
        printf("i=%d elemin=%u mincomp=%u partner=%u phore=%u process=%d goahead=%u\n",
               i, h_eleminwts[i], h_minwtcomponent[i], h_partners[i],
               h_phores[i], (int)h_process[i], h_goahead[i]);
    }

    cudaFree(mstwt);
    cudaFree(eleminwts);
    cudaFree(minwtcomponent);
    cudaFree(partners);
    cudaFree(phores);
    cudaFree(process);
    cudaFree(goahead);
    graph.deallocOnDevice();
    hgraph.deallocOnHost();

    return 0;
}