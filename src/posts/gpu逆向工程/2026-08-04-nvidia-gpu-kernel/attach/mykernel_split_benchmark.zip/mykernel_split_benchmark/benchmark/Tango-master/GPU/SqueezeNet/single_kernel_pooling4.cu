// Auto-generated CUDA kernel file: pooling4
// Extracted from: Tango-master/GPU/SqueezeNet/SN.cu
// Original line: 1496

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

// ===== Kernel =====
// Kernel: pooling4 (line 1496)
__global__ void pooling4(double *Layer4_Neurons_GPU,double *Layer4_pool_GPU,int out,int out_fr,int out_fc,int kernel,int stride_width,int in_fr,int in_fc) {

    int row = threadIdx.x;
    int col = blockIdx.x;
    double max = 0.0;
    {
        for(int output =0;output < 256 ;output++)
        {
            if(row%2 != 0)
            { 
                if(col%2 != 0)
                {
                    for(int i = row-1; i <= row+1; i++)
                    {   
			if(i>54) break;        
                        for(int j = col-1; j <= col+1; j++)
                        {
			    if(j>54) break;
                            if(max < ((Layer4_Neurons_GPU[output*55*55+i*55+j])))
                                max =   ((Layer4_Neurons_GPU[output*55*55+i*55+j])) ;
 
                        }
                    }
                    Layer4_pool_GPU[output*27*27+((row-1)/2)*27+(col-1)/2] = max;
                    max = 0.0;   
                }
            }
        }
    }
    __syncthreads();
   // if(row == 1 && col == 1)
	//printf("Max pool 4 o/p: %.8f\n", Layer4_pool_GPU[90399]);

}

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    const int out = 256;
    const int in_fr = 55, in_fc = 55;
    const int out_fr = 27, out_fc = 27;
    const int kernel = 3;
    const int stride_width = 2;

    size_t input_size = (size_t)out * in_fr * in_fc;
    size_t output_size = (size_t)out * out_fr * out_fc;

    double *h_in  = (double*)malloc(input_size * sizeof(double));
    double *h_out = (double*)malloc(output_size * sizeof(double));

    if (!h_in || !h_out) return -1;

    for (size_t i = 0; i < input_size; ++i) h_in[i] = (double)(i % 13) * 0.01;

    double *d_in = nullptr, *d_out = nullptr;
    cudaMalloc(&d_in, input_size * sizeof(double));
    cudaMalloc(&d_out, output_size * sizeof(double));

    cudaMemcpy(d_in, h_in, input_size * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemset(d_out, 0, output_size * sizeof(double));

    dim3 grid(1);
    dim3 block(2);

    pooling4<<<grid, block>>>(d_in, d_out, out, out_fr, out_fc, kernel, stride_width, in_fr, in_fc);

    cudaDeviceSynchronize();
    if (cudaGetLastError() != cudaSuccess) {
        fprintf(stderr, "CUDA error in pooling4.\n");
        return -1;
    }

    cudaMemcpy(h_out, d_out, output_size * sizeof(double), cudaMemcpyDeviceToHost);

    printf("pooling4 done. out[0] = %f\n", h_out[0]);

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);
    return 0;
}