#include "pta_single_kernel_test_common.cuh"

__device__ inline void offsetMaskSetLite(uint base, uint col, uint off, uint val) {
    __offsetMask__[mul32((off - 1) * __offsetMaskRowsPerOffset__ + base) + col] = val;
}

__global__ void createOffsetMasks(int numObjectVars, uint maxOffset) {
    uint tid = getThreadIdInGrid();
    uint stride = getThreadsPerGrid();

    for (uint obj = tid; obj < (uint)numObjectVars; obj += stride) {
        uint base = BASE_OF(obj);
        uint word = WORD_OF(obj);
        uint bit = BIT_OF(obj);

        uint sz = __size__[obj];

        for (uint off = 1; off <= maxOffset; off++) {
            uint mask = 0;

            if (sz > off) {
                mask = 1u << bit;
            }

            atomicOr((uint*)&__offsetMask__[mul32((off - 1) * __offsetMaskRowsPerOffset__ + base) + word], mask);
        }
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint sizes[MAX_TEST_VARS];
    for (uint i = 0; i < MAX_TEST_VARS; i++) sizes[i] = 4;
    sizes[0] = 8;
    sizes[1] = 1;

    cudaMemcpy(env.d_size, sizes, sizeof(sizes), cudaMemcpyHostToDevice);

    uint rowsPerOffset = 1;
    cudaMemcpyToSymbol(__offsetMaskRowsPerOffset__, &rowsPerOffset, sizeof(uint));

    dim3 block(32, 4);
    dim3 grid(1);

    createOffsetMasks<<<grid, block>>>(64, 2);
    checkCuda(cudaGetLastError(), "createOffsetMasks launch failed");
    checkCuda(cudaDeviceSynchronize(), "createOffsetMasks execution failed");

    uint mask[8];
    cudaMemcpy(mask, env.d_offsetMask, sizeof(mask), cudaMemcpyDeviceToHost);

    printf("createOffsetMasks finished\n");
    for (int i = 0; i < 4; i++) {
        printf("offsetMask[%d]=%u\n", i, mask[i]);
    }

    destroyPTATestEnv(env);
    return 0;
}