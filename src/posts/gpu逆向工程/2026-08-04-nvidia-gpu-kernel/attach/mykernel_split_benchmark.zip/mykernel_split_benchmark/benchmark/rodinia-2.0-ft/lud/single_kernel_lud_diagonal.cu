// Auto-generated CUDA kernel file: lud_diagonal
// Extracted from: rodinia/2.0-ft/lud/lud_kernel.cu
// Original line: 6

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>

// ===== Macro Definitions =====
#define BLOCK_SIZE 16  // from line 4

// ===== Kernel =====
// Kernel: lud_diagonal (line 6)
__global__ void 
lud_diagonal(float *m, int matrix_dim, int offset) {

  int i,j;
  __shared__ float shadow[BLOCK_SIZE][BLOCK_SIZE];

  int array_offset = offset*matrix_dim+offset;  // [参数: m, matrix_dim, offset]
  for(i=0; i < BLOCK_SIZE; i++){
    shadow[i][threadIdx.x]=m[array_offset+threadIdx.x];  // [参数: m, offset]
    array_offset += matrix_dim;  // [参数: m, matrix_dim, offset]
  }
  __syncthreads();

  for(i=0; i < BLOCK_SIZE-1; i++) {

    if (threadIdx.x>i){
      for(j=0; j < i; j++)
        shadow[threadIdx.x][i] -= shadow[threadIdx.x][j]*shadow[j][i];
      shadow[threadIdx.x][i] /= shadow[i][i];

      __syncthreads();

      for(j=0; j < i+1; j++)
        shadow[i+1][threadIdx.x] -= shadow[i+1][j]*shadow[j][threadIdx.x];

      __syncthreads();
    }
  }

  /* 
     The first row is not modified, it  // [参数: m]
     is no need to write it back to the
     global memory  // [参数: m]

   */
  array_offset = (offset+1)*matrix_dim+offset;  // [参数: m, matrix_dim, offset]
  for(i=1; i < BLOCK_SIZE; i++){
    m[array_offset+threadIdx.x]=shadow[i][threadIdx.x];  // [参数: m, offset]
    array_offset += matrix_dim;  // [参数: m, matrix_dim, offset]
  }

}


// 在 single_kernel_lud_diagonal.cu 末尾追加

int main() {
    const int matrix_dim = 64;  // 必须是 BLOCK_SIZE 的倍数
    const int offset = 0;       // 对角块从 (0,0) 开始
    const int total_elem = matrix_dim * matrix_dim;

    // 初始化矩阵（对角块区域填充测试数据）
    float *h_m = (float*)malloc(total_elem * sizeof(float));
    for (int i = 0; i < total_elem; i++) {
        h_m[i] = (i % matrix_dim == i / matrix_dim) ? 2.0f : 0.1f; // 对角线为2，其他0.1
    }

    // 拷贝到 GPU
    float *d_m;
    cudaMalloc(&d_m, total_elem * sizeof(float));
    cudaMemcpy(d_m, h_m, total_elem * sizeof(float), cudaMemcpyHostToDevice);

    // 启动 kernel（只处理一个对角块）
    printf("Running lud_diagonal: matrix_dim=%d, offset=%d\n", matrix_dim, offset);
    lud_diagonal<<<1, BLOCK_SIZE>>>(d_m, matrix_dim, offset);
    
    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));

    // 拷回结果
    cudaMemcpy(h_m, d_m, total_elem * sizeof(float), cudaMemcpyDeviceToHost);

    // 验证：对角块的 L/U 分解应改变原值
    printf("Sample diagonal block values:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%.4f ", h_m[i * matrix_dim + j]);
        }
        printf("\n");
    }

    cudaFree(d_m);
    free(h_m);
    return err == cudaSuccess ? 0 : 1;
}