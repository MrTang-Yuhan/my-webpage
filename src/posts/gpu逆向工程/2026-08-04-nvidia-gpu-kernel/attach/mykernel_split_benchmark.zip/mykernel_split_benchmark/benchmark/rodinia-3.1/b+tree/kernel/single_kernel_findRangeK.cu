// Auto-generated CUDA kernel file: findRangeK
#include <stdio.h>
#include <stdlib.h>

// ===== 内联 common.h 所需类型 =====
#define DEFAULT_ORDER 256
#define ORDER DEFAULT_ORDER

typedef struct knode {
    int  keys[ORDER + 1];
    long indices[ORDER + 1];
} knode;

// ===== Kernel =====
__global__ void
findRangeK(long height,
           knode *knodesD,
           long knodes_elem,
           long *currKnodeD,
           long *offsetD,
           long *lastKnodeD,
           long *offset_2D,
           int  *startD,
           int  *endD,
           int  *RecstartD,
           int  *ReclenD) {

    int thid = threadIdx.x;
    int bid  = blockIdx.x;

    int i;
    for (i = 0; i < height; i++) {
        if ((knodesD[currKnodeD[bid]].keys[thid]   <= startD[bid]) &&
            (knodesD[currKnodeD[bid]].keys[thid+1] >  startD[bid])) {
            if (knodesD[currKnodeD[bid]].indices[thid] < knodes_elem)
                offsetD[bid] = knodesD[currKnodeD[bid]].indices[thid];
        }
        if ((knodesD[lastKnodeD[bid]].keys[thid]   <= endD[bid]) &&
            (knodesD[lastKnodeD[bid]].keys[thid+1] >  endD[bid])) {
            if (knodesD[lastKnodeD[bid]].indices[thid] < knodes_elem)
                offset_2D[bid] = knodesD[lastKnodeD[bid]].indices[thid];
        }
        __syncthreads();

        if (thid == 0) {
            currKnodeD[bid] = offsetD[bid];
            lastKnodeD[bid] = offset_2D[bid];
        }
        __syncthreads();
    }

    if (knodesD[currKnodeD[bid]].keys[thid] == startD[bid])
        RecstartD[bid] = knodesD[currKnodeD[bid]].indices[thid];
    __syncthreads();

    if (knodesD[lastKnodeD[bid]].keys[thid] == endD[bid])
        ReclenD[bid] = knodesD[lastKnodeD[bid]].indices[thid] - RecstartD[bid] + 1;
}

// ===== Main =====
int main() {
    const int  THREADS = ORDER;   // 256
    const int  BLOCKS  = 1;
    const long HEIGHT  = 1;

    // 叶节点：keys[i]=i, indices[i]=i（记录索引即 key 值本身）
    knode h_knode;
    for (int i = 0; i <= ORDER; i++) {
        h_knode.keys[i]    = i;
        h_knode.indices[i] = i;
    }

    long h_currKnode[BLOCKS] = {0};
    long h_offset[BLOCKS]    = {0};
    long h_lastKnode[BLOCKS] = {0};
    long h_offset2[BLOCKS]   = {0};
    int  h_start[BLOCKS]     = {10};  // 查询范围 [10, 20]
    int  h_end[BLOCKS]       = {20};
    int  h_recstart[BLOCKS]  = {0};
    int  h_reclen[BLOCKS]    = {0};

    knode *d_knodes;
    long  *d_currKnode, *d_offset, *d_lastKnode, *d_offset2;
    int   *d_start, *d_end, *d_recstart, *d_reclen;

    cudaMalloc(&d_knodes,    1      * sizeof(knode));
    cudaMalloc(&d_currKnode, BLOCKS * sizeof(long));
    cudaMalloc(&d_offset,    BLOCKS * sizeof(long));
    cudaMalloc(&d_lastKnode, BLOCKS * sizeof(long));
    cudaMalloc(&d_offset2,   BLOCKS * sizeof(long));
    cudaMalloc(&d_start,     BLOCKS * sizeof(int));
    cudaMalloc(&d_end,       BLOCKS * sizeof(int));
    cudaMalloc(&d_recstart,  BLOCKS * sizeof(int));
    cudaMalloc(&d_reclen,    BLOCKS * sizeof(int));

    cudaMemcpy(d_knodes,    &h_knode,     sizeof(knode),       cudaMemcpyHostToDevice);
    cudaMemcpy(d_currKnode, h_currKnode,  BLOCKS*sizeof(long), cudaMemcpyHostToDevice);
    cudaMemcpy(d_offset,    h_offset,     BLOCKS*sizeof(long), cudaMemcpyHostToDevice);
    cudaMemcpy(d_lastKnode, h_lastKnode,  BLOCKS*sizeof(long), cudaMemcpyHostToDevice);
    cudaMemcpy(d_offset2,   h_offset2,    BLOCKS*sizeof(long), cudaMemcpyHostToDevice);
    cudaMemcpy(d_start,     h_start,      BLOCKS*sizeof(int),  cudaMemcpyHostToDevice);
    cudaMemcpy(d_end,       h_end,        BLOCKS*sizeof(int),  cudaMemcpyHostToDevice);
    cudaMemset(d_recstart,  0, BLOCKS * sizeof(int));
    cudaMemset(d_reclen,    0, BLOCKS * sizeof(int));

    findRangeK<<<BLOCKS, THREADS>>>(HEIGHT, d_knodes, 1,
                                    d_currKnode, d_offset,
                                    d_lastKnode, d_offset2,
                                    d_start, d_end,
                                    d_recstart, d_reclen);
    cudaError_t err = cudaDeviceSynchronize();
    if (err != cudaSuccess)
        fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(err));

    cudaMemcpy(h_recstart, d_recstart, BLOCKS*sizeof(int), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_reclen,   d_reclen,   BLOCKS*sizeof(int), cudaMemcpyDeviceToHost);
    printf("Range [10,20]: RecstartD=%d ReclenD=%d (expected 10, 11)\n",
           h_recstart[0], h_reclen[0]);

    cudaFree(d_knodes);    cudaFree(d_currKnode); cudaFree(d_offset);
    cudaFree(d_lastKnode); cudaFree(d_offset2);   cudaFree(d_start);
    cudaFree(d_end);       cudaFree(d_recstart);  cudaFree(d_reclen);
    return 0;
}