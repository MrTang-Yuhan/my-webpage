// ===== Includes =====
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// ===== Macro Definitions =====
#define GAMMA 1.4f
#define block_length 192
#define NDIM 3
#define NNB 4
#define RK 3
#define ff_mach 1.2f
#define deg_angle_of_attack 0.0f
#define VAR_DENSITY 0
#define VAR_MOMENTUM 1
#define VAR_DENSITY_ENERGY (VAR_MOMENTUM+NDIM)
#define NVAR (VAR_DENSITY_ENERGY+1)

#define checkCuda(call) do { \
    cudaError_t e = call; \
    if(e != cudaSuccess){ fprintf(stderr,"CUDA %s:%d %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1); } \
} while(0)

// ===== far-field constant =====
__device__ __constant__ float ff_variable[NVAR];

// ===== Kernel =====
__global__ void cuda_initialize_variables(int nelr, float* variables) {
    const int i = blockDim.x*blockIdx.x + threadIdx.x;
    for(int j = 0; j < NVAR; j++)
        variables[i + j*nelr] = ff_variable[j];
}

// ===== Main =====
int main() {
    const int nelr = 960; // 必须是 block_length 的倍数

    // 初始化 far-field 变量
    float angle = deg_angle_of_attack * (float)M_PI / 180.0f;
    float ff_pressure  = 1.0f;
    float ff_density   = GAMMA * ff_pressure;
    float ff_speed     = ff_mach * sqrtf(GAMMA * ff_pressure / ff_density);
    float h_ff[NVAR];
    h_ff[VAR_DENSITY]        = ff_density;
    h_ff[VAR_MOMENTUM+0]     = ff_density * ff_speed * cosf(angle);
    h_ff[VAR_MOMENTUM+1]     = ff_density * ff_speed * sinf(angle);
    h_ff[VAR_MOMENTUM+2]     = 0.0f;
    h_ff[VAR_DENSITY_ENERGY] = ff_pressure/(GAMMA-1.0f) + 0.5f*ff_density*ff_speed*ff_speed;
    checkCuda(cudaMemcpyToSymbol(ff_variable, h_ff, NVAR*sizeof(float)));

    float *d_variables;
    checkCuda(cudaMalloc(&d_variables, nelr*NVAR*sizeof(float)));

    cuda_initialize_variables<<<nelr/block_length, block_length>>>(nelr, d_variables);
    checkCuda(cudaDeviceSynchronize());

    // 验证：取第0个元素的 VAR_DENSITY
    float h_out;
    checkCuda(cudaMemcpy(&h_out, d_variables, sizeof(float), cudaMemcpyDeviceToHost));
    printf("cuda_initialize_variables OK. variables[0]=%.4f (expect %.4f)\n", h_out, h_ff[VAR_DENSITY]);

    cudaFree(d_variables);
    return 0;
}