#include "pta_single_kernel_test_common.cuh"

__device__ uint hashCodeLite(uint index) {
    uint base = graphGet(index + BASE);

    if (base == NIL) {
        return 0;
    }

    uint bits = graphGet(index + threadIdx.x);
    uint h = bits ? ((base + 1) * 1315423911u) ^ (threadIdx.x * 2654435761u) ^ bits : 0;

    for (int offset = 16; offset > 0; offset >>= 1) {
        h ^= __shfl_down_sync(0xFFFFFFFF, h, offset);
    }

    return __shfl_sync(0xFFFFFFFF, h, 0);
}

__device__ inline int isEmptyHashLite(uint var, uint rel) {
    return graphGet(getHeadIndex(var, rel) + BASE) == NIL;
}

__global__ void computeCurrPtsHash() {
    uint warp = blockIdx.x * blockDim.y + threadIdx.y;
    uint nwarps = gridDim.x * blockDim.y;

    uint nvars = __numVars__;

    for (uint src = warp; src < nvars; src += nwarps) {
        if (!isEmptyHashLite(src, CURR_DIFF_PTS)) {
            uint hash = hashCodeLite(getCurrDiffPtsHeadIndex(src));

            if (threadIdx.x == 0) {
                uint pos = atomicAdd(&__numKeysCounter__, 1);
                __key__[pos] = hash;
                __val__[pos] = src;
            }
        }
    }

    __syncthreads();

    if (isFirstThreadOfBlock()) {
        __numKeys__ = __numKeysCounter__;
        __numKeysCounter__ = 0;
        __worklistIndex0__ = 0;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint elt[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) elt[i] = 0;
    elt[0] = 0x3;
    elt[BASE] = 0;
    elt[NEXT] = NIL;

    cudaMemcpy(env.d_graph + TEST_CURR_DIFF_PTS_START + 5 * ELEMENT_WIDTH,
               elt, sizeof(elt), cudaMemcpyHostToDevice);

    uint zero = 0;
    cudaMemcpyToSymbol(__numKeysCounter__, &zero, sizeof(uint));

    dim3 block(32, 4);
    dim3 grid(1);

    computeCurrPtsHash<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "computeCurrPtsHash launch failed");
    checkCuda(cudaDeviceSynchronize(), "computeCurrPtsHash execution failed");

    uint keys[8], vals[8], numKeys;
    cudaMemcpy(keys, env.d_key, sizeof(keys), cudaMemcpyDeviceToHost);
    cudaMemcpy(vals, env.d_val, sizeof(vals), cudaMemcpyDeviceToHost);
    cudaMemcpyFromSymbol(&numKeys, __numKeys__, sizeof(uint));

    printf("computeCurrPtsHash finished\n");
    printf("numKeys=%u\n", numKeys);
    for (int i = 0; i < 4; i++) {
        printf("key[%d]=%u val[%d]=%u\n", i, keys[i], i, vals[i]);
    }

    destroyPTATestEnv(env);
    return 0;
}