// Auto-generated CUDA kernel file: ExecuteTenthLayer
// Extracted from: Tango-master/GPU/SqueezeNet/SN.cu
// Original line: 2069

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

// ===== Kernel =====
// Kernel: ExecuteTenthLayer (line 2069)
__global__ void ExecuteTenthLayer(double *Layer10_Weights_GPU, double *fire9_Features, double *Layer10_Features) {

	double Features = 0;
	int x = threadIdx.x;
	int y = blockIdx.x;
	//bool flag = 0;
	//if(x == 1 && y==1)
	//	flag = 1;
	if(x!=0 && x!=14 && y!=0 && y!=14)
	{
	for(int f=0; f<1000; f++)
	{
		Features = 0;
		for(int n=0; n<512; n++)
		{
			//double result = 0;
			//printf("(%d, %d) ", f,n);
               		Features+= fire9_Features[n*13*13 + (x-1)*13 + y-1]*Layer10_Weights_GPU[f*512+n];
			//if(f==0 && flag)
			//	printf("%.8f * %.8f = %.8f\n", fire9_Features[n*15*15 + x*15 + y], Layer10_Weights_GPU[f*512+n], fire9_Features[n*15*15 + x*15 + y]*Layer10_Weights_GPU[f*512+n]);
		}
		//ReLU activation function computation
		if(Features<0)
			Features = 0;
		Layer10_Features[f*15*15 + x*15 + y] = Features;// + fire8squeeze1x1_Weights_GPU[24576 + f];
		//printf("%.8f ",Features);
	}
	}
	__syncthreads();
	//if(x == 1 && y == 1)
		//printf("Layer10 o/p: %.8f, %d\n", Layer10_Features[39]);

}

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    const int f_size = 13;      // fire9_Features: 512 × 13 × 13
    const int out_channels = 1000;  // Layer10_Features: 1000 × 15 × 15
    const int in_channels = 512;

    size_t fire9_size = (size_t)in_channels * f_size * f_size;
    size_t weights_size = (size_t)out_channels * in_channels;
    size_t output_size = (size_t)out_channels * 15 * 15;

    double *h_fire9 = (double*)malloc(fire9_size * sizeof(double));
    double *h_weights = (double*)malloc(weights_size * sizeof(double));
    double *h_out = (double*)malloc(output_size * sizeof(double));

    if (!h_fire9 || !h_weights || !h_out) return -1;

    for (size_t i = 0; i < fire9_size; ++i) h_fire9[i] = (double)(i % 11) * 0.01;
    for (size_t i = 0; i < weights_size; ++i) h_weights[i] = (double)(i % 7) * 0.02;

    double *d_fire9 = nullptr, *d_weights = nullptr, *d_out = nullptr;
    cudaMalloc(&d_fire9, fire9_size * sizeof(double));
    cudaMalloc(&d_weights, weights_size * sizeof(double));
    cudaMalloc(&d_out, output_size * sizeof(double));

    cudaMemcpy(d_fire9, h_fire9, fire9_size * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemcpy(d_weights, h_weights, weights_size * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemset(d_out, 0, output_size * sizeof(double));

    // kernel uses: x = threadIdx.x, y = blockIdx.x
    // and only runs if x≠0,14 and y≠0,14 → valid (1..13) × (1..13)
    dim3 grid(13);   // y ∈ [1,13]
    dim3 block(13);  // x ∈ [1,13]

    ExecuteTenthLayer<<<grid, block>>>(d_weights, d_fire9, d_out);

    cudaDeviceSynchronize();
    if (cudaGetLastError() != cudaSuccess) {
        fprintf(stderr, "CUDA error in ExecuteTenthLayer.\n");
        return -1;
    }

    cudaMemcpy(h_out, d_out, output_size * sizeof(double), cudaMemcpyDeviceToHost);

    printf("ExecuteTenthLayer done. out[0] = %f\n", h_out[0]);

    cudaFree(d_fire9);
    cudaFree(d_weights);
    cudaFree(d_out);
    free(h_fire9);
    free(h_weights);
    free(h_out);
    return 0;
}