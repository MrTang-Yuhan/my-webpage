// Auto-generated CUDA kernel file: executelrnNormCuda
// Extracted from: Tango-master/GPU/AlexNet/an_kernel.cu
// Original line: 228

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: executelrnNormCuda (line 228)
__global__ void executelrnNormCuda(float *Layer_InNeurons_GPU, float alpha, float beta,int local_size,int out,int fr,int fc,float *Layer_OutNeurons_GPU,int func_call) {

        int nStart = 0, nEnd = 0;
        float value = 0.0;float sum = 0.0;
        int output = blockIdx.x;
        int row = threadIdx.x + func_call * 32;
        int col = threadIdx.y + func_call * 32;
        nStart=(output-2) > 1 ? (output-2) : 1 ;
        nEnd=(output+2) <  out ? (output+2) : out ;
        for(int i = (nStart-1); i < (nEnd-1) ; i++) // kernel convolution
        {
            sum += pow(( Layer_InNeurons_GPU[i*fr*fc + row*fc + col]),2);
        }
        value = (Layer_InNeurons_GPU[output*fr*fc + row*fc + col]) / (pow( 1 + ((alpha/local_size) *sum),beta));
        sum = 0;
        Layer_OutNeurons_GPU[output*fr*fc + row*fc + col] = value;

}
int main() {
    const int out = 96;
    const int fr = 27;
    const int fc = 27;
    const float alpha = 0.0001f;
    const float beta = 0.75f;
    const int local_size = 5;
    const int func_call = 0;

    size_t tensor_size = (size_t)out * fr * fc;

    float *h_in  = (float*)malloc(tensor_size * sizeof(float));
    float *h_out = (float*)malloc(tensor_size * sizeof(float));

    if (!h_in || !h_out) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < tensor_size; ++i) {
        h_in[i] = 1.0f + (float)(i % 23) * 0.01f;
    }

    float *d_in = NULL;
    float *d_out = NULL;

    CHECK(cudaMalloc((void**)&d_in,  tensor_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out, tensor_size * sizeof(float)));

    CHECK(cudaMemcpy(d_in, h_in, tensor_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_out, 0, tensor_size * sizeof(float)));

    dim3 grid(out);
    dim3 block(fr, fc);

    executelrnNormCuda<<<grid, block>>>(
        d_in, alpha, beta, local_size, out, fr, fc, d_out, func_call
    );

    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, tensor_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executelrnNormCuda done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);

    return 0;
}