// Standalone CUDA kernel file: decimate_2
// Smoke-test version with main()

#include <cuda.h>
#include <cuda_runtime.h>

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

typedef unsigned int uint;

static inline void checkCuda(cudaError_t err, const char* msg) {
  if (err != cudaSuccess) {
    fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
    exit(EXIT_FAILURE);
  }
}

struct GPUCSRGraph {
  int nnodes;
  int nedges;

  int *row_offsets;
  int *columns;

  bool *sat;
  float *bias;
  bool *value;

  __device__ __host__ int degree(int node) const {
    return row_offsets[node + 1] - row_offsets[node];
  }
};

struct Edge {
  int nedges;
  int *src;
  int *dst;
  bool *bar;
  float *eta;
  float *pi_0;
  float *pi_S;
  float *pi_U;

  bool alloc() {
    assert(nedges > 0);

    src  = (int*)   calloc(nedges, sizeof(*src));
    dst  = (int*)   calloc(nedges, sizeof(*dst));
    bar  = (bool*)  calloc(nedges, sizeof(*bar));
    eta  = (float*) calloc(nedges, sizeof(*eta));
    pi_0 = (float*) calloc(nedges, sizeof(*pi_0));
    pi_S = (float*) calloc(nedges, sizeof(*pi_S));
    pi_U = (float*) calloc(nedges, sizeof(*pi_U));

    return src && dst && bar && eta && pi_0 && pi_S && pi_U;
  }
};

__global__ void decimate_2(GPUCSRGraph clauses,
                           GPUCSRGraph vars,
                           Edge ed,
                           int *g_bias_list_vars,
                           const int *bias_list_len,
                           int fixperstep) {
  int id = threadIdx.x + blockIdx.x * blockDim.x;
  int threads = blockDim.x * gridDim.x;

  // NOTE: this is slower because the lower-work computation does not use all SMs.
  for (int l = *bias_list_len - fixperstep + id;
       l < *bias_list_len;
       l += threads) {
    int v = g_bias_list_vars[l];

    vars.sat[v] = true;

    int edoff = vars.row_offsets[v];
    int cllen = vars.degree(v);

    // for all a E V(i)
    for (int edndx = 0; edndx < cllen; edndx++) {
      int edge = vars.columns[edoff + edndx];
      int cl = ed.src[edge];

      if (!clauses.sat[cl]) {
        if (ed.bar[edge] != vars.value[v]) {
          clauses.sat[cl] = true;
        }
      }
    }
  }
}

// ============================================================
// Test helpers
// ============================================================

static void allocTinyGraph(GPUCSRGraph &g,
                           int nnodes,
                           int ncols,
                           const int *h_row_offsets,
                           const int *h_columns) {
  g.nnodes = nnodes;
  g.nedges = ncols;

  checkCuda(cudaMalloc((void**)&g.row_offsets, (nnodes + 1) * sizeof(int)),
            "malloc graph row_offsets");
  checkCuda(cudaMalloc((void**)&g.columns, ncols * sizeof(int)),
            "malloc graph columns");
  checkCuda(cudaMalloc((void**)&g.sat, nnodes * sizeof(bool)),
            "malloc graph sat");
  checkCuda(cudaMalloc((void**)&g.bias, nnodes * sizeof(float)),
            "malloc graph bias");
  checkCuda(cudaMalloc((void**)&g.value, nnodes * sizeof(bool)),
            "malloc graph value");

  checkCuda(cudaMemcpy(g.row_offsets,
                       h_row_offsets,
                       (nnodes + 1) * sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy row_offsets");

  checkCuda(cudaMemcpy(g.columns,
                       h_columns,
                       ncols * sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy columns");

  checkCuda(cudaMemset(g.sat, 0, nnodes * sizeof(bool)), "memset sat");
  checkCuda(cudaMemset(g.bias, 0, nnodes * sizeof(float)), "memset bias");
  checkCuda(cudaMemset(g.value, 0, nnodes * sizeof(bool)), "memset value");
}

static void freeTinyGraph(GPUCSRGraph &g) {
  if (g.row_offsets) cudaFree(g.row_offsets);
  if (g.columns) cudaFree(g.columns);
  if (g.sat) cudaFree(g.sat);
  if (g.bias) cudaFree(g.bias);
  if (g.value) cudaFree(g.value);

  g.row_offsets = NULL;
  g.columns = NULL;
  g.sat = NULL;
  g.bias = NULL;
  g.value = NULL;
}

static void allocTinyEdge(Edge &ed) {
  ed.nedges = 3;

  checkCuda(cudaMalloc((void**)&ed.src,  ed.nedges * sizeof(int)),   "malloc ed.src");
  checkCuda(cudaMalloc((void**)&ed.dst,  ed.nedges * sizeof(int)),   "malloc ed.dst");
  checkCuda(cudaMalloc((void**)&ed.bar,  ed.nedges * sizeof(bool)),  "malloc ed.bar");
  checkCuda(cudaMalloc((void**)&ed.eta,  ed.nedges * sizeof(float)), "malloc ed.eta");
  checkCuda(cudaMalloc((void**)&ed.pi_0, ed.nedges * sizeof(float)), "malloc ed.pi_0");
  checkCuda(cudaMalloc((void**)&ed.pi_S, ed.nedges * sizeof(float)), "malloc ed.pi_S");
  checkCuda(cudaMalloc((void**)&ed.pi_U, ed.nedges * sizeof(float)), "malloc ed.pi_U");

  int h_src[3] = {0, 0, 1};
  int h_dst[3] = {0, 1, 0};
  bool h_bar[3] = {false, true, false};

  float h_eta[3]  = {0.20f, 0.30f, 0.40f};
  float h_pi0[3]  = {0.60f, 0.50f, 0.70f};
  float h_piS[3]  = {0.20f, 0.20f, 0.10f};
  float h_piU[3]  = {0.20f, 0.30f, 0.20f};

  checkCuda(cudaMemcpy(ed.src, h_src, sizeof(h_src), cudaMemcpyHostToDevice), "copy ed.src");
  checkCuda(cudaMemcpy(ed.dst, h_dst, sizeof(h_dst), cudaMemcpyHostToDevice), "copy ed.dst");
  checkCuda(cudaMemcpy(ed.bar, h_bar, sizeof(h_bar), cudaMemcpyHostToDevice), "copy ed.bar");
  checkCuda(cudaMemcpy(ed.eta, h_eta, sizeof(h_eta), cudaMemcpyHostToDevice), "copy ed.eta");
  checkCuda(cudaMemcpy(ed.pi_0, h_pi0, sizeof(h_pi0), cudaMemcpyHostToDevice), "copy ed.pi_0");
  checkCuda(cudaMemcpy(ed.pi_S, h_piS, sizeof(h_piS), cudaMemcpyHostToDevice), "copy ed.pi_S");
  checkCuda(cudaMemcpy(ed.pi_U, h_piU, sizeof(h_piU), cudaMemcpyHostToDevice), "copy ed.pi_U");
}

static void freeTinyEdge(Edge &ed) {
  if (ed.src) cudaFree(ed.src);
  if (ed.dst) cudaFree(ed.dst);
  if (ed.bar) cudaFree(ed.bar);
  if (ed.eta) cudaFree(ed.eta);
  if (ed.pi_0) cudaFree(ed.pi_0);
  if (ed.pi_S) cudaFree(ed.pi_S);
  if (ed.pi_U) cudaFree(ed.pi_U);

  ed.src = NULL;
  ed.dst = NULL;
  ed.bar = NULL;
  ed.eta = NULL;
  ed.pi_0 = NULL;
  ed.pi_S = NULL;
  ed.pi_U = NULL;
}

static void initTinyGraphs(GPUCSRGraph &clauses, GPUCSRGraph &vars) {
  int h_clause_row_offsets[3] = {0, 2, 3};
  int h_clause_columns[3]     = {0, 1, 2};

  int h_var_row_offsets[3] = {0, 2, 3};
  int h_var_columns[3]     = {0, 2, 1};

  allocTinyGraph(clauses, 2, 3, h_clause_row_offsets, h_clause_columns);
  allocTinyGraph(vars,    2, 3, h_var_row_offsets,    h_var_columns);
}

static void destroyTinyGraphs(GPUCSRGraph &clauses, GPUCSRGraph &vars) {
  freeTinyGraph(clauses);
  freeTinyGraph(vars);
}

// ============================================================
// main
// ============================================================

int main() {
  GPUCSRGraph clauses;
  GPUCSRGraph vars;
  Edge ed;

  int *d_bias_list_vars = NULL;
  int *d_bias_list_len = NULL;

  initTinyGraphs(clauses, vars);
  allocTinyEdge(ed);

  // 给 vars.value 设置一个测试值。
  // var0 = true, var1 = false
  bool h_value[2] = {true, false};
  checkCuda(cudaMemcpy(vars.value,
                       h_value,
                       2 * sizeof(bool),
                       cudaMemcpyHostToDevice),
            "copy vars.value");

  checkCuda(cudaMalloc((void**)&d_bias_list_vars, 2 * sizeof(int)),
            "malloc bias_list_vars");
  checkCuda(cudaMalloc((void**)&d_bias_list_len, sizeof(int)),
            "malloc bias_list_len");

  // 模拟已经排序后的 bias_list_vars。
  // bias_list_len = 2，fixperstep = 1 时，只会固定最后一个变量 var1。
  int h_list[2] = {0, 1};
  int h_bias_list_len = 2;

  checkCuda(cudaMemcpy(d_bias_list_vars,
                       h_list,
                       2 * sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy bias_list_vars");

  checkCuda(cudaMemcpy(d_bias_list_len,
                       &h_bias_list_len,
                       sizeof(int),
                       cudaMemcpyHostToDevice),
            "copy bias_list_len");

  dim3 block(128);
  dim3 grid(1);

  decimate_2<<<grid, block>>>(clauses,
                              vars,
                              ed,
                              d_bias_list_vars,
                              d_bias_list_len,
                              1);

  checkCuda(cudaGetLastError(), "decimate_2 launch failed");
  checkCuda(cudaDeviceSynchronize(), "decimate_2 execution failed");

  bool h_clauses_sat_bool[2];
  bool h_vars_sat_bool[2];

  checkCuda(cudaMemcpy(h_clauses_sat_bool,
                       clauses.sat,
                       2 * sizeof(bool),
                       cudaMemcpyDeviceToHost),
            "copy clauses.sat");

  checkCuda(cudaMemcpy(h_vars_sat_bool,
                       vars.sat,
                       2 * sizeof(bool),
                       cudaMemcpyDeviceToHost),
            "copy vars.sat");

  printf("decimate_2 finished\n");
  printf("clauses.sat[0]=%d clauses.sat[1]=%d\n",
         (int)h_clauses_sat_bool[0],
         (int)h_clauses_sat_bool[1]);
  printf("vars.sat[0]=%d vars.sat[1]=%d\n",
         (int)h_vars_sat_bool[0],
         (int)h_vars_sat_bool[1]);

  cudaFree(d_bias_list_vars);
  cudaFree(d_bias_list_len);

  freeTinyEdge(ed);
  destroyTinyGraphs(clauses, vars);

  return 0;
}