// Auto-generated CUDA kernel file: atax_kernel1
// Extracted from: polybench-gpu-1.0/CUDA/ATAX/atax.cu
// Original line: 84

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define NX 4096  // from line 26
#define NY 4096  // from line 27

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/ATAX/atax.cu:38

// ===== Kernel =====
// Kernel: atax_kernel1 (line 84)
__global__ void atax_kernel1(DATA_TYPE *A, DATA_TYPE *x, DATA_TYPE *tmp) {

	int i = blockIdx.x * blockDim.x + threadIdx.x;

	if (i < NX)
	{
		int j;
		for(j=0; j < NY; j++)
		{
			tmp[i] += A[i * NY + j] * x[j];
		}
	}

}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_A = (size_t)NX * NY;
    const size_t size_x = NY;
    const size_t size_tmp = NX;

    DATA_TYPE *h_A = (DATA_TYPE*)malloc(size_A * sizeof(DATA_TYPE));
    DATA_TYPE *h_x = (DATA_TYPE*)malloc(size_x * sizeof(DATA_TYPE));
    DATA_TYPE *h_tmp = (DATA_TYPE*)malloc(size_tmp * sizeof(DATA_TYPE));

    DATA_TYPE *d_A = nullptr;
    DATA_TYPE *d_x = nullptr;
    DATA_TYPE *d_tmp = nullptr;

    if (!h_A || !h_x || !h_tmp) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_A; ++i) h_A[i] = (DATA_TYPE)(i % 100) / 100.0f;
    for (size_t i = 0; i < size_x; ++i) h_x[i] = (DATA_TYPE)(i % 100) / 100.0f;
    for (size_t i = 0; i < size_tmp; ++i) h_tmp[i] = 0;

    err = cudaMalloc((void**)&d_A, size_A * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_A failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_x, size_x * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_x failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_tmp, size_tmp * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_tmp failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_A, h_A, size_A * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D A failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_x, h_x, size_x * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D x failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_tmp, h_tmp, size_tmp * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D tmp failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((NX + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    atax_kernel1<<<gridSize, blockSize>>>(d_A, d_x, d_tmp);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("Kernel1 execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_tmp, d_tmp, size_tmp * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H tmp failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("tmp[0] = %f\n", (double)h_tmp[0]);

    cudaFree(d_A);
    cudaFree(d_x);
    cudaFree(d_tmp);
    free(h_A);
    free(h_x);
    free(h_tmp);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}