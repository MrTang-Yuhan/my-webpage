// Standalone version for single_kernel_dfindelemin.cu

#include "common.h"
#include "graph.h"
#include "component.h"
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MYINFINITY 100000000
#define dprintf if (debug) printf

// ===== Kernel =====
__global__ void dfindelemin(unsigned *mstwt, Graph graph, ComponentSpace cs,
                            foru *eleminwts, foru *minwtcomponent,
                            unsigned *partners, unsigned *phore,
                            bool *processinnextiteration,
                            unsigned *goaheadnodeofcomponent,
                            unsigned inpid) {
    unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
    if (inpid < graph.nnodes) id = inpid;

    if (id < graph.nnodes) {
        unsigned src = id;
        unsigned srcboss = cs.find(src);
        unsigned dstboss = graph.nnodes;
        foru minwt = MYINFINITY;
        unsigned degree = graph.getOutDegree(src);

        for (unsigned ii = 0; ii < degree; ++ii) {
            foru wt = graph.getWeight(src, ii);
            if (wt < minwt) {
                unsigned dst = graph.getDestination(src, ii);
                unsigned tempdstboss = cs.find(dst);
                if (srcboss != tempdstboss) {
                    minwt = wt;
                    dstboss = tempdstboss;
                }
            }
        }

        dprintf("\tminwt[%d] = %d\n", id, minwt);
        eleminwts[id] = minwt;
        partners[id] = dstboss;

        if (minwt < minwtcomponent[srcboss] && srcboss != dstboss) {
            atomicMin(&minwtcomponent[srcboss], minwt);
        }
    }
}

static void build_test_graph(Graph &hg) {
    hg.nnodes = 3;
    hg.nedges = 6;
    hg.allocOnHost();

    for (unsigned i = 0; i < hg.nnodes; i++) hg.srcsrc[i] = i;

    hg.psrc[0] = 1; hg.psrc[1] = 3; hg.psrc[2] = 5;
    hg.noutgoing[0] = 2; hg.noutgoing[1] = 2; hg.noutgoing[2] = 2;
    hg.nincoming[0] = 2; hg.nincoming[1] = 2; hg.nincoming[2] = 2;

    hg.edgessrcdst[1] = 1; hg.edgessrcwt[1] = 1;
    hg.edgessrcdst[2] = 2; hg.edgessrcwt[2] = 4;
    hg.edgessrcdst[3] = 0; hg.edgessrcwt[3] = 1;
    hg.edgessrcdst[4] = 2; hg.edgessrcwt[4] = 2;
    hg.edgessrcdst[5] = 0; hg.edgessrcwt[5] = 4;
    hg.edgessrcdst[6] = 1; hg.edgessrcwt[6] = 2;
}

int main() {
    Graph hgraph, graph;
    build_test_graph(hgraph);
    hgraph.cudaCopy(graph);

    ComponentSpace cs(graph.nnodes);

    unsigned *mstwt = NULL;
    foru *eleminwts = NULL, *minwtcomponent = NULL;
    unsigned *partners = NULL, *phore = NULL, *goahead = NULL;
    bool *process = NULL;

    unsigned hmstwt = 0;
    foru h_init_min[3] = {MYINFINITY, MYINFINITY, MYINFINITY};
    unsigned h_init_partners[3] = {graph.nnodes, graph.nnodes, graph.nnodes};
    unsigned h_zero_u[3] = {0, 0, 0};
    bool h_zero_b[3] = {false, false, false};

    cudaMalloc((void **)&mstwt, sizeof(unsigned));
    cudaMemcpy(mstwt, &hmstwt, sizeof(unsigned), cudaMemcpyHostToDevice);

    cudaMalloc((void **)&eleminwts, 3 * sizeof(foru));
    cudaMalloc((void **)&minwtcomponent, 3 * sizeof(foru));
    cudaMalloc((void **)&partners, 3 * sizeof(unsigned));
    cudaMalloc((void **)&phore, 3 * sizeof(unsigned));
    cudaMalloc((void **)&process, 3 * sizeof(bool));
    cudaMalloc((void **)&goahead, 3 * sizeof(unsigned));

    cudaMemcpy(eleminwts, h_init_min, 3 * sizeof(foru), cudaMemcpyHostToDevice);
    cudaMemcpy(minwtcomponent, h_init_min, 3 * sizeof(foru), cudaMemcpyHostToDevice);
    cudaMemcpy(partners, h_init_partners, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(phore, h_zero_u, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(process, h_zero_b, 3 * sizeof(bool), cudaMemcpyHostToDevice);
    cudaMemcpy(goahead, h_init_partners, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);

    dfindelemin<<<1, 128>>>(mstwt, graph, cs, eleminwts, minwtcomponent, partners, phore, process, goahead, graph.nnodes);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    foru h_elemin[3], h_mincomp[3];
    unsigned h_partners[3];
    cudaMemcpy(h_elemin, eleminwts, 3 * sizeof(foru), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_mincomp, minwtcomponent, 3 * sizeof(foru), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_partners, partners, 3 * sizeof(unsigned), cudaMemcpyDeviceToHost);

    printf("dfindelemin finished\n");
    for (int i = 0; i < 3; i++) {
        printf("i=%d elemin=%u partner=%u minwtcomponent=%u\n",
               i, h_elemin[i], h_partners[i], h_mincomp[i]);
    }

    cudaFree(mstwt);
    cudaFree(eleminwts);
    cudaFree(minwtcomponent);
    cudaFree(partners);
    cudaFree(phore);
    cudaFree(process);
    cudaFree(goahead);
    graph.deallocOnDevice();
    hgraph.deallocOnHost();

    return 0;
}