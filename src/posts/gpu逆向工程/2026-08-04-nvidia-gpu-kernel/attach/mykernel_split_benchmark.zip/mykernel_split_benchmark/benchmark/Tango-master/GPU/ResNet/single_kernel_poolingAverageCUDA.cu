// Auto-generated CUDA kernel file: poolingAverageCUDA
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 500

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: poolingAverageCUDA (line 500)
__global__ void poolingAverageCUDA(float *Layer2_Neurons_GPU,float *Layer2_pool_GPU,int out,int out_fr,int out_fc,int kernel,int stride_width,int in_fr,int in_fc,int pad) {

	float sum = 0.0;
        int loopr = kernel, loopc = kernel;
	int stride = 0,colstride = 0;
	{
		int output = blockIdx.x;//for(int output =0;output < out ;output++)
		{
                        int row = 0;
			{  
                                colstride = (row*stride_width -pad)*in_fr;	
				colstride = colstride < 0 ? 0: colstride; 
				stride = 0;
				int col = 0;
                                {
					loopr = kernel; loopc = kernel;
					stride = col*stride_width - pad;	
                                        stride = stride < 0 ? 0: stride; 
                                        
					for(int i = 0; i < loopr; i++)
					{			
						for(int j = 0; j < loopc; j++)
						{
							sum += Layer2_Neurons_GPU[(output*in_fr*in_fc) + i*in_fc + j + stride + colstride] ;

						}
					}
					Layer2_pool_GPU[output] = (sum/(loopc*loopr));
#ifdef POOL_DEBUG			
					printf("\n %f %d\n",max,downsample);
#endif	
					sum = 0.0;
				}
			}
		}
	}

}

int main() {
    const int out = 8;
    const int in_fr = 4;
    const int in_fc = 4;
    const int out_fr = 1;
    const int out_fc = 1;
    const int kernel = 4;
    const int stride_width = 1;
    const int pad = 0;
 
    size_t input_size = (size_t)out * in_fr * in_fc;
    size_t output_size = out;
 
    float *h_in = (float*)malloc(input_size * sizeof(float));
    float *h_out = (float*)malloc(output_size * sizeof(float));
 
    if (!h_in || !h_out) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }
 
    for (size_t i = 0; i < input_size; ++i) {
        h_in[i] = (float)(i % 17) * 0.1f;
    }
 
    float *d_in = NULL, *d_out = NULL;
    CHECK(cudaMalloc((void**)&d_in, input_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_out, output_size * sizeof(float)));
 
    CHECK(cudaMemcpy(d_in, h_in, input_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_out, 0, output_size * sizeof(float)));
 
    dim3 grid(out);
    dim3 block(1);
 
    poolingAverageCUDA<<<grid, block>>>(
        d_in, d_out, out, out_fr, out_fc, kernel, stride_width, in_fr, in_fc, pad
    );
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());
 
    CHECK(cudaMemcpy(h_out, d_out, output_size * sizeof(float), cudaMemcpyDeviceToHost));
 
    printf("poolingAverageCUDA done.\n");
    for (int i = 0; i < out; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }
 
    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);
 
    return 0;
}