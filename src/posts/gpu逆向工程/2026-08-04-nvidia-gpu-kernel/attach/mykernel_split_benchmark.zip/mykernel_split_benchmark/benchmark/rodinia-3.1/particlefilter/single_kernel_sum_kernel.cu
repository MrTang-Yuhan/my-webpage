// Auto-generated CUDA kernel file: sum_kernel
// Extracted from: rodinia-3.1/particlefilter/single_kernel_sum_kernel.cu
// Original line: 21

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>
#include <float.h>
#include <sys/time.h>

// ===== Global Variables =====
const int threads_per_block = 512;  // [来源: 全局作用域定义, line 14]  // [来源: 全局作用域定义, line 17]

// ===== Kernel =====
// Kernel: sum_kernel (line 21)
__global__ void sum_kernel(double* partial_sums, int Nparticles) {


    int block_id = blockIdx.x;
    int i = blockDim.x * block_id + threadIdx.x;

    if (i == 0) {
        int x;
        double sum = 0.0;
        int num_blocks = ceil((double) Nparticles / (double) threads_per_block);
        for (x = 0; x < num_blocks; x++) {
            sum += partial_sums[x];
        }
        partial_sums[0] = sum;
    }


}

#include <cuda_runtime.h>

static void checkCuda(cudaError_t err, const char* msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "CUDA error at %s: %s\n", msg, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

int main() {
    const int Nparticles = 2048;
    const int num_blocks = (int)ceil((double)Nparticles / (double)threads_per_block);

    double *h_partial_sums = (double*)malloc(sizeof(double) * num_blocks);
    for (int i = 0; i < num_blocks; i++) {
        h_partial_sums[i] = 1.0 + i;
    }

    double *d_partial_sums;
    checkCuda(cudaMalloc((void**)&d_partial_sums, sizeof(double) * num_blocks), "cudaMalloc d_partial_sums");
    checkCuda(cudaMemcpy(d_partial_sums, h_partial_sums, sizeof(double) * num_blocks, cudaMemcpyHostToDevice), "copy partial_sums");

    sum_kernel<<<1, 1>>>(d_partial_sums, Nparticles);

    checkCuda(cudaGetLastError(), "launch sum_kernel");
    checkCuda(cudaDeviceSynchronize(), "sync sum_kernel");

    checkCuda(cudaMemcpy(h_partial_sums, d_partial_sums, sizeof(double) * num_blocks, cudaMemcpyDeviceToHost), "copy back partial_sums");

    printf("sum_kernel finished.\n");
    printf("sum = %f\n", h_partial_sums[0]);

    cudaFree(d_partial_sums);
    free(h_partial_sums);
    return 0;
}