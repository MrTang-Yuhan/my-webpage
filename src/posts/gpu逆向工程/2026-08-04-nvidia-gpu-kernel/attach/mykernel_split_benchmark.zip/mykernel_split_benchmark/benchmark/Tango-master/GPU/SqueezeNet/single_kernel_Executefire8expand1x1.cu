// Auto-generated CUDA kernel file: Executefire8expand1x1
// Extracted from: Tango-master/GPU/SqueezeNet/SN.cu
// Original line: 1867

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: Executefire8expand1x1 (line 1867)
__global__ void Executefire8expand1x1(double *fire8expand1x1_Weights_GPU, double *fire8_Features, double *fire8squeeze1x1_Features) {

	double Features = 0;
	int x = threadIdx.x;
	int y = blockIdx.x;
	for(int f=0; f<256; f++)
	{
		Features = 0;
		for(int n=0; n<64; n++)
		{
			double result = 0;
               		result = fire8squeeze1x1_Features[n*27*27 + x*27 + y]*fire8expand1x1_Weights_GPU[f*64+n];
			//if(x==0 && y==0 && f==0)
				//printf("(%.8f,%.8f) ", result, fire2expand1x1_Weights_GPU[f*16+n]);
			Features+= result;
		}
		//ReLU activation function computation
		if(Features<0)
			Features = 0;
		fire8_Features[f*27*27 + x*27+ y] = Features;
	}
	__syncthreads();
	//if(x == 0 && y == 0)
		//printf("\nFire 8 expand: %.8f \n", fire8_Features[35330]);

}

int main() {
    const int in_channels = 64;
    const int out_channels = 256;
    const int H = 27, W = 27;

    size_t weight_size = (size_t)out_channels * in_channels;
    size_t input_size  = (size_t)in_channels * H * W;
    size_t output_size = (size_t)out_channels * H * W;

    double *h_weight = (double*)malloc(weight_size * sizeof(double));
    double *h_input  = (double*)malloc(input_size * sizeof(double));
    double *h_output = (double*)malloc(output_size * sizeof(double));

    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (double)(i % 19) * 0.001;
    for (size_t i = 0; i < input_size;  ++i) h_input[i]  = (double)(i % 11) * 0.01;

    double *d_weight = NULL, *d_input = NULL, *d_output = NULL;
    cudaMalloc((void**)&d_weight, weight_size * sizeof(double));
    cudaMalloc((void**)&d_input,  input_size * sizeof(double));
    cudaMalloc((void**)&d_output, output_size * sizeof(double));

    cudaMemcpy(d_weight, h_weight, weight_size * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemcpy(d_input,  h_input,  input_size * sizeof(double),  cudaMemcpyHostToDevice);
    cudaMemset(d_output, 0, output_size * sizeof(double));

    dim3 grid(W);
    dim3 block(H);

    Executefire8expand1x1<<<grid, block>>>(d_weight, d_output, d_input);
    cudaDeviceSynchronize();

    cudaMemcpy(h_output, d_output, output_size * sizeof(double), cudaMemcpyDeviceToHost);

    printf("Executefire8expand1x1 done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("output[%d] = %f\n", i, h_output[i]);
    }

    cudaFree(d_weight);
    cudaFree(d_input);
    cudaFree(d_output);
    free(h_weight);
    free(h_input);
    free(h_output);

    return 0;
}