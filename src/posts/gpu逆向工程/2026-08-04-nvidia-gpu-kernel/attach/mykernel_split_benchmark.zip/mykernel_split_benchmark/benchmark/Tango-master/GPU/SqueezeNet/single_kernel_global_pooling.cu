// Auto-generated CUDA kernel file: global_pooling
// Extracted from: Tango-master/GPU/SqueezeNet/SN.cu
// Original line: 2102

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

// ===== Kernel =====
// Kernel: global_pooling (line 2102)
__global__ void global_pooling(double *Layer10_Features,double *output_GPU) {

    int tid = threadIdx.x;
    double avg = 0.0;
    for(int i = 0; i < 15; i++)
    {           
        for(int j = 0; j <= 15; j++)
        {
		avg+= Layer10_Features[tid*225 + i*15 + j];
        }   
    }
    output_GPU[tid] = avg/225;
    __syncthreads();
    //if(tid==0)
	//printf("Global pool o/p: %.8f\n", output_GPU[1]);

}

#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    const int out = 1000;  // 假设 1000 个通道（根据 SN 结构）
    const int feat_size = 15 * 15;  // 15x15 feature map

    size_t input_size = (size_t)out * feat_size;
    size_t output_size = out;

    double *h_in  = (double*)malloc(input_size * sizeof(double));
    double *h_out = (double*)malloc(output_size * sizeof(double));

    if (!h_in || !h_out) return -1;

    for (size_t i = 0; i < input_size; ++i) h_in[i] = (double)(i % 17) * 0.01;

    double *d_in = nullptr, *d_out = nullptr;
    cudaMalloc(&d_in, input_size * sizeof(double));
    cudaMalloc(&d_out, output_size * sizeof(double));

    cudaMemcpy(d_in, h_in, input_size * sizeof(double), cudaMemcpyHostToDevice);
    cudaMemset(d_out, 0, output_size * sizeof(double));

    dim3 block(1000);
    dim3 grid(1);

    global_pooling<<<grid, block>>>(d_in, d_out);

    cudaDeviceSynchronize();
    if (cudaGetLastError() != cudaSuccess) {
        fprintf(stderr, "CUDA error in global_pooling.\n");
        return -1;
    }

    cudaMemcpy(h_out, d_out, output_size * sizeof(double), cudaMemcpyDeviceToHost);

    printf("global_pooling done. out[0] = %f\n", h_out[0]);

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);
    return 0;
}