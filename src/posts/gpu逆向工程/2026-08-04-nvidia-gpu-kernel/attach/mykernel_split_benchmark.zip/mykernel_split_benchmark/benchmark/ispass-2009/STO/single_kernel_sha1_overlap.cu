// Auto-generated CUDA kernel file: sha1_overlap
// Extracted from: ispass-2009/STO/sha1_kernel.cu
// Original line: 1109

// ===== Includes =====
#include "cust.h"
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ===== Macro Definitions =====
#define F(x,y,z) (x ^ y ^ z)  // from line 1011
#define FEATURE_REDUCED_HASH_SIZE  // from line 63 (from ispass-2009/STO/cust.h)
#define FEATURE_SHARED_MEMORY  // from line 56 (from ispass-2009/STO/cust.h)
#define GET_CACHED_INDEX(index) (x##index)  // from line 800
#define GET_UINT32_BE(n,b,i)                            \
{                                                       \
    (n) = ( (unsigned long) (b)[(i)    ] << 24 )        \
        | ( (unsigned long) (b)[(i) + 1] << 16 )        \
        | ( (unsigned long) (b)[(i) + 2] <<  8 )        \
        | ( (unsigned long) (b)[(i) + 3]       );       \
}  // from line 92
#define K 0xCA62C1D6  // from line 1012
#define P(a,b,c,d,e,x)                                  \
{                                                       \
    e += S(a,5) + F(b,c,d) + K + x; b = S(b,30);        \
}  // from line 917
#define PUT_UINT32_BE(n,b,i)                            \
{                                                       \
    (b)[(i)    ] = (unsigned char) ( (n) >> 24 );       \
    (b)[(i) + 1] = (unsigned char) ( (n) >> 16 );       \
    (b)[(i) + 2] = (unsigned char) ( (n) >>  8 );       \
    (b)[(i) + 3] = (unsigned char) ( (n)       );       \
}  // from line 102
#define R(t)                                            \
(                                                       \
    temp = sharedMemory[SHARED_MEMORY_INDEX((t -  3) & 0x0F)] ^ sharedMemory[SHARED_MEMORY_INDEX((t - 8) & 0x0F)] ^     \
           sharedMemory[SHARED_MEMORY_INDEX((t - 14) & 0x0F)] ^ sharedMemory[SHARED_MEMORY_INDEX( t      & 0x0F)],      \
    ( sharedMemory[SHARED_MEMORY_INDEX(t & 0x0F)] = S(temp,1) )                         \
)  // from line 908
#define S(x,n) ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n)))  // from line 897
  #define SHA1_HASH_SIZE   20  // from line 111 (from ispass-2009/STO/cust.h)
#define SHARED_MEMORY_INDEX(index) (32 * (index) + (threadIdx.x & 0x1F))  // from line 114

// ===== Global Variables =====
int t = 1;  // global (from ispass-2009/RAY/rayTracing.cu:108)

// ===== Function Forward Declarations =====
__device__
static void sha1_internal( unsigned int *input, unsigned int *sharedMemory, 
			  unsigned int chunkSize, unsigned char *output );
__device__
static void sha1_internal_overlap( unsigned int *input, unsigned int *sharedMemory, 
			  unsigned int chunkSize, unsigned char *output );

// ===== Device/Helper Functions =====
__device__
unsigned long macroRFunction(int t, unsigned int *sharedMemory) {
	return sharedMemory[SHARED_MEMORY_INDEX((t -  3) & 0x0F)] ^ sharedMemory[SHARED_MEMORY_INDEX((t - 8) & 0x0F)] ^
           sharedMemory[SHARED_MEMORY_INDEX((t - 14) & 0x0F)] ^ sharedMemory[SHARED_MEMORY_INDEX( t      & 0x0F)];
}
// Function: sha1_internal (from ispass-2009/STO/sha1_kernel.cu:484)
__device__
static void sha1_internal( unsigned int *input, unsigned int *sharedMemory, 
			  unsigned int chunkSize, unsigned char *output ) {


  /* Number of passes (512 bit blocks) we have to do */
  int numberOfPasses = chunkSize / 64 + 1;
  /* Used during the hashing process */
  unsigned long temp, A, B, C, D ,E;
  //unsigned long shared14, shared15;
  /* Needed to do the little endian stuff */
  unsigned char *data = (unsigned char *)sharedMemory;

  /* Will hold the hash value through the 
     intermediate stages of SHA1 algorithm */
  unsigned int state0 = 0x67452301;
  unsigned int state1 = 0xEFCDAB89;
  unsigned int state2 = 0x98BADCFE;
  unsigned int state3 = 0x10325476;
  unsigned int state4 = 0xC3D2E1F0;

  
/*  int x0 = SHARED_MEMORY_INDEX(0);
  int x1 = SHARED_MEMORY_INDEX(1);
  int x2 = SHARED_MEMORY_INDEX(2);
  int x3 = SHARED_MEMORY_INDEX(3);
  int x4 = SHARED_MEMORY_INDEX(4);
  int x5 = SHARED_MEMORY_INDEX(5);
  int x6 = SHARED_MEMORY_INDEX(6);
  int x7 = SHARED_MEMORY_INDEX(7);
  int x8 = SHARED_MEMORY_INDEX(8);
  int x9 = SHARED_MEMORY_INDEX(9);
  int x10 = SHARED_MEMORY_INDEX(10);
  int x11 = SHARED_MEMORY_INDEX(11);
  int x12 = SHARED_MEMORY_INDEX(12);
  int x13 = SHARED_MEMORY_INDEX(13);
  int x14 = SHARED_MEMORY_INDEX(14);
  int x15 = SHARED_MEMORY_INDEX(15);
*/
#undef GET_CACHED_INDEX
#define GET_CACHED_INDEX(index) SHARED_MEMORY_INDEX(index)//(x##index)


  for( int index = 0 ; index < (numberOfPasses) ; index++ ) {

    /* Move data to the thread's shared memory space */
    sharedMemory[GET_CACHED_INDEX(0)] = input[0 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(1)] = input[1 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(2)] = input[2 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(3)] = input[3 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(4)] = input[4 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(5)] = input[5 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(6)] = input[6 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(7)] = input[7 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(8)] = input[8 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(9)] = input[9 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(10)] = input[10 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(11)] = input[11 + 16 * index];
    sharedMemory[GET_CACHED_INDEX(12)] = input[12 + 16 * index];

    /* Testing the code with and without this if statement shows that
       it has no effect on performance. */
    if(index == numberOfPasses -1 ) {
      /* The last pass will contain the size of the chunk size (according to
	 official SHA1 algorithm). */
      sharedMemory[GET_CACHED_INDEX(13)] = 0x00000080;

	  PUT_UINT32_BE( chunkSize >> 29, 
		   data, GET_CACHED_INDEX(14) * 4 );
      PUT_UINT32_BE( chunkSize << 3, 
		   data, GET_CACHED_INDEX(15) * 4 );

    }
    else {
      sharedMemory[GET_CACHED_INDEX(13)] = input[13 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(14)] = input[14 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(15)] = input[15 + 16 * index];
    }

	/* Get the little endian stuff done. */
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(0)], 
		   data, GET_CACHED_INDEX(0) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(1)], 
		   data, GET_CACHED_INDEX(1) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(2)], 
		   data, GET_CACHED_INDEX(2) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(3)], 
		   data, GET_CACHED_INDEX(3) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(4)], 
		   data, GET_CACHED_INDEX(4) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(5)], 
		   data, GET_CACHED_INDEX(5) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(6)], 
		   data, GET_CACHED_INDEX(6) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(7)], 
		   data, GET_CACHED_INDEX(7) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(8)], 
		   data, GET_CACHED_INDEX(8) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(9)], 
		   data, GET_CACHED_INDEX(9) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(10)], 
		   data, GET_CACHED_INDEX(10) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(11)], 
		   data, GET_CACHED_INDEX(11) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(12)], 
		   data, GET_CACHED_INDEX(12) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(13)], 
		   data, GET_CACHED_INDEX(13) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(14)], 
		   data, GET_CACHED_INDEX(14) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(15)], 
		   data, GET_CACHED_INDEX(15) * 4 );


#undef S
#define S(x,n) ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n)))


#undef R
#define R(t)                                            \
(                                                       \
    temp = macroRFunction(t, sharedMemory) ,      \
    ( sharedMemory[SHARED_MEMORY_INDEX(t & 0x0F)] = S(temp,1) )       \
)

/*
#define R(t)                                            \
(                                                       \
    temp = sharedMemory[SHARED_MEMORY_INDEX((t -  3) & 0x0F)] ^ sharedMemory[SHARED_MEMORY_INDEX((t - 8) & 0x0F)] ^     \
           sharedMemory[SHARED_MEMORY_INDEX((t - 14) & 0x0F)] ^ sharedMemory[SHARED_MEMORY_INDEX( t      & 0x0F)],      \
    ( sharedMemory[SHARED_MEMORY_INDEX(t & 0x0F)] = S(temp,1) )                         \
)
*/

#undef P
#define P(a,b,c,d,e,x)                                  \
{                                                       \
    e += S(a,5) + F(b,c,d) + K + x; b = S(b,30);        \
}

    A = state0;
    B = state1;
    C = state2;
    D = state3;
    E = state4;


#define F(x,y,z) (z ^ (x & (y ^ z)))
#define K 0x5A827999

    P( A, B, C, D, E, sharedMemory[ GET_CACHED_INDEX(0)]  );
    P( E, A, B, C, D, sharedMemory[ GET_CACHED_INDEX(1)]  );
    P( D, E, A, B, C, sharedMemory[ GET_CACHED_INDEX(2)]  );
    P( C, D, E, A, B, sharedMemory[ GET_CACHED_INDEX(3)]  );
    P( B, C, D, E, A, sharedMemory[ GET_CACHED_INDEX(4)]  );
    P( A, B, C, D, E, sharedMemory[ GET_CACHED_INDEX(5)]  );
    P( E, A, B, C, D, sharedMemory[ GET_CACHED_INDEX(6)]  );
    P( D, E, A, B, C, sharedMemory[ GET_CACHED_INDEX(7)]  );
    P( C, D, E, A, B, sharedMemory[ GET_CACHED_INDEX(8)]  );
    P( B, C, D, E, A, sharedMemory[ GET_CACHED_INDEX(9)]  );
    P( A, B, C, D, E, sharedMemory[ GET_CACHED_INDEX(10)] );
    P( E, A, B, C, D, sharedMemory[ GET_CACHED_INDEX(11)] );
    P( D, E, A, B, C, sharedMemory[ GET_CACHED_INDEX(12)] );
    P( C, D, E, A, B, sharedMemory[ GET_CACHED_INDEX(13)] );
    P( B, C, D, E, A, sharedMemory[ GET_CACHED_INDEX(14)] );
    P( A, B, C, D, E, sharedMemory[ GET_CACHED_INDEX(15)] );
    P( E, A, B, C, D, R(16) );
    P( D, E, A, B, C, R(17) );
    P( C, D, E, A, B, R(18) );
    P( B, C, D, E, A, R(19) );


#undef K
#undef F

#define F(x,y,z) (x ^ y ^ z)
#define K 0x6ED9EBA1

    P( A, B, C, D, E, R(20) );
    P( E, A, B, C, D, R(21) );
    P( D, E, A, B, C, R(22) );
    P( C, D, E, A, B, R(23) );
    P( B, C, D, E, A, R(24) );
    P( A, B, C, D, E, R(25) );
    P( E, A, B, C, D, R(26) );
    P( D, E, A, B, C, R(27) );
    P( C, D, E, A, B, R(28) );
    P( B, C, D, E, A, R(29) );
    P( A, B, C, D, E, R(30) );
    P( E, A, B, C, D, R(31) );
    P( D, E, A, B, C, R(32) );
    P( C, D, E, A, B, R(33) );
    P( B, C, D, E, A, R(34) );
    P( A, B, C, D, E, R(35) );
    P( E, A, B, C, D, R(36) );
    P( D, E, A, B, C, R(37) );
    P( C, D, E, A, B, R(38) );
    P( B, C, D, E, A, R(39) );

#undef K
#undef F

#define F(x,y,z) ((x & y) | (z & (x | y)))
#define K 0x8F1BBCDC

    P( A, B, C, D, E, R(40) );
    P( E, A, B, C, D, R(41) );
    P( D, E, A, B, C, R(42) );
    P( C, D, E, A, B, R(43) );
    P( B, C, D, E, A, R(44) );
    P( A, B, C, D, E, R(45) );
    P( E, A, B, C, D, R(46) );
    P( D, E, A, B, C, R(47) );
    P( C, D, E, A, B, R(48) );
    P( B, C, D, E, A, R(49) );
    P( A, B, C, D, E, R(50) );
    P( E, A, B, C, D, R(51) );
    P( D, E, A, B, C, R(52) );
    P( C, D, E, A, B, R(53) );
    P( B, C, D, E, A, R(54) );
    P( A, B, C, D, E, R(55) );
    P( E, A, B, C, D, R(56) );
    P( D, E, A, B, C, R(57) );
    P( C, D, E, A, B, R(58) );
    P( B, C, D, E, A, R(59) );

#undef K
#undef F

#define F(x,y,z) (x ^ y ^ z)
#define K 0xCA62C1D6

    P( A, B, C, D, E, R(60) );
    P( E, A, B, C, D, R(61) );
    P( D, E, A, B, C, R(62) );
    P( C, D, E, A, B, R(63) );
    P( B, C, D, E, A, R(64) );
    P( A, B, C, D, E, R(65) );
    P( E, A, B, C, D, R(66) );
    P( D, E, A, B, C, R(67) );
    P( C, D, E, A, B, R(68) );
    P( B, C, D, E, A, R(69) );
    P( A, B, C, D, E, R(70) );
    P( E, A, B, C, D, R(71) );
    P( D, E, A, B, C, R(72) );
    P( C, D, E, A, B, R(73) );
    P( B, C, D, E, A, R(74) );
    P( A, B, C, D, E, R(75) );
    P( E, A, B, C, D, R(76) );
    P( D, E, A, B, C, R(77) );
    P( C, D, E, A, B, R(78) );
    P( B, C, D, E, A, R(79) );

#undef K
#undef F

    state0 += A;
    state1 += B;
    state2 += C;
    state3 += D;
    state4 += E;
	}

	/* Got the hash, store it in the output buffer. */
	PUT_UINT32_BE( state0, output,  0 );
#ifndef FEATURE_REDUCED_HASH_SIZE
	PUT_UINT32_BE( state1, output,  4 );
	PUT_UINT32_BE( state2, output,  8 );
	PUT_UINT32_BE( state3, output, 12 );
	PUT_UINT32_BE( state4, output, 16 );
#endif


}

// Function: sha1_internal_overlap (from ispass-2009/STO/sha1_kernel.cu:757)
__device__
static void sha1_internal_overlap( unsigned int *input, unsigned int *sharedMemory, 
			  unsigned int chunkSize, unsigned char *output ) {


  /* Number of passes (512 bit blocks) we have to do */
  int numberOfPasses = chunkSize / 64 + 1;
  /* Used during the hashing process */
  unsigned long temp, A, B, C, D ,E;
  //unsigned long shared14, shared15;
  /* Needed to do the big endian stuff */
  unsigned char *data = (unsigned char *)sharedMemory;
  // number of padding bytes.
  int numPadBytes = 0;
  int numPadInt = 0;
  //int numPadRemain = 0;

  /* Will hold the hash value through the 
     intermediate stages of SHA1 algorithm */
  unsigned int state0 = 0x67452301;
  unsigned int state1 = 0xEFCDAB89;
  unsigned int state2 = 0x98BADCFE;
  unsigned int state3 = 0x10325476;
  unsigned int state4 = 0xC3D2E1F0;

  
  int x0 = SHARED_MEMORY_INDEX(0);
  int x1 = SHARED_MEMORY_INDEX(1);
  int x2 = SHARED_MEMORY_INDEX(2);
  int x3 = SHARED_MEMORY_INDEX(3);
  int x4 = SHARED_MEMORY_INDEX(4);
  int x5 = SHARED_MEMORY_INDEX(5);
  int x6 = SHARED_MEMORY_INDEX(6);
  int x7 = SHARED_MEMORY_INDEX(7);
  int x8 = SHARED_MEMORY_INDEX(8);
  int x9 = SHARED_MEMORY_INDEX(9);
  int x10 = SHARED_MEMORY_INDEX(10);
  int x11 = SHARED_MEMORY_INDEX(11);
  int x12 = SHARED_MEMORY_INDEX(12);
  int x13 = SHARED_MEMORY_INDEX(13);
  int x14 = SHARED_MEMORY_INDEX(14);
  int x15 = SHARED_MEMORY_INDEX(15);

#undef GET_CACHED_INDEX
#define GET_CACHED_INDEX(index) (x##index)


  for( int index = 0 ; index < (numberOfPasses) ; index++ ) {
    
    if(index == numberOfPasses -1 ){
      
      numPadBytes = (64-12) - (chunkSize - (numberOfPasses-1)*64);
      numPadInt = numPadBytes/sizeof(int);
      /*numPadRemain = numPadBytes-numPadInt*sizeof(int);
      printf("\nLast loop chunkSize = %d, numberOfPasses= %d and \nnumPadBytes = %d, numPadInt =%d, numPadRemain = %d\n",
	chunkSize,numberOfPasses,numPadBytes,numPadInt,numPadRemain);*/
      
      int i=0;
      for(i=0;i<numPadInt;i++){
	sharedMemory[SHARED_MEMORY_INDEX(13-i)] = 0;
      }
      int j=0;
      for(j=0;j<(16-3-numPadInt);j++){
	//printf("j= %d\n",j);
	sharedMemory[SHARED_MEMORY_INDEX(j)] = input[j + 16 * index];
      }
      
      
      /* The last pass will contain the size of the chunk size (according to
	 official SHA1 algorithm). */
      sharedMemory[SHARED_MEMORY_INDEX(13-i)] = 0x00000080;
      //printf("the last one at %d\n",13-i);
      
      PUT_UINT32_BE( chunkSize >> 29, 
		     data, GET_CACHED_INDEX(14) * 4 );
      PUT_UINT32_BE( chunkSize << 3, 
			   data, GET_CACHED_INDEX(15) * 4 );
    }
    else{
      /* Move data to the thread's shared memory space */
      //printf("Not last loop\n");
      sharedMemory[GET_CACHED_INDEX(0)] = input[0 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(1)] = input[1 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(2)] = input[2 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(3)] = input[3 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(4)] = input[4 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(5)] = input[5 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(6)] = input[6 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(7)] = input[7 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(8)] = input[8 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(9)] = input[9 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(10)] = input[10 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(11)] = input[11 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(12)] = input[12 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(13)] = input[13 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(14)] = input[14 + 16 * index];
      sharedMemory[GET_CACHED_INDEX(15)] = input[15 + 16 * index];
    }
    
    /*	  int k=0;
	  printf("\nGPU DATA\n");
	  for(k=0;k<16;k++){
	  printf("%d\t",sharedMemory[SHARED_MEMORY_INDEX(k)]);
	  }
	  printf("\n\n");*/
    
    /* Get the little endian stuff done. */
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(0)], 
		   data, GET_CACHED_INDEX(0) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(1)], 
		   data, GET_CACHED_INDEX(1) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(2)], 
		   data, GET_CACHED_INDEX(2) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(3)], 
		   data, GET_CACHED_INDEX(3) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(4)], 
		   data, GET_CACHED_INDEX(4) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(5)], 
		   data, GET_CACHED_INDEX(5) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(6)], 
		   data, GET_CACHED_INDEX(6) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(7)], 
		   data, GET_CACHED_INDEX(7) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(8)], 
		   data, GET_CACHED_INDEX(8) * 4 );
    GET_UINT32_BE( sharedMemory[ GET_CACHED_INDEX(9)], 
		   data, GET_CACHED_INDEX(9) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(10)], 
		   data, GET_CACHED_INDEX(10) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(11)], 
		   data, GET_CACHED_INDEX(11) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(12)], 
		   data, GET_CACHED_INDEX(12) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(13)], 
		   data, GET_CACHED_INDEX(13) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(14)], 
		   data, GET_CACHED_INDEX(14) * 4 );
    GET_UINT32_BE( sharedMemory[GET_CACHED_INDEX(15)], 
		   data, GET_CACHED_INDEX(15) * 4 );

#undef S
#define S(x,n) ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n)))


#undef R
#define R(t)                                            \
(                                                       \
    temp = macroRFunction(t, sharedMemory) ,      \
    ( sharedMemory[SHARED_MEMORY_INDEX(t & 0x0F)] = S(temp,1) )       \
)

/*
#define R(t)                                            \
(                                                       \
    temp = sharedMemory[SHARED_MEMORY_INDEX((t -  3) & 0x0F)] ^ sharedMemory[SHARED_MEMORY_INDEX((t - 8) & 0x0F)] ^     \
           sharedMemory[SHARED_MEMORY_INDEX((t - 14) & 0x0F)] ^ sharedMemory[SHARED_MEMORY_INDEX( t      & 0x0F)],      \
    ( sharedMemory[SHARED_MEMORY_INDEX(t & 0x0F)] = S(temp,1) )                         \
)
*/

#undef P
#define P(a,b,c,d,e,x)                                  \
{                                                       \
    e += S(a,5) + F(b,c,d) + K + x; b = S(b,30);        \
}

    A = state0;
    B = state1;
    C = state2;
    D = state3;
    E = state4;


#define F(x,y,z) (z ^ (x & (y ^ z)))
#define K 0x5A827999

    P( A, B, C, D, E, sharedMemory[ GET_CACHED_INDEX(0)]  );
    P( E, A, B, C, D, sharedMemory[ GET_CACHED_INDEX(1)]  );
    P( D, E, A, B, C, sharedMemory[ GET_CACHED_INDEX(2)]  );
    P( C, D, E, A, B, sharedMemory[ GET_CACHED_INDEX(3)]  );
    P( B, C, D, E, A, sharedMemory[ GET_CACHED_INDEX(4)]  );
    P( A, B, C, D, E, sharedMemory[ GET_CACHED_INDEX(5)]  );
    P( E, A, B, C, D, sharedMemory[ GET_CACHED_INDEX(6)]  );
    P( D, E, A, B, C, sharedMemory[ GET_CACHED_INDEX(7)]  );
    P( C, D, E, A, B, sharedMemory[ GET_CACHED_INDEX(8)]  );
    P( B, C, D, E, A, sharedMemory[ GET_CACHED_INDEX(9)]  );
    P( A, B, C, D, E, sharedMemory[ GET_CACHED_INDEX(10)] );
    P( E, A, B, C, D, sharedMemory[ GET_CACHED_INDEX(11)] );
    P( D, E, A, B, C, sharedMemory[ GET_CACHED_INDEX(12)] );
    P( C, D, E, A, B, sharedMemory[ GET_CACHED_INDEX(13)] );
    P( B, C, D, E, A, sharedMemory[ GET_CACHED_INDEX(14)] );
    P( A, B, C, D, E, sharedMemory[ GET_CACHED_INDEX(15)] );
    P( E, A, B, C, D, R(16) );
    P( D, E, A, B, C, R(17) );
    P( C, D, E, A, B, R(18) );
    P( B, C, D, E, A, R(19) );


#undef K
#undef F

#define F(x,y,z) (x ^ y ^ z)
#define K 0x6ED9EBA1

    P( A, B, C, D, E, R(20) );
    P( E, A, B, C, D, R(21) );
    P( D, E, A, B, C, R(22) );
    P( C, D, E, A, B, R(23) );
    P( B, C, D, E, A, R(24) );
    P( A, B, C, D, E, R(25) );
    P( E, A, B, C, D, R(26) );
    P( D, E, A, B, C, R(27) );
    P( C, D, E, A, B, R(28) );
    P( B, C, D, E, A, R(29) );
    P( A, B, C, D, E, R(30) );
    P( E, A, B, C, D, R(31) );
    P( D, E, A, B, C, R(32) );
    P( C, D, E, A, B, R(33) );
    P( B, C, D, E, A, R(34) );
    P( A, B, C, D, E, R(35) );
    P( E, A, B, C, D, R(36) );
    P( D, E, A, B, C, R(37) );
    P( C, D, E, A, B, R(38) );
    P( B, C, D, E, A, R(39) );

#undef K
#undef F

#define F(x,y,z) ((x & y) | (z & (x | y)))
#define K 0x8F1BBCDC

    P( A, B, C, D, E, R(40) );
    P( E, A, B, C, D, R(41) );
    P( D, E, A, B, C, R(42) );
    P( C, D, E, A, B, R(43) );
    P( B, C, D, E, A, R(44) );
    P( A, B, C, D, E, R(45) );
    P( E, A, B, C, D, R(46) );
    P( D, E, A, B, C, R(47) );
    P( C, D, E, A, B, R(48) );
    P( B, C, D, E, A, R(49) );
    P( A, B, C, D, E, R(50) );
    P( E, A, B, C, D, R(51) );
    P( D, E, A, B, C, R(52) );
    P( C, D, E, A, B, R(53) );
    P( B, C, D, E, A, R(54) );
    P( A, B, C, D, E, R(55) );
    P( E, A, B, C, D, R(56) );
    P( D, E, A, B, C, R(57) );
    P( C, D, E, A, B, R(58) );
    P( B, C, D, E, A, R(59) );

#undef K
#undef F

#define F(x,y,z) (x ^ y ^ z)
#define K 0xCA62C1D6

    P( A, B, C, D, E, R(60) );
    P( E, A, B, C, D, R(61) );
    P( D, E, A, B, C, R(62) );
    P( C, D, E, A, B, R(63) );
    P( B, C, D, E, A, R(64) );
    P( A, B, C, D, E, R(65) );
    P( E, A, B, C, D, R(66) );
    P( D, E, A, B, C, R(67) );
    P( C, D, E, A, B, R(68) );
    P( B, C, D, E, A, R(69) );
    P( A, B, C, D, E, R(70) );
    P( E, A, B, C, D, R(71) );
    P( D, E, A, B, C, R(72) );
    P( C, D, E, A, B, R(73) );
    P( B, C, D, E, A, R(74) );
    P( A, B, C, D, E, R(75) );
    P( E, A, B, C, D, R(76) );
    P( D, E, A, B, C, R(77) );
    P( C, D, E, A, B, R(78) );
    P( B, C, D, E, A, R(79) );

#undef K
#undef F

    state0 += A;
    state1 += B;
    state2 += C;
    state3 += D;
    state4 += E;
	}

	/* Got the hash, store it in the output buffer. */
	PUT_UINT32_BE( state0, output,  0 );
#ifndef FEATURE_REDUCED_HASH_SIZE
	PUT_UINT32_BE( state1, output,  4 );
	PUT_UINT32_BE( state2, output,  8 );
	PUT_UINT32_BE( state3, output, 12 );
	PUT_UINT32_BE( state4, output, 16 );
#endif


}

// ===== Kernel =====
// Kernel: sha1_overlap (line 1109)
__global__
void sha1_overlap( unsigned char *input, int chunkSize, int offset,
		   int totalThreads, int padSize, unsigned char *output ) {


  int threadIndex = threadIdx.x + blockDim.x * blockIdx.x;
  int chunkIndex = threadIndex * offset;
  int hashIndex  = threadIndex * SHA1_HASH_SIZE;

  if(threadIndex >= totalThreads)
    return;
  
  if ((threadIndex == (totalThreads - 1))) {
    chunkSize-= padSize;
  }

#ifdef FEATURE_SHARED_MEMORY
  
  __shared__ unsigned int sharedMemory[4 * 1024 - 32];
  
    //NOTE : SAMER : this can exceed the size of the shared memory 
  unsigned int *sharedMemoryIndex = sharedMemory + ((threadIdx.x >> 5) * 512);
  unsigned int *inputIndex = (unsigned int *)(input + chunkIndex);
  
  sha1_internal_overlap(inputIndex, sharedMemoryIndex, chunkSize, 
	       output + hashIndex );

#else
  sha1_internal(input + chunkIndex, chunkSize, output + hashIndex );
#endif /* FEATURE_SHARED_MEMORY */



}

int main(int argc, char **argv) {
    int totalThreads = 64;
    int chunkSize = 52;
    int offset = 52;
    int padSize = 0;

    if (argc >= 2) totalThreads = atoi(argv[1]);
    if (argc >= 3) chunkSize = atoi(argv[2]);
    if (argc >= 4) offset = atoi(argv[3]);

    if (totalThreads <= 0) {
        fprintf(stderr, "totalThreads must be > 0\n");
        return -1;
    }

    if (chunkSize <= 0 || chunkSize > 52) {
        fprintf(stderr, "For this standalone main, chunkSize should be in range 1..52\n");
        return -1;
    }

    if (offset <= 0) {
        fprintf(stderr, "offset must be > 0\n");
        return -1;
    }

    size_t inputSize = (size_t)(totalThreads - 1) * offset + chunkSize;
    size_t outputSize = (size_t)totalThreads * SHA1_HASH_SIZE;

    unsigned char *h_input = (unsigned char *)malloc(inputSize);
    unsigned char *h_output = (unsigned char *)malloc(outputSize);

    if (!h_input || !h_output) {
        fprintf(stderr, "host malloc failed\n");
        free(h_input);
        free(h_output);
        return -1;
    }

    for (size_t i = 0; i < inputSize; i++) {
        h_input[i] = (unsigned char)('a' + (i % 26));
    }

    memset(h_output, 0, outputSize);

    unsigned char *d_input = NULL;
    unsigned char *d_output = NULL;

    cudaError_t err;

    err = cudaMalloc((void **)&d_input, inputSize);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_input failed: %s\n", cudaGetErrorString(err));
        free(h_input);
        free(h_output);
        return -1;
    }

    err = cudaMalloc((void **)&d_output, outputSize);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc d_output failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_input);
        free(h_input);
        free(h_output);
        return -1;
    }

    cudaMemcpy(d_input, h_input, inputSize, cudaMemcpyHostToDevice);
    cudaMemset(d_output, 0, outputSize);

    dim3 block(128);
    dim3 grid((totalThreads + block.x - 1) / block.x);

    sha1_overlap<<<grid, block>>>(d_input, chunkSize, offset, totalThreads, padSize, d_output);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_input);
        cudaFree(d_output);
        free(h_input);
        free(h_output);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_input);
        cudaFree(d_output);
        free(h_input);
        free(h_output);
        return -1;
    }

    cudaMemcpy(h_output, d_output, outputSize, cudaMemcpyDeviceToHost);

    printf("SHA1 overlap output, first few hashes:\n");
    int printThreads = totalThreads < 4 ? totalThreads : 4;
    for (int i = 0; i < printThreads; i++) {
        printf("hash[%d] = ", i);
        for (int j = 0; j < SHA1_HASH_SIZE; j++) {
            printf("%02x", h_output[i * SHA1_HASH_SIZE + j]);
        }
        printf("\n");
    }

    cudaFree(d_input);
    cudaFree(d_output);
    free(h_input);
    free(h_output);

    return 0;
}