// Standalone version for single_kernel_find_neighbours.cu

#include <cuda.h>
#include <cuda_runtime.h>
#include <cub/cub.cuh>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

typedef unsigned int uint;
#ifndef debug
#define debug 0
#endif

#include "cutil_subset.h"
#include "sharedptr.h"
#include "dmr.h"
#include "geomprim.h"

// ===== Device helper =====
__device__ bool shares_edge(uint nodes1[3], uint nodes2[3]) {
    int i;
    int match = 0;
    uint help;

    for (i = 0; i < 3; i++) {
        if ((help = nodes1[i]) != INVALIDID) {
            if (help == nodes2[0]) match++;
            else if (help == nodes2[1]) match++;
            else if (help == nodes2[2]) match++;
        }
    }

    return match == 2;
}

// ===== Kernel =====
__global__ void find_neighbours(Mesh mesh, int start, int end) {
    int id = threadIdx.x + blockDim.x * blockIdx.x;
    int threads = blockDim.x * gridDim.x;
    int ele;
    int oele;
    int nc = 0;
    uint nodes1[3], nodes2[3], neigh[3] = {INVALIDID, INVALIDID, INVALIDID};

    for (int x = 0; x < (int)mesh.nelements; x += 4096) {
        for (ele = id + start; ele < end; ele += threads) {
            if (x == 0) {
                neigh[0] = INVALIDID;
                neigh[1] = INVALIDID;
                neigh[2] = INVALIDID;
            } else {
                neigh[0] = mesh.neighbours[ele].x;
                neigh[1] = mesh.neighbours[ele].y;
                neigh[2] = mesh.neighbours[ele].z;
            }

            if (neigh[2] != INVALIDID) continue;

            nodes1[0] = mesh.elements[ele].x;
            nodes1[1] = mesh.elements[ele].y;
            nodes1[2] = mesh.elements[ele].z;
            nc = (neigh[0] == INVALIDID) ? 0 : ((neigh[1] == INVALIDID) ? 1 : 2);

            for (oele = 0; oele < (int)mesh.nelements; oele++) {
                if (oele == ele) continue;

                nodes2[0] = mesh.elements[oele].x;
                nodes2[1] = mesh.elements[oele].y;
                nodes2[2] = mesh.elements[oele].z;

                if (shares_edge(nodes1, nodes2)) {
                    assert(nc < 3);
                    neigh[nc++] = oele;
                }

                if ((IS_SEGMENT(mesh.elements[ele]) && nc == 2) || nc == 3)
                    break;
            }

            mesh.neighbours[ele].x = neigh[0];
            mesh.neighbours[ele].y = neigh[1];
            mesh.neighbours[ele].z = neigh[2];
        }
    }
}

// ===== Host helper =====
static void build_two_triangle_mesh(ShMesh &mesh) {
    mesh.maxnnodes = 8;
    mesh.maxnelements = 8;

    mesh.nnodes = 4;
    mesh.ntriangles = 2;
    mesh.nsegments = 0;
    mesh.nelements = 2;

    mesh.nodex.alloc(mesh.maxnnodes);
    mesh.nodey.alloc(mesh.maxnnodes);
    mesh.elements.alloc(mesh.maxnelements);
    mesh.neighbours.alloc(mesh.maxnelements);
    mesh.isdel.alloc(mesh.maxnelements);
    mesh.isbad.alloc(mesh.maxnelements);
    mesh.owners.alloc(mesh.maxnelements);

    FORD *x = mesh.nodex.cpu_wr_ptr(true);
    FORD *y = mesh.nodey.cpu_wr_ptr(true);
    uint3 *elements = mesh.elements.cpu_wr_ptr(true);
    uint3 *neigh = mesh.neighbours.cpu_wr_ptr(true);
    bool *isdel = mesh.isdel.cpu_wr_ptr(true);
    bool *isbad = mesh.isbad.cpu_wr_ptr(true);
    int *owners = mesh.owners.cpu_wr_ptr(true);

    // 正方形拆成两个三角形
    // 0----1
    // |  / |
    // | /  |
    // 2----3
    x[0] = 0.0; y[0] = 1.0;
    x[1] = 1.0; y[1] = 1.0;
    x[2] = 0.0; y[2] = 0.0;
    x[3] = 1.0; y[3] = 0.0;

    elements[0].x = 0; elements[0].y = 1; elements[0].z = 2;
    elements[1].x = 1; elements[1].y = 3; elements[1].z = 2;

    for (unsigned i = 0; i < mesh.maxnelements; i++) {
        neigh[i].x = neigh[i].y = neigh[i].z = INVALIDID;
        isdel[i] = false;
        isbad[i] = false;
        owners[i] = 0;
    }
}

int main() {
    ShMesh mesh;
    build_two_triangle_mesh(mesh);

    Mesh gmesh(mesh);

    int block = 128;
    int grid = 1;

    find_neighbours<<<grid, block>>>(gmesh, 0, mesh.nelements);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    uint3 *neigh = mesh.neighbours.cpu_rd_ptr();

    printf("find_neighbours finished\n");
    for (unsigned i = 0; i < mesh.nelements; i++) {
        printf("neighbours[%u] = (%u, %u, %u)\n",
               i, neigh[i].x, neigh[i].y, neigh[i].z);
    }

    return 0;
}