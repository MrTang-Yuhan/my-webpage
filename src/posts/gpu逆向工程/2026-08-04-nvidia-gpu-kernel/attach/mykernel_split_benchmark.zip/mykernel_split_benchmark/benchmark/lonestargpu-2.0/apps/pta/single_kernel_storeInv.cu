// Standalone CUDA kernel file: storeInv
// Smoke-test version for PTA storeInv kernel

#include "pta_single_kernel_test_common.cuh"

__device__ void unionToCopyInvLite(uint to, uint fromIndex) {
    uint toIndex = getCopyInvHeadIndex(to);

    uint fromBase = graphGet(fromIndex + BASE);
    if (fromBase == NIL) {
        return;
    }

    uint fromBits = graphGet(fromIndex + threadIdx.x);
    uint toBits = graphGet(toIndex + threadIdx.x);

    uint result;

    if (threadIdx.x == NEXT) {
        result = NIL;
    } else if (toBits == NIL) {
        result = fromBits;
    } else {
        result = toBits | fromBits;
    }

    if (threadIdx.x == BASE) {
        result = fromBase;
    }

    graphSet(toIndex + threadIdx.x, result);
}

__device__ void warpStoreInvLite(uint i) {
    uint src = __key__[i];
    uint start = __keyAux__[i];
    uint end = __keyAux__[i + 1];

    if (src == NIL) {
        return;
    }

    for (uint j = start; j < end; j++) {
        uint fromIndex = __val__[j];

        if (fromIndex != NIL) {
            unionToCopyInvLite(src, fromIndex);
        }
    }
}

__global__ void storeInv() {
    uint tidWarp = blockIdx.x * blockDim.y + threadIdx.y;
    uint nwarps = gridDim.x * blockDim.y;

    uint numKeys = __numKeys__;

    if (numKeys == 0) {
        return;
    }

    for (uint i = tidWarp; i + 1 < numKeys; i += nwarps) {
        warpStoreInvLite(i);
    }

    __syncthreads();

    if (isFirstThreadOfBlock()) {
        __worklistIndex0__ = 0;
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    // 构造一个 from pts element
    uint fromIndex = 1000;

    uint fromElt[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) {
        fromElt[i] = 0;
    }

    fromElt[0] = 0x5;
    fromElt[BASE] = 0;
    fromElt[NEXT] = NIL;

    checkCuda(cudaMemcpy(env.d_graph + fromIndex,
                         fromElt,
                         ELEMENT_WIDTH * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy from element");

    uint h_key[MAX_TEST_VARS];
    uint h_keyAux[MAX_TEST_VARS + 1];
    uint h_val[MAX_TEST_VARS];

    for (uint i = 0; i < MAX_TEST_VARS; i++) {
        h_key[i] = NIL;
        h_val[i] = NIL;
    }

    for (uint i = 0; i <= MAX_TEST_VARS; i++) {
        h_keyAux[i] = 0;
    }

    h_key[0] = 1;
    h_keyAux[0] = 0;
    h_keyAux[1] = 1;
    h_val[0] = fromIndex;

    uint numKeys = 2;

    checkCuda(cudaMemcpy(env.d_key,
                         h_key,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy key");

    checkCuda(cudaMemcpy(env.d_keyAux,
                         h_keyAux,
                         (MAX_TEST_VARS + 1) * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy keyAux");

    checkCuda(cudaMemcpy(env.d_val,
                         h_val,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy val");

    checkCuda(cudaMemcpyToSymbol(__numKeys__, &numKeys, sizeof(uint)),
              "set numKeys");

    dim3 block(32, 16);
    dim3 grid(1);

    storeInv<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "storeInv launch failed");
    checkCuda(cudaDeviceSynchronize(), "storeInv execution failed");

    uint copyOut[ELEMENT_WIDTH];
    uint copyHead1 = TEST_COPY_INV_START + 1 * ELEMENT_WIDTH;

    checkCuda(cudaMemcpy(copyOut,
                         env.d_graph + copyHead1,
                         ELEMENT_WIDTH * sizeof(uint),
                         cudaMemcpyDeviceToHost),
              "copy copyInv out");

    printf("storeInv finished\n");
    printf("COPY_INV[1].word0=%u base=%u next=%u\n",
           copyOut[0], copyOut[BASE], copyOut[NEXT]);

    destroyPTATestEnv(env);
    return 0;
}