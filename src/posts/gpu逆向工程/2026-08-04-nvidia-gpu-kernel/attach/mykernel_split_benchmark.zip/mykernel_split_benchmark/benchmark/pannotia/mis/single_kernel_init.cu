// Auto-generated CUDA kernel file: init
// Extracted from: pannotia/mis/kernel.cu
// Original line: 70

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: init (line 70)
__global__ void
init(int *s_array, int *c_array, int *cu_array, int num_nodes, int num_edges) {

    // Get my workitem id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;
    if (tid < num_nodes) {
        // Set the status array: not processed
        c_array[tid] = -1;
        cu_array[tid] = -1;
        s_array[tid] = 0;
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;

    const size_t size_nodes = (size_t)num_nodes * sizeof(int);

    int *h_s_array = (int*)malloc(size_nodes);
    int *h_c_array = (int*)malloc(size_nodes);
    int *h_cu_array = (int*)malloc(size_nodes);

    int *d_s_array = nullptr;
    int *d_c_array = nullptr;
    int *d_cu_array = nullptr;

    if (!h_s_array || !h_c_array || !h_cu_array) {
        printf("host malloc failed\n");
        free(h_s_array);
        free(h_c_array);
        free(h_cu_array);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_s_array[i] = 123;
        h_c_array[i] = 456;
        h_cu_array[i] = 789;
    }

    err = cudaMalloc((void**)&d_s_array, size_nodes);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_s_array failed: %s\n", cudaGetErrorString(err));
        free(h_s_array);
        free(h_c_array);
        free(h_cu_array);
        return -1;
    }

    err = cudaMalloc((void**)&d_c_array, size_nodes);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_c_array failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_s_array);
        free(h_s_array);
        free(h_c_array);
        free(h_cu_array);
        return -1;
    }

    err = cudaMalloc((void**)&d_cu_array, size_nodes);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_cu_array failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_s_array);
        cudaFree(d_c_array);
        free(h_s_array);
        free(h_c_array);
        free(h_cu_array);
        return -1;
    }

    cudaMemcpy(d_s_array, h_s_array, size_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_c_array, h_c_array, size_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_cu_array, h_cu_array, size_nodes, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    init<<<gridSize, blockSize>>>(d_s_array, d_c_array, d_cu_array, num_nodes, num_edges);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_s_array);
        cudaFree(d_c_array);
        cudaFree(d_cu_array);
        free(h_s_array);
        free(h_c_array);
        free(h_cu_array);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_s_array);
        cudaFree(d_c_array);
        cudaFree(d_cu_array);
        free(h_s_array);
        free(h_c_array);
        free(h_cu_array);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaMemcpy(h_s_array, d_s_array, size_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_c_array, d_c_array, size_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_cu_array, d_cu_array, size_nodes, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("init execution time: %.3f ms\n", ms);

    printf("s_array[0] = %d\n", h_s_array[0]);
    printf("c_array[0] = %d\n", h_c_array[0]);
    printf("cu_array[0] = %d\n", h_cu_array[0]);

    cudaFree(d_s_array);
    cudaFree(d_c_array);
    cudaFree(d_cu_array);
    free(h_s_array);
    free(h_c_array);
    free(h_cu_array);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}