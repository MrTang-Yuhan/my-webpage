// Auto-generated CUDA kernel file: ExecuteLSTM
// Extracted from: Tango-master/GPU/LSTM/lstm.cu
// Original line: 524

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>
#include <cuda_runtime.h>


#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)


// ===== Macro Definitions =====
#define input_0 0.98  // from line 25
#define input_1 0.88  // from line 26

// ===== Function Forward Declarations =====
__device__ double hard_sigmoid(double x);

// ===== Device/Helper Functions =====
// Function: hard_sigmoid (from Tango-master/GPU/LSTM/lstm.cu:511)
__device__ double hard_sigmoid(double x) {

	if(x<-2.5)
		return 0;
	else
	{
		if(x>2.5)
			return 1;
		else
			return (0.2*x + 0.5);
	}

}

// ===== Kernel =====
// Kernel: ExecuteLSTM (line 524)
__global__ void ExecuteLSTM(double *w_i, double *u_i, double *b_i, double *w_f, double *u_f, double *b_f, double *w_c, double *u_c, double *b_c, double *w_o, double *u_o, double *b_o, double *weight, double *bias, double *LSTM_results) {

	int x = threadIdx.x;
	__shared__ double u[100];
	double c = 0;
	double at, it, ft, ot, statet, output_state;
	double i[2];
	double temp_ua = 0, temp_ui = 0, temp_uf = 0, temp_uo = 0;
	//int index = threadIdx.x*2;
	i[0] = input_0;
	i[1] = input_1;
	at = tanh((i[0]*w_c[x]) + b_c[x]);
	it = hard_sigmoid((i[0]*w_i[x]) + b_i[x]);
	ft = hard_sigmoid((i[0]*w_f[x]) + b_f[x]);
	ot = hard_sigmoid((i[0]*w_o[x]) + b_o[x]);
	statet = at*it + ft*c;
	c = statet;
	output_state = ot*tanh(statet);
	u[x] = output_state;
	__syncthreads();
	if(x==0)
	{
		double result = *bias;
		for(int i=0; i<100; i++)
		{
			result += weight[i]*u[i];
		}
		//printf("The result for i=0 is %f\n",result);
		LSTM_results[0] = result;
	}
	__syncthreads();
	for(int i=0; i<100; i++)
	{
		temp_ua += u[i] * u_c[i*100 + x];
		temp_ui += u[i] * u_i[i*100 + x];
		temp_uf += u[i] * u_f[i*100 + x];
		temp_uo += u[i] * u_o[i*100 + x]; 	
	}
	at = tanh((i[1]*w_c[x]) + temp_ua + b_c[x]);
	it = hard_sigmoid((i[1]*w_i[x]) + temp_ui + b_i[x]);
	ft = hard_sigmoid((i[1]*w_f[x]) + temp_uf + b_f[x]);
	ot = hard_sigmoid((i[1]*w_o[x]) + temp_uo + b_o[x]);
	statet = at*it + ft*c;
	output_state = ot*tanh(statet);
	u[x] = output_state;
	__syncthreads();
	if(x==0)
	{
		double result = *bias;
		for(int i=0; i<100; i++)
		{
			result += weight[i]*u[i];
		}
		//printf("The result for i=1 is %f\n",result);
		LSTM_results[1] = result;
	}

}

int main() {
    const int hidden_size = 100;
    const int output_size = 2;   // kernel 里只写了 LSTM_results[0], LSTM_results[1]

    size_t vec_size = hidden_size * sizeof(double);
    size_t mat_size = hidden_size * hidden_size * sizeof(double);
    size_t bias_scalar_size = sizeof(double);
    size_t result_size = output_size * sizeof(double);

    // Host memory
    double *h_w_i = (double*)malloc(vec_size);
    double *h_u_i = (double*)malloc(mat_size);
    double *h_b_i = (double*)malloc(vec_size);

    double *h_w_f = (double*)malloc(vec_size);
    double *h_u_f = (double*)malloc(mat_size);
    double *h_b_f = (double*)malloc(vec_size);

    double *h_w_c = (double*)malloc(vec_size);
    double *h_u_c = (double*)malloc(mat_size);
    double *h_b_c = (double*)malloc(vec_size);

    double *h_w_o = (double*)malloc(vec_size);
    double *h_u_o = (double*)malloc(mat_size);
    double *h_b_o = (double*)malloc(vec_size);

    double *h_weight = (double*)malloc(vec_size);
    double *h_bias = (double*)malloc(bias_scalar_size);
    double *h_results = (double*)malloc(result_size);

    if (!h_w_i || !h_u_i || !h_b_i ||
        !h_w_f || !h_u_f || !h_b_f ||
        !h_w_c || !h_u_c || !h_b_c ||
        !h_w_o || !h_u_o || !h_b_o ||
        !h_weight || !h_bias || !h_results) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    // Initialize host data
    for (int i = 0; i < hidden_size; ++i) {
        h_w_i[i] = (double)(i % 11) * 0.01;
        h_b_i[i] = 0.05;

        h_w_f[i] = (double)(i % 13) * 0.01;
        h_b_f[i] = 0.04;

        h_w_c[i] = (double)(i % 17) * 0.01;
        h_b_c[i] = 0.03;

        h_w_o[i] = (double)(i % 19) * 0.01;
        h_b_o[i] = 0.02;

        h_weight[i] = (double)(i % 7) * 0.02;
    }

    for (int i = 0; i < hidden_size * hidden_size; ++i) {
        h_u_i[i] = (double)(i % 23) * 0.001;
        h_u_f[i] = (double)(i % 29) * 0.001;
        h_u_c[i] = (double)(i % 31) * 0.001;
        h_u_o[i] = (double)(i % 37) * 0.001;
    }

    h_bias[0] = 0.1;
    h_results[0] = 0.0;
    h_results[1] = 0.0;

    // Device memory
    double *d_w_i = NULL, *d_u_i = NULL, *d_b_i = NULL;
    double *d_w_f = NULL, *d_u_f = NULL, *d_b_f = NULL;
    double *d_w_c = NULL, *d_u_c = NULL, *d_b_c = NULL;
    double *d_w_o = NULL, *d_u_o = NULL, *d_b_o = NULL;
    double *d_weight = NULL, *d_bias = NULL, *d_results = NULL;

    CHECK(cudaMalloc((void**)&d_w_i, vec_size));
    CHECK(cudaMalloc((void**)&d_u_i, mat_size));
    CHECK(cudaMalloc((void**)&d_b_i, vec_size));

    CHECK(cudaMalloc((void**)&d_w_f, vec_size));
    CHECK(cudaMalloc((void**)&d_u_f, mat_size));
    CHECK(cudaMalloc((void**)&d_b_f, vec_size));

    CHECK(cudaMalloc((void**)&d_w_c, vec_size));
    CHECK(cudaMalloc((void**)&d_u_c, mat_size));
    CHECK(cudaMalloc((void**)&d_b_c, vec_size));

    CHECK(cudaMalloc((void**)&d_w_o, vec_size));
    CHECK(cudaMalloc((void**)&d_u_o, mat_size));
    CHECK(cudaMalloc((void**)&d_b_o, vec_size));

    CHECK(cudaMalloc((void**)&d_weight, vec_size));
    CHECK(cudaMalloc((void**)&d_bias, bias_scalar_size));
    CHECK(cudaMalloc((void**)&d_results, result_size));

    // Copy to device
    CHECK(cudaMemcpy(d_w_i, h_w_i, vec_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_u_i, h_u_i, mat_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_b_i, h_b_i, vec_size, cudaMemcpyHostToDevice));

    CHECK(cudaMemcpy(d_w_f, h_w_f, vec_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_u_f, h_u_f, mat_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_b_f, h_b_f, vec_size, cudaMemcpyHostToDevice));

    CHECK(cudaMemcpy(d_w_c, h_w_c, vec_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_u_c, h_u_c, mat_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_b_c, h_b_c, vec_size, cudaMemcpyHostToDevice));

    CHECK(cudaMemcpy(d_w_o, h_w_o, vec_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_u_o, h_u_o, mat_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_b_o, h_b_o, vec_size, cudaMemcpyHostToDevice));

    CHECK(cudaMemcpy(d_weight, h_weight, vec_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_bias, h_bias, bias_scalar_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_results, h_results, result_size, cudaMemcpyHostToDevice));

    // Launch kernel
    dim3 grid(1);
    dim3 block(hidden_size);

    ExecuteLSTM<<<grid, block>>>(
        d_w_i, d_u_i, d_b_i,
        d_w_f, d_u_f, d_b_f,
        d_w_c, d_u_c, d_b_c,
        d_w_o, d_u_o, d_b_o,
        d_weight, d_bias, d_results
    );

    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    // Copy result back
    CHECK(cudaMemcpy(h_results, d_results, result_size, cudaMemcpyDeviceToHost));

    printf("ExecuteLSTM done.\n");
    printf("LSTM_results[0] = %f\n", h_results[0]);
    printf("LSTM_results[1] = %f\n", h_results[1]);

    // Free device memory
    cudaFree(d_w_i);
    cudaFree(d_u_i);
    cudaFree(d_b_i);

    cudaFree(d_w_f);
    cudaFree(d_u_f);
    cudaFree(d_b_f);

    cudaFree(d_w_c);
    cudaFree(d_u_c);
    cudaFree(d_b_c);

    cudaFree(d_w_o);
    cudaFree(d_u_o);
    cudaFree(d_b_o);

    cudaFree(d_weight);
    cudaFree(d_bias);
    cudaFree(d_results);

    // Free host memory
    free(h_w_i);
    free(h_u_i);
    free(h_b_i);

    free(h_w_f);
    free(h_u_f);
    free(h_b_f);

    free(h_w_c);
    free(h_u_c);
    free(h_b_c);

    free(h_w_o);
    free(h_u_o);
    free(h_b_o);

    free(h_weight);
    free(h_bias);
    free(h_results);

    return 0;
}