// test_heartwall_kernel.cu
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <cuda.h>

// ===== 从 define.c 内联结构体定义 =====
#define fp float
#define NUMBER_THREADS 512
#define ENDO_POINTS 20
#define EPI_POINTS  31
#define ALL_POINTS  51

typedef struct params_common_change {
    fp*  d_frame;
    int  frame_no;
} params_common_change;

typedef struct params_common {
    int sSize, tSize, maxMove;
    fp  alpha;
    int no_frames, frame_rows, frame_cols, frame_elem, frame_mem;
    int endoPoints, endo_mem;
    int *endoRow, *endoCol, *tEndoRowLoc, *tEndoColLoc;
    int *d_endoRow, *d_endoCol, *d_tEndoRowLoc, *d_tEndoColLoc;
    fp  *d_endoT;
    int epiPoints, epi_mem;
    int *epiRow, *epiCol, *tEpiRowLoc, *tEpiColLoc;
    int *d_epiRow, *d_epiCol, *d_tEpiRowLoc, *d_tEpiColLoc;
    fp  *d_epiT;
    int allPoints;
    int in_rows, in_cols, in_elem, in_mem;
    int in2_rows, in2_cols, in2_elem, in2_mem;
    int conv_rows, conv_cols, conv_elem, conv_mem, ioffset, joffset;
    int in2_pad_add_rows, in2_pad_add_cols;
    int in2_pad_cumv_rows, in2_pad_cumv_cols, in2_pad_cumv_elem, in2_pad_cumv_mem;
    int in2_pad_cumv_sel_rows, in2_pad_cumv_sel_cols, in2_pad_cumv_sel_elem, in2_pad_cumv_sel_mem;
    int in2_pad_cumv_sel_rowlow, in2_pad_cumv_sel_rowhig, in2_pad_cumv_sel_collow, in2_pad_cumv_sel_colhig;
    int in2_pad_cumv_sel2_rowlow, in2_pad_cumv_sel2_rowhig, in2_pad_cumv_sel2_collow, in2_pad_cumv_sel2_colhig;
    int in2_sub_cumh_rows, in2_sub_cumh_cols, in2_sub_cumh_elem, in2_sub_cumh_mem;
    int in2_sub_cumh_sel_rows, in2_sub_cumh_sel_cols, in2_sub_cumh_sel_elem, in2_sub_cumh_sel_mem;
    int in2_sub_cumh_sel_rowlow, in2_sub_cumh_sel_rowhig, in2_sub_cumh_sel_collow, in2_sub_cumh_sel_colhig;
    int in2_sub_cumh_sel2_rowlow, in2_sub_cumh_sel2_rowhig, in2_sub_cumh_sel2_collow, in2_sub_cumh_sel2_colhig;
    int in2_sub2_rows, in2_sub2_cols, in2_sub2_elem, in2_sub2_mem;
    int in2_sqr_rows, in2_sqr_cols, in2_sqr_elem, in2_sqr_mem;
    int in2_sqr_sub2_rows, in2_sqr_sub2_cols, in2_sqr_sub2_elem, in2_sqr_sub2_mem;
    int in_sqr_rows, in_sqr_cols, in_sqr_elem, in_sqr_mem;
    int tMask_rows, tMask_cols, tMask_elem, tMask_mem;
    int mask_rows, mask_cols, mask_elem, mask_mem;
    int mask_conv_rows, mask_conv_cols, mask_conv_elem, mask_conv_mem;
    int mask_conv_ioffset, mask_conv_joffset;
} params_common;

typedef struct params_unique {
    int *d_Row, *d_Col, *d_tRowLoc, *d_tColLoc;
    fp  *d_T;
    int  point_no, in_pointer;
    fp  *d_in2, *d_conv, *d_in_mod;
    fp  *d_in2_pad_cumv, *d_in2_pad_cumv_sel;
    fp  *d_in2_sub_cumh, *d_in2_sub_cumh_sel;
    fp  *d_in2_sub2, *d_in2_sqr, *d_in2_sqr_sub2;
    fp  *d_in_sqr, *d_tMask, *d_mask, *d_mask_conv;
} params_unique;

// ===== 设备端全局变量（kernel 直接访问） =====
__device__ __constant__ params_common        d_common;
__device__ __constant__ params_common_change d_common_change;
__device__ params_unique                     d_unique[ALL_POINTS];

// ===== Kernel =====
__global__ void kernel() {
    fp* d_in;
    int rot_row, rot_col, in2_rowlow, in2_collow;
    int ic, jc, jp1, ja1, ja2, ip1, ia1, ia2, ja, jb, ia, ib;
    float s;
    int i, j, row, col, ori_row, ori_col, position;
    float sum;
    int pos_ori;
    float temp, temp2;
    int location, cent, tMask_row, tMask_col;
    float largest_value_current = 0, largest_value = 0;
    int   largest_coordinate_current = 0, largest_coordinate = 0;
    float fin_max_val = 0;
    int   fin_max_coo = 0;
    int   largest_row, largest_col, offset_row, offset_col;
    __shared__ float in_partial_sum[51];
    __shared__ float in_sqr_partial_sum[51];
    __shared__ float in_final_sum;
    __shared__ float in_sqr_final_sum;
    float mean, mean_sqr, variance, deviation;
    __shared__ float denomT;
    __shared__ float par_max_val[131];
    __shared__ int   par_max_coo[131];
    int pointer;
    __shared__ float d_in_mod_temp[2601];
    int ori_pointer, loc_pointer;

    int bx = blockIdx.x;
    int tx = threadIdx.x;
    int ei_new;

    if (d_common_change.frame_no == 0) {
        d_in = &d_unique[bx].d_T[d_unique[bx].in_pointer];
        ei_new = tx;
        if (ei_new == 0) {
            pointer = d_unique[bx].point_no * d_common.no_frames + d_common_change.frame_no;
            d_unique[bx].d_tRowLoc[pointer] = d_unique[bx].d_Row[d_unique[bx].point_no];
            d_unique[bx].d_tColLoc[pointer] = d_unique[bx].d_Col[d_unique[bx].point_no];
        }
        ei_new = tx;
        while (ei_new < d_common.in_elem) {
            row = (ei_new+1) % d_common.in_rows - 1;
            col = (ei_new+1) / d_common.in_rows + 1 - 1;
            if ((ei_new+1) % d_common.in_rows == 0) { row = d_common.in_rows-1; col = col-1; }
            ori_row = d_unique[bx].d_Row[d_unique[bx].point_no] - 25 + row - 1;
            ori_col = d_unique[bx].d_Col[d_unique[bx].point_no] - 25 + col - 1;
            ori_pointer = ori_col * d_common.frame_rows + ori_row;
            d_in[col * d_common.in_rows + row] = d_common_change.d_frame[ori_pointer];
            ei_new += NUMBER_THREADS;
        }
    }

    if (d_common_change.frame_no != 0) {
        in2_rowlow = d_unique[bx].d_Row[d_unique[bx].point_no] - d_common.sSize;
        in2_collow = d_unique[bx].d_Col[d_unique[bx].point_no] - d_common.sSize;
        ei_new = tx;
        while (ei_new < d_common.in2_elem) {
            row = (ei_new+1) % d_common.in2_rows - 1;
            col = (ei_new+1) / d_common.in2_rows + 1 - 1;
            if ((ei_new+1) % d_common.in2_rows == 0) { row = d_common.in2_rows-1; col = col-1; }
            ori_row = row + in2_rowlow - 1;
            ori_col = col + in2_collow - 1;
            d_unique[bx].d_in2[ei_new] = d_common_change.d_frame[ori_col * d_common.frame_rows + ori_row];
            ei_new += NUMBER_THREADS;
        }
        __syncthreads();

        d_in = &d_unique[bx].d_T[d_unique[bx].in_pointer];
        ei_new = tx;
        while (ei_new < d_common.in_elem) {
            row = (ei_new+1) % d_common.in_rows - 1;
            col = (ei_new+1) / d_common.in_rows + 1 - 1;
            if ((ei_new+1) % d_common.in_rows == 0) { row = d_common.in_rows-1; col = col-1; }
            rot_row = (d_common.in_rows-1) - row;
            rot_col = (d_common.in_rows-1) - col;
            d_in_mod_temp[ei_new] = d_in[rot_col * d_common.in_rows + rot_row];
            ei_new += NUMBER_THREADS;
        }
        __syncthreads();

        ei_new = tx;
        while (ei_new < d_common.conv_elem) {
            ic = (ei_new+1) % d_common.conv_rows;
            jc = (ei_new+1) / d_common.conv_rows + 1;
            if ((ei_new+1) % d_common.conv_rows == 0) { ic = d_common.conv_rows; jc = jc-1; }
            j = jc + d_common.joffset; jp1 = j+1;
            ja1 = (d_common.in2_cols < jp1) ? jp1 - d_common.in2_cols : 1;
            ja2 = (d_common.in_cols  < j)   ? d_common.in_cols : j;
            i = ic + d_common.ioffset; ip1 = i+1;
            ia1 = (d_common.in2_rows < ip1) ? ip1 - d_common.in2_rows : 1;
            ia2 = (d_common.in_rows  < i)   ? d_common.in_rows : i;
            s = 0;
            for (ja=ja1; ja<=ja2; ja++) {
                jb = jp1 - ja;
                for (ia=ia1; ia<=ia2; ia++) {
                    ib = ip1 - ia;
                    s += d_in_mod_temp[d_common.in_rows*(ja-1)+ia-1] *
                         d_unique[bx].d_in2[d_common.in2_rows*(jb-1)+ib-1];
                }
            }
            d_unique[bx].d_conv[ei_new] = s;
            ei_new += NUMBER_THREADS;
        }
        __syncthreads();

        // --- 后续 cumsum / correlation / mask_conv / max 步骤省略（结构相同）---
        // 完整 kernel 体见上传的 single_kernel_kernel.cu
    }
}

// ===== 辅助：cudaMalloc + memset =====
static fp* alloc_fp(int n) {
    fp* p; cudaMalloc(&p, n * sizeof(fp)); cudaMemset(p, 0, n * sizeof(fp)); return p;
}
static int* alloc_int(int n) {
    int* p; cudaMalloc(&p, n * sizeof(int)); cudaMemset(p, 0, n * sizeof(int)); return p;
}

int main() {
    // ----------------------------
    // 参数设置（对应 Rodinia heartwall 默认小规模）
    // ----------------------------
    const int sSize      = 10;
    const int tSize      = 10;
    const int in_rows    = 2*tSize + 1;   // 21
    const int in_cols    = 2*tSize + 1;   // 21
    const int in_elem    = in_rows * in_cols;
    const int in2_rows   = 2*sSize + 2*tSize + 1; // 41
    const int in2_cols   = in2_rows;
    const int in2_elem   = in2_rows * in2_cols;
    const int conv_rows  = in_rows + in2_rows - 1; // 61
    const int conv_cols  = conv_rows;
    const int conv_elem  = conv_rows * conv_cols;
    const int frame_rows = 256;
    const int frame_cols = 256;
    const int frame_elem = frame_rows * frame_cols;
    const int no_frames  = 2;
    const int no_points  = 2;  // 测试用 2 个点（对应 2 个 block）

    // ----------------------------
    // 构造 params_common（host 端）
    // ----------------------------
    params_common h_common;
    memset(&h_common, 0, sizeof(h_common));
    h_common.sSize      = sSize;
    h_common.tSize      = tSize;
    h_common.alpha      = 0.1f;
    h_common.no_frames  = no_frames;
    h_common.frame_rows = frame_rows;
    h_common.frame_cols = frame_cols;
    h_common.frame_elem = frame_elem;
    h_common.in_rows    = in_rows;
    h_common.in_cols    = in_cols;
    h_common.in_elem    = in_elem;
    h_common.in2_rows   = in2_rows;
    h_common.in2_cols   = in2_cols;
    h_common.in2_elem   = in2_elem;
    h_common.conv_rows  = conv_rows;
    h_common.conv_cols  = conv_cols;
    h_common.conv_elem  = conv_elem;
    h_common.ioffset    = in2_rows - 1;
    h_common.joffset    = in2_cols - 1;
    h_common.in_sqr_rows = in_rows;
    h_common.in_sqr_cols = in_cols;
    h_common.in_sqr_elem = in_elem;
    // cumsum 参数（简化，实际 Rodinia 有完整计算）
    h_common.in2_pad_add_rows = tSize;
    h_common.in2_pad_add_cols = tSize;
    h_common.in2_pad_cumv_rows = in2_rows + 2*tSize;
    h_common.in2_pad_cumv_cols = in2_cols + 2*tSize;
    h_common.in2_pad_cumv_elem = h_common.in2_pad_cumv_rows * h_common.in2_pad_cumv_cols;
    h_common.in2_pad_cumv_sel_rows = in2_rows;
    h_common.in2_pad_cumv_sel_cols = in2_cols;
    h_common.in2_pad_cumv_sel_elem = in2_elem;
    h_common.in2_pad_cumv_sel_rowlow = tSize + 1;
    h_common.in2_pad_cumv_sel_collow = tSize + 1;
    h_common.in2_pad_cumv_sel2_rowlow = 1;
    h_common.in2_pad_cumv_sel2_collow = 1;
    h_common.in2_sub_cumh_rows = in2_rows;
    h_common.in2_sub_cumh_cols = in2_cols;
    h_common.in2_sub_cumh_elem = in2_elem;
    h_common.in2_sub_cumh_sel_rows = in2_rows;
    h_common.in2_sub_cumh_sel_cols = in2_cols;
    h_common.in2_sub_cumh_sel_elem = in2_elem;
    h_common.in2_sub_cumh_sel_rowlow = 1;
    h_common.in2_sub_cumh_sel_collow = 1;
    h_common.in2_sub_cumh_sel2_rowlow = 1;
    h_common.in2_sub_cumh_sel2_collow = 1;
    h_common.in2_sub2_rows = in2_rows;
    h_common.in2_sub2_cols = in2_cols;
    h_common.in2_sub2_elem = in2_elem;
    h_common.in2_sqr_rows  = in2_rows;
    h_common.in2_sqr_cols  = in2_cols;
    h_common.in2_sqr_elem  = in2_elem;
    h_common.tMask_rows    = 2*sSize + 1;
    h_common.tMask_cols    = 2*sSize + 1;
    h_common.tMask_elem    = h_common.tMask_rows * h_common.tMask_cols;
    h_common.mask_rows     = in_rows;
    h_common.mask_cols     = in_cols;
    h_common.mask_conv_rows = h_common.tMask_rows + in_rows - 1;
    h_common.mask_conv_cols = h_common.tMask_cols + in_cols - 1;
    h_common.mask_conv_elem = h_common.mask_conv_rows * h_common.mask_conv_cols;
    h_common.mask_conv_ioffset = in_rows - 1;
    h_common.mask_conv_joffset = in_cols - 1;

    // ----------------------------
    // 构造 params_unique（每个点）
    // ----------------------------
    params_unique h_unique[ALL_POINTS];
    memset(h_unique, 0, sizeof(h_unique));

    for (int p = 0; p < no_points; p++) {
        // host 端 Row/Col 初始值
        int h_Row[1] = { 128 };
        int h_Col[1] = { 128 };
        int h_tRowLoc[2] = { 0, 0 };
        int h_tColLoc[2] = { 0, 0 };

        h_unique[p].d_Row     = alloc_int(1);
        h_unique[p].d_Col     = alloc_int(1);
        h_unique[p].d_tRowLoc = alloc_int(no_frames);
        h_unique[p].d_tColLoc = alloc_int(no_frames);
        h_unique[p].d_T       = alloc_fp(in_elem);

        cudaMemcpy(h_unique[p].d_Row,     h_Row,     sizeof(int),           cudaMemcpyHostToDevice);
        cudaMemcpy(h_unique[p].d_Col,     h_Col,     sizeof(int),           cudaMemcpyHostToDevice);
        cudaMemcpy(h_unique[p].d_tRowLoc, h_tRowLoc, no_frames*sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(h_unique[p].d_tColLoc, h_tColLoc, no_frames*sizeof(int), cudaMemcpyHostToDevice);

        h_unique[p].point_no   = p;
        h_unique[p].in_pointer = 0;

        h_unique[p].d_in2             = alloc_fp(in2_elem);
        h_unique[p].d_conv            = alloc_fp(conv_elem);
        h_unique[p].d_in_mod          = alloc_fp(in_elem);
        h_unique[p].d_in2_pad_cumv    = alloc_fp(h_common.in2_pad_cumv_elem);
        h_unique[p].d_in2_pad_cumv_sel= alloc_fp(in2_elem);
        h_unique[p].d_in2_sub_cumh    = alloc_fp(in2_elem);
        h_unique[p].d_in2_sub_cumh_sel= alloc_fp(in2_elem);
        h_unique[p].d_in2_sub2        = alloc_fp(in2_elem);
        h_unique[p].d_in2_sqr         = alloc_fp(in2_elem);
        h_unique[p].d_in2_sqr_sub2    = alloc_fp(in2_elem);
        h_unique[p].d_in_sqr          = alloc_fp(in_elem);
        h_unique[p].d_tMask           = alloc_fp(h_common.tMask_elem);
        h_unique[p].d_mask            = alloc_fp(h_common.mask_elem);
        h_unique[p].d_mask_conv       = alloc_fp(h_common.mask_conv_elem);
    }

    // ----------------------------
    // 构造 frame（随机填充）
    // ----------------------------
    fp* h_frame = (fp*)malloc(frame_elem * sizeof(fp));
    for (int i = 0; i < frame_elem; i++) h_frame[i] = (fp)(rand() % 256) / 255.0f;
    fp* d_frame; cudaMalloc(&d_frame, frame_elem * sizeof(fp));
    cudaMemcpy(d_frame, h_frame, frame_elem * sizeof(fp), cudaMemcpyHostToDevice);

    // ----------------------------
    // 拷贝常量到设备
    // ----------------------------
    cudaMemcpyToSymbol(d_common, &h_common, sizeof(params_common));
    cudaMemcpyToSymbol(d_unique, h_unique,  no_points * sizeof(params_unique));

    // ----------------------------
    // 测试 frame_no == 0（模板生成阶段）
    // ----------------------------
    printf("=== Testing frame_no = 0 (template generation) ===\n");
    params_common_change h_change;
    h_change.d_frame  = d_frame;
    h_change.frame_no = 0;
    cudaMemcpyToSymbol(d_common_change, &h_change, sizeof(params_common_change));

    kernel<<<no_points, NUMBER_THREADS>>>();
    cudaError_t err = cudaDeviceSynchronize();
    printf("frame_no=0: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));

    // 读回 tRowLoc/tColLoc 验证
    for (int p = 0; p < no_points; p++) {
        int result[2] = {-1, -1};
        cudaMemcpy(result, h_unique[p].d_tRowLoc, 2*sizeof(int), cudaMemcpyDeviceToHost);
        printf("  Point %d: tRowLoc[0]=%d (expected 128)\n", p, result[0]);
    }

    // ----------------------------
    // 测试 frame_no == 1（处理阶段）
    // ----------------------------
    printf("\n=== Testing frame_no = 1 (processing) ===\n");
    h_change.frame_no = 1;
    cudaMemcpyToSymbol(d_common_change, &h_change, sizeof(params_common_change));

    kernel<<<no_points, NUMBER_THREADS>>>();
    err = cudaDeviceSynchronize();
    printf("frame_no=1: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));

    // 读回 conv 结果做简单检查
    fp* h_conv = (fp*)malloc(conv_elem * sizeof(fp));
    cudaMemcpy(h_conv, h_unique[0].d_conv, conv_elem * sizeof(fp), cudaMemcpyDeviceToHost);
    float conv_sum = 0;
    for (int i = 0; i < conv_elem; i++) conv_sum += h_conv[i];
    printf("  Point 0: conv sum = %f (non-zero means convolution ran)\n", conv_sum);

    // ----------------------------
    // 清理
    // ----------------------------
    for (int p = 0; p < no_points; p++) {
        cudaFree(h_unique[p].d_Row);     cudaFree(h_unique[p].d_Col);
        cudaFree(h_unique[p].d_tRowLoc); cudaFree(h_unique[p].d_tColLoc);
        cudaFree(h_unique[p].d_T);       cudaFree(h_unique[p].d_in2);
        cudaFree(h_unique[p].d_conv);    cudaFree(h_unique[p].d_in_mod);
        cudaFree(h_unique[p].d_in2_pad_cumv);     cudaFree(h_unique[p].d_in2_pad_cumv_sel);
        cudaFree(h_unique[p].d_in2_sub_cumh);     cudaFree(h_unique[p].d_in2_sub_cumh_sel);
        cudaFree(h_unique[p].d_in2_sub2);         cudaFree(h_unique[p].d_in2_sqr);
        cudaFree(h_unique[p].d_in2_sqr_sub2);     cudaFree(h_unique[p].d_in_sqr);
        cudaFree(h_unique[p].d_tMask);   cudaFree(h_unique[p].d_mask);
        cudaFree(h_unique[p].d_mask_conv);
    }
    cudaFree(d_frame);
    free(h_frame); free(h_conv);

    return 0;
}