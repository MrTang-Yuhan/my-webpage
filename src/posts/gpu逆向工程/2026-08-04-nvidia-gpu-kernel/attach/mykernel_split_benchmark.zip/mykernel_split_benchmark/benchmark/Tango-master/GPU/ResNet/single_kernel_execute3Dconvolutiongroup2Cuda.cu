// Auto-generated CUDA kernel file: execute3Dconvolutiongroup2Cuda
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 739

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: execute3Dconvolutiongroup2Cuda (line 739)
__global__ void execute3Dconvolutiongroup2Cuda(float *bias,float *Layer2_Neurons_GPU, float *Layer2_Weights_GPU,float *Layer3_Neurons_GPU,int out,int fr,int fc,int stride_width,int kernel,int pad,int in_output,int group) {

	float product = 0.0;
	int x_pad = 0, y_pad = 0, loopc = 0,loopr = 0;
	int stride = 0,colstride = 0;
		{
			/* Execute second set of inputs */
			int output = blockIdx.x + out;
			//for(int output = out ;output < (out << 1)   ;output++) /* out = 256 */
			{      
				colstride = 0;	
                                int row = threadIdx.x;
				//for(int row =0; row < fr; row++) /* out = 256 */
				{	
					stride = 0;	
					if(row > pad)
						colstride = (row - pad) * fr;
					int col = threadIdx.y;
					//for(int col =0; col < fc ;col++) /* out = 256 */
					{
						if(col >= pad)
							stride = col*stride_width;
						x_pad = 0; y_pad = 0;
						/* set the loops value */
						loopc = kernel;loopr = kernel;
						/* take care of padding in left hand side of image*/ 
						if( row < pad)
						{
							x_pad = pad - row;
							loopr = kernel - x_pad;
						} 
						/* take care of padding in upper side of image*/ 
						if( col < pad )
						{
							y_pad = pad - col;
							loopc = kernel - y_pad;
						} 
						/* take care of padding in right side of image*/ 
						if(col >= fc - pad)
							loopc =  fc + pad - col;  
						/* take care of padding in bottom of image */ 
						if(row >= fr - pad)
							loopr =  fr + pad - row;
						for(int feature = in_output ; feature < (in_output << 1) ; feature++) // calculate the feature maps
						{
							for(int i =0; i < loopr ; i++) // kernel convolution
							{
								for(int j =0; j < loopc ; j++) // kernel convolution
								{
									product += (( Layer2_Neurons_GPU[feature*fr*fc + i*fc + j + stride + colstride] * Layer2_Weights_GPU[output*kernel*kernel*in_output + (feature-in_output)*kernel*kernel + i*kernel + j + kernel*x_pad + y_pad]));
								}
							}
						}
						product += bias[output];
						if(product < 0) /* ReLU Layer */
							product = 0;
						Layer3_Neurons_GPU[output*fr*fc + row*fc + col] = product;
						product = 0.0;
					}
				}

			}
		}

}

int main() {
    const int out = 4;
    const int in_output = 4;
    const int total_out = 2 * out;
    const int total_in = 2 * in_output;

    const int fr = 8, fc = 8;
    const int stride_width = 1;
    const int kernel = 3;
    const int pad = 1;
    const int group = 2;

    size_t bias_size   = total_out;
    size_t input_size  = (size_t)total_in * fr * fc;
    size_t weight_size = (size_t)total_out * kernel * kernel * in_output;
    size_t output_size = (size_t)total_out * fr * fc;

    float *h_bias   = (float*)malloc(bias_size * sizeof(float));
    float *h_input  = (float*)malloc(input_size * sizeof(float));
    float *h_weight = (float*)malloc(weight_size * sizeof(float));
    float *h_output = (float*)malloc(output_size * sizeof(float));

    for (size_t i = 0; i < bias_size; ++i) h_bias[i] = 0.1f;
    for (size_t i = 0; i < input_size; ++i) h_input[i] = (float)(i % 17) * 0.01f;
    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (float)(i % 13) * 0.02f;
    for (size_t i = 0; i < output_size; ++i) h_output[i] = 0.0f;

    float *d_bias = NULL, *d_input = NULL, *d_weight = NULL, *d_output = NULL;
    CHECK(cudaMalloc((void**)&d_bias, bias_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_input, input_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_output, output_size * sizeof(float)));

    CHECK(cudaMemcpy(d_bias, h_bias, bias_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_input, h_input, input_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_output, h_output, output_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block(fr, fc);

    execute3Dconvolutiongroup2Cuda<<<grid, block>>>(
        d_bias, d_input, d_weight, d_output,
        out, fr, fc, stride_width, kernel, pad, in_output, group
    );

    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_output, d_output, output_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("execute3Dconvolutiongroup2Cuda done.\n");
    for (int i = out * fr * fc; i < out * fr * fc + 10; ++i) {
        printf("output[%d] = %f\n", i, h_output[i]);
    }

    cudaFree(d_bias);
    cudaFree(d_input);
    cudaFree(d_weight);
    cudaFree(d_output);

    free(h_bias);
    free(h_input);
    free(h_weight);
    free(h_output);

    return 0;
}