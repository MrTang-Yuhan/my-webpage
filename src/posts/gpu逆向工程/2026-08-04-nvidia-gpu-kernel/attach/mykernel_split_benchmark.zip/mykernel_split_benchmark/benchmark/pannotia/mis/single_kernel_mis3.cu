// Auto-generated CUDA kernel file: mis3
// Extracted from: pannotia/mis/kernel.cu
// Original line: 183

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: mis3 (line 183)
__global__ void
mis3(int *cu_array, int *c_array, int num_nodes) {

    //get my workitem id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;

    //set the status array
    if (tid < num_nodes && cu_array[tid] == -2) {
        c_array[tid] = cu_array[tid];
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const size_t size_nodes = (size_t)num_nodes * sizeof(int);

    int *h_cu_array = (int*)malloc(size_nodes);
    int *h_c_array = (int*)malloc(size_nodes);

    int *d_cu_array = nullptr;
    int *d_c_array = nullptr;

    if (!h_cu_array || !h_c_array) {
        printf("host malloc failed\n");
        free(h_cu_array);
        free(h_c_array);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_cu_array[i] = -1;
        h_c_array[i] = -1;
    }

    // 构造一些会被拷贝的标记
    h_cu_array[0] = -2;
    h_cu_array[2] = -2;
    h_cu_array[4] = -2;

    err = cudaMalloc((void**)&d_cu_array, size_nodes);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_cu_array failed: %s\n", cudaGetErrorString(err));
        free(h_cu_array);
        free(h_c_array);
        return -1;
    }

    err = cudaMalloc((void**)&d_c_array, size_nodes);
    if (err != cudaSuccess) {
        printf("cudaMalloc d_c_array failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_cu_array);
        free(h_cu_array);
        free(h_c_array);
        return -1;
    }

    cudaMemcpy(d_cu_array, h_cu_array, size_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_c_array, h_c_array, size_nodes, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    mis3<<<gridSize, blockSize>>>(d_cu_array, d_c_array, num_nodes);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_cu_array);
        cudaFree(d_c_array);
        free(h_cu_array);
        free(h_c_array);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_cu_array);
        cudaFree(d_c_array);
        free(h_cu_array);
        free(h_c_array);
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
        return -1;
    }

    cudaMemcpy(h_c_array, d_c_array, size_nodes, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("mis3 execution time: %.3f ms\n", ms);

    printf("c_array[0] = %d\n", h_c_array[0]);
    printf("c_array[1] = %d\n", h_c_array[1]);
    printf("c_array[2] = %d\n", h_c_array[2]);
    printf("c_array[4] = %d\n", h_c_array[4]);

    cudaFree(d_cu_array);
    cudaFree(d_c_array);
    free(h_cu_array);
    free(h_c_array);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}