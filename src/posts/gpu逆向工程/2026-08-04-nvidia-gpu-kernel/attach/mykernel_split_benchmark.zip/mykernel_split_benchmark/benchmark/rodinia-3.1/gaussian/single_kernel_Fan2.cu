// Auto-generated CUDA kernel file: Fan2
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "cuda.h"
#include <string.h>
#include <math.h>

#define MAXBLOCKSIZE 512
#define BLOCK_SIZE_XY 4

__global__ void Fan2(float *m_cuda, float *a_cuda, float *b_cuda,
                     int Size, int j1, int t) {
    if(threadIdx.x + blockIdx.x * blockDim.x >= Size-1-t) return;
    if(threadIdx.y + blockIdx.y * blockDim.y >= Size-t)   return;

    int xidx = blockIdx.x * blockDim.x + threadIdx.x;
    int yidx = blockIdx.y * blockDim.y + threadIdx.y;

    a_cuda[Size*(xidx+1+t)+(yidx+t)] -=
        m_cuda[Size*(xidx+1+t)+t] * a_cuda[Size*t+(yidx+t)];

    if(yidx == 0) {
        b_cuda[xidx+1+t] -=
            m_cuda[Size*(xidx+1+t)+(yidx+t)] * b_cuda[t];
    }
}

int main(int argc, char *argv[]) {
    int Size = 4;  // 矩阵大小
    int t    = 0;  // 消元步骤
    int j1   = 0;

    size_t bytes = Size * Size * sizeof(float);
    size_t vbytes = Size * sizeof(float);

    // 初始化主机数据
    float *h_m = (float*)calloc(Size * Size, sizeof(float));
    float *h_a = (float*)malloc(bytes);
    float *h_b = (float*)malloc(vbytes);
    for (int i = 0; i < Size * Size; i++) h_a[i] = (float)(i + 1);
    for (int i = 0; i < Size; i++)        h_b[i] = (float)(i + 1);
    // 给 m 赋一个简单的乘数
    for (int i = 1; i < Size; i++) h_m[Size * i + 0] = 0.5f;

    // 分配设备内存
    float *d_m, *d_a, *d_b;
    cudaMalloc(&d_m, bytes);
    cudaMalloc(&d_a, bytes);
    cudaMalloc(&d_b, vbytes);
    cudaMemcpy(d_m, h_m, bytes,  cudaMemcpyHostToDevice);
    cudaMemcpy(d_a, h_a, bytes,  cudaMemcpyHostToDevice);
    cudaMemcpy(d_b, h_b, vbytes, cudaMemcpyHostToDevice);

    // 启动 kernel（2D grid）
    dim3 threads(BLOCK_SIZE_XY, BLOCK_SIZE_XY);
    dim3 blocks((Size - 1 - t + threads.x - 1) / threads.x,
                (Size - t     + threads.y - 1) / threads.y);
    Fan2<<<blocks, threads>>>(d_m, d_a, d_b, Size, j1, t);
    cudaDeviceSynchronize();

    // 取回结果并打印
    cudaMemcpy(h_a, d_a, bytes,  cudaMemcpyDeviceToHost);
    cudaMemcpy(h_b, d_b, vbytes, cudaMemcpyDeviceToHost);
    printf("a_cuda[1][0]: %f\n", h_a[Size * 1 + 0]);
    printf("b_cuda[1]:    %f\n", h_b[1]);

    cudaFree(d_m); cudaFree(d_a); cudaFree(d_b);
    free(h_m);     free(h_a);     free(h_b);
    return 0;
}