// Standalone version for single_kernel_dfindcompmintwo.cu

#include "common.h"
#include "graph.h"
#include "component.h"
#include "gbar.cuh"
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MYINFINITY 100000000
#define dprintf if (debug) printf

// ===== Kernel =====
__global__ void dfindcompmintwo(unsigned *mstwt, Graph graph, ComponentSpace csw,
                                foru *eleminwts, foru *minwtcomponent,
                                unsigned *partners, unsigned *phores,
                                bool *processinnextiteration,
                                unsigned *goaheadnodeofcomponent,
                                unsigned inpid, GlobalBarrier gb,
                                bool *repeat, unsigned *count) {
    unsigned tid = blockIdx.x * blockDim.x + threadIdx.x;
    unsigned id, nthreads = blockDim.x * gridDim.x;
    if (inpid < graph.nnodes) id = inpid;

    unsigned up = (graph.nnodes + nthreads - 1) / nthreads * nthreads;
    unsigned srcboss, dstboss;

    for (id = tid; id < up; id += nthreads) {
        if (id < graph.nnodes && processinnextiteration[id]) {
            srcboss = csw.find(id);
            dstboss = csw.find(partners[id]);
        }

        gb.Sync();

        if (id < graph.nnodes && processinnextiteration[id] && srcboss != dstboss) {
            dprintf("trying unify id=%d (%d -> %d)\n", id, srcboss, dstboss);

            if (csw.unify(srcboss, dstboss)) {
                atomicAdd(mstwt, eleminwts[id]);
                atomicAdd(count, 1u);
                processinnextiteration[id] = false;
                eleminwts[id] = MYINFINITY;
            } else {
                *repeat = true;
            }
        }

        gb.Sync();
    }
}

static void build_test_graph(Graph &hg) {
    hg.nnodes = 3;
    hg.nedges = 6;
    hg.allocOnHost();

    for (unsigned i = 0; i < hg.nnodes; i++) hg.srcsrc[i] = i;
    hg.psrc[0] = 1; hg.psrc[1] = 3; hg.psrc[2] = 5;
    hg.noutgoing[0] = 2; hg.noutgoing[1] = 2; hg.noutgoing[2] = 2;
    hg.nincoming[0] = 2; hg.nincoming[1] = 2; hg.nincoming[2] = 2;

    hg.edgessrcdst[1] = 1; hg.edgessrcwt[1] = 1;
    hg.edgessrcdst[2] = 2; hg.edgessrcwt[2] = 4;
    hg.edgessrcdst[3] = 0; hg.edgessrcwt[3] = 1;
    hg.edgessrcdst[4] = 2; hg.edgessrcwt[4] = 2;
    hg.edgessrcdst[5] = 0; hg.edgessrcwt[5] = 4;
    hg.edgessrcdst[6] = 1; hg.edgessrcwt[6] = 2;
}

int main() {
    Graph hgraph, graph;
    build_test_graph(hgraph);
    hgraph.cudaCopy(graph);

    ComponentSpace cs(graph.nnodes);

    unsigned *mstwt = NULL, *phores = NULL, *goahead = NULL, *partners = NULL, *count = NULL;
    foru *eleminwts = NULL, *minwtcomponent = NULL;
    bool *process = NULL, *repeat = NULL;

    unsigned hmstwt = 0, hcount = 0, h_goahead[3] = {0, 1, 2}, h_phores[3] = {0, 0, 0};
    unsigned h_partners[3] = {1, 1, 2};
    foru h_elemin[3] = {1, MYINFINITY, MYINFINITY};
    foru h_mincomp[3] = {1, MYINFINITY, MYINFINITY};
    bool h_process[3] = {true, false, false};
    bool h_repeat = false;

    cudaMalloc((void **)&mstwt, sizeof(unsigned));
    cudaMalloc((void **)&count, sizeof(unsigned));
    cudaMalloc((void **)&eleminwts, 3 * sizeof(foru));
    cudaMalloc((void **)&minwtcomponent, 3 * sizeof(foru));
    cudaMalloc((void **)&partners, 3 * sizeof(unsigned));
    cudaMalloc((void **)&phores, 3 * sizeof(unsigned));
    cudaMalloc((void **)&process, 3 * sizeof(bool));
    cudaMalloc((void **)&goahead, 3 * sizeof(unsigned));
    cudaMalloc((void **)&repeat, sizeof(bool));

    cudaMemcpy(mstwt, &hmstwt, sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(count, &hcount, sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(eleminwts, h_elemin, 3 * sizeof(foru), cudaMemcpyHostToDevice);
    cudaMemcpy(minwtcomponent, h_mincomp, 3 * sizeof(foru), cudaMemcpyHostToDevice);
    cudaMemcpy(partners, h_partners, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(phores, h_phores, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(process, h_process, 3 * sizeof(bool), cudaMemcpyHostToDevice);
    cudaMemcpy(goahead, h_goahead, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(repeat, &h_repeat, sizeof(bool), cudaMemcpyHostToDevice);

    GlobalBarrierLifetime gbl;
    gbl.Setup(1);

    dfindcompmintwo<<<1, 128>>>(mstwt, graph, cs, eleminwts, minwtcomponent,
                                partners, phores, process, goahead,
                                graph.nnodes, gbl, repeat, count);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(&hmstwt, mstwt, sizeof(unsigned), cudaMemcpyDeviceToHost);
    cudaMemcpy(&hcount, count, sizeof(unsigned), cudaMemcpyDeviceToHost);
    cudaMemcpy(&h_repeat, repeat, sizeof(bool), cudaMemcpyDeviceToHost);

    printf("dfindcompmintwo finished\n");
    printf("mstwt = %u\n", hmstwt);
    printf("count = %u\n", hcount);
    printf("repeat = %d\n", (int)h_repeat);
    printf("components = %u\n", cs.numberOfComponentsHost());

    cudaFree(mstwt);
    cudaFree(count);
    cudaFree(eleminwts);
    cudaFree(minwtcomponent);
    cudaFree(partners);
    cudaFree(phores);
    cudaFree(process);
    cudaFree(goahead);
    cudaFree(repeat);
    graph.deallocOnDevice();
    hgraph.deallocOnHost();

    return 0;
}