// Auto-generated CUDA kernel file: executeBnNormLayerCUDA_split
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 815

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeBnNormLayerCUDA_split (line 815)
__global__ void executeBnNormLayerCUDA_split(float *Layer_Neurons,float *mean,float *var,int out,int f_size,int tfactor) {

           int output = blockIdx.x;
	   int row_even = threadIdx.x * tfactor;
	   int col_even = threadIdx.y * tfactor;
	   if(row_even < f_size && col_even < f_size)
	   {      
		   for(int row= row_even; row < row_even + tfactor ; row++) 
		   {	
			   for(int col =col_even; col < col_even+ tfactor ;col++) 
			   {
				   { 
					   Layer_Neurons[output*f_size*f_size + row*f_size + col] = (Layer_Neurons[output*f_size*f_size + row*f_size + col] - mean[output])/(sqrt(var[output] + 1e-5));

				   }
			   }
		   }
	   }

}

#include <math.h>


int main() {
    const int out = 4;
    const int f_size = 8;
    const int tfactor = 2;

    size_t neuron_size = (size_t)out * f_size * f_size;
    size_t stat_size = out;

    float *h_neurons = (float*)malloc(neuron_size * sizeof(float));
    float *h_mean    = (float*)malloc(stat_size * sizeof(float));
    float *h_var     = (float*)malloc(stat_size * sizeof(float));

    for (size_t i = 0; i < neuron_size; ++i) h_neurons[i] = (float)(i % 25) * 0.1f;
    for (int i = 0; i < out; ++i) {
        h_mean[i] = 0.5f;
        h_var[i]  = 1.0f;
    }

    float *d_neurons = NULL, *d_mean = NULL, *d_var = NULL;
    CHECK(cudaMalloc((void**)&d_neurons, neuron_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_mean, stat_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_var, stat_size * sizeof(float)));

    CHECK(cudaMemcpy(d_neurons, h_neurons, neuron_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_mean, h_mean, stat_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_var, h_var, stat_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block((f_size + tfactor - 1) / tfactor, (f_size + tfactor - 1) / tfactor);

    executeBnNormLayerCUDA_split<<<grid, block>>>(d_neurons, d_mean, d_var, out, f_size, tfactor);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_neurons, d_neurons, neuron_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeBnNormLayerCUDA_split done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("neurons[%d] = %f\n", i, h_neurons[i]);
    }

    cudaFree(d_neurons);
    cudaFree(d_mean);
    cudaFree(d_var);

    free(h_neurons);
    free(h_mean);
    free(h_var);

    return 0;
}