// Auto-generated CUDA kernel file: mvt_kernel1
// Extracted from: polybench-gpu-1.0/CUDA/MVT/single_kernel_mvt_kernel1.cu
// Original line: 23

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define N 4096  // from line 26  // from line 16

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/MVT/single_kernel_mvt_kernel1.cu:19

// ===== Kernel =====
// Kernel: mvt_kernel1 (line 23)
__global__ void mvt_kernel1(DATA_TYPE *a, DATA_TYPE *x1, DATA_TYPE *y_1) {


	int i = blockIdx.x * blockDim.x + threadIdx.x;

	if (i < N)
	{
		int j;
		for(j=0; j < N; j++)
		{
			x1[i] += a[i * N + j] * y_1[j];
		}
	}


}
int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_mat = (size_t)N * N;
    const size_t size_vec = (size_t)N;

    DATA_TYPE *h_a   = (DATA_TYPE*)malloc(size_mat * sizeof(DATA_TYPE));
    DATA_TYPE *h_x1  = (DATA_TYPE*)malloc(size_vec * sizeof(DATA_TYPE));
    DATA_TYPE *h_y_1 = (DATA_TYPE*)malloc(size_vec * sizeof(DATA_TYPE));

    DATA_TYPE *d_a   = nullptr;
    DATA_TYPE *d_x1  = nullptr;
    DATA_TYPE *d_y_1 = nullptr;

    if (!h_a || !h_x1 || !h_y_1) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_mat; ++i) {
        h_a[i] = (DATA_TYPE)((i % 100) + 1) / 100.0f;
    }

    for (size_t i = 0; i < size_vec; ++i) {
        h_x1[i]  = 0.0f;
        h_y_1[i] = (DATA_TYPE)((i % 100) + 1) / 100.0f;
    }

    err = cudaMalloc((void**)&d_a, size_mat * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_a failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_x1, size_vec * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_x1 failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_y_1, size_vec * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_y_1 failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_a, h_a, size_mat * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D a failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_x1, h_x1, size_vec * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D x1 failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_y_1, h_y_1, size_vec * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D y_1 failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(256);
    dim3 gridSize((N + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    mvt_kernel1<<<gridSize, blockSize>>>(d_a, d_x1, d_y_1);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("mvt_kernel1 execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_x1, d_x1, size_vec * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H x1 failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("x1[0]     = %f\n", (double)h_x1[0]);
    printf("x1[N - 1] = %f\n", (double)h_x1[N - 1]);

    cudaFree(d_a);
    cudaFree(d_x1);
    cudaFree(d_y_1);

    free(h_a);
    free(h_x1);
    free(h_y_1);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}