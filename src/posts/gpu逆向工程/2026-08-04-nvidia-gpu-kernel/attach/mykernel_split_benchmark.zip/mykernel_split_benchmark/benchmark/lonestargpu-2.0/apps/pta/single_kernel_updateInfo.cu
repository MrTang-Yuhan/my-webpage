// Standalone CUDA kernel file: updateInfo
// Smoke-test version for PTA updateInfo kernel

#include "pta_single_kernel_test_common.cuh"

__device__ inline int isEmpty_updateInfo(uint var, uint rel) {
    uint head = getHeadIndex(var, rel);
    return graphGet(head + BASE) == NIL;
}

__device__ void syncAllThreads_updateInfo() {
    __syncthreads();

    uint to = gridDim.x - 1;
    if (isFirstThreadOfBlock()) {
        volatile uint* counter = &__counter__;
        if (atomicInc((uint*)counter, to) < to) {
            while (*counter) {
            }
        }
    }

    __syncthreads();
}

__global__ void updateInfo() {
    uint init = getThreadIdInGrid();
    uint inc = getThreadsPerGrid();
    uint nvars = __numVars__;

    // a) path compression + diffPtsMask update
    for (uint var = init; var < nvars; var += inc) {
        uint rep = getRepRec(var);

        if (rep != var) {
            setRep(var, rep);
        }

        uint nonEmpty = !isEmpty_updateInfo(rep, CURR_DIFF_PTS);
        uint ballot = __ballot_sync(0xFFFFFFFF, nonEmpty);

        uint base = BASE_OF(var);
        uint word = WORD_OF(var);

        if (threadIdx.x == word) {
            __diffPtsMask__[mul32(base) + word] = ballot;
        }
    }

    syncAllThreads_updateInfo();

    // b) update store rules
    uint to = __numStore__;

    for (uint index = init; index < to; index += inc) {
        uint src = __storeConstraints__[index];

        if (src != NIL) {
            src = getRepRec(src);

            uint old = atomicCAS(__lock__ + src, UNLOCKED, LOCKED);
            uint val = (old == UNLOCKED) ? src : NIL;

            __storeConstraints__[index] = val;
        }
    }

    syncAllThreads_updateInfo();

    // c) unlock
    for (uint index = init; index < to; index += inc) {
        uint src = __storeConstraints__[index];

        if (src != NIL) {
            uint rep = getRepRec(src);
            unlockVar(rep);
        }
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint h_store[MAX_TEST_VARS];
    for (uint i = 0; i < MAX_TEST_VARS; i++) {
        h_store[i] = NIL;
    }

    h_store[0] = 1;
    h_store[1] = 2;
    h_store[2] = 3;

    uint numStore = 3;

    checkCuda(cudaMemcpy(env.d_storeConstraints,
                         h_store,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy storeConstraints");

    checkCuda(cudaMemcpyToSymbol(__numStore__, &numStore, sizeof(uint)),
              "set __numStore__");

    dim3 block(32, 4);
    dim3 grid(1);

    updateInfo<<<grid, block>>>();
    checkCuda(cudaGetLastError(), "updateInfo launch failed");
    checkCuda(cudaDeviceSynchronize(), "updateInfo execution failed");

    uint h_rep[8];
    uint h_mask[8];
    uint h_store_out[8];

    checkCuda(cudaMemcpy(h_rep, env.d_rep, sizeof(h_rep), cudaMemcpyDeviceToHost), "copy rep");
    checkCuda(cudaMemcpy(h_mask, env.d_diffPtsMask, sizeof(h_mask), cudaMemcpyDeviceToHost), "copy mask");
    checkCuda(cudaMemcpy(h_store_out, env.d_storeConstraints, sizeof(h_store_out), cudaMemcpyDeviceToHost), "copy store out");

    printf("updateInfo finished\n");
    for (int i = 0; i < 8; i++) {
        printf("rep[%d]=%u diffMask[%d]=%u store[%d]=%u\n",
               i, h_rep[i], i, h_mask[i], i, h_store_out[i]);
    }

    destroyPTATestEnv(env);
    return 0;
}