// Auto-generated CUDA kernel file: bpnn_layerforward_CUDA
// Extracted from: rodinia/2.0-ft/backprop/backprop_cuda_kernel.cu
// Original line: 12

// ===== Includes =====
#include <stdio.h>
#include "backprop.h"
#include "math.h"
#include "cuda.h"

// ===== Macro Definitions =====
#define _BACKPROP_CUDA_KERNEL_H_  // from line 4

// ===== Kernel =====
// Kernel: bpnn_layerforward_CUDA (line 12)
__global__ void
bpnn_layerforward_CUDA(float *input_cuda,
	                   float *output_hidden_cuda,
					   float *input_hidden_cuda,
					   float *hidden_partial_sum,
					   int in,
					   int hid) {

   int by = blockIdx.y;  // [参数: in]
   int tx = threadIdx.x;  // [参数: in]
   int ty = threadIdx.y;  // [参数: in]

   int index =  ( hid + 1 ) * HEIGHT * by + ( hid + 1 ) * ty + tx + 1 + ( hid + 1 ) ;    // [参数: in, hid]

   int index_in = HEIGHT * by + ty + 1;  // [参数: in]
   
   __shared__ float input_node[HEIGHT];  // [参数: in]
   __shared__ float weight_matrix[HEIGHT][WIDTH];


   if ( tx == 0 )
   input_node[ty] = input_cuda[index_in] ;  // [参数: input_cuda, in]
   
   __syncthreads();

   weight_matrix[ty][tx] = input_hidden_cuda[index];  // [参数: input_hidden_cuda, in, hid]

   __syncthreads();
   
   weight_matrix[ty][tx] = weight_matrix[ty][tx] * input_node[ty];  // [参数: in]

   __syncthreads();   
   
   for ( int i = 1 ; i <= __log2f(HEIGHT) ; i++){  // [参数: in]
 
	   int power_two = __powf(2, i);  // [参数: in]

	   if( ty % power_two == 0 )
	   weight_matrix[ty][tx] = weight_matrix[ty][tx] + weight_matrix[ty + power_two/2][tx];

	   __syncthreads();

   }
   
   //__syncthreads();

   input_hidden_cuda[index] = weight_matrix[ty][tx];  // [参数: input_hidden_cuda, in, hid]
   
/*
   for ( unsigned int i = 2 ; i <= HEIGHT ; i *= 2){  // [参数: in]
 
	   unsigned int power_two = i - 1;  // [参数: in]

	   if( (ty & power_two) == 0 ) {
		weight_matrix[ty][tx] = weight_matrix[ty][tx] + weight_matrix[ty + power_two/2][tx];
	   }

   }
   */

   __syncthreads();

   if ( tx == 0 ) {
	   hidden_partial_sum[by * hid + ty] = weight_matrix[tx][ty];  // [参数: hidden_partial_sum, hid]
   }


}


int main() {
  int in = HEIGHT;
  int hid = WIDTH;

  size_t input_size   = (HEIGHT + 1) * sizeof(float);
  size_t output_size  = (hid + 1) * sizeof(float);
  size_t weight_size  = (hid + 1) * HEIGHT * sizeof(float);
  size_t partial_size = hid * sizeof(float);

  float *h_input   = (float*)malloc(input_size);
  float *h_output  = (float*)malloc(output_size);
  float *h_weight  = (float*)malloc(weight_size);
  float *h_partial = (float*)malloc(partial_size);

  for (int i = 0; i < HEIGHT + 1; i++) h_input[i] = 1.0f;
  for (int i = 0; i < hid + 1; i++) h_output[i] = 0.0f;
  for (int i = 0; i < (hid + 1) * HEIGHT; i++) h_weight[i] = 0.5f;
  for (int i = 0; i < hid; i++) h_partial[i] = 0.0f;

  float *d_input, *d_output, *d_weight, *d_partial;
  cudaMalloc((void**)&d_input, input_size);
  cudaMalloc((void**)&d_output, output_size);
  cudaMalloc((void**)&d_weight, weight_size);
  cudaMalloc((void**)&d_partial, partial_size);

  cudaMemcpy(d_input, h_input, input_size, cudaMemcpyHostToDevice);
  cudaMemcpy(d_output, h_output, output_size, cudaMemcpyHostToDevice);
  cudaMemcpy(d_weight, h_weight, weight_size, cudaMemcpyHostToDevice);
  cudaMemcpy(d_partial, h_partial, partial_size, cudaMemcpyHostToDevice);

  dim3 block(WIDTH, HEIGHT);
  dim3 grid(1, 1);

  bpnn_layerforward_CUDA<<<grid, block>>>(d_input, d_output, d_weight, d_partial, in, hid);
  cudaDeviceSynchronize();

  cudaMemcpy(h_partial, d_partial, partial_size, cudaMemcpyDeviceToHost);

  printf("bpnn_layerforward_CUDA finished. h_partial[0]=%f\n", h_partial[0]);

  cudaFree(d_input);
  cudaFree(d_output);
  cudaFree(d_weight);
  cudaFree(d_partial);

  free(h_input);
  free(h_output);
  free(h_weight);
  free(h_partial);

  return 0;
}