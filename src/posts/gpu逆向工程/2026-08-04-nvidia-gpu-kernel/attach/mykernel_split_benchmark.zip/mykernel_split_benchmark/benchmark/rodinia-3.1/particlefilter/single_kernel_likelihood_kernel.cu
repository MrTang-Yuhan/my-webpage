// Auto-generated CUDA kernel file: likelihood_kernel
// Extracted from: rodinia-3.1/particlefilter/single_kernel_likelihood_kernel.cu
// Original line: 68

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>
#include <float.h>
#include <sys/time.h>

// ===== Device Functions =====
// Function: calcLikelihoodSum (line 18)
__device__ double calcLikelihoodSum(unsigned char * I, int * ind, int numOnes, int index) {


    double likelihoodSum = 0.0;
    int x;
    for (x = 0; x < numOnes; x++)
        likelihoodSum += (pow((double) (I[ind[index * numOnes + x]] - 100), 2) - pow((double) (I[ind[index * numOnes + x]] - 228), 2)) / 50.0;
    return likelihoodSum;


}

__device__ double d_randu(int * seed, int index);
// Function: d_randn (line 29)
__device__ double d_randn(int * seed, int index) {


    //Box-Muller algortihm
    double pi = 3.14159265358979323846;
    double u = d_randu(seed, index);
    double v = d_randu(seed, index);
    double cosine = cos(2 * pi * v);
    double rt = -2 * log(u);
    return sqrt(rt) * cosine;


}

// Function: d_randu (line 42)
__device__ double d_randu(int * seed, int index) {



    int M = INT_MAX;
    int A = 1103515245;
    int C = 12345;
    int num = A * seed[index] + C;
    seed[index] = num % M;

    return fabs(seed[index] / ((double) M));


}

// Function: dev_round_double (line 56)
__device__ double dev_round_double(double value) {


    int newValue = (int) (value);
    if (value - newValue < .5f)
        return newValue;
    else
        return newValue++;


}

// ===== Kernel =====
// Kernel: likelihood_kernel (line 68)
__global__ void likelihood_kernel(double * arrayX, double * arrayY, double * xj, double * yj, double * CDF, int * ind, int * objxy, double * likelihood, unsigned char * I, double * u, double * weights, int Nparticles, int countOnes, int max_size, int k, int IszY, int Nfr, int *seed, double* partial_sums) {


    int block_id = blockIdx.x;
    int i = blockDim.x * block_id + threadIdx.x;
    int y;
    
    int indX, indY; 
    __shared__ double buffer[512];
    if (i < Nparticles) {
        arrayX[i] = xj[i]; 
        arrayY[i] = yj[i]; 

        weights[i] = 1 / ((double) (Nparticles)); //Donnie - moved this line from end of find_index_kernel to prevent all weights from being reset before calculating position on final iteration.

        arrayX[i] = arrayX[i] + 1.0 + 5.0 * d_randn(seed, i);
        arrayY[i] = arrayY[i] - 2.0 + 2.0 * d_randn(seed, i);
        
    }

    __syncthreads();

    if (i < Nparticles) {
        for (y = 0; y < countOnes; y++) {
            //added dev_round_double() to be consistent with roundDouble
            indX = dev_round_double(arrayX[i]) + objxy[y * 2 + 1];
            indY = dev_round_double(arrayY[i]) + objxy[y * 2];
            
            ind[i * countOnes + y] = abs(indX * IszY * Nfr + indY * Nfr + k);
            if (ind[i * countOnes + y] >= max_size)
                ind[i * countOnes + y] = 0;
        }
        likelihood[i] = calcLikelihoodSum(I, ind, countOnes, i);
        
        likelihood[i] = likelihood[i] / countOnes;
        
        weights[i] = weights[i] * exp(likelihood[i]); //Donnie Newell - added the missing exponential function call
        
    }

    buffer[threadIdx.x] = 0.0;

    __syncthreads();

    if (i < Nparticles) {

        buffer[threadIdx.x] = weights[i];
    }

    __syncthreads();

    //this doesn't account for the last block that isn't full
    for (unsigned int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (threadIdx.x < s) {
            buffer[threadIdx.x] += buffer[threadIdx.x + s];
        }
        
        __syncthreads();
            
    }
    if (threadIdx.x == 0) {
        partial_sums[blockIdx.x] = buffer[0];
    }
    
    __syncthreads();

    


}

#include <cuda_runtime.h>

static void checkCuda(cudaError_t err, const char* msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "CUDA error at %s: %s\n", msg, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

int main() {
    const int Nparticles = 1024;
    const int countOnes = 4;
    const int max_size = 4096;
    const int k = 0;
    const int IszY = 16;
    const int Nfr = 16;

    const int threads = 512;
    const int blocks = (Nparticles + threads - 1) / threads;

    double *h_arrayX = (double*)malloc(sizeof(double) * Nparticles);
    double *h_arrayY = (double*)malloc(sizeof(double) * Nparticles);
    double *h_xj = (double*)malloc(sizeof(double) * Nparticles);
    double *h_yj = (double*)malloc(sizeof(double) * Nparticles);
    double *h_CDF = (double*)malloc(sizeof(double) * Nparticles);
    int *h_ind = (int*)malloc(sizeof(int) * Nparticles * countOnes);
    int *h_objxy = (int*)malloc(sizeof(int) * countOnes * 2);
    double *h_likelihood = (double*)malloc(sizeof(double) * Nparticles);
    unsigned char *h_I = (unsigned char*)malloc(sizeof(unsigned char) * max_size);
    double *h_u = (double*)malloc(sizeof(double) * Nparticles);
    double *h_weights = (double*)malloc(sizeof(double) * Nparticles);
    int *h_seed = (int*)malloc(sizeof(int) * Nparticles);
    double *h_partial_sums = (double*)malloc(sizeof(double) * blocks);

    for (int i = 0; i < Nparticles; i++) {
        h_arrayX[i] = 0.0;
        h_arrayY[i] = 0.0;
        h_xj[i] = 10.0 + (i % 7);
        h_yj[i] = 20.0 + (i % 5);
        h_CDF[i] = (double)(i + 1) / Nparticles;
        h_likelihood[i] = 0.0;
        h_u[i] = 0.0;
        h_weights[i] = 1.0 / Nparticles;
        h_seed[i] = 1234 + i;
    }

    for (int i = 0; i < Nparticles * countOnes; i++) h_ind[i] = 0;
    for (int i = 0; i < blocks; i++) h_partial_sums[i] = 0.0;
    for (int i = 0; i < max_size; i++) h_I[i] = (unsigned char)(i % 256);

    for (int i = 0; i < countOnes; i++) {
        h_objxy[2 * i] = i;
        h_objxy[2 * i + 1] = i;
    }

    double *d_arrayX, *d_arrayY, *d_xj, *d_yj, *d_CDF, *d_likelihood, *d_u, *d_weights, *d_partial_sums;
    int *d_ind, *d_objxy, *d_seed;
    unsigned char *d_I;

    checkCuda(cudaMalloc((void**)&d_arrayX, sizeof(double) * Nparticles), "cudaMalloc d_arrayX");
    checkCuda(cudaMalloc((void**)&d_arrayY, sizeof(double) * Nparticles), "cudaMalloc d_arrayY");
    checkCuda(cudaMalloc((void**)&d_xj, sizeof(double) * Nparticles), "cudaMalloc d_xj");
    checkCuda(cudaMalloc((void**)&d_yj, sizeof(double) * Nparticles), "cudaMalloc d_yj");
    checkCuda(cudaMalloc((void**)&d_CDF, sizeof(double) * Nparticles), "cudaMalloc d_CDF");
    checkCuda(cudaMalloc((void**)&d_ind, sizeof(int) * Nparticles * countOnes), "cudaMalloc d_ind");
    checkCuda(cudaMalloc((void**)&d_objxy, sizeof(int) * countOnes * 2), "cudaMalloc d_objxy");
    checkCuda(cudaMalloc((void**)&d_likelihood, sizeof(double) * Nparticles), "cudaMalloc d_likelihood");
    checkCuda(cudaMalloc((void**)&d_I, sizeof(unsigned char) * max_size), "cudaMalloc d_I");
    checkCuda(cudaMalloc((void**)&d_u, sizeof(double) * Nparticles), "cudaMalloc d_u");
    checkCuda(cudaMalloc((void**)&d_weights, sizeof(double) * Nparticles), "cudaMalloc d_weights");
    checkCuda(cudaMalloc((void**)&d_seed, sizeof(int) * Nparticles), "cudaMalloc d_seed");
    checkCuda(cudaMalloc((void**)&d_partial_sums, sizeof(double) * blocks), "cudaMalloc d_partial_sums");

    checkCuda(cudaMemcpy(d_arrayX, h_arrayX, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "memcpy arrayX");
    checkCuda(cudaMemcpy(d_arrayY, h_arrayY, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "memcpy arrayY");
    checkCuda(cudaMemcpy(d_xj, h_xj, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "memcpy xj");
    checkCuda(cudaMemcpy(d_yj, h_yj, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "memcpy yj");
    checkCuda(cudaMemcpy(d_CDF, h_CDF, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "memcpy CDF");
    checkCuda(cudaMemcpy(d_ind, h_ind, sizeof(int) * Nparticles * countOnes, cudaMemcpyHostToDevice), "memcpy ind");
    checkCuda(cudaMemcpy(d_objxy, h_objxy, sizeof(int) * countOnes * 2, cudaMemcpyHostToDevice), "memcpy objxy");
    checkCuda(cudaMemcpy(d_likelihood, h_likelihood, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "memcpy likelihood");
    checkCuda(cudaMemcpy(d_I, h_I, sizeof(unsigned char) * max_size, cudaMemcpyHostToDevice), "memcpy I");
    checkCuda(cudaMemcpy(d_u, h_u, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "memcpy u");
    checkCuda(cudaMemcpy(d_weights, h_weights, sizeof(double) * Nparticles, cudaMemcpyHostToDevice), "memcpy weights");
    checkCuda(cudaMemcpy(d_seed, h_seed, sizeof(int) * Nparticles, cudaMemcpyHostToDevice), "memcpy seed");
    checkCuda(cudaMemcpy(d_partial_sums, h_partial_sums, sizeof(double) * blocks, cudaMemcpyHostToDevice), "memcpy partial_sums");

    likelihood_kernel<<<blocks, threads>>>(
        d_arrayX, d_arrayY, d_xj, d_yj, d_CDF, d_ind, d_objxy, d_likelihood,
        d_I, d_u, d_weights, Nparticles, countOnes, max_size, k, IszY, Nfr, d_seed, d_partial_sums
    );

    checkCuda(cudaGetLastError(), "launch likelihood_kernel");
    checkCuda(cudaDeviceSynchronize(), "sync likelihood_kernel");

    checkCuda(cudaMemcpy(h_partial_sums, d_partial_sums, sizeof(double) * blocks, cudaMemcpyDeviceToHost), "copy back partial_sums");
    checkCuda(cudaMemcpy(h_weights, d_weights, sizeof(double) * Nparticles, cudaMemcpyDeviceToHost), "copy back weights");

    printf("likelihood_kernel finished.\n");
    printf("partial_sums[0] = %f\n", h_partial_sums[0]);
    printf("weights[0] = %f\n", h_weights[0]);

    cudaFree(d_arrayX); cudaFree(d_arrayY); cudaFree(d_xj); cudaFree(d_yj);
    cudaFree(d_CDF); cudaFree(d_ind); cudaFree(d_objxy); cudaFree(d_likelihood);
    cudaFree(d_I); cudaFree(d_u); cudaFree(d_weights); cudaFree(d_seed); cudaFree(d_partial_sums);

    free(h_arrayX); free(h_arrayY); free(h_xj); free(h_yj); free(h_CDF);
    free(h_ind); free(h_objxy); free(h_likelihood); free(h_I); free(h_u);
    free(h_weights); free(h_seed); free(h_partial_sums);

    return 0;
}