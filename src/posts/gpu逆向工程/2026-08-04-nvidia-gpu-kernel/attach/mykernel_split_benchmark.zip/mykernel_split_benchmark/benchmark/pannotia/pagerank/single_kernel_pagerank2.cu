// Auto-generated CUDA kernel file: pagerank2
// Extracted from: pannotia/pagerank/kernel.cu
// Original line: 105

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: pagerank2 (line 105)
__global__ void
pagerank2(int *row, int *col, int *data, float *page_rank1, float *page_rank2,
          const int num_nodes, const int num_edges) {

    // Get my workitem id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;

    // Update pagerank value with the damping factor
    if (tid < num_nodes) {
        page_rank1[tid]	= 0.15 / (float)num_nodes + 0.85 * page_rank2[tid];
        page_rank2[tid] = 0.0f;
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;

    const size_t size_row = (size_t)num_nodes * sizeof(int);
    const size_t size_col = (size_t)num_edges * sizeof(int);
    const size_t size_data = (size_t)num_edges * sizeof(int);
    const size_t size_pr = (size_t)num_nodes * sizeof(float);

    int *h_row = (int*)malloc(size_row);
    int *h_col = (int*)malloc(size_col);
    int *h_data = (int*)malloc(size_data);
    float *h_page_rank1 = (float*)malloc(size_pr);
    float *h_page_rank2 = (float*)malloc(size_pr);

    int *d_row = nullptr;
    int *d_col = nullptr;
    int *d_data = nullptr;
    float *d_page_rank1 = nullptr;
    float *d_page_rank2 = nullptr;

    if (!h_row || !h_col || !h_data || !h_page_rank1 || !h_page_rank2) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_col);
        free(h_data);
        free(h_page_rank1);
        free(h_page_rank2);
        return -1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_row[i] = (i < num_nodes - 1) ? i : num_edges;
        h_page_rank1[i] = 0.0f;
        h_page_rank2[i] = 1.0f / (float)num_nodes;
    }

    for (int i = 0; i < num_edges; ++i) {
        h_col[i] = i + 1;
        h_data[i] = 1;
    }

    cudaMalloc((void**)&d_row, size_row);
    cudaMalloc((void**)&d_col, size_col);
    cudaMalloc((void**)&d_data, size_data);
    cudaMalloc((void**)&d_page_rank1, size_pr);
    cudaMalloc((void**)&d_page_rank2, size_pr);

    cudaMemcpy(d_row, h_row, size_row, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col, h_col, size_col, cudaMemcpyHostToDevice);
    cudaMemcpy(d_data, h_data, size_data, cudaMemcpyHostToDevice);
    cudaMemcpy(d_page_rank1, h_page_rank1, size_pr, cudaMemcpyHostToDevice);
    cudaMemcpy(d_page_rank2, h_page_rank2, size_pr, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    pagerank2<<<gridSize, blockSize>>>(
        d_row, d_col, d_data, d_page_rank1, d_page_rank2, num_nodes, num_edges
    );
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_page_rank1, d_page_rank1, size_pr, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_page_rank2, d_page_rank2, size_pr, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop);
    printf("pagerank2 execution time: %.3f ms\n", ms);

    printf("page_rank1[0] = %f\n", h_page_rank1[0]);
    printf("page_rank1[1] = %f\n", h_page_rank1[1]);
    printf("page_rank2[0] = %f\n", h_page_rank2[0]);

    cudaFree(d_row);
    cudaFree(d_col);
    cudaFree(d_data);
    cudaFree(d_page_rank1);
    cudaFree(d_page_rank2);

    free(h_row);
    free(h_col);
    free(h_data);
    free(h_page_rank1);
    free(h_page_rank2);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}