// Auto-generated CUDA kernel file: Fan1
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "cuda.h"
#include <string.h>
#include <math.h>

#define MAXBLOCKSIZE 512
#define BLOCK_SIZE_XY 4

__global__ void Fan1(float *m_cuda, float *a_cuda, int Size, int t) {
    if(threadIdx.x + blockIdx.x * blockDim.x >= Size-1-t) return;
    *(m_cuda+Size*(blockDim.x*blockIdx.x+threadIdx.x+t+1)+t) =
        *(a_cuda+Size*(blockDim.x*blockIdx.x+threadIdx.x+t+1)+t) /
        *(a_cuda+Size*t+t);
}

int main(int argc, char *argv[]) {
    int Size = 4;  // 矩阵大小
    int t    = 0;  // 消元步骤

    size_t bytes = Size * Size * sizeof(float);

    // 初始化主机数据
    float *h_m = (float*)calloc(Size * Size, sizeof(float));
    float *h_a = (float*)malloc(bytes);
    for (int i = 0; i < Size * Size; i++)
        h_a[i] = (float)(i + 1);

    // 分配设备内存
    float *d_m, *d_a;
    cudaMalloc(&d_m, bytes);
    cudaMalloc(&d_a, bytes);
    cudaMemcpy(d_m, h_m, bytes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_a, h_a, bytes, cudaMemcpyHostToDevice);

    // 启动 kernel
    int threads = MAXBLOCKSIZE;
    int blocks  = (Size - 1 - t + threads - 1) / threads;
    Fan1<<<blocks, threads>>>(d_m, d_a, Size, t);
    cudaDeviceSynchronize();

    // 取回结果并打印
    cudaMemcpy(h_m, d_m, bytes, cudaMemcpyDeviceToHost);
    printf("m_cuda (row 1, col 0): %f\n", h_m[Size * 1 + 0]);

    cudaFree(d_m); cudaFree(d_a);
    free(h_m);     free(h_a);
    return 0;
}