// Auto-generated CUDA kernel file: syr2k_kernel
// Extracted from: polybench-gpu-1.0/CUDA/SYR2K/syr2k.cu
// Original line: 119

// ===== Includes =====
// #include "../../common/polybenchUtilFuncts.h"
#include <assert.h>
#include <cuda.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// ===== Macro Definitions =====
#define ALPHA 12435  // from line 34
#define BETA 4546  // from line 35
#define M 2048  // from line 27
#define N 2048  // from line 26

// ===== Type Definitions =====
typedef float DATA_TYPE; // from polybench-gpu-1.0/CUDA/SYR2K/syr2k.cu:38

// ===== Kernel =====
// Kernel: syr2k_kernel (line 119)
__global__ void syr2k_kernel(DATA_TYPE *a, DATA_TYPE *b, DATA_TYPE *c) {

	int j = blockIdx.x * blockDim.x + threadIdx.x;
	int i = blockIdx.y * blockDim.y + threadIdx.y;

	if ((i < N) && (j < N))
	{
		c[i * N + j] *= BETA;
		
		int k;
		for(k = 0; k < M; k++)
		{
			c[i * N + j] += ALPHA * a[i * M + k] * b[j * M + k] + ALPHA * b[i * M + k] * a[j * M + k];
		}
	}

}

int main(int argc, char** argv) {
    cudaError_t err;

    const size_t size_a = (size_t)N * M;
    const size_t size_b = (size_t)N * M;
    const size_t size_c = (size_t)N * N;

    DATA_TYPE *h_a = (DATA_TYPE*)malloc(size_a * sizeof(DATA_TYPE));
    DATA_TYPE *h_b = (DATA_TYPE*)malloc(size_b * sizeof(DATA_TYPE));
    DATA_TYPE *h_c = (DATA_TYPE*)malloc(size_c * sizeof(DATA_TYPE));

    DATA_TYPE *d_a = nullptr;
    DATA_TYPE *d_b = nullptr;
    DATA_TYPE *d_c = nullptr;

    if (!h_a || !h_b || !h_c) {
        printf("host malloc failed\n");
        return -1;
    }

    for (size_t i = 0; i < size_a; ++i)
        h_a[i] = (DATA_TYPE)((i % 100) + 1) / 100.0f;

    for (size_t i = 0; i < size_b; ++i)
        h_b[i] = (DATA_TYPE)(((i + 1) % 100) + 1) / 100.0f;

    for (size_t i = 0; i < size_c; ++i)
        h_c[i] = (DATA_TYPE)((i % 100) + 1) / 100.0f;

    err = cudaMalloc((void**)&d_a, size_a * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_a failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_b, size_b * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_b failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMalloc((void**)&d_c, size_c * sizeof(DATA_TYPE));
    if (err != cudaSuccess) {
        printf("cudaMalloc d_c failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_a, h_a, size_a * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D a failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_b, h_b, size_b * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D b failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaMemcpy(d_c, h_c, size_c * sizeof(DATA_TYPE), cudaMemcpyHostToDevice);
    if (err != cudaSuccess) {
        printf("H2D c failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    dim3 blockSize(16, 16);
    dim3 gridSize((N + blockSize.x - 1) / blockSize.x,
                  (N + blockSize.y - 1) / blockSize.y);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    syr2k_kernel<<<gridSize, blockSize>>>(d_a, d_b, d_c);
    cudaEventRecord(stop);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaEventSynchronize(stop);
    float milliseconds = 0.0f;
    cudaEventElapsedTime(&milliseconds, start, stop);
    printf("syr2k_kernel execution time: %.3f ms\n", milliseconds);

    err = cudaMemcpy(h_c, d_c, size_c * sizeof(DATA_TYPE), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        printf("D2H c failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    printf("c[0] = %f\n", (double)h_c[0]);
    printf("c[N * N - 1] = %f\n", (double)h_c[size_c - 1]);

    cudaFree(d_a);
    cudaFree(d_b);
    cudaFree(d_c);

    free(h_a);
    free(h_b);
    free(h_c);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}