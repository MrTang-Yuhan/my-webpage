// Auto-generated CUDA kernel file: dynproc_kernel
// Extracted from: rodinia/2.0-ft/pathfinder/pathfinder.cu
// Original line: 101

// ===== Includes =====
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>

// ===== Macro Definitions =====
#define BLOCK_SIZE 256  // from line 6
#define STR_SIZE 256  // from line 7
#define DEVICE 0  // from line 8
#define HALO 1 // halo width along one direction when advancing to the next iteration  // from line 9
#define BENCH_PRINT  // from line 11
#define M_SEED 9  // from line 19
#define IN_RANGE(x, min, max)   ((x)>=(min) && (x)<=(max))  // from line 97
#define CLAMP_RANGE(x, min, max) x = (x<(min)) ? min : ((x>(max)) ? max : x )  // from line 98
#define MIN(a, b) ((a)<=(b) ? (a) : (b))  // from line 99

// ===== Global Variables =====
int* data;  // [来源: 全局作用域定义, line 16]
int* result;  // [来源: 全局作用域定义, line 18]

// ===== Kernel =====
// Kernel: dynproc_kernel (line 101)
__global__ void dynproc_kernel(
                int iteration, 
                int *gpuWall,
                int *gpuSrc,
                int *gpuResults,
                int cols, 
                int rows,
                int startStep,
                int border) {


        __shared__ int prev[BLOCK_SIZE];
        __shared__ int result[BLOCK_SIZE];

	int bx = blockIdx.x;
	int tx=threadIdx.x;
	
        // each block finally computes result for a small block
        // after N iterations. 
        // it is the non-overlapping small blocks that cover 
        // all the input data

        // calculate the small block size
	int small_block_cols = BLOCK_SIZE-iteration*HALO*2;  // [参数: iteration, cols]

        // calculate the boundary for the block according to 
        // the boundary of its small block
        int blkX = small_block_cols*bx-border;  // [参数: cols, border]
        int blkXmax = blkX+BLOCK_SIZE-1;

        // calculate the global thread coordination
	int xidx = blkX+tx;
       
        // effective range within this block that falls within 
        // the valid range of the input data
        // used to rule out computation outside the boundary.
        int validXmin = (blkX < 0) ? -blkX : 0;
        int validXmax = (blkXmax > cols-1) ? BLOCK_SIZE-1-(blkXmax-cols+1) : BLOCK_SIZE-1;  // [参数: cols]

        int W = tx-1;
        int E = tx+1;
        
        W = (W < validXmin) ? validXmin : W;
        E = (E > validXmax) ? validXmax : E;

        bool isValid = IN_RANGE(tx, validXmin, validXmax);

	if(IN_RANGE(xidx, 0, cols-1)){  // [参数: cols]
            prev[tx] = gpuSrc[xidx];  // [参数: gpuSrc]
	}

        bool computed;
        for (int i=0; i<iteration ; i++){   // [参数: iteration]
            computed = false;
            if( IN_RANGE(tx, i+1, BLOCK_SIZE-i-2) &&  \
                  isValid){
                  computed = true;
                  int left = prev[W];
                  int up = prev[tx];
                  int right = prev[E];
                  int shortest = MIN(left, up);
                  shortest = MIN(shortest, right);
                  int index = cols*(startStep+i)+xidx;  // [参数: cols, startStep]
                  result[tx] = shortest + gpuWall[index];  // [参数: gpuWall]
	
            }
            __syncthreads();
            if(i==iteration-1)  // [参数: iteration]
                break;
            if(computed)	 //Assign the computation range
                prev[tx]= result[tx];
      }

      // update the global memory
      // after the last iteration, only threads coordinated within the 
      // small block perform the calculation and switch on ``computed''
      if (computed){
          gpuResults[xidx]=result[tx];		  // [参数: gpuResults]
      }

}

// 在 single_kernel_dynproc_kernel.cu 末尾追加

int main() {
    const int rows = 100;
    const int cols = 100;
    const int pyramid_height = 10;  // 迭代次数
    
    // 分配主机内存
    int *h_wall = (int*)malloc(rows * cols * sizeof(int));
    int *h_src = (int*)malloc(cols * sizeof(int));
    int *h_result = (int*)malloc(cols * sizeof(int));
    
    // 初始化数据
    srand(M_SEED);
    for (int i = 0; i < rows * cols; i++) {
        h_wall[i] = rand() % 10;
    }
    for (int i = 0; i < cols; i++) {
        h_src[i] = 0;  // 起始行全为 0
    }
    
    // 分配 GPU 内存
    int *d_wall, *d_src, *d_result;
    cudaMalloc(&d_wall, rows * cols * sizeof(int));
    cudaMalloc(&d_src, cols * sizeof(int));
    cudaMalloc(&d_result, cols * sizeof(int));
    
    cudaMemcpy(d_wall, h_wall, rows * cols * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_src, h_src, cols * sizeof(int), cudaMemcpyHostToDevice);
    
    printf("Running dynproc_kernel (Pathfinder):\n");
    printf("  Grid: %d x %d\n", rows, cols);
    printf("  Pyramid height: %d\n", pyramid_height);
    
    // 执行多轮迭代
    int src = 0, dst = 1;
    for (int t = 0; t < rows - 1; t += pyramid_height) {
        int iteration = MIN(pyramid_height, rows - t - 1);
        int border = iteration * HALO;
        int num_blocks = (cols - iteration * HALO * 2 + BLOCK_SIZE - 1) / (BLOCK_SIZE - iteration * HALO * 2);
        
        dynproc_kernel<<<num_blocks, BLOCK_SIZE>>>(
            iteration, d_wall, d_src, d_result, cols, rows, t, border
        );
        
        // 交换 src 和 result
        int *temp = d_src;
        d_src = d_result;
        d_result = temp;
    }
    
    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));
    
    // 拷回结果
    cudaMemcpy(h_result, d_src, cols * sizeof(int), cudaMemcpyDeviceToHost);
    
    // 找最短路径
    int min_idx = 0, min_val = h_result[0];
    for (int i = 1; i < cols; i++) {
        if (h_result[i] < min_val) {
            min_val = h_result[i];
            min_idx = i;
        }
    }
    
    printf("\nShortest path:\n");
    printf("  End column: %d\n", min_idx);
    printf("  Total cost: %d\n", min_val);
    
    cudaFree(d_wall);
    cudaFree(d_src);
    cudaFree(d_result);
    free(h_wall);
    free(h_src);
    free(h_result);
    
    return err == cudaSuccess ? 0 : 1;
}