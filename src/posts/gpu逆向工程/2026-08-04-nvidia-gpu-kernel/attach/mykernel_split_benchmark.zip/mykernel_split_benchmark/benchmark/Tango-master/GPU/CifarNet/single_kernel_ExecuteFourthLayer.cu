// Auto-generated CUDA kernel file: ExecuteFourthLayer
// Extracted from: Tango-master/GPU/CifarNet/CN_cuda.cu
// Original line: 434

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: ExecuteFourthLayer (line 434)
__global__ void ExecuteFourthLayer(double *Layer4_Weights_CPU, double *Layer4_Features, double *Pool3_Layer_Features) {

	int n = threadIdx.x;
	{
		double result = 0;
		for(int f=0; f<64; f++)
		{
			for(int x=0; x<4; x++)
			{
				for(int y=0; y<4; y++)
				{
					result+= Pool3_Layer_Features[f*4*4 +x*4 + y] * Layer4_Weights_CPU[y+(x*4)+(f*4*4)+(n*4*4*64)];
				}
			}
		}
		Layer4_Features[n] = result;
	}

}


int main() {
    const int IN_C = 64;
    const int H = 4, W = 4;
    const int OUT_N = 64;

    size_t input_size  = IN_C * H * W;          // 64*4*4 = 1024
    size_t weight_size = OUT_N * input_size;    // 64 * 1024
    size_t output_size = OUT_N;

    double *h_weight = (double*)malloc(weight_size * sizeof(double));
    double *h_in = (double*)malloc(input_size * sizeof(double));
    double *h_out = (double*)malloc(output_size * sizeof(double));

    for (size_t i = 0; i < weight_size; ++i) h_weight[i] = (double)(i % 29) * 0.001;
    for (size_t i = 0; i < input_size;  ++i) h_in[i] = (double)(i % 31) * 0.1;

    double *d_weight = NULL, *d_in = NULL, *d_out = NULL;

    CHECK(cudaMalloc((void**)&d_weight, weight_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_in, input_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_out, output_size * sizeof(double)));

    CHECK(cudaMemcpy(d_weight, h_weight, weight_size * sizeof(double), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_in, h_in, input_size * sizeof(double), cudaMemcpyHostToDevice));

    dim3 grid(1);
    dim3 block(OUT_N);

    ExecuteFourthLayer<<<grid, block>>>(d_weight, d_out, d_in);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, output_size * sizeof(double), cudaMemcpyDeviceToHost));

    printf("ExecuteFourthLayer done.\n");
    for (int i = 0; i < 10 && i < OUT_N; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_weight);
    cudaFree(d_in);
    cudaFree(d_out);

    free(h_weight);
    free(h_in);
    free(h_out);

    return 0;
}