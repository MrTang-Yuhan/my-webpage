// Auto-generated CUDA kernel file: pooling3
// Extracted from: Tango-master/GPU/CifarNet/CN_cuda.cu
// Original line: 547

// ===== Includes =====
#include <algorithm>
#include <assert.h>
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>

#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Kernel =====
// Kernel: pooling3 (line 547)
__global__ void pooling3(double *Layer3_Neurons_GPU,double *Layer3_pool_GPU,int out,int out_fr,int out_fc,int kernel,int stride_width,int in_fr,int in_fc) {

    double avg = 0.0;
    int count = 0;
    int row = threadIdx.x;
    int col = threadIdx.y;
    {
        for(int output =0;output < out ;output++)
        {
            if((row%2 != 0) && (row<8))
            { 
                if((col%2 != 0) && (col<8))
                {
                    for(int i = row-1; i <= row+1; i++)
                    {   
			if(i>7) break;        
                        for(int j = col-1; j <= col+1; j++)
                        {
			    if(j>7) break;
                            avg+= ((Layer3_Neurons_GPU[output*8*8 + i*8 + j]));
			    count++;

                        }
                    }
                    Layer3_pool_GPU[output*4*4+(row-1)*2+(col-1)/2] = avg/count;   
                    avg = 0.0;   
		    count=0;
                }
            }
        }
    }

}

int main() {
    const int out = 64;
    const int in_fr = 8, in_fc = 8;
    const int out_fr = 4, out_fc = 4;
    const int kernel = 3;
    const int stride_width = 2;

    size_t in_size  = (size_t)out * in_fr * in_fc;
    size_t out_size = (size_t)out * out_fr * out_fc;

    double *h_in  = (double*)malloc(in_size * sizeof(double));
    double *h_out = (double*)malloc(out_size * sizeof(double));

    if (!h_in || !h_out) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < in_size; ++i) {
        h_in[i] = (double)(i % 17) * 0.1;
    }

    double *d_in = NULL, *d_out = NULL;
    CHECK(cudaMalloc((void**)&d_in,  in_size * sizeof(double)));
    CHECK(cudaMalloc((void**)&d_out, out_size * sizeof(double)));

    CHECK(cudaMemcpy(d_in, h_in, in_size * sizeof(double), cudaMemcpyHostToDevice));
    CHECK(cudaMemset(d_out, 0, out_size * sizeof(double)));

    dim3 grid(1);
    dim3 block(8, 8);

    pooling3<<<grid, block>>>(d_in, d_out, out, out_fr, out_fc, kernel, stride_width, in_fr, in_fc);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_out, d_out, out_size * sizeof(double), cudaMemcpyDeviceToHost));

    printf("pooling3 done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("out[%d] = %f\n", i, h_out[i]);
    }

    cudaFree(d_in);
    cudaFree(d_out);
    free(h_in);
    free(h_out);

    return 0;
}