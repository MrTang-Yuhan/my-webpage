// Auto-generated CUDA kernel file: mis2
// Extracted from: pannotia/mis/kernel.cu
// Original line: 140

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Kernel =====
// Kernel: mis2 (line 140)
__global__ void
mis2(int *row, int *col, int *node_value, int *s_array, int *c_array,
     int *cu_array, int *min_array, int num_nodes, int num_edges) {

    // Get my workitem id
    int tid = blockDim.x * blockIdx.x + threadIdx.x;

    if (tid < num_nodes) {
        if (node_value[tid] <= min_array[tid]  && c_array[tid] == -1) {
            // -1: Not processed -2: Inactive 2: Independent set
            // Put the item into the independent set
            s_array[tid] = 2;

            // Get the start and end pointers
            int start = row[tid];
            int end;

            if (tid + 1 < num_nodes) {
                end = row[tid + 1];
            } else {
                end = num_edges;
            }

            // Set the status to inactive
            c_array[tid] = -2;

            // Mark all the neighbors inactive
            for (int edge = start; edge < end; edge++) {
                if (c_array[col[edge]] == -1) {
                    //use status update array to avoid race
                    cu_array[col[edge]] = -2;
                }
            }
        }
    }

}

int main(int argc, char** argv) {
    cudaError_t err;

    const int num_nodes = 1024;
    const int num_edges = num_nodes - 1;

    const size_t size_nodes = (size_t)num_nodes * sizeof(int);
    const size_t size_edges = (size_t)num_edges * sizeof(int);

    int *h_row = (int*)malloc(size_nodes);
    int *h_col = (int*)malloc(size_edges);
    int *h_node_value = (int*)malloc(size_nodes);
    int *h_s_array = (int*)malloc(size_nodes);
    int *h_c_array = (int*)malloc(size_nodes);
    int *h_cu_array = (int*)malloc(size_nodes);
    int *h_min_array = (int*)malloc(size_nodes);

    int *d_row = nullptr;
    int *d_col = nullptr;
    int *d_node_value = nullptr;
    int *d_s_array = nullptr;
    int *d_c_array = nullptr;
    int *d_cu_array = nullptr;
    int *d_min_array = nullptr;

    if (!h_row || !h_col || !h_node_value || !h_s_array || !h_c_array || !h_cu_array || !h_min_array) {
        printf("host malloc failed\n");
        free(h_row);
        free(h_col);
        free(h_node_value);
        free(h_s_array);
        free(h_c_array);
        free(h_cu_array);
        free(h_min_array);
        return -1;
    }

    // 构造简单链式图
    for (int i = 0; i < num_nodes; ++i) {
        if (i < num_nodes - 1) h_row[i] = i;
        else h_row[i] = num_edges;
    }

    for (int i = 0; i < num_edges; ++i) {
        h_col[i] = i + 1;
    }

    for (int i = 0; i < num_nodes; ++i) {
        h_node_value[i] = i % 100;
        h_s_array[i] = 0;
        h_c_array[i] = -1;
        h_cu_array[i] = -1;
        h_min_array[i] = h_node_value[i];
    }

    cudaMalloc((void**)&d_row, size_nodes);
    cudaMalloc((void**)&d_col, size_edges);
    cudaMalloc((void**)&d_node_value, size_nodes);
    cudaMalloc((void**)&d_s_array, size_nodes);
    cudaMalloc((void**)&d_c_array, size_nodes);
    cudaMalloc((void**)&d_cu_array, size_nodes);
    cudaMalloc((void**)&d_min_array, size_nodes);

    cudaMemcpy(d_row, h_row, size_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_col, h_col, size_edges, cudaMemcpyHostToDevice);
    cudaMemcpy(d_node_value, h_node_value, size_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_s_array, h_s_array, size_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_c_array, h_c_array, size_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_cu_array, h_cu_array, size_nodes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_min_array, h_min_array, size_nodes, cudaMemcpyHostToDevice);

    dim3 blockSize(256);
    dim3 gridSize((num_nodes + blockSize.x - 1) / blockSize.x);

    cudaEvent_t start, stop_evt;
    cudaEventCreate(&start);
    cudaEventCreate(&stop_evt);

    cudaEventRecord(start);
    mis2<<<gridSize, blockSize>>>(
        d_row, d_col, d_node_value, d_s_array, d_c_array,
        d_cu_array, d_min_array, num_nodes, num_edges
    );
    cudaEventRecord(stop_evt);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        printf("Kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_s_array, d_s_array, size_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_c_array, d_c_array, size_nodes, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_cu_array, d_cu_array, size_nodes, cudaMemcpyDeviceToHost);

    cudaEventSynchronize(stop_evt);
    float ms = 0.0f;
    cudaEventElapsedTime(&ms, start, stop_evt);
    printf("mis2 execution time: %.3f ms\n", ms);

    printf("s_array[0] = %d\n", h_s_array[0]);
    printf("c_array[0] = %d\n", h_c_array[0]);
    printf("cu_array[1] = %d\n", h_cu_array[1]);
    printf("s_array[1] = %d\n", h_s_array[1]);

    cudaFree(d_row);
    cudaFree(d_col);
    cudaFree(d_node_value);
    cudaFree(d_s_array);
    cudaFree(d_c_array);
    cudaFree(d_cu_array);
    cudaFree(d_min_array);

    free(h_row);
    free(h_col);
    free(h_node_value);
    free(h_s_array);
    free(h_c_array);
    free(h_cu_array);
    free(h_min_array);

    cudaEventDestroy(start);
    cudaEventDestroy(stop_evt);

    return 0;
}