// Auto-generated CUDA kernel file: Pathcalc_Portfolio_KernelGPU2
// Extracted from: ispass-2009/LIB/single_kernel_Pathcalc_Portfolio_KernelGPU2.cu
// Original line: 99

// ===== Includes =====
#include <cuda.h>
#include <cuda_runtime.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Macro Definitions =====
#define N 80  // from line 15
#define NN 80  // from line 14  // from line 12  // from line 12
#define NPATH 4096  // from line 18  // from line 13  // from line 13
#define Nmat 40  // from line 16
#define Nopt 15  // from line 17
#define S(x,n) ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n)))  // from line 172 (from ispass-2009/STO/md5_cpu.cpp)  // from line 14  // from line 14

// ===== Global Variables =====
__device__ __constant__ float delta;  // global (from ispass-2009/LIB/single_kernel_Pathcalc_Portfolio_KernelGPU2.cu:24)
__device__ __constant__ float lambda[NN];  // global (from ispass-2009/LIB/single_kernel_Pathcalc_Portfolio_KernelGPU2.cu:25)
__device__ __constant__ int maturities[Nopt];  // global (from ispass-2009/LIB/single_kernel_Pathcalc_Portfolio_KernelGPU2.cu:26)
__device__ __constant__ float swaprates[Nopt];  // global (from ispass-2009/LIB/single_kernel_Pathcalc_Portfolio_KernelGPU2.cu:27)

// ===== Function Forward Declarations =====
__device__ void path_calc(float *L, float *z);
__device__ float portfolio(float *L);

// ===== Device/Helper Functions =====
// Function: path_calc (from ispass-2009/LIB/single_kernel_Pathcalc_Portfolio_KernelGPU2.cu:37)
__device__ void path_calc(float *L, float *z) {



  int   i, n;
  float sqez, lam, con1, v, vrat;

  for(n=0; n<Nmat; n++) {
    sqez = sqrtf(delta)*z[n];
    v = 0.0;

    for (i=n+1; i<N; i++) {
      lam  = lambda[i-n-1];
      con1 = delta*lam;
      v   += __fdividef(con1*L[i],1.0+delta*L[i]);
      vrat = __expf(con1*v + lam*(sqez-0.5*con1));
      L[i] = L[i]*vrat;
    }
  }



}

// Function: portfolio (from ispass-2009/LIB/single_kernel_Pathcalc_Portfolio_KernelGPU2.cu:60)
__device__ float portfolio(float *L) {



  int   n, m, i;
  float v, b, s, swapval, B[40], S[40];
	
  b = 1.0;
  s = 0.0;

  for(n=Nmat; n<N; n++) {
    b = b/(1.0+delta*L[n]);
    s = s + delta*b;
    B[n-Nmat] = b;
    S[n-Nmat] = s;
  }

  v = 0.0;

  for(i=0; i<Nopt; i++){
    m = maturities[i] -1;
    swapval = B[m] + swaprates[i]*S[m] - 1.0;
    if(swapval<0)
      v += -100.0*swapval;
  }

  // apply discount //

  b = 1.0;
  for (n=0; n<Nmat; n++) b = b/(1.0+delta*L[n]);

  v = b*v;

  return v;



}

// ===== Kernel =====
// Kernel: Pathcalc_Portfolio_KernelGPU2 (line 99)
__global__ void Pathcalc_Portfolio_KernelGPU2(float *d_v) {



  const int     tid = blockDim.x * blockIdx.x + threadIdx.x;
  const int threadN = blockDim.x * gridDim.x;

  int   i, path;
  float L[NN], z[NN];
  
  /* Monte Carlo LIBOR path calculation*/

  for(path = tid; path < NPATH; path += threadN){
    // initialise the data for current thread
    for (i=0; i<N; i++) {
      // for real application, z should be randomly generated
      z[i] = 0.3;
      L[i] = 0.05;
    }	   
    path_calc(L, z);
    d_v[path] = portfolio(L);
  }



}
int main() {
    float *d_v = NULL;
    float h_v[NPATH];

    // 初始化 host 侧参数
    float h_delta = 0.25f;
    float h_lambda[NN];
    int   h_maturities[Nopt];
    float h_swaprates[Nopt];

    for (int i = 0; i < NN; i++) {
        h_lambda[i] = 0.2f + 0.001f * i;
    }

    for (int i = 0; i < Nopt; i++) {
        h_maturities[i] = i + 1;
        h_swaprates[i] = 0.04f + 0.001f * i;
    }

    // 拷贝常量到 GPU
    cudaMemcpyToSymbol(delta, &h_delta, sizeof(float));
    cudaMemcpyToSymbol(lambda, h_lambda, sizeof(float) * NN);
    cudaMemcpyToSymbol(maturities, h_maturities, sizeof(int) * Nopt);
    cudaMemcpyToSymbol(swaprates, h_swaprates, sizeof(float) * Nopt);

    // 分配输出
    cudaError_t err = cudaMalloc((void**)&d_v, sizeof(float) * NPATH);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMalloc(d_v) failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    // kernel 配置
    dim3 block(256);
    dim3 grid((NPATH + block.x - 1) / block.x);

    // 启动 kernel
    Pathcalc_Portfolio_KernelGPU2<<<grid, block>>>(d_v);

    err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "Kernel launch failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_v);
        return -1;
    }

    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "Kernel execution failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_v);
        return -1;
    }

    // 拷回结果
    err = cudaMemcpy(h_v, d_v, sizeof(float) * NPATH, cudaMemcpyDeviceToHost);
    if (err != cudaSuccess) {
        fprintf(stderr, "cudaMemcpy D2H failed: %s\n", cudaGetErrorString(err));
        cudaFree(d_v);
        return -1;
    }

    // 打印前 10 个结果
    printf("Pathcalc_Portfolio_KernelGPU2 output (first 10):\n");
    for (int i = 0; i < 10; i++) {
        printf("h_v[%d] = %f\n", i, h_v[i]);
    }

    cudaFree(d_v);
    return 0;
}