#include "pta_single_kernel_test_common.cuh"

__device__ int checkForErrorsDevice(uint var, uint rel) {
    uint index = getHeadIndex(var, rel);

    uint base = graphGet(index + BASE);
    uint bits = graphGet(index + threadIdx.x);

    if (__all_sync(0xFFFFFFFF, bits == NIL)) {
        return 0;
    }

    if (base == NIL) {
        if (threadIdx.x == 0) {
            printf("ERROR: var=%u rel=%u base=NIL but element is not empty\n", var, rel);
            __error__ = 1;
        }
        return 1;
    }

    if (__all_sync(0xFFFFFFFF, threadIdx.x >= BASE || bits == 0 || bits == NIL)) {
        if (threadIdx.x == 0) {
            printf("ERROR: var=%u rel=%u empty bits with non-NIL base\n", var, rel);
            __error__ = 1;
        }
        return 1;
    }

    return 0;
}

__global__ void checkForErrors(uint rel) {
    uint warp = blockIdx.x * blockDim.y + threadIdx.y;
    uint nwarps = gridDim.x * blockDim.y;

    uint nvars = __numVars__;

    for (uint var = warp; var < nvars; var += nwarps) {
        if (checkForErrorsDevice(var, rel)) {
            return;
        }
    }
}

int main() {
    PTATestEnv env;
    initPTATestEnv(env, 64);

    uint elt[ELEMENT_WIDTH];
    for (uint i = 0; i < ELEMENT_WIDTH; i++) elt[i] = 0;
    elt[0] = 0x1;
    elt[BASE] = 0;
    elt[NEXT] = NIL;

    cudaMemcpy(env.d_graph + TEST_COPY_INV_START + 3 * ELEMENT_WIDTH,
               elt, sizeof(elt), cudaMemcpyHostToDevice);

    uint zero = 0;
    cudaMemcpyToSymbol(__error__, &zero, sizeof(uint));

    dim3 block(32, 4);
    dim3 grid(1);

    checkForErrors<<<grid, block>>>(COPY_INV);
    checkCuda(cudaGetLastError(), "checkForErrors launch failed");
    checkCuda(cudaDeviceSynchronize(), "checkForErrors execution failed");

    uint h_error = 0;
    cudaMemcpyFromSymbol(&h_error, __error__, sizeof(uint));

    printf("checkForErrors finished\n");
    printf("__error__=%u\n", h_error);

    destroyPTATestEnv(env);
    return 0;
}