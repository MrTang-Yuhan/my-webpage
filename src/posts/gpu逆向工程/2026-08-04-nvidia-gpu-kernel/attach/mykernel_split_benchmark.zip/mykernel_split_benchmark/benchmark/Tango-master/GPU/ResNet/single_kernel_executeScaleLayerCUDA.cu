// Auto-generated CUDA kernel file: executeScaleLayerCUDA
// Extracted from: Tango-master/GPU/ResNet/rn_kernel.cu
// Original line: 836

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)
// ===== Kernel =====
// Kernel: executeScaleLayerCUDA (line 836)
__global__ void executeScaleLayerCUDA(float *Layer_Neurons,float *scale,float *bias,int out,int f_size) {

        
	int output = blockIdx.x;
	//for(int output = 0;output < out;output++)
	{
		int i = threadIdx.x * blockDim.x + threadIdx.y;
		//for(int i=0;i < f_size;i++)
		{
			/* Scale Layer = input * scale + bias */
			Layer_Neurons[output*f_size + i]  = (Layer_Neurons[output*f_size + i] * scale[output]) + bias[output];
		}
	}


}

int main() {
    const int out = 4;
    const int f_size = 64;

    size_t neuron_size = (size_t)out * f_size;
    size_t param_size = out;

    float *h_neurons = (float*)malloc(neuron_size * sizeof(float));
    float *h_scale   = (float*)malloc(param_size * sizeof(float));
    float *h_bias    = (float*)malloc(param_size * sizeof(float));

    if (!h_neurons || !h_scale || !h_bias) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    for (size_t i = 0; i < neuron_size; ++i) h_neurons[i] = (float)(i % 11) * 0.1f;
    for (int i = 0; i < out; ++i) {
        h_scale[i] = 1.5f;
        h_bias[i] = 0.2f;
    }

    float *d_neurons = NULL, *d_scale = NULL, *d_bias = NULL;
    CHECK(cudaMalloc((void**)&d_neurons, neuron_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_scale, param_size * sizeof(float)));
    CHECK(cudaMalloc((void**)&d_bias, param_size * sizeof(float)));

    CHECK(cudaMemcpy(d_neurons, h_neurons, neuron_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_scale, h_scale, param_size * sizeof(float), cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_bias, h_bias, param_size * sizeof(float), cudaMemcpyHostToDevice));

    dim3 grid(out);
    dim3 block(8, 8);

    executeScaleLayerCUDA<<<grid, block>>>(d_neurons, d_scale, d_bias, out, f_size);
    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_neurons, d_neurons, neuron_size * sizeof(float), cudaMemcpyDeviceToHost));

    printf("executeScaleLayerCUDA done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("neurons[%d] = %f\n", i, h_neurons[i]);
    }

    cudaFree(d_neurons);
    cudaFree(d_scale);
    cudaFree(d_bias);

    free(h_neurons);
    free(h_scale);
    free(h_bias);

    return 0;
}