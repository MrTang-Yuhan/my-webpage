// Standalone version for single_kernel_dfindcompmin.cu

#include "common.h"
#include "graph.h"
#include "component.h"
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

#define MYINFINITY 100000000

// ===== Kernel =====
__global__ void dfindcompmin(unsigned *mstwt, Graph graph, ComponentSpace cs,
                             foru *eleminwts, foru *minwtcomponent,
                             unsigned *partners, unsigned *phores,
                             bool *processinnextiteration,
                             unsigned *goaheadnodeofcomponent,
                             unsigned inpid) {
    unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
    if (inpid < graph.nnodes) id = inpid;

    if (id < graph.nnodes) {
        if (partners[id] == graph.nnodes)
            return;

        unsigned srcboss = cs.find(id);
        unsigned dstboss = cs.find(partners[id]);

        if (id != partners[id] &&
            srcboss != dstboss &&
            eleminwts[id] != MYINFINITY &&
            minwtcomponent[srcboss] == eleminwts[id] &&
            dstboss != id &&
            goaheadnodeofcomponent[srcboss] == id) {
            processinnextiteration[id] = true;
        } else {
            processinnextiteration[id] = false;
        }
    }
}

static void build_test_graph(Graph &hg) {
    hg.nnodes = 3;
    hg.nedges = 6;
    hg.allocOnHost();

    for (unsigned i = 0; i < hg.nnodes; i++) hg.srcsrc[i] = i;
    hg.psrc[0] = 1; hg.psrc[1] = 3; hg.psrc[2] = 5;
    hg.noutgoing[0] = 2; hg.noutgoing[1] = 2; hg.noutgoing[2] = 2;
    hg.nincoming[0] = 2; hg.nincoming[1] = 2; hg.nincoming[2] = 2;

    hg.edgessrcdst[1] = 1; hg.edgessrcwt[1] = 1;
    hg.edgessrcdst[2] = 2; hg.edgessrcwt[2] = 4;
    hg.edgessrcdst[3] = 0; hg.edgessrcwt[3] = 1;
    hg.edgessrcdst[4] = 2; hg.edgessrcwt[4] = 2;
    hg.edgessrcdst[5] = 0; hg.edgessrcwt[5] = 4;
    hg.edgessrcdst[6] = 1; hg.edgessrcwt[6] = 2;
}

int main() {
    Graph hgraph, graph;
    build_test_graph(hgraph);
    hgraph.cudaCopy(graph);

    ComponentSpace cs(graph.nnodes);

    unsigned *mstwt = NULL;
    foru *eleminwts = NULL, *minwtcomponent = NULL;
    unsigned *partners = NULL, *phores = NULL, *goahead = NULL;
    bool *process = NULL;
    unsigned hmstwt = 0;
    unsigned h_zero_u[3] = {0, 0, 0};

    foru h_elemin[3] = {1, 1, 2};
    foru h_mincomp[3] = {1, 1, 2};
    unsigned h_partners[3] = {1, 0, 1};
    unsigned h_goahead[3] = {0, 1, 2};
    bool h_process[3] = {false, false, false};

    cudaMalloc((void **)&mstwt, sizeof(unsigned));
    cudaMemcpy(mstwt, &hmstwt, sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMalloc((void **)&eleminwts, 3 * sizeof(foru));
    cudaMalloc((void **)&minwtcomponent, 3 * sizeof(foru));
    cudaMalloc((void **)&partners, 3 * sizeof(unsigned));
    cudaMalloc((void **)&phores, 3 * sizeof(unsigned));
    cudaMalloc((void **)&process, 3 * sizeof(bool));
    cudaMalloc((void **)&goahead, 3 * sizeof(unsigned));

    cudaMemcpy(eleminwts, h_elemin, 3 * sizeof(foru), cudaMemcpyHostToDevice);
    cudaMemcpy(minwtcomponent, h_mincomp, 3 * sizeof(foru), cudaMemcpyHostToDevice);
    cudaMemcpy(partners, h_partners, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(phores, h_zero_u, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);
    cudaMemcpy(process, h_process, 3 * sizeof(bool), cudaMemcpyHostToDevice);
    cudaMemcpy(goahead, h_goahead, 3 * sizeof(unsigned), cudaMemcpyHostToDevice);

    dfindcompmin<<<1, 128>>>(mstwt, graph, cs, eleminwts, minwtcomponent, partners, phores, process, goahead, graph.nnodes);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel launch failed: %s\n", cudaGetErrorString(err));
        return -1;
    }
    err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        fprintf(stderr, "kernel execution failed: %s\n", cudaGetErrorString(err));
        return -1;
    }

    cudaMemcpy(h_process, process, 3 * sizeof(bool), cudaMemcpyDeviceToHost);

    printf("dfindcompmin finished\n");
    for (int i = 0; i < 3; i++) {
        printf("processinnextiteration[%d] = %d\n", i, (int)h_process[i]);
    }

    cudaFree(mstwt);
    cudaFree(eleminwts);
    cudaFree(minwtcomponent);
    cudaFree(partners);
    cudaFree(phores);
    cudaFree(process);
    cudaFree(goahead);
    graph.deallocOnDevice();
    hgraph.deallocOnHost();

    return 0;
}