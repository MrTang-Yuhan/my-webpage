// Auto-generated CUDA kernel file: GPU_forward_pass_gru
// Extracted from: Tango-master/GPU/GRU/gru_kernel.cu
// Original line: 60

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <stdlib.h>
#include<math.h>
#include<stdio.h>
#include <cuda_runtime.h>

#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

// ===== Function Forward Declarations =====
__device__ float hard_sigmoid(float x);

// ===== Device/Helper Functions =====
// Function: hard_sigmoid (from Tango-master/GPU/GRU/gru_kernel.cu:21)
__device__ float hard_sigmoid(float x) {

    if (x<-2.5)
        return 0;
    else
        if(x>2.5)
            return 1;
        else
            return(0.2*x + 0.5);

}

// ===== Kernel =====
// Kernel: GPU_forward_pass_gru (line 60)
__global__ void GPU_forward_pass_gru(float *x_t, float *GPU_states ,float *GPU_kernel_h_w,float *GPU_kernel_r_w,float *GPU_kernel_z_w,float *GPU_bias_h,float *GPU_bias_r,float *GPU_bias_z,float *GPU_rec_h_w,float *GPU_rec_r_w,float *GPU_rec_z_w) {

    int index = threadIdx.x * blockDim.x + threadIdx.y;
    float z,h;
    // Number of units = 100, hardcoded to 100
    int num_units = 100;
    __shared__  float update_gate[100];
        
	float rec_z = 0.0,rec_r = 0.0,rec_h = 0.0;

    // calculate h(t-1)*Uz and h(t-1)*Ur (matrix mul operation)
    for(int i=0;i < num_units; i++)
	{
         rec_z += GPU_states[i] * GPU_rec_z_w[index + num_units * i];
         rec_r += GPU_states[i] * GPU_rec_r_w[index + num_units * i];
              
	}

    // calculate Reset Gate
	z = hard_sigmoid((x_t[0] * GPU_kernel_z_w[index]) 
        + rec_z + GPU_bias_z[index]);

    // calculate Update Gate
	update_gate[index] = hard_sigmoid((x_t[0] * GPU_kernel_r_w[index]) 
                         + rec_r + GPU_bias_r[index]);

	__syncthreads();

    // calculate dot_product(r, h(t-1)) * Uh
    for(int i=0;i < num_units; i++)
	{
         rec_h += update_gate[i] * GPU_states[i] * GPU_rec_h_w[index + num_units * i];
	}

    // calculate h(t)~
	h = tanh((x_t[0] * GPU_kernel_h_w[index]) +  rec_h + GPU_bias_h[index]);

    // calculate h(t)
	GPU_states[index] = (1 - z) * GPU_states[index] + (z) * h;

}

#define CHECK(call)                                                         \
do {                                                                        \
    cudaError_t err = call;                                                 \
    if (err != cudaSuccess) {                                               \
        fprintf(stderr, "CUDA error at %s:%d -> %s\n",                      \
                __FILE__, __LINE__, cudaGetErrorString(err));               \
        exit(EXIT_FAILURE);                                                 \
    }                                                                       \
} while (0)

int main() {
    const int num_units = 100;
    const int input_size = 1;   // kernel 里只用了 x_t[0]

    size_t x_size      = input_size * sizeof(float);
    size_t state_size  = num_units * sizeof(float);
    size_t bias_size   = num_units * sizeof(float);
    size_t rec_size    = num_units * num_units * sizeof(float);
    size_t kern_size   = num_units * sizeof(float);  // 因为只乘 x_t[0]

    // Host memory
    float *h_x_t          = (float*)malloc(x_size);
    float *h_states       = (float*)malloc(state_size);
    float *h_kernel_h_w   = (float*)malloc(kern_size);
    float *h_kernel_r_w   = (float*)malloc(kern_size);
    float *h_kernel_z_w   = (float*)malloc(kern_size);
    float *h_bias_h       = (float*)malloc(bias_size);
    float *h_bias_r       = (float*)malloc(bias_size);
    float *h_bias_z       = (float*)malloc(bias_size);
    float *h_rec_h_w      = (float*)malloc(rec_size);
    float *h_rec_r_w      = (float*)malloc(rec_size);
    float *h_rec_z_w      = (float*)malloc(rec_size);

    if (!h_x_t || !h_states || !h_kernel_h_w || !h_kernel_r_w || !h_kernel_z_w ||
        !h_bias_h || !h_bias_r || !h_bias_z ||
        !h_rec_h_w || !h_rec_r_w || !h_rec_z_w) {
        fprintf(stderr, "Host malloc failed.\n");
        return EXIT_FAILURE;
    }

    // Initialize host data
    h_x_t[0] = 0.5f;

    for (int i = 0; i < num_units; ++i) {
        h_states[i]     = (float)(i % 7) * 0.1f;
        h_kernel_h_w[i] = (float)(i % 11) * 0.01f;
        h_kernel_r_w[i] = (float)(i % 13) * 0.01f;
        h_kernel_z_w[i] = (float)(i % 17) * 0.01f;
        h_bias_h[i]     = 0.1f;
        h_bias_r[i]     = 0.05f;
        h_bias_z[i]     = 0.02f;
    }

    for (int i = 0; i < num_units * num_units; ++i) {
        h_rec_h_w[i] = (float)(i % 19) * 0.001f;
        h_rec_r_w[i] = (float)(i % 23) * 0.001f;
        h_rec_z_w[i] = (float)(i % 29) * 0.001f;
    }

    // Device memory
    float *d_x_t = NULL;
    float *d_states = NULL;
    float *d_kernel_h_w = NULL;
    float *d_kernel_r_w = NULL;
    float *d_kernel_z_w = NULL;
    float *d_bias_h = NULL;
    float *d_bias_r = NULL;
    float *d_bias_z = NULL;
    float *d_rec_h_w = NULL;
    float *d_rec_r_w = NULL;
    float *d_rec_z_w = NULL;

    CHECK(cudaMalloc((void**)&d_x_t, x_size));
    CHECK(cudaMalloc((void**)&d_states, state_size));
    CHECK(cudaMalloc((void**)&d_kernel_h_w, kern_size));
    CHECK(cudaMalloc((void**)&d_kernel_r_w, kern_size));
    CHECK(cudaMalloc((void**)&d_kernel_z_w, kern_size));
    CHECK(cudaMalloc((void**)&d_bias_h, bias_size));
    CHECK(cudaMalloc((void**)&d_bias_r, bias_size));
    CHECK(cudaMalloc((void**)&d_bias_z, bias_size));
    CHECK(cudaMalloc((void**)&d_rec_h_w, rec_size));
    CHECK(cudaMalloc((void**)&d_rec_r_w, rec_size));
    CHECK(cudaMalloc((void**)&d_rec_z_w, rec_size));

    CHECK(cudaMemcpy(d_x_t, h_x_t, x_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_states, h_states, state_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_kernel_h_w, h_kernel_h_w, kern_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_kernel_r_w, h_kernel_r_w, kern_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_kernel_z_w, h_kernel_z_w, kern_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_bias_h, h_bias_h, bias_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_bias_r, h_bias_r, bias_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_bias_z, h_bias_z, bias_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_rec_h_w, h_rec_h_w, rec_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_rec_r_w, h_rec_r_w, rec_size, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(d_rec_z_w, h_rec_z_w, rec_size, cudaMemcpyHostToDevice));

    // 启动 kernel
    // 这里用 block(10,10)，因为 index = threadIdx.x * blockDim.x + threadIdx.y
    // 对于 blockDim=(10,10)，index 范围正好是 0~99
    dim3 grid(1);
    dim3 block(10, 10);

    GPU_forward_pass_gru<<<grid, block>>>(
        d_x_t,
        d_states,
        d_kernel_h_w,
        d_kernel_r_w,
        d_kernel_z_w,
        d_bias_h,
        d_bias_r,
        d_bias_z,
        d_rec_h_w,
        d_rec_r_w,
        d_rec_z_w
    );

    CHECK(cudaGetLastError());
    CHECK(cudaDeviceSynchronize());

    CHECK(cudaMemcpy(h_states, d_states, state_size, cudaMemcpyDeviceToHost));

    printf("GPU_forward_pass_gru done.\n");
    for (int i = 0; i < 10; ++i) {
        printf("state[%d] = %f\n", i, h_states[i]);
    }

    cudaFree(d_x_t);
    cudaFree(d_states);
    cudaFree(d_kernel_h_w);
    cudaFree(d_kernel_r_w);
    cudaFree(d_kernel_z_w);
    cudaFree(d_bias_h);
    cudaFree(d_bias_r);
    cudaFree(d_bias_z);
    cudaFree(d_rec_h_w);
    cudaFree(d_rec_r_w);
    cudaFree(d_rec_z_w);

    free(h_x_t);
    free(h_states);
    free(h_kernel_h_w);
    free(h_kernel_r_w);
    free(h_kernel_z_w);
    free(h_bias_h);
    free(h_bias_r);
    free(h_bias_z);
    free(h_rec_h_w);
    free(h_rec_r_w);
    free(h_rec_z_w);

    return 0;
}