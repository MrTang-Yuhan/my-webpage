// Auto-generated CUDA kernel file: lud_internal
// Extracted from: rodinia-3.1/lud/cuda/lud_kernel.cu
// Original line: 167

// ===== Includes =====
#include <cuda.h>
#include <stdio.h>
#include <cstdlib>
#include <vector>
// ===== Macro Definitions =====
#define BLOCK_SIZE 16  // from line 11

// ===== Kernel =====
// Kernel: lud_internal (line 167)
__global__ void
lud_internal(float *m, int matrix_dim, int offset) {

  __shared__ float peri_row[BLOCK_SIZE][BLOCK_SIZE];
  __shared__ float peri_col[BLOCK_SIZE][BLOCK_SIZE];

  int i;
  float sum;

  int global_row_id = offset + (blockIdx.y+1)*BLOCK_SIZE;
  int global_col_id = offset + (blockIdx.x+1)*BLOCK_SIZE;

  peri_row[threadIdx.y][threadIdx.x] = m[(offset+threadIdx.y)*matrix_dim+global_col_id+threadIdx.x];
  peri_col[threadIdx.y][threadIdx.x] = m[(global_row_id+threadIdx.y)*matrix_dim+offset+threadIdx.x];

  __syncthreads();

  sum = 0;
  for (i=0; i < BLOCK_SIZE; i++)
    sum += peri_col[threadIdx.y][i] * peri_row[i][threadIdx.x];
  m[(global_row_id+threadIdx.y)*matrix_dim+global_col_id+threadIdx.x] -= sum;



}

__global__ void lud_internal(float *m, int matrix_dim, int offset);

#define CHECK_CUDA(call) do { \
    cudaError_t err = (call); \
    if (err != cudaSuccess) { \
        fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__, cudaGetErrorString(err)); \
        exit(EXIT_FAILURE); \
    } \
} while(0)

int main() {
    const int matrix_dim = 64;
    const int offset = 0;
    const int total = matrix_dim * matrix_dim;

    // internal block 数量：(matrix_dim / BLOCK_SIZE) - 1，二维
    const int num_blocks = (matrix_dim / BLOCK_SIZE) - 1;

    std::vector<float> h_m(total);
    for (int i = 0; i < matrix_dim; ++i)
        for (int j = 0; j < matrix_dim; ++j)
            h_m[i * matrix_dim + j] = (i == j) ? 2.0f : 0.1f;

    float *d_m = nullptr;
    CHECK_CUDA(cudaMalloc((void**)&d_m, total * sizeof(float)));
    CHECK_CUDA(cudaMemcpy(d_m, h_m.data(), total * sizeof(float), cudaMemcpyHostToDevice));

    // lud_internal:
    //   grid  = (num_blocks, num_blocks)（二维，覆盖所有内部子块）
    //   block = (BLOCK_SIZE, BLOCK_SIZE)（每个线程处理一个矩阵元素）
    dim3 grid(num_blocks, num_blocks);
    dim3 block(BLOCK_SIZE, BLOCK_SIZE);

    lud_internal<<<grid, block>>>(d_m, matrix_dim, offset);
    CHECK_CUDA(cudaGetLastError());
    CHECK_CUDA(cudaDeviceSynchronize());

    CHECK_CUDA(cudaMemcpy(h_m.data(), d_m, total * sizeof(float), cudaMemcpyDeviceToHost));

    printf("lud_internal done. 部分结果:\n");
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j)
            printf("%8.4f ", h_m[i * matrix_dim + j]);
        printf("\n");
    }

    CHECK_CUDA(cudaFree(d_m));
    return 0;
}