// ===== Includes =====
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>

// ===== Macro Definitions =====
#define GAMMA 1.4f
#define block_length 192
#define NDIM 3
#define RK 3
#define VAR_DENSITY 0
#define VAR_MOMENTUM 1
#define VAR_DENSITY_ENERGY (VAR_MOMENTUM+NDIM)
#define NVAR (VAR_DENSITY_ENERGY+1)

#define checkCuda(call) do { \
    cudaError_t e = call; \
    if(e != cudaSuccess){ fprintf(stderr,"CUDA %s:%d %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1); } \
} while(0)

// ===== Kernel =====
__global__ void cuda_time_step(
    int j, int nelr,
    float* old_variables, float* variables,
    float* step_factors, float* fluxes)
{
    const int i = blockDim.x*blockIdx.x + threadIdx.x;
    float factor = step_factors[i] / (float)(RK+1-j);

    variables[i+VAR_DENSITY*nelr]        = old_variables[i+VAR_DENSITY*nelr]        + factor*fluxes[i+VAR_DENSITY*nelr];
    variables[i+VAR_DENSITY_ENERGY*nelr] = old_variables[i+VAR_DENSITY_ENERGY*nelr] + factor*fluxes[i+VAR_DENSITY_ENERGY*nelr];
    variables[i+(VAR_MOMENTUM+0)*nelr]   = old_variables[i+(VAR_MOMENTUM+0)*nelr]   + factor*fluxes[i+(VAR_MOMENTUM+0)*nelr];
    variables[i+(VAR_MOMENTUM+1)*nelr]   = old_variables[i+(VAR_MOMENTUM+1)*nelr]   + factor*fluxes[i+(VAR_MOMENTUM+1)*nelr];
    variables[i+(VAR_MOMENTUM+2)*nelr]   = old_variables[i+(VAR_MOMENTUM+2)*nelr]   + factor*fluxes[i+(VAR_MOMENTUM+2)*nelr];
}

// ===== Main =====
int main() {
    const int nelr = 960;

    float ff_pressure = 1.0f;
    float ff_density  = GAMMA * ff_pressure;
    float ff_speed    = 1.2f * sqrtf(GAMMA * ff_pressure / ff_density);
    float ff_de       = ff_pressure/(GAMMA-1.0f) + 0.5f*ff_density*ff_speed*ff_speed;

    // 初始化 host 数据
    float *h_old = (float*)malloc(nelr*NVAR*sizeof(float));
    float *h_var = (float*)malloc(nelr*NVAR*sizeof(float));
    float *h_sf  = (float*)malloc(nelr*sizeof(float));
    float *h_flux= (float*)calloc(nelr*NVAR, sizeof(float));  // flux 全零 → variables 不变

    for(int i = 0; i < nelr; i++){
        h_old[i+VAR_DENSITY*nelr]        = ff_density;
        h_old[i+(VAR_MOMENTUM+0)*nelr]   = ff_density*ff_speed;
        h_old[i+(VAR_MOMENTUM+1)*nelr]   = 0.0f;
        h_old[i+(VAR_MOMENTUM+2)*nelr]   = 0.0f;
        h_old[i+VAR_DENSITY_ENERGY*nelr] = ff_de;
        h_sf[i] = 0.01f;  // 固定步长因子
    }
    memcpy(h_var, h_old, nelr*NVAR*sizeof(float));

    float *d_old, *d_var, *d_sf, *d_flux;
    checkCuda(cudaMalloc(&d_old,  nelr*NVAR*sizeof(float)));
    checkCuda(cudaMalloc(&d_var,  nelr*NVAR*sizeof(float)));
    checkCuda(cudaMalloc(&d_sf,   nelr*sizeof(float)));
    checkCuda(cudaMalloc(&d_flux, nelr*NVAR*sizeof(float)));

    checkCuda(cudaMemcpy(d_old,  h_old,  nelr*NVAR*sizeof(float), cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_var,  h_var,  nelr*NVAR*sizeof(float), cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_sf,   h_sf,   nelr*sizeof(float),      cudaMemcpyHostToDevice));
    checkCuda(cudaMemcpy(d_flux, h_flux, nelr*NVAR*sizeof(float), cudaMemcpyHostToDevice));

    // 模拟 RK3 的三个子步
    for(int rk = 1; rk <= RK; rk++){
        cuda_time_step<<<nelr/block_length, block_length>>>(rk, nelr, d_old, d_var, d_sf, d_flux);
        checkCuda(cudaDeviceSynchronize());
    }

    float h_out;
    checkCuda(cudaMemcpy(&h_out, d_var, sizeof(float), cudaMemcpyDeviceToHost));
    printf("cuda_time_step OK. variables[0]=%.4f (expect %.4f)\n", h_out, ff_density);

    free(h_old); free(h_var); free(h_sf); free(h_flux);
    cudaFree(d_old); cudaFree(d_var); cudaFree(d_sf); cudaFree(d_flux);
    return 0;
}