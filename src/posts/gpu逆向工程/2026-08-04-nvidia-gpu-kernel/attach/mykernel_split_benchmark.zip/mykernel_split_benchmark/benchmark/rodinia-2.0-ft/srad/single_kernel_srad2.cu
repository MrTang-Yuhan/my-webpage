// Auto-generated CUDA kernel file: srad2
// Extracted from: rodinia/2.0-ft/srad/srad_v1/srad2_kernel.cu
// Original line: 4

// ===== Includes =====
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <cuda.h>
#include <stdio.h>
#include "define.c"
// #include "extract_kernel.cu"
// #include "prepare_kernel.cu"
// #include "reduce_kernel.cu"
// #include "srad_kernel.cu"
// #include "srad2_kernel.cu"
// #include "compress_kernel.cu"
// #include "graphics.c"
// #include "resize.c"
// #include "timer.c"

// #include "device.c"				// (in library path specified to compiler)	needed by for device functions
// ===== Kernel =====
// Kernel: srad2 (line 4)
__global__ void srad2(	fp d_lambda, 
										int d_Nr, 
										int d_Nc, 
										long d_Ne, 
										int *d_iN, 
										int *d_iS, 
										int *d_jE, 
										int *d_jW,
										fp *d_dN, 
										fp *d_dS, 
										fp *d_dE, 
										fp *d_dW, 
										fp *d_c, 
										fp *d_I) {


	// indexes
    int bx = blockIdx.x;													// get current horizontal block index
	int tx = threadIdx.x;													// get current horizontal thread index
	int ei = bx*NUMBER_THREADS+tx;											// more threads than actual elements !!!
	int row;																// column, x position
	int col;																// row, y position

	// variables
	fp d_cN,d_cS,d_cW,d_cE;  // [参数: d_c]
	fp d_D;

	// figure out row/col location in new matrix
	row = (ei+1) % d_Nr - 1;												// (0-n) row  // [参数: d_Nr]
	col = (ei+1) / d_Nr + 1 - 1;											// (0-n) column  // [参数: d_Nr]
	if((ei+1) % d_Nr == 0){  // [参数: d_Nr]
		row = d_Nr - 1;  // [参数: d_Nr]
		col = col - 1;
	}

	if(ei<d_Ne){															// make sure that only threads matching jobs run  // [参数: d_Ne]

		// diffusion coefficent
		d_cN = d_c[ei];														// north diffusion coefficient  // [参数: d_c]
		d_cS = d_c[d_iS[row] + d_Nr*col];										// south diffusion coefficient  // [参数: d_Nr, d_iS, d_c]
		d_cW = d_c[ei];														// west diffusion coefficient  // [参数: d_c]
		d_cE = d_c[row + d_Nr * d_jE[col]];									// east diffusion coefficient  // [参数: d_Nr, d_jE, d_c]

		// divergence (equ 58)
		d_D = d_cN*d_dN[ei] + d_cS*d_dS[ei] + d_cW*d_dW[ei] + d_cE*d_dE[ei];// divergence  // [参数: d_dN, d_dS, d_dE, d_dW, d_c]

		// image update (equ 61) (every element of IMAGE)
		d_I[ei] = d_I[ei] + 0.25*d_lambda*d_D;								// updates image (based on input time step and divergence)  // [参数: d_lambda, d_I]

	}


}

// 在末尾追加
int main() {
    const int Nr = 512;
    const int Nc = 512;
    const long Ne = Nr * Nc;
    const fp lambda = 0.5;
    
    // 初始化（同 srad.cu）
    int *h_iN = (int*)malloc(Nr * sizeof(int));
    int *h_iS = (int*)malloc(Nr * sizeof(int));
    int *h_jE = (int*)malloc(Nc * sizeof(int));
    int *h_jW = (int*)malloc(Nc * sizeof(int));
    
    for (int i = 0; i < Nr; i++) {
        h_iN[i] = (i == 0) ? 0 : i - 1;
        h_iS[i] = (i == Nr - 1) ? Nr - 1 : i + 1;
    }
    for (int j = 0; j < Nc; j++) {
        h_jW[j] = (j == 0) ? 0 : j - 1;
        h_jE[j] = (j == Nc - 1) ? Nc - 1 : j + 1;
    }
    
    fp *h_I = (fp*)malloc(Ne * sizeof(fp));
    fp *h_dN = (fp*)malloc(Ne * sizeof(fp));
    fp *h_dS = (fp*)malloc(Ne * sizeof(fp));
    fp *h_dE = (fp*)malloc(Ne * sizeof(fp));
    fp *h_dW = (fp*)malloc(Ne * sizeof(fp));
    fp *h_c = (fp*)malloc(Ne * sizeof(fp));
    
    for (long i = 0; i < Ne; i++) {
        h_I[i] = exp((rand() % 255) / 255.0f);
        h_dN[i] = (rand() % 100) / 100.0f - 0.5f;
        h_dS[i] = (rand() % 100) / 100.0f - 0.5f;
        h_dE[i] = (rand() % 100) / 100.0f - 0.5f;
        h_dW[i] = (rand() % 100) / 100.0f - 0.5f;
        h_c[i] = (rand() % 100) / 100.0f;
    }
    
    // GPU 内存
    int *d_iN, *d_iS, *d_jE, *d_jW;
    fp *d_dN, *d_dS, *d_dE, *d_dW, *d_c, *d_I;
    
    cudaMalloc(&d_iN, Nr * sizeof(int));
    cudaMalloc(&d_iS, Nr * sizeof(int));
    cudaMalloc(&d_jE, Nc * sizeof(int));
    cudaMalloc(&d_jW, Nc * sizeof(int));
    cudaMalloc(&d_dN, Ne * sizeof(fp));
    cudaMalloc(&d_dS, Ne * sizeof(fp));
    cudaMalloc(&d_dE, Ne * sizeof(fp));
    cudaMalloc(&d_dW, Ne * sizeof(fp));
    cudaMalloc(&d_c, Ne * sizeof(fp));
    cudaMalloc(&d_I, Ne * sizeof(fp));
    
    cudaMemcpy(d_iN, h_iN, Nr * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_iS, h_iS, Nr * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_jE, h_jE, Nc * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_jW, h_jW, Nc * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_dN, h_dN, Ne * sizeof(fp), cudaMemcpyHostToDevice);
    cudaMemcpy(d_dS, h_dS, Ne * sizeof(fp), cudaMemcpyHostToDevice);
    cudaMemcpy(d_dE, h_dE, Ne * sizeof(fp), cudaMemcpyHostToDevice);
    cudaMemcpy(d_dW, h_dW, Ne * sizeof(fp), cudaMemcpyHostToDevice);
    cudaMemcpy(d_c, h_c, Ne * sizeof(fp), cudaMemcpyHostToDevice);
    cudaMemcpy(d_I, h_I, Ne * sizeof(fp), cudaMemcpyHostToDevice);
    
    printf("Running srad2 kernel (step 2):\n");
    printf("  Image: %d x %d\n", Nr, Nc);
    
    int num_blocks = (Ne + NUMBER_THREADS - 1) / NUMBER_THREADS;
    srad2<<<num_blocks, NUMBER_THREADS>>>(
        lambda, Nr, Nc, Ne, d_iN, d_iS, d_jE, d_jW,
        d_dN, d_dS, d_dE, d_dW, d_c, d_I
    );
    
    cudaError_t err = cudaDeviceSynchronize();
    printf("Kernel: %s\n", err == cudaSuccess ? "PASSED" : cudaGetErrorString(err));
    
    cudaMemcpy(h_I, d_I, Ne * sizeof(fp), cudaMemcpyDeviceToHost);
    printf("\nSample updated pixels:\n");
    for (int i = 0; i < 5; i++) {
        printf("  [%d]: %.4f\n", i, h_I[i]);
    }
    
    // 清理
    cudaFree(d_iN); cudaFree(d_iS); cudaFree(d_jE); cudaFree(d_jW);
    cudaFree(d_dN); cudaFree(d_dS); cudaFree(d_dE); cudaFree(d_dW);
    cudaFree(d_c); cudaFree(d_I);
    free(h_iN); free(h_iS); free(h_jE); free(h_jW);
    free(h_dN); free(h_dS); free(h_dE); free(h_dW); free(h_c); free(h_I);
    
    return err == cudaSuccess ? 0 : 1;
}