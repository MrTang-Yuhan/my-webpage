// Auto-generated CUDA kernel file: printWorklist
// Extracted from: lonestargpu-2.0/include/worklist.h
// Original line: 377

// ===== Includes =====
#include <cuda.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <time.h>
#include <vector>

// ===== Type Definitions =====
struct Worklist {
	enum {NotAllocated, AllocatedOnHost, AllocatedOnDevice} memory;

	__device__ unsigned pushRange(unsigned *start, unsigned nitems);
	__device__ unsigned push(unsigned work);
	__device__ unsigned popRange(unsigned *start, unsigned nitems);
	__device__ unsigned pop(unsigned &work);
	__device__ void clear();
	__device__ void myItems(unsigned &start, unsigned &end);
	__device__ unsigned getItem(unsigned at);
	__device__ unsigned getItemWithin(unsigned at, unsigned hsize);
	__device__ unsigned count();

	void init();
	void init(unsigned initialcapacity);
	void setSize(unsigned hsize);
	unsigned getSize();
	void setCapacity(unsigned hcapacity);
	unsigned getCapacity();
	void pushRangeHost(unsigned *start, unsigned nitems);
	void pushHost(unsigned work);
	void clearHost();
	void setInitialSize(unsigned hsize);
	unsigned calculateSize(unsigned hstart, unsigned hend);
	void setStartEnd(unsigned hstart, unsigned hend);
	void getStartEnd(unsigned &hstart, unsigned &hend);
	void copyOldToNew(unsigned *olditems, unsigned *newitems, unsigned oldsize, unsigned oldcapacity);
	void compressHost(unsigned wlsize, unsigned sentinel);
	void printHost();
	unsigned appendHost(Worklist *otherwl);

	Worklist();
	~Worklist();
	unsigned ensureSpace(unsigned space);
	unsigned *alloc(unsigned allocsize);
	unsigned realloc(unsigned space);
	unsigned dealloc();
	unsigned freeSize();

	unsigned *items;
	unsigned *start, *end, *capacity;	// since these change, we don't want their copies with threads, hence pointers.

	unsigned noverflows;


} Worklist; // from lonestargpu-2.0/include/worklist.h:17

// ===== Kernel =====
// Kernel: printWorklist (line 377)
__global__ void printWorklist(Worklist wl) {

	unsigned start, end;
	start = *wl.start;
	end = *wl.end;
	printf("\t");
	for (unsigned ii = start; ii < end; ++ii) {
		printf("%d,", wl.getItem(ii));
	}
	printf("\n");

}
