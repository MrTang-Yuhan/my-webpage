#pragma once

#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

typedef unsigned int uint;

// ============================================================
// Basic constants
// ============================================================

#define WARP_SIZE 32
#define LOG2_32 5
#define ELEMENT_WIDTH 32

#define BASE 30U
#define NEXT 31U

#define PTS 0
#define NEXT_DIFF_PTS 1
#define CURR_DIFF_PTS 2
#define COPY_INV 3
#define LOAD_INV 4
#define STORE 5

#define LAST_DYNAMIC_REL STORE

#define NIL UINT_MAX
#define UNLOCKED UINT_MAX
#define LOCKED (UINT_MAX - 1)

#define ELEMENT_CARDINALITY (30 * 32)

#define BASE_OF(x) ((x) / ELEMENT_CARDINALITY)
#define WORD_OF(x) (((x) % ELEMENT_CARDINALITY) >> LOG2_32)
#define BIT_OF(x) ((x) & 31U)

#define MAX_TEST_VARS 128
#define TEST_GRAPH_SIZE (1 << 20)

// ============================================================
// Test graph layout
//
// 原始 Andersen PTA 里使用巨大 HEAP_SIZE 并且部分区域倒着增长。
// 这里为了 single-kernel smoke test，使用固定小布局，全部正向。
// ============================================================

#define TEST_PTS_START 0
#define TEST_NEXT_DIFF_PTS_START (256 * 1024)
#define TEST_CURR_DIFF_PTS_START (512 * 1024)
#define TEST_COPY_INV_START (640 * 1024)
#define TEST_LOAD_INV_START (768 * 1024)
#define TEST_STORE_START (896 * 1024)

// ============================================================
// Kernel-specific sizes
// ============================================================

#define HCD_TABLE_SIZE 256
#define HCD_DECODE_VECTOR_SIZE 8192

#define DECODE_VECTOR_SIZE 128

#define STORE_INV_THREADS_PER_BLOCK 512
#define COPY_INV_THREADS_PER_BLOCK 512
#define GEP_INV_THREADS_PER_BLOCK 512
#define UPDATE_THREADS_PER_BLOCK 1024
#define DEF_THREADS_PER_BLOCK 1024

#define MAX_WARPS_PER_BLOCK 32
#define WARPS_PER_BLOCK(x) ((x) / WARP_SIZE)

#define OFFSET_BITS 10
#define MAX_GEP_OFFSET (1 << OFFSET_BITS)
#define OFFSET_MASK (MAX_GEP_OFFSET - 1)

#define uintSize (sizeof(uint))

// ============================================================
// Device globals
// ============================================================

__device__ uint __counter__ = 0;

__device__ uint __worklistIndex0__ = 0;
__device__ uint __worklistIndex1__ = 0;

__device__ bool __done__ = true;
__device__ uint __error__ = 0;

__device__ uint __ptsFreeList__ = 0;
__device__ uint __currDiffPtsFreeList__ = 0;
__device__ uint __nextDiffPtsFreeList__ = 0;
__device__ uint __otherFreeList__ = 0;

__device__ uint __numKeys__ = 0;
__device__ uint __numKeysCounter__ = 0;
__device__ uint __numStore__ = 0;

// ============================================================
// Constant symbols
// ============================================================

__constant__ uint* __graph__;
__constant__ volatile uint* __rep__;
__constant__ uint* __lock__;
__constant__ uint* __diffPtsMask__;

__constant__ uint* __initialRep__;
__constant__ uint* __initialNonRep__;
__constant__ uint __numInitialRep__;

__constant__ uint __numVars__;

__constant__ uint __storeStart__;
__constant__ uint __loadInvStart__;

__constant__ uint* __storeConstraints__;

__constant__ uint* __key__;
__constant__ uint* __keyAux__;
__constant__ uint* __val__;

__constant__ uint* __hcdIndex__;
__constant__ uint* __hcdTable__;
__constant__ uint __numHcdIndex__;
__constant__ uint* __nextVar__;

__constant__ uint* __currPtsHead__;

__constant__ uint* __offsetMask__;
__constant__ uint __offsetMaskRowsPerOffset__;
__constant__ uint* __size__;

__constant__ uint* __gepInv__;
__constant__ uint __numGepInv__;

// ============================================================
// CUDA check
// ============================================================

static inline void checkCuda(cudaError_t err, const char* msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "%s: %s\n", msg, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

// ============================================================
// Correct symbol binding helpers
//
// 注意：cudaMemcpyToSymbol 的第一个参数必须是 symbol 本体。
// 不能把 __constant__ symbol 传给普通函数参数。
// 所以这里必须用宏，而不是 static inline function。
// ============================================================

#define BIND_PTR_TO_SYMBOL(symbol, ptr)                                             \
    do {                                                                            \
        checkCuda(cudaMemcpyToSymbol(symbol, &(ptr), sizeof(uint*)),                \
                  "cudaMemcpyToSymbol pointer failed");                             \
    } while (0)

#define BIND_VAL_TO_SYMBOL(symbol, value)                                           \
    do {                                                                            \
        checkCuda(cudaMemcpyToSymbol(symbol, &(value), sizeof(value)),              \
                  "cudaMemcpyToSymbol value failed");                               \
    } while (0)

// ============================================================
// Math helpers
// ============================================================

__device__ __host__ static inline uint mul32(uint x) {
    return x << LOG2_32;
}

__device__ __host__ static inline uint div32(uint x) {
    return x >> LOG2_32;
}

__device__ __host__ static inline uint mod32(uint x) {
    return x & 31U;
}

__device__ __host__ static inline uint mod(uint x, uint base) {
    return x & (base - 1);
}

__device__ __host__ static inline uint roundToPrevMultipleOf(uint num, uint powerOfTwo) {
    if ((num & (powerOfTwo - 1)) == 0) {
        return num;
    }
    return ((num / powerOfTwo + 1) * powerOfTwo) - WARP_SIZE;
}

__device__ __host__ static inline uint gep_id(uint srcOffset) {
    return srcOffset >> OFFSET_BITS;
}

__device__ __host__ static inline uint gep_offset(uint srcOffset) {
    return srcOffset & OFFSET_MASK;
}

__device__ __host__ static inline uint gep_pack(uint id, uint offset) {
    return (id << OFFSET_BITS) | (offset & OFFSET_MASK);
}

__device__ __host__ static inline int isBitActive(uint word, uint bit) {
    return word & (1u << bit);
}

// ============================================================
// Graph access
// ============================================================

__device__ inline uint graphGet(uint pos) {
    return __graph__[pos];
}

__device__ inline void graphSet(uint pos, uint val) {
    __graph__[pos] = val;
}

// 原始抽取文件里常用的名字，做一层兼容。
__device__ inline uint __graphGet__(const uint pos) {
    return graphGet(pos);
}

__device__ inline void __graphSet__(const uint pos, const uint val) {
    graphSet(pos, val);
}

// ============================================================
// Head-index helpers
// ============================================================

__device__ inline uint getPtsHeadIndex(uint var) {
    return TEST_PTS_START + mul32(var);
}

__device__ inline uint getNextDiffPtsHeadIndex(uint var) {
    return TEST_NEXT_DIFF_PTS_START + mul32(var);
}

__device__ inline uint getCurrDiffPtsHeadIndex(uint var) {
    return TEST_CURR_DIFF_PTS_START + mul32(var);
}

__device__ inline uint getCopyInvHeadIndex(uint var) {
    return TEST_COPY_INV_START + mul32(var);
}

__device__ inline uint getLoadInvHeadIndex(uint var) {
    return __loadInvStart__ + mul32(var);
}

__device__ inline uint getStoreHeadIndex(uint var) {
    return __storeStart__ + mul32(var);
}

__device__ inline uint getHeadIndex(uint var, uint rel) {
    if (rel == PTS) {
        return getPtsHeadIndex(var);
    }

    if (rel == NEXT_DIFF_PTS) {
        return getNextDiffPtsHeadIndex(var);
    }

    if (rel == CURR_DIFF_PTS) {
        return getCurrDiffPtsHeadIndex(var);
    }

    if (rel == COPY_INV) {
        return getCopyInvHeadIndex(var);
    }

    if (rel == LOAD_INV) {
        return getLoadInvHeadIndex(var);
    }

    if (rel == STORE) {
        return getStoreHeadIndex(var);
    }

    return getPtsHeadIndex(var);
}

// ============================================================
// Thread helpers
// ============================================================

__device__ inline uint getWarpIdInGrid() {
    return blockIdx.x * blockDim.y + threadIdx.y;
}

__device__ inline uint getWarpsPerGrid() {
    return blockDim.y * gridDim.x;
}

__device__ inline uint getThreadIdInGrid() {
    return mul32(getWarpIdInGrid()) + threadIdx.x;
}

__device__ inline uint getThreadsPerGrid() {
    return mul32(blockDim.y * gridDim.x);
}

__device__ inline uint getThreadIdInBlock() {
    return mul32(threadIdx.y) + threadIdx.x;
}

__device__ inline uint getBlocksPerGrid() {
    return gridDim.x;
}

__device__ inline bool isFirstThreadOfBlock() {
    return getThreadIdInBlock() == 0;
}

__device__ inline bool isFirstThreadOfWarp() {
    return threadIdx.x == 0;
}

__device__ inline bool isFirstWarpOfBlock() {
    return threadIdx.y == 0;
}

__device__ inline bool isFirstWarpOfGrid() {
    return blockIdx.x == 0 && threadIdx.y == 0;
}

// ============================================================
// Warp helpers
// ============================================================

__device__ inline uint getValAtThread(const uint myVal, const uint lane) {
    return __shfl_sync(0xFFFFFFFF, myVal, lane);
}

__device__ inline uint warpGet(uint myVal, uint lane) {
    return __shfl_sync(0xFFFFFFFF, myVal, lane);
}

// ============================================================
// Rep / lock helpers
// ============================================================

__device__ inline uint getRep(uint var) {
    return __rep__[var];
}

__device__ inline uint getRepRec(uint var) {
    uint rep = var;
    uint repRep = __rep__[rep];

    while (repRep != rep) {
        rep = repRep;
        repRep = __rep__[rep];
    }

    return rep;
}

__device__ inline void setRep(uint var, uint rep) {
    __rep__[var] = rep;
}

__device__ inline uint lockVar(uint var) {
    uint locked = 0;

    if (isFirstThreadOfWarp()) {
        locked = atomicCAS(__lock__ + var, UNLOCKED, LOCKED) == UNLOCKED;
    }

    return __any_sync(0xFFFFFFFF, locked);
}

__device__ inline uint lock(const uint var) {
    return lockVar(var);
}

__device__ inline void unlockVar(uint var) {
    __lock__[var] = UNLOCKED;
}

__device__ inline void unlock(const uint var) {
    unlockVar(var);
}

// ============================================================
// Alloc helpers
//
// smoke-test 版本只保证不会越界到测试区域外。
// ============================================================

__device__ inline uint mallocPts(uint size = ELEMENT_WIDTH) {
    __shared__ volatile uint shared[MAX_WARPS_PER_BLOCK];

    if (isFirstThreadOfWarp()) {
        shared[threadIdx.y] = atomicAdd(&__ptsFreeList__, size);
    }

    return shared[threadIdx.y];
}

__device__ inline uint mallocNextDiffPts() {
    __shared__ volatile uint shared[MAX_WARPS_PER_BLOCK];

    if (isFirstThreadOfWarp()) {
        shared[threadIdx.y] = atomicSub(&__nextDiffPtsFreeList__, ELEMENT_WIDTH);
    }

    return shared[threadIdx.y];
}

__device__ inline uint mallocCurrDiffPts() {
    __shared__ volatile uint shared[MAX_WARPS_PER_BLOCK];

    if (isFirstThreadOfWarp()) {
        shared[threadIdx.y] = atomicSub(&__currDiffPtsFreeList__, ELEMENT_WIDTH);
    }

    return shared[threadIdx.y];
}

__device__ inline uint mallocOther() {
    __shared__ volatile uint shared[MAX_WARPS_PER_BLOCK];

    if (isFirstThreadOfWarp()) {
        shared[threadIdx.y] = atomicAdd(&__otherFreeList__, ELEMENT_WIDTH);
    }

    return shared[threadIdx.y];
}

__device__ inline uint mallocIn(uint rel) {
    if (rel == NEXT_DIFF_PTS) {
        return mallocNextDiffPts();
    }

    if (rel == CURR_DIFF_PTS) {
        return mallocCurrDiffPts();
    }

    if (rel == PTS) {
        return mallocPts();
    }

    return mallocOther();
}

// ============================================================
// Worklist helpers
// ============================================================

__device__ inline uint getAndIncrement(uint* counter, uint delta) {
    __shared__ volatile uint shared[MAX_WARPS_PER_BLOCK];

    if (isFirstThreadOfWarp()) {
        shared[threadIdx.y] = atomicAdd(counter, delta);
    }

    return shared[threadIdx.y];
}

__device__ inline uint getAndIncrement(uint delta) {
    return getAndIncrement(&__worklistIndex0__, delta);
}

__device__ inline uint resetWorklistIndex() {
    __syncthreads();

    uint numBlocks = getBlocksPerGrid();

    if (isFirstThreadOfBlock() &&
        atomicInc(&__counter__, numBlocks - 1) == (numBlocks - 1)) {
        __worklistIndex0__ = 0;
        __counter__ = 0;
        return 1;
    }

    return 0;
}

// ============================================================
// Debug names
// ============================================================

__device__ inline const char* getName(uint rel) {
    switch (rel) {
        case PTS:
            return "PTS";
        case NEXT_DIFF_PTS:
            return "NEXT_DIFF_PTS";
        case CURR_DIFF_PTS:
            return "CURR_DIFF_PTS";
        case COPY_INV:
            return "COPY_INV";
        case LOAD_INV:
            return "LOAD_INV";
        case STORE:
            return "STORE";
        default:
            return "UNKNOWN";
    }
}

// ============================================================
// Test environment
// ============================================================

struct PTATestEnv {
    uint nvars;

    uint* d_graph;
    uint* d_rep;
    uint* d_lock;
    uint* d_diffPtsMask;

    uint* d_initialRep;
    uint* d_initialNonRep;

    uint* d_storeConstraints;

    uint* d_key;
    uint* d_keyAux;
    uint* d_val;

    uint* d_hcdIndex;
    uint* d_hcdTable;
    uint* d_nextVar;

    uint* d_currPtsHead;

    uint* d_offsetMask;
    uint* d_size;

    uint* d_gepInv;

    PTATestEnv()
        : nvars(0),
          d_graph(NULL),
          d_rep(NULL),
          d_lock(NULL),
          d_diffPtsMask(NULL),
          d_initialRep(NULL),
          d_initialNonRep(NULL),
          d_storeConstraints(NULL),
          d_key(NULL),
          d_keyAux(NULL),
          d_val(NULL),
          d_hcdIndex(NULL),
          d_hcdTable(NULL),
          d_nextVar(NULL),
          d_currPtsHead(NULL),
          d_offsetMask(NULL),
          d_size(NULL),
          d_gepInv(NULL) {}
};

// ============================================================
// Initialize test environment
// ============================================================

static inline void initPTATestEnv(PTATestEnv& env, uint nvars) {
    env.nvars = nvars;

    checkCuda(cudaMalloc((void**)&env.d_graph,
                         TEST_GRAPH_SIZE * sizeof(uint)),
              "malloc graph");

    checkCuda(cudaMalloc((void**)&env.d_rep,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc rep");

    checkCuda(cudaMalloc((void**)&env.d_lock,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc lock");

    checkCuda(cudaMalloc((void**)&env.d_diffPtsMask,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc diff mask");

    checkCuda(cudaMalloc((void**)&env.d_initialRep,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc initialRep");

    checkCuda(cudaMalloc((void**)&env.d_initialNonRep,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc initialNonRep");

    checkCuda(cudaMalloc((void**)&env.d_storeConstraints,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc storeConstraints");

    checkCuda(cudaMalloc((void**)&env.d_key,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc key");

    checkCuda(cudaMalloc((void**)&env.d_keyAux,
                         (MAX_TEST_VARS + 1) * sizeof(uint)),
              "malloc keyAux");

    checkCuda(cudaMalloc((void**)&env.d_val,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc val");

    checkCuda(cudaMalloc((void**)&env.d_hcdIndex,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc hcdIndex");

    checkCuda(cudaMalloc((void**)&env.d_hcdTable,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc hcdTable");

    checkCuda(cudaMalloc((void**)&env.d_nextVar,
                         MAX_TEST_VARS * 128 * sizeof(uint)),
              "malloc nextVar");

    checkCuda(cudaMalloc((void**)&env.d_currPtsHead,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc currPtsHead");

    checkCuda(cudaMalloc((void**)&env.d_offsetMask,
                         MAX_TEST_VARS * 32 * sizeof(uint)),
              "malloc offsetMask");

    checkCuda(cudaMalloc((void**)&env.d_size,
                         MAX_TEST_VARS * sizeof(uint)),
              "malloc size");

    checkCuda(cudaMalloc((void**)&env.d_gepInv,
                         MAX_TEST_VARS * 2 * sizeof(uint)),
              "malloc gepInv");

    checkCuda(cudaMemset(env.d_graph,
                         0xFF,
                         TEST_GRAPH_SIZE * sizeof(uint)),
              "memset graph NIL");

    checkCuda(cudaMemset(env.d_diffPtsMask,
                         0,
                         MAX_TEST_VARS * sizeof(uint)),
              "memset diff mask");

    checkCuda(cudaMemset(env.d_offsetMask,
                         0,
                         MAX_TEST_VARS * 32 * sizeof(uint)),
              "memset offsetMask");

    uint h_rep[MAX_TEST_VARS];
    uint h_lock[MAX_TEST_VARS];
    uint h_init[MAX_TEST_VARS];
    uint h_store[MAX_TEST_VARS];
    uint h_key[MAX_TEST_VARS];
    uint h_keyAux[MAX_TEST_VARS + 1];
    uint h_val[MAX_TEST_VARS];

    uint h_hcdIndex[MAX_TEST_VARS];
    uint h_hcdTable[MAX_TEST_VARS];

    uint h_currPtsHead[MAX_TEST_VARS];
    uint h_size[MAX_TEST_VARS];
    uint h_gepInv[MAX_TEST_VARS * 2];

    for (uint i = 0; i < MAX_TEST_VARS; i++) {
        h_rep[i] = i;
        h_lock[i] = UNLOCKED;
        h_init[i] = i;

        h_store[i] = NIL;

        h_key[i] = NIL;
        h_val[i] = NIL;

        h_hcdIndex[i] = 0;
        h_hcdTable[i] = NIL;

        h_currPtsHead[i] = NIL;
        h_size[i] = 4;
    }

    for (uint i = 0; i <= MAX_TEST_VARS; i++) {
        h_keyAux[i] = 0;
    }

    for (uint i = 0; i < MAX_TEST_VARS * 2; i++) {
        h_gepInv[i] = NIL;
    }

    checkCuda(cudaMemcpy(env.d_rep,
                         h_rep,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy rep");

    checkCuda(cudaMemcpy(env.d_lock,
                         h_lock,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy lock");

    checkCuda(cudaMemcpy(env.d_initialRep,
                         h_init,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy initialRep");

    checkCuda(cudaMemcpy(env.d_initialNonRep,
                         h_init,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy initialNonRep");

    checkCuda(cudaMemcpy(env.d_storeConstraints,
                         h_store,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy storeConstraints");

    checkCuda(cudaMemcpy(env.d_key,
                         h_key,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy key");

    checkCuda(cudaMemcpy(env.d_keyAux,
                         h_keyAux,
                         (MAX_TEST_VARS + 1) * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy keyAux");

    checkCuda(cudaMemcpy(env.d_val,
                         h_val,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy val");

    checkCuda(cudaMemcpy(env.d_hcdIndex,
                         h_hcdIndex,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy hcdIndex");

    checkCuda(cudaMemcpy(env.d_hcdTable,
                         h_hcdTable,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy hcdTable");

    checkCuda(cudaMemcpy(env.d_currPtsHead,
                         h_currPtsHead,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy currPtsHead");

    checkCuda(cudaMemcpy(env.d_size,
                         h_size,
                         MAX_TEST_VARS * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy size");

    checkCuda(cudaMemcpy(env.d_gepInv,
                         h_gepInv,
                         MAX_TEST_VARS * 2 * sizeof(uint),
                         cudaMemcpyHostToDevice),
              "copy gepInv");

    // ========================================================
    // Bind pointer symbols
    // ========================================================

    BIND_PTR_TO_SYMBOL(__graph__, env.d_graph);
    BIND_PTR_TO_SYMBOL(__rep__, env.d_rep);
    BIND_PTR_TO_SYMBOL(__lock__, env.d_lock);
    BIND_PTR_TO_SYMBOL(__diffPtsMask__, env.d_diffPtsMask);

    BIND_PTR_TO_SYMBOL(__initialRep__, env.d_initialRep);
    BIND_PTR_TO_SYMBOL(__initialNonRep__, env.d_initialNonRep);

    BIND_PTR_TO_SYMBOL(__storeConstraints__, env.d_storeConstraints);

    BIND_PTR_TO_SYMBOL(__key__, env.d_key);
    BIND_PTR_TO_SYMBOL(__keyAux__, env.d_keyAux);
    BIND_PTR_TO_SYMBOL(__val__, env.d_val);

    BIND_PTR_TO_SYMBOL(__hcdIndex__, env.d_hcdIndex);
    BIND_PTR_TO_SYMBOL(__hcdTable__, env.d_hcdTable);
    BIND_PTR_TO_SYMBOL(__nextVar__, env.d_nextVar);

    BIND_PTR_TO_SYMBOL(__currPtsHead__, env.d_currPtsHead);

    BIND_PTR_TO_SYMBOL(__offsetMask__, env.d_offsetMask);
    BIND_PTR_TO_SYMBOL(__size__, env.d_size);

    BIND_PTR_TO_SYMBOL(__gepInv__, env.d_gepInv);

    // ========================================================
    // Bind scalar constant symbols
    // ========================================================

    uint storeStart = TEST_STORE_START;
    uint loadInvStart = TEST_LOAD_INV_START;

    uint zero = 0;
    uint one = 1;

    BIND_VAL_TO_SYMBOL(__numVars__, nvars);
    BIND_VAL_TO_SYMBOL(__storeStart__, storeStart);
    BIND_VAL_TO_SYMBOL(__loadInvStart__, loadInvStart);
    BIND_VAL_TO_SYMBOL(__numInitialRep__, zero);
    BIND_VAL_TO_SYMBOL(__numHcdIndex__, zero);
    BIND_VAL_TO_SYMBOL(__offsetMaskRowsPerOffset__, one);
    BIND_VAL_TO_SYMBOL(__numGepInv__, zero);

    // ========================================================
    // Initialize device scalar globals
    // ========================================================

    checkCuda(cudaMemcpyToSymbol(__numStore__,
                                 &zero,
                                 sizeof(uint)),
              "set __numStore__");

    checkCuda(cudaMemcpyToSymbol(__numKeys__,
                                 &zero,
                                 sizeof(uint)),
              "set __numKeys__");

    checkCuda(cudaMemcpyToSymbol(__numKeysCounter__,
                                 &zero,
                                 sizeof(uint)),
              "set __numKeysCounter__");

    checkCuda(cudaMemcpyToSymbol(__worklistIndex0__,
                                 &zero,
                                 sizeof(uint)),
              "set __worklistIndex0__");

    checkCuda(cudaMemcpyToSymbol(__worklistIndex1__,
                                 &zero,
                                 sizeof(uint)),
              "set __worklistIndex1__");

    checkCuda(cudaMemcpyToSymbol(__counter__,
                                 &zero,
                                 sizeof(uint)),
              "set __counter__");

    checkCuda(cudaMemcpyToSymbol(__error__,
                                 &zero,
                                 sizeof(uint)),
              "set __error__");

    bool done = true;
    checkCuda(cudaMemcpyToSymbol(__done__,
                                 &done,
                                 sizeof(bool)),
              "set __done__");

    // ========================================================
    // Initialize freelists
    // ========================================================

    uint ptsFree = TEST_PTS_START + nvars * ELEMENT_WIDTH;
    uint currFree = TEST_CURR_DIFF_PTS_START + nvars * ELEMENT_WIDTH;
    uint nextFree = TEST_NEXT_DIFF_PTS_START + nvars * ELEMENT_WIDTH;
    uint otherFree = TEST_COPY_INV_START + nvars * ELEMENT_WIDTH * 4;

    checkCuda(cudaMemcpyToSymbol(__ptsFreeList__,
                                 &ptsFree,
                                 sizeof(uint)),
              "set __ptsFreeList__");

    checkCuda(cudaMemcpyToSymbol(__currDiffPtsFreeList__,
                                 &currFree,
                                 sizeof(uint)),
              "set __currDiffPtsFreeList__");

    checkCuda(cudaMemcpyToSymbol(__nextDiffPtsFreeList__,
                                 &nextFree,
                                 sizeof(uint)),
              "set __nextDiffPtsFreeList__");

    checkCuda(cudaMemcpyToSymbol(__otherFreeList__,
                                 &otherFree,
                                 sizeof(uint)),
              "set __otherFreeList__");
}

// ============================================================
// Destroy test environment
// ============================================================

static inline void destroyPTATestEnv(PTATestEnv& env) {
    if (env.d_graph) cudaFree(env.d_graph);
    if (env.d_rep) cudaFree(env.d_rep);
    if (env.d_lock) cudaFree(env.d_lock);
    if (env.d_diffPtsMask) cudaFree(env.d_diffPtsMask);

    if (env.d_initialRep) cudaFree(env.d_initialRep);
    if (env.d_initialNonRep) cudaFree(env.d_initialNonRep);

    if (env.d_storeConstraints) cudaFree(env.d_storeConstraints);

    if (env.d_key) cudaFree(env.d_key);
    if (env.d_keyAux) cudaFree(env.d_keyAux);
    if (env.d_val) cudaFree(env.d_val);

    if (env.d_hcdIndex) cudaFree(env.d_hcdIndex);
    if (env.d_hcdTable) cudaFree(env.d_hcdTable);
    if (env.d_nextVar) cudaFree(env.d_nextVar);

    if (env.d_currPtsHead) cudaFree(env.d_currPtsHead);

    if (env.d_offsetMask) cudaFree(env.d_offsetMask);
    if (env.d_size) cudaFree(env.d_size);

    if (env.d_gepInv) cudaFree(env.d_gepInv);

    env.d_graph = NULL;
    env.d_rep = NULL;
    env.d_lock = NULL;
    env.d_diffPtsMask = NULL;

    env.d_initialRep = NULL;
    env.d_initialNonRep = NULL;

    env.d_storeConstraints = NULL;

    env.d_key = NULL;
    env.d_keyAux = NULL;
    env.d_val = NULL;

    env.d_hcdIndex = NULL;
    env.d_hcdTable = NULL;
    env.d_nextVar = NULL;

    env.d_currPtsHead = NULL;

    env.d_offsetMask = NULL;
    env.d_size = NULL;

    env.d_gepInv = NULL;
}