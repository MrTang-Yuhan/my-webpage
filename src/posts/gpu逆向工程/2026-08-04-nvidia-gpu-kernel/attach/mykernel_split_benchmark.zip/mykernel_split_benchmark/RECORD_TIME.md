# CUDA Executable Running Record

`-9 含义：运行失败。错误原因：signal SIGKILL, Killed.`
`-6 含义：运行失败。错误原因：模拟器 bug：free(): double free detected in tcache 2`

# rodinia-2.0-ft

- Search directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft`
- Build directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/build`
- Config file: `/accel-sim/accel-sim-framework-dev/single_run/gpgpusim.config`
- Timeout
| No. | Executable | Output | Running Time(s) | Return Code |
|---:|---|---|---|---:|
| 1 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/backprop/single_kernel_bpnn_adjust_weights_cuda` | `single_kernel_bpnn_adjust_weights_cuda.txt` | 00:00:04 | 0 |
| 2 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/backprop/single_kernel_bpnn_layerforward_CUDA` | `single_kernel_bpnn_layerforward_CUDA.txt` | 00:00:04 | 0 |
| 3 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/bfs/single_kernel_Kernel` | `single_kernel_Kernel.txt` | 00:00:04 | 0 |
| 4 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/bfs/single_kernel_Kernel2` | `single_kernel_Kernel2.txt` | 00:00:03 | 0 |
| 5 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/heartwall/single_kernel_kernel` | `single_kernel_kernel.txt` | 00:00:19 | 0 |
| 6 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/hotspot/single_kernel_calculate_temp` | `single_kernel_calculate_temp.txt` | 00:00:06 | 0 |
| 7 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/lud/single_kernel_lud_diagonal` | `single_kernel_lud_diagonal.txt` | 00:00:07 | 0 |
| 8 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/lud/single_kernel_lud_internal` | `single_kernel_lud_internal.txt` | 00:00:04 | 0 |
| 9 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/lud/single_kernel_lud_perimeter` | `single_kernel_lud_perimeter.txt` | 00:00:10 | 0 |
| 10 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/nn/single_kernel_euclid` | `single_kernel_euclid.txt` | 00:00:04 | 0 |
| 11 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/nw/single_kernel_needle_cuda_shared_1` | `single_kernel_needle_cuda_shared_1.txt` | 00:00:05 | 0 |
| 12 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/nw/single_kernel_needle_cuda_shared_2` | `single_kernel_needle_cuda_shared_2.txt` | 00:00:05 | 0 |
| 13 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/pathfinder/single_kernel_dynproc_kernel` | `single_kernel_dynproc_kernel.txt` | 00:00:18 | 0 |
| 14 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/srad/single_kernel_compress` | `single_kernel_compress.txt` | 00:01:59 | 0 |
| 15 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/srad/single_kernel_extract` | `single_kernel_extract.txt` | 00:01:26 | 0 |
| 16 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/srad/single_kernel_srad` | `single_kernel_srad.txt` | 00:02:15 | 0 |
| 17 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/srad/single_kernel_srad2` | `single_kernel_srad2.txt` | 00:01:42 | 0 |
| 18 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-2.0-ft/streamcluster/single_kernel_pgain_kernel` | `single_kernel_pgain_kernel.txt` | 00:00:04 | 0 |


# rodinia-3.1

- Search directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1`
- Build directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/build`
- Config file: `/accel-sim/accel-sim-framework-dev/single_run/gpgpusim.config`
- Timeout
| No. | Executable | Output | Running Time(s) | Return Code |
|---:|---|---|---|---:|
| 1 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/b+tree/kernel/single_kernel_findK` | `single_kernel_findK.txt` | 00:00:03 | 0 |
| 2 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/b+tree/kernel/single_kernel_findRangeK` | `single_kernel_findRangeK.txt` | 00:00:03 | 0 |
| 3 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/cfd/single_kernel_cuda_compute_flux` | `single_kernel_cuda_compute_flux.txt` | 00:00:07 | 0 |
| 4 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/cfd/single_kernel_cuda_compute_flux_contributions` | `single_kernel_cuda_compute_flux_contributions.txt` | 00:00:03 | 0 |
| 5 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/cfd/single_kernel_cuda_compute_step_factor` | `single_kernel_cuda_compute_step_factor.txt` | 00:00:03 | 0 |
| 6 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/cfd/single_kernel_cuda_initialize_variables` | `single_kernel_cuda_initialize_variables.txt` | 00:00:03 | 0 |
| 7 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/cfd/single_kernel_cuda_time_step` | `single_kernel_cuda_time_step.txt` | 00:00:06 | 0 |
| 8 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/gaussian/single_kernel_Fan1` | `single_kernel_Fan1.txt` | 00:00:03 | 0 |
| 9 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/gaussian/single_kernel_Fan2` | `single_kernel_Fan2.txt` | 00:00:03 | 0 |
| 10 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/huffman/single_kernel_histo_kernel` | `single_kernel_histo_kernel.txt` | 00:48:35 | -9 |
| 11 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/huffman/single_kernel_pack2` | `single_kernel_pack2.txt` | 00:00:31 | 0 |
| 12 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/huffman/single_kernel_prescan` | `single_kernel_prescan.txt` | 00:00:04 | 0 |
| 13 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/huffman/single_kernel_uniformAdd` | `single_kernel_uniformAdd.txt` | 00:00:04 | 0 |
| 14 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/huffman/single_kernel_vlc_encode_kernel_sm64huff` | `single_kernel_vlc_encode_kernel_sm64huff.txt` | 00:00:04 | 0 |
| 15 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/hybridsort/single_kernel_bucketprefixoffset` | `single_kernel_bucketprefixoffset.txt` | 00:00:04 | 0 |
| 16 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/hybridsort/single_kernel_bucketsort` | `single_kernel_bucketsort.txt` | 00:00:06 | 0 |
| 17 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/hybridsort/single_kernel_histogram1024Kernel` | `single_kernel_histogram1024Kernel.txt` | 00:05:10 | 0 |
| 18 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/hybridsort/single_kernel_mergepack` | `single_kernel_mergepack.txt` | 00:00:03 | 0 |
| 19 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/lavaMD/single_kernel_kernel_gpu_cuda` | `single_kernel_kernel_gpu_cuda.txt` | 00:02:22 | 0 |
| 20 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/leukocyte/CUDA/single_kernel_GICOV_kernel` | `single_kernel_GICOV_kernel.txt` | 00:22:53 | 0 |
| 21 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/leukocyte/CUDA/single_kernel_dilate_kernel` | `single_kernel_dilate_kernel.txt` | 00:00:12 | 0 |
| 22 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/myocyte/single_kernel_kernel` | `single_kernel_kernel.txt` | 00:00:05 | -6 |
| 23 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/myocyte/single_kernel_solver_2` | `single_kernel_solver_2.txt` | 00:00:04 | -6 |
| 24 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/particlefilter/single_kernel_find_index_kernel` | `single_kernel_find_index_kernel.txt` | 00:00:38 | 0 |
| 25 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/particlefilter/single_kernel_kernel` | `particlefilter__single_kernel_kernel.txt` | 00:00:38 | 0 |
| 26 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/particlefilter/single_kernel_normalize_weights_kernel` | `single_kernel_normalize_weights_kernel.txt` | 00:00:17 | 0 |
| 27 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/rodinia-3.1/particlefilter/single_kernel_sum_kernel` | `single_kernel_sum_kernel.txt` | 00:00:03 | 0 |

# polybench

- Search directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0`
- Build directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/build`
- Config file: `/accel-sim/accel-sim-framework-dev/single_run/gpgpusim.config`
- Timeout

| No. | Executable | Output | Running Time(s) | Return Code |
|---:|---|---|---|---:|
| 1 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/2DCONV/single_kernel_Convolution2D_kernel` | `single_kernel_Convolution2D_kernel.txt` | 00:34:50 | -9 |
| 2 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/2MM/single_kernel_mm2_kernel1` | `single_kernel_mm2_kernel1.txt` | 00:22:20 | -9 |
| 3 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/2MM/single_kernel_mm2_kernel2` | `single_kernel_mm2_kernel2.txt` | 00:07:28 | -9 |
| 4 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/3DCONV/single_kernel_convolution3D_kernel` | `single_kernel_convolution3D_kernel.txt` | 00:21:12 | 0 |
| 5 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/3MM/single_kernel_mm3_kernel1` | `single_kernel_mm3_kernel1.txt` | 00:58:55 | 0 |
| 6 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/3MM/single_kernel_mm3_kernel2` | `single_kernel_mm3_kernel2.txt` | 00:53:02 | 0 |
| 7 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/3MM/single_kernel_mm3_kernel3` | `single_kernel_mm3_kernel3.txt` | 00:52:33 | 0 |
| 8 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/ATAX/single_kernel_atax_kernel1` | `single_kernel_atax_kernel1.txt` | 00:12:46 | 0 |
| 9 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/ATAX/single_kernel_atax_kernel2` | `single_kernel_atax_kernel2.txt` | 00:16:33 | 0 |
| 10 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/BICG/single_kernel_bicg_kernel1` | `single_kernel_bicg_kernel1.txt` | 00:16:20 | 0 |
| 11 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/BICG/single_kernel_bicg_kernel2` | `single_kernel_bicg_kernel2.txt` | 00:12:41 | 0 |
| 12 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/CORR/single_kernel_corr_kernel` | `single_kernel_corr_kernel.txt` | 03:52:25 | -9 |
| 13 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/CORR/single_kernel_mean_kernel` | `single_kernel_mean_kernel.txt` | 00:25:03 | 0 |
| 14 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/CORR/single_kernel_reduce_kernel` | `single_kernel_reduce_kernel.txt` | 00:00:06 | 0 |
| 15 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/CORR/single_kernel_std_kernel` | `single_kernel_std_kernel.txt` | 00:28:00 | 0 |
| 16 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/COVAR/single_kernel_covar_kernel` | `single_kernel_covar_kernel.txt` | timeout | N/A |
| 17 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/COVAR/single_kernel_mean_kernel` | `CUDA__COVAR__single_kernel_mean_kernel.txt` | 00:02:50 | 0 |
| 18 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/COVAR/single_kernel_reduce_kernel` | `CUDA__COVAR__single_kernel_reduce_kernel.txt` | 00:08:27 | 0 |
| 19 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/FDTD-2D/single_kernel_fdtd_step1_kernel` | `single_kernel_fdtd_step1_kernel.txt` | 00:00:07 | 0 |
| 20 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/FDTD-2D/single_kernel_fdtd_step2_kernel` | `single_kernel_fdtd_step2_kernel.txt` | 00:00:07 | 0 |
| 21 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/FDTD-2D/single_kernel_fdtd_step3_kernel` | `single_kernel_fdtd_step3_kernel.txt` | 00:00:08 | 0 |
| 22 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/GEMM/single_kernel_gemm_kernel` | `single_kernel_gemm_kernel.txt` | 00:56:14 | 0 |
| 23 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/GESUMMV/single_kernel_gesummv_kernel` | `single_kernel_gesummv_kernel.txt` | 00:28:27 | 0 |
| 24 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/GRAMSCHM/single_kernel_gramschmidt_kernel1` | `single_kernel_gramschmidt_kernel1.txt` | 00:01:47 | 0 |
| 25 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/GRAMSCHM/single_kernel_gramschmidt_kernel2` | `single_kernel_gramschmidt_kernel2.txt` | 00:00:06 | 0 |
| 26 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/GRAMSCHM/single_kernel_gramschmidt_kernel3` | `single_kernel_gramschmidt_kernel3.txt` | 00:10:36 | 0 |
| 27 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/MVT/single_kernel_mvt_kernel1` | `single_kernel_mvt_kernel1.txt` | 00:12:50 | 0 |
| 28 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/MVT/single_kernel_mvt_kernel2` | `single_kernel_mvt_kernel2.txt` | 00:16:33 | 0 |
| 29 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/SYR2K/single_kernel_syr2k_kernel` | `single_kernel_syr2k_kernel.txt` | 00:16:05 | -9 |
| 30 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/polybench-gpu-1.0/CUDA/SYRK/single_kernel_syrk_kernel` | `single_kernel_syrk_kernel.txt` | 02:26:17 | -9 |

# pannotia

- Search directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia`
- Build directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/build`
- Config file: `/accel-sim/accel-sim-framework-dev/single_run/gpgpusim.config`
- Timeout

| No. | Executable | Output | Running Time(s) | Return Code |
|---:|---|---|---|---:|
| 1 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/bc/single_kernel_back_sum_kernel` | `single_kernel_back_sum_kernel.txt` | 00:00:05 | 0 |
| 2 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/bc/single_kernel_backtrack_kernel` | `single_kernel_backtrack_kernel.txt` | 00:00:04 | 0 |
| 3 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/bc/single_kernel_bfs_kernel` | `single_kernel_bfs_kernel.txt` | 00:00:03 | 0 |
| 4 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/bc/single_kernel_clean_1d_array` | `single_kernel_clean_1d_array.txt` | 00:00:03 | 0 |
| 5 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/bc/single_kernel_clean_2d_array` | `single_kernel_clean_2d_array.txt` | 00:00:58 | 0 |
| 6 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/bc/single_kernel_clean_bc` | `single_kernel_clean_bc.txt` | 00:00:03 | 0 |
| 7 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/color/single_kernel_color1` | `single_kernel_color1.txt` | 00:00:04 | 0 |
| 8 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/color/single_kernel_color2` | `single_kernel_color2.txt` | 00:00:03 | 0 |
| 9 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/fw/single_kernel_floydwarshall` | `single_kernel_floydwarshall.txt` | 00:00:54 | 0 |
| 10 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/fw/single_kernel_floydwarshall_dia_block` | `single_kernel_floydwarshall_dia_block.txt` | 00:00:03 | 0 |
| 11 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/fw/single_kernel_floydwarshall_remaining_blocks` | `single_kernel_floydwarshall_remaining_blocks.txt` | 00:02:19 | 0 |
| 12 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/fw/single_kernel_floydwarshall_strip_blocks_x` | `single_kernel_floydwarshall_strip_blocks_x.txt` | 00:00:08 | 0 |
| 13 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/fw/single_kernel_floydwarshall_strip_blocks_y` | `single_kernel_floydwarshall_strip_blocks_y.txt` | 00:00:07 | 0 |
| 14 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/mis/single_kernel_init` | `single_kernel_init.txt` | 00:00:03 | 0 |
| 15 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/mis/single_kernel_mis1` | `single_kernel_mis1.txt` | 00:00:04 | 0 |
| 16 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/mis/single_kernel_mis2` | `single_kernel_mis2.txt` | 00:00:04 | 0 |
| 17 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/mis/single_kernel_mis3` | `single_kernel_mis3.txt` | 00:00:03 | 0 |
| 18 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/pagerank/single_kernel_inibuffer` | `single_kernel_inibuffer.txt` | 00:00:03 | 0 |
| 19 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/pagerank/single_kernel_inicsr` | `single_kernel_inicsr.txt` | 00:00:03 | 0 |
| 20 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/pagerank/single_kernel_pagerank1` | `single_kernel_pagerank1.txt` | 00:00:04 | 0 |
| 21 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/pagerank/single_kernel_pagerank2` | `single_kernel_pagerank2.txt` | 00:00:03 | 0 |
| 22 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/pagerank/single_kernel_spmv_csr_scalar_kernel` | `single_kernel_spmv_csr_scalar_kernel.txt` | 00:00:03 | 0 |
| 23 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/sssp/single_kernel_ell_min_dot_plus_kernel` | `single_kernel_ell_min_dot_plus_kernel.txt` | 00:00:04 | 0 |
| 24 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/sssp/single_kernel_spmv_min_dot_plus_kernel` | `single_kernel_spmv_min_dot_plus_kernel.txt` | 00:00:04 | 0 |
| 25 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/sssp/single_kernel_vector_assign` | `single_kernel_vector_assign.txt` | 00:00:03 | 0 |
| 26 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/sssp/single_kernel_vector_diff` | `single_kernel_vector_diff.txt` | 00:00:03 | 0 |
| 27 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/pannotia/sssp/single_kernel_vector_init` | `single_kernel_vector_init.txt` | 00:00:03 | 0 |


# ISPASS-2009

- Search directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009`
- Build directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/build`
- Config file: `/accel-sim/accel-sim-framework-dev/single_run/gpgpusim.config`
- Timeout

| No. | Executable | Output | Running Time(s) | Return Code |
|---:|---|---|---|---:|
| 1 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/BFS/single_kernel_Kernel` | `single_kernel_Kernel.txt` | 00:00:07 | 0 |
| 2 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/CP/cuda_base/single_kernel_cenergy` | `single_kernel_cenergy.txt` | timeout | N/A |
| 3 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/LPS/single_kernel_GPU_laplace3d` | `single_kernel_GPU_laplace3d.txt` | 00:01:33 | 0 |
| 4 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/NN/single_kernel_executeFirstLayer` | `single_kernel_executeFirstLayer.txt` | 00:00:05 | 0 |
| 5 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/NN/single_kernel_executeFourthLayer` | `single_kernel_executeFourthLayer.txt` | 00:00:07 | 0 |
| 6 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/NN/single_kernel_executeSecondLayer` | `single_kernel_executeSecondLayer.txt` | 00:00:34 | 0 |
| 7 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/NN/single_kernel_executeThirdLayer` | `single_kernel_executeThirdLayer.txt` | 00:06:33 | 0 |
| 8 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/NQU/single_kernel_solve_nqueen_cuda_kernel` | `single_kernel_solve_nqueen_cuda_kernel.txt` | 00:01:31 | 0 |
| 9 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/STO/single_kernel_md5` | `single_kernel_md5.txt` | 00:00:04 | 0 |
| 10 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/STO/single_kernel_md5_overlap` | `single_kernel_md5_overlap.txt` | 00:00:04 | 0 |
| 11 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/STO/single_kernel_sha1` | `single_kernel_sha1.txt` | 00:00:05 | 0 |
| 12 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/ispass-2009/STO/single_kernel_sha1_overlap` | `single_kernel_sha1_overlap.txt` | 00:00:05 | 0 |


# LonestarGPU

- Search directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0`
- Build directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/build`
- Config file: `/accel-sim/accel-sim-framework-dev/single_run/gpgpusim.config`
- Timeout

| No. | Executable | Output | Running Time(s) | Return Code |
|---:|---|---|---|---:|
| 1 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/bfs/single_kernel_dprocess` | `single_kernel_dprocess.txt` | 00:00:06 | 0 |
| 1 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/bfs/single_kernel_initialize` | `single_kernel_initialize.txt` | 00:00:03 | 0 |
| 2 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/dmr/single_kernel_check_triangles` | `single_kernel_check_triangles.txt` | 00:00:03 | 0 |
| 3 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/dmr/single_kernel_find_neighbours` | `single_kernel_find_neighbours.txt` | 00:00:03 | 0 |
| 4 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_addEdges` | `single_kernel_addEdges.txt` | 00:00:03 | 0 |
| 5 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_computeCurrPtsHash` | `single_kernel_computeCurrPtsHash.txt` | 00:00:04 | -6 |
| 6 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_createOffsetMasks` | `single_kernel_createOffsetMasks.txt` | 00:00:03 | 0 |
| 7 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_findCurrPtsEquivalents` | `single_kernel_findCurrPtsEquivalents.txt` | 00:00:03 | 0 |
| 8 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_gepInv` | `single_kernel_gepInv.txt` | 00:00:03 | -6 |
| 9 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_hcd` | `single_kernel_hcd.txt` | 00:00:04 | 0 |
| 10 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_initialize` | `apps__pta__single_kernel_initialize.txt` | 00:00:03 | 0 |
| 11 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_storeInv` | `single_kernel_storeInv.txt` | 00:00:03 | 0 |
| 12 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_updateInfo` | `single_kernel_updateInfo.txt` | 00:00:03 | 0 |
| 13 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/pta/single_kernel_updatePtsInformation` | `single_kernel_updatePtsInformation.txt` | 00:00:05 | 0 |
| 14 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/sp/single_kernel_calc_pi_values` | `single_kernel_calc_pi_values.txt` | 00:00:03 | 0 |
| 15 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/sp/single_kernel_decimate_2` | `single_kernel_decimate_2.txt` | 00:00:03 | 0 |
| 16 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/sp/single_kernel_update_bias` | `single_kernel_update_bias.txt` | 00:00:03 | -6 |
| 17 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/sp/single_kernel_update_eta` | `single_kernel_update_eta.txt` | 00:00:03 | 0 |
| 18 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/sssp/single_kernel_drelax` | `apps__sssp__single_kernel_drelax.txt` | 00:00:03 | 0 |
| 19 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/sssp/single_kernel_dverifysolution` | `apps__sssp__single_kernel_dverifysolution.txt` | 00:00:03 | 0 |
| 20 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/sssp/single_kernel_initialize` | `apps__sssp__single_kernel_initialize.txt` | 00:00:03 | 0 |
| 21 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/lonestargpu-2.0/apps/sssp/single_kernel_remove_dups` | `single_kernel_remove_dups.txt` | 00:00:03 | 0 |


# Tango

- Search directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master`
- Build directory: `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/build`
- Config file: `/accel-sim/accel-sim-framework-dev/single_run/gpgpusim.config`
- Timeout

| No. | Executable | Output | Running Time(s) | Return Code |
|---:|---|---|---|---:|
| 1 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_execute3DconvolutionCuda` | `single_kernel_execute3DconvolutionCuda.txt` | timeout | N/A |
| 2 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_execute3Dconvolutiongroup2Cuda` | `single_kernel_execute3Dconvolutiongroup2Cuda.txt` | timeout | N/A |
| 3 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_executeFCLayer` | `single_kernel_executeFCLayer.txt` | 00:04:46 | 0 |
| 4 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_executeFirstLayer` | `single_kernel_executeFirstLayer.txt` | 00:57:57 | 0 |
| 5 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_executeFourthLayer` | `single_kernel_executeFourthLayer.txt` | 00:00:16 | 0 |
| 6 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_executeThirdLayer` | `single_kernel_executeThirdLayer.txt` | 00:13:35 | 0 |
| 7 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_executelrnNormCuda` | `single_kernel_executelrnNormCuda.txt` | 00:00:24 | -6 |
| 8 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_executelrnNormCuda_split` | `single_kernel_executelrnNormCuda_split.txt` | 00:00:06 | -6 |
| 9 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/AlexNet/single_kernel_executepoolingCuda` | `single_kernel_executepoolingCuda.txt` | 00:00:39 | 0 |
| 10 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/CifarNet/single_kernel_ExecuteFifthLayer` | `single_kernel_ExecuteFifthLayer.txt` | 00:00:04 | 0 |
| 11 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/CifarNet/single_kernel_ExecuteFirstLayer` | `single_kernel_ExecuteFirstLayer.txt` | 00:06:20 | 0 |
| 12 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/CifarNet/single_kernel_ExecuteFourthLayer` | `single_kernel_ExecuteFourthLayer.txt` | 00:00:21 | 0 |
| 13 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/CifarNet/single_kernel_ExecuteSecondLayer` | `single_kernel_ExecuteSecondLayer.txt` | 00:11:21 | 0 |
| 14 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/CifarNet/single_kernel_ExecuteThirdLayer` | `single_kernel_ExecuteThirdLayer.txt` | 00:17:28 | 0 |
| 15 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/CifarNet/single_kernel_pooling1` | `single_kernel_pooling1.txt` | 00:00:19 | 0 |
| 16 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/CifarNet/single_kernel_pooling2` | `single_kernel_pooling2.txt` | 00:00:13 | 0 |
| 17 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/CifarNet/single_kernel_pooling3` | `single_kernel_pooling3.txt` | 00:00:17 | 0 |
| 18 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/GRU/single_kernel_GPU_forward_pass_gru` | `single_kernel_GPU_forward_pass_gru.txt` | 00:00:16 | 0 |
| 19 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/LSTM/single_kernel_ExecuteLSTM` | `single_kernel_ExecuteLSTM.txt` | 00:00:21 | 0 |
| 20 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_execute3DconvolutionCuda` | `GPU__ResNet__single_kernel_execute3DconvolutionCuda.txt` | 00:00:05 | 0 |
| 21 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_execute3DconvolutionCuda_split` | `single_kernel_execute3DconvolutionCuda_split.txt` | 00:00:08 | 0 |
| 22 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_execute3Dconvolutiongroup2Cuda` | `GPU__ResNet__single_kernel_execute3Dconvolutiongroup2Cuda.txt` | 00:00:04 | 0 |
| 23 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_executeBnNormLayerCUDA` | `single_kernel_executeBnNormLayerCUDA.txt` | 00:00:03 | 0 |
| 24 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_executeBnNormLayerCUDA_split` | `single_kernel_executeBnNormLayerCUDA_split.txt` | 00:00:03 | 0 |
| 25 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_executeEltWiseLayerCUDA` | `single_kernel_executeEltWiseLayerCUDA.txt` | 00:00:03 | 0 |
| 26 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_executeEltWiseLayerCUDA_split` | `single_kernel_executeEltWiseLayerCUDA_split.txt` | 00:00:03 | 0 |
| 27 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_executeFCLayerCUDA` | `single_kernel_executeFCLayerCUDA.txt` | 00:00:06 | 0 |
| 28 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/ResNet/single_kernel_executeFirstLayerCUDA` | `single_kernel_executeFirstLayerCUDA.txt` | 00:00:14 | 0 |
| 29 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_ExecuteFirstLayer` | `GPU__SqueezeNet__single_kernel_ExecuteFirstLayer.txt` | 02:21:26 | 0 |
| 30 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_ExecuteTenthLayer` | `single_kernel_ExecuteTenthLayer.txt` | timeout | N/A |
| 31 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire2expand1x1` | `single_kernel_Executefire2expand1x1.txt` | 00:02:45 | 0 |
| 32 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire2expand3x3` | `single_kernel_Executefire2expand3x3.txt` | 00:58:36 | 0 |
| 33 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire2squeeze1x1` | `single_kernel_Executefire2squeeze1x1.txt` | 00:10:34 | 0 |
| 34 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire3expand1x1` | `single_kernel_Executefire3expand1x1.txt` | 00:02:44 | 0 |
| 35 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire3expand3x3` | `single_kernel_Executefire3expand3x3.txt` | 00:58:21 | 0 |
| 36 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire3squeeze1x1` | `single_kernel_Executefire3squeeze1x1.txt` | 00:14:11 | 0 |
| 37 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire4expand1x1` | `single_kernel_Executefire4expand1x1.txt` | 00:27:42 | 0 |
| 38 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire4expand3x3` | `single_kernel_Executefire4expand3x3.txt` | timeout | N/A |
| 39 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire4squeeze1x1` | `single_kernel_Executefire4squeeze1x1.txt` | 00:28:03 | 0 |
| 40 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire5expand1x1` | `single_kernel_Executefire5expand1x1.txt` | 00:04:28 | 0 |
| 41 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire5expand3x3` | `single_kernel_Executefire5expand3x3.txt` | 01:27:26 | 0 |
| 42 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire5squeeze1x1` | `single_kernel_Executefire5squeeze1x1.txt` | 00:23:50 | 0 |
| 43 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire6expand1x1` | `single_kernel_Executefire6expand1x1.txt` | 00:09:54 | 0 |
| 44 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire6expand3x3` | `single_kernel_Executefire6expand3x3.txt` | 03:16:34 | 0 |
| 45 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire6squeeze1x1` | `single_kernel_Executefire6squeeze1x1.txt` | 00:35:49 | 0 |
| 46 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire7expand1x1` | `single_kernel_Executefire7expand1x1.txt` | 00:09:44 | 0 |
| 47 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire7expand3x3` | `single_kernel_Executefire7expand3x3.txt` | 03:13:21 | 0 |
| 48 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire7squeeze1x1` | `single_kernel_Executefire7squeeze1x1.txt` | 00:53:05 | 0 |
| 49 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire8expand1x1` | `single_kernel_Executefire8expand1x1.txt` | 00:47:35 | 0 |
| 50 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire8expand3x3` | `single_kernel_Executefire8expand3x3.txt` | timeout | N/A |
| 51 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire8squeeze1x1` | `single_kernel_Executefire8squeeze1x1.txt` | 01:11:48 | 0 |
| 52 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire9expand1x1` | `single_kernel_Executefire9expand1x1.txt` | 00:09:35 | 0 |
| 53 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire9expand3x3` | `single_kernel_Executefire9expand3x3.txt` | 03:02:58 | 0 |
| 54 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_Executefire9squeeze1x1` | `single_kernel_Executefire9squeeze1x1.txt` | 00:49:30 | 0 |
| 55 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_global_pooling` | `single_kernel_global_pooling.txt` | 00:00:36 | 0 |
| 56 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_pooling1` | `GPU__SqueezeNet__single_kernel_pooling1.txt` | 00:00:04 | 0 |
| 57 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_pooling4` | `single_kernel_pooling4.txt` | 00:00:04 | 0 |
| 58 | `/accel-sim/accel-sim-framework-dev/gpu-app-collection/src/cuda-test/Tango-master/GPU/SqueezeNet/single_kernel_pooling8` | `single_kernel_pooling8.txt` | 00:00:05 | 0 |
