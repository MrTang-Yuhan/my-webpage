# Accelsim 模拟器 kernel 运行结果测试

对每个 workload 进行预处理：首先按照 `__global__` kernel 对 workload 进行拆分，将其划分为多个独立的 kernel；随后借助 AI 工具为每个 kernel 补充对应的 host 端代码，使其能够单独编译和运行。

# 文件结构

- `./benchmark/`：用于存放已经完成 `__global__` kernel 拆分的 `.cu` 文件。  
  以 `kernel_split_benchmark/benchmark/Tango-master/GPU/LSTM/` 为例：
  - `single_kernel_ExecuteLSTM.cu`：完成 `__global__` kernel 拆分后的 `.cu` 文件

# 基准测试

- [ispass-2009](https://github.com/accel-sim/gpu-app-collection)，来自[论文](https://ieeexplore.ieee.org/document/4919648)，没有找到明确开源协议
- [LonestarGPU](https://iss.oden.utexas.edu/?p=projects/galois/lonestargpu)，采用 BSD-3-clause license
- [Pannotia](https://github.com/pannotia/pannotia)，来自[论文](https://www.cs.virginia.edu/~skadron/Papers/Che-pannotia-iiswc2013.pdf)，© 2014 Advanced Micro Devices, Inc. All rights reserved.
- [PolyBench](https://www.cs.colostate.edu/~pouchet/software/polybench/GPU/index.html)，没有找到明确开源协议
- [Rodinia](https://github.com/socal-ucr/Rodinia)，仓库内有标注它的自定义协议
- [Tango](https://gitlab.com/Tango-DNNbench/Tango/-/blob/master/LICENSE?ref_type=heads)，来自[论文](https://ieeexplore.ieee.org/document/8695662/), 采用 GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007


 
