# Triton Tutorials

本仓库通过带有详细中文注释的 Python 实现，讲解
[Triton 官方教程](https://triton-lang.org/main/getting-started/tutorials/index.html)
中的常用 GPU 内核。建议按目录编号顺序阅读，并结合配套视频理解代码。

[![ERROR DISPLAYING IMAGE, CLICK HERE FOR VIDEO](https://img.youtube.com/vi/FtmnriHLbAg/0.jpg)](https://www.youtube.com/playlist?list=PL_NMDNzkCbLR69QafQUa6yTx-T-VPIoaZ)

## Python 教程导航

| 目录 | Python 实现 | 主题 |
| --- | --- | --- |
| `04_vector_addition` | `vector_addition.py` | 向量加法、PID、边界掩码 |
| `05_fused_softmax` | `fused_softmax.py` | 融合 Softmax 与 SRAM 驻留 |
| `06_matmul` | `matmul.py` | 分块矩阵乘法与组主序调度 |
| `07_dropout` | `dropout.py` | 确定性随机数与融合 Dropout |
| `08_layernorm` | `layernorm.py` | LayerNorm 前向与反向传播 |
| `09_flash_attention` | `flash_attention.py` | 因果 FlashAttention 前向与反向传播 |
| `10_CEloss_project` | `celoss.py` | 融合交叉熵实验项目 |

每个目录的 README 都按照对应 `.py` 文件说明实现目标、核心数据流、关键
约束以及测试和基准测试入口。代码内的“步骤”编号给出了推荐阅读顺序，通常先从
测试或参考实现理解目标，再阅读包装函数、Triton 内核和性能测试。

> **硬件说明：** 原教程在 NVIDIA RTX 4060 Ti 上测试和基准测量。不同 GPU 的
> VRAM、SRAM 和架构能力不同，可能需要调整块大小或测试规模，也可能得到不同的
> 性能和数值误差。

## 学习资源

- [Triton 官方教程](https://triton-lang.org/main/getting-started/tutorials/index.html)
- [FlashAttention 参考实现](https://github.com/hkproj/triton-flash-attention)及其
  [配套视频](https://www.youtube.com/watch?v=zy8ChVd_oTM&t=1s)
- FlashAttention 论文：[v1](https://arxiv.org/abs/2205.14135)和
  [v2](https://arxiv.org/abs/2307.08691)
- [GPU MODE 课程](https://github.com/gpu-mode/lectures/tree/main)，其中第 14 课
  介绍 Triton
