"""使用 Triton 实现带因果掩码的 FlashAttention 前向和反向传播。

此实现仅支持因果掩码，不支持其他掩码或无掩码情形。
前向传播主要基于两篇原始论文中的伪代码：
https://arxiv.org/abs/2205.14135
https://arxiv.org/abs/2307.08691
反向传播主要基于 Triton 文档中的实现，因为它比原始论文中的伪代码快得多：
https://triton-lang.org/main/getting-started/tutorials/06-fused-attention.html#sphx-glr-getting-started-tutorials-06-fused-attention-py

你将学到：
- 调用子内核
- 使用更快的 tl.exp2() 替代 tl.exp()
- Flash Attention 特有的并行化策略
- tl.static_assert()
- 多轴启动网格及启动网格轴顺序的重要性
- 何时应在单独的内核中预计算某些值
- 使用近似常量值而非实时计算

该内核未包含的显著特性：
- 除 fp32 和混合精度以外的数据类型支持
- dropout
- 可能还有我遗漏的功能

当前 autotune 搜索空间仅保留一组配置，方便教学和快速启动；若要追求更高性能，
应针对目标 GPU 扩大候选配置并重新调优。
"""

import math
import sys

import torch
import triton
import triton.language as tl

DEVICE = torch.device(f"cuda:{torch.cuda.current_device()}")  # 0-D/设备元数据。

# 如需使用 Triton 解释器调试，可取消下面两行的注释。
# import os
# os.environ["TRITON_INTERPRET"] = "1"


@triton.jit
def _attention_forward_inner(
    q,
    output,
    denominator,
    row_max,
    k_ptr,
    v_ptr,
    k_transpose_offsets,
    v_offsets,
    query_block_id,
    softmax_scale,
    stride_k_seq,
    stride_v_seq,
    block_size_qo: tl.constexpr,
    block_size_kv: tl.constexpr,
    diagonal: tl.constexpr,
    query_offsets: tl.constexpr,
    key_value_offsets: tl.constexpr,
    seq_len: tl.constexpr,
    head_dim: tl.constexpr,
):
    """遍历 k/v 分块，并在线更新 Softmax 状态和输出累加器。

    箭头表示此 PID 的循环方向；每个箭头对应不同的 PID。
                         seq_len of k & v
                         ------------>
                         ------------>
    seq_len of q         ------------>
                         ------------>
                         ------------>
    但若实际考虑因果掩码，情况更接近于：
                         seq_len of k & v
                         >
                         --->
    seq_len of q         ------>
                         --------->
                         ------------>
    更准确地说，我们在第二次调用此内部内核时处理对角线部分：
                         seq_len of k & v
                         x
                            x
    seq_len of q               x
                                  x
                                     x
    第一次调用则处理对角线下方的所有部分：
                         seq_len of k & v

                         -->
    seq_len of q         ----->
                         -------->
                         ----------->

    Args:
        q: 当前 q tile，形状为 `[BLOCK_SIZE_QO, D]`。
        output: 输出累加器，形状为 `[BLOCK_SIZE_QO, D]`。
        denominator: 在线 Softmax 行分母，形状为 `[BLOCK_SIZE_QO]`。
        row_max: 在线 Softmax 行最大值，形状为 `[BLOCK_SIZE_QO]`。
        k_ptr: 当前注意力头的 K 指针，局部逻辑形状为 `(N, D)`。
        v_ptr: 当前注意力头的 V 指针，局部逻辑形状为 `(N, D)`。
        k_transpose_offsets: K tile 转置寻址偏移，形状为 `[D, BLOCK_SIZE_KV]`。
        v_offsets: V tile 寻址偏移，形状为 `[BLOCK_SIZE_KV, D]`。
        query_block_id: 0-D 标量；当前 Q/output tile 的序列索引。
        softmax_scale: 0-D 标量；已转换到以 2 为底指数空间的缩放系数。
        stride_k_seq: 0-D 标量；K 沿序列维的步幅。
        stride_v_seq: 0-D 标量；V 沿序列维的步幅。
        block_size_qo: 0-D 编译期标量；Q/output tile 的序列长度 BLOCK_SIZE_QO。
        block_size_kv: 0-D 编译期标量；K/V tile 的序列长度 BLOCK_SIZE_KV。
        diagonal: 0-D 编译期布尔值；是否处理需要因果掩码的对角块。
        query_offsets: `[BLOCK_SIZE_QO]`；Q/output tile 的序列坐标。
        key_value_offsets: `[BLOCK_SIZE_KV]`；K/V tile 的序列坐标。
        seq_len: 0-D 编译期标量；序列长度 N。
        head_dim: 0-D 编译期标量；注意力头维度 D。

    Returns:
        更新后的在线 Softmax 状态：`output` 为 `[BLOCK_SIZE_QO, D]`，
        `denominator` 和 `row_max` 均为 `[BLOCK_SIZE_QO]`。
    """
    if diagonal:
        # 仅用于对角线上的块，其中存在未掩码键与掩码键之间的转换
        lo = query_block_id * block_size_qo  # 0-D 标量；K/V 起始序列坐标。
        hi = (query_block_id + 1) * block_size_qo  # 0-D 标量；K/V 结束坐标。
        # 向编译器声明 lo 的对齐关系，以启用更高效的寻址。
        lo = tl.multiple_of(lo, block_size_qo)  # 0-D 标量；对齐后的起点。
    else:
        # 此部分处理因果掩码中对角线下方的所有块
        lo, hi = 0, query_block_id * block_size_qo  # 2 个 0-D 标量；循环范围。

    k_transpose_offsets += lo * stride_k_seq
    v_offsets += lo * stride_v_seq
    key_value_offsets += lo

    # 沿 k 和 v 的 seq_len 维遍历各块，并在此过程中更新 output 累加器
    for key_value_start in range(lo, hi, block_size_kv):  # 0-D 标量；当前 K/V 块起点。
        # 告知编译器 key_value_start 是 block_size_kv 的倍数，以便进行优化
        key_value_start = tl.multiple_of(key_value_start, block_size_kv)  # 0-D 标量。

        # 计算 (q @ k^T) / sqrt(head_dim)
        key_value_mask = key_value_offsets < seq_len  # [BLOCK_SIZE_KV] 布尔掩码。
        # 转置后的 K tile 形状为 [D, BLOCK_SIZE_KV]。
        k_transpose = tl.load(
            k_ptr + k_transpose_offsets, mask=key_value_mask[None, :], other=0.0
        )  # [D, BLOCK_SIZE_KV]。
        # 序列掩码将块中超出 seq_len 的不存在 token 设为零向量
        scores = (
            tl.dot(q, k_transpose) * softmax_scale
        )  # [BLOCK_SIZE_QO, BLOCK_SIZE_KV]。
        # 被掩码的 token 会在 scores 的底边和右边形成紧邻的零列与零行

        if diagonal:  # 0-D 编译期布尔值；对角块需要逐元素因果掩码。
            # 因果掩码在含对角线的下三角部分为 True
            causal_mask = query_offsets[:, None] >= (key_value_offsets[None, :])
            # causal_mask：[BLOCK_SIZE_QO, BLOCK_SIZE_KV] 布尔掩码。
            # 加上因果掩码会将上三角（不含对角线）的值设为 -inf
            scores += tl.where(causal_mask, 0, -1.0e6)  # 屏蔽未来 token。
        # 注意，原先紧邻 scores 右边的被掩码 token 大多已替换为 -inf；
        # 紧邻底边的被掩码 token 仍大多为 0，但每行右侧有部分 -inf，
        # 最后一行除外，其仍全为 0。

        # 在线 Softmax 不能直接把不同 tile 的指数和相加，因为每个 tile
        # 可能使用不同的最大值。先更新全局行最大值，再用 alpha 把旧分母
        # 和旧输出重标定到同一指数基准，便可在不物化完整注意力矩阵的前提
        # 下继续累加。
        new_row_max = tl.maximum(
            row_max, tl.max(scores, axis=1)
        )  # [BLOCK_SIZE_QO]。
        # 底部的被掩码 token 行只含 0 和 -inf，因此最大值为 0
        # 减去行最大值可避免指数溢出。
        scores -= new_row_max[
            :, None
        ]  # [BLOCK_SIZE_QO, BLOCK_SIZE_KV]。
        # 对被掩码的不存在 token 而言，减去 0，因此没有变化

        # 计算每个安全点积的指数值，作为 softmax 的分子
        probabilities = tl.exp2(
            scores
        )  # [BLOCK_SIZE_QO, BLOCK_SIZE_KV]。
        # 使用 2 为底而非 e 为底，因为前者更快，且 softmax 对此变化保持不变；
        # 但这会使反向传播中的导数稍复杂。
        # 对底部被掩码的不存在 token，所有这些元素均为 2^0=1

        # 按行计算注意力分数之和
        new_denominator = tl.sum(
            probabilities, axis=1
        )  # [BLOCK_SIZE_QO]。
        # 对被掩码的不存在 token，求和对象是一组 1 和一些 -inf；最底部一行除外，
        # 它全为 1，因此其和最大，等于 block_size_qo
        alpha = tl.exp2(row_max - new_row_max)  # [BLOCK_SIZE_QO]。
        # alpha 将旧状态从 row_max 基准转换到 new_row_max 基准。
        denominator = (
            denominator * alpha + new_denominator
        )  # [BLOCK_SIZE_QO]。
        # 对每个被掩码的不存在 token，其 L_i 条目趋近于 seq_len

        # 计算 output = probabilities @ v + output * alpha
        # V tile 的形状为 [BLOCK_SIZE_KV, D]。
        v = tl.load(
            v_ptr + v_offsets,
            mask=key_value_mask[:, None],
            other=0.0,
        )  # [BLOCK_SIZE_KV, D]。
        output = output * alpha[:, None]  # [BLOCK_SIZE_QO, D]。
        # 将 probabilities 与 v 块的点积累加到 output 中
        output = tl.dot(
            probabilities, v, acc=output
        )  # [BLOCK_SIZE_QO, D]。
        # 注意，我们在除以 softmax 分母 l_i 前就执行了 v 投影；
        # 这在此上下文中可行，因为两个操作满足结合律。
        # acc 告知 Triton 将值累加到 O_block 中。
        # 被掩码的不存在 token 在 probabilities 的底部行中是一组 1，在 v 的底部行中是一组 0。
        # 此矩阵乘法会使 output 的底部行含有错误值，但稍后以适当掩码存储 output 时会忽略它们。

        # 将旧最大值设为新最大值，以供下一次 for 循环迭代使用
        row_max = new_row_max  # [BLOCK_SIZE_QO]。

        # 迭代指针
        k_transpose_offsets += block_size_kv * stride_k_seq
        v_offsets += block_size_kv * stride_v_seq
        key_value_offsets += block_size_kv

    return output, denominator, row_max


@triton.autotune(  # 装饰器选择当前头维上最高效的元参数。
    [
        triton.Config(
            {"block_size_qo": block_size_qo, "block_size_kv": block_size_kv},
            num_stages=num_stages,
            num_warps=num_warps,
        )
        for block_size_qo in [16]  # 可继续评估 32、64 和 128。
        for block_size_kv in [16]  # 可继续评估 32、64 和 128。
        for num_stages in [3]  # 可继续评估 5 和 7。
        for num_warps in [4]  # 可继续评估 8 和 16。
    ],
    key=["head_dim"],  # 每次 key 变化，Triton 都会重新编译内核以选择最佳配置。
)

@triton.jit
def attention_forward(
    q_ptr,
    k_ptr,
    v_ptr,  # Q/K/V 的逻辑形状均为 (B, H, N, D)。
    output_ptr,  # 输出逻辑形状为 (B, H, N, D)。
    lse_ptr,
    softmax_scale,
    stride_q_batch,
    stride_q_head,
    stride_q_seq,
    stride_q_dim,
    stride_k_batch,
    stride_k_head,
    stride_k_seq,
    stride_k_dim,
    stride_v_batch,
    stride_v_head,
    stride_v_seq,
    stride_v_dim,
    stride_output_batch,
    stride_output_head,
    stride_output_seq,
    stride_output_dim,
    stride_lse_batch,
    stride_lse_head,
    stride_lse_seq,
    batch_size,  # 批次大小作为运行时参数传入。
    # 元参数（在编译时确定）
    num_heads: tl.constexpr,
    seq_len: tl.constexpr,
    head_dim: tl.constexpr,  # 头维应为 2 的幂。
    block_size_qo: tl.constexpr,
    block_size_kv: tl.constexpr,
):
    """计算因果 FlashAttention 前向输出并保存反向传播所需的 lse。

    每个程序固定一个批次、注意力头和 q tile，在 SRAM 中保留 q 与输出
    累加器，并遍历对应的 k/v tile。

    Args:
        q_ptr: Q 指针，逻辑形状为 `(B, H, N, D)`。
        k_ptr: K 指针，逻辑形状为 `(B, H, N, D)`。
        v_ptr: V 指针，逻辑形状为 `(B, H, N, D)`。
        output_ptr: 输出指针，逻辑形状为 `(B, H, N, D)`。
        lse_ptr: log-sum-exp 输出指针，形状为 `(B, H, N)`。
        softmax_scale: 0-D 标量；注意力 logits 的缩放系数。
        stride_*: 0-D 标量；对应张量在批次、头、序列或头维上的元素步幅。
        batch_size: 0-D 标量；批次大小 B。
        num_heads: 0-D 编译期标量；注意力头数 H。
        seq_len: 0-D 编译期标量；序列长度 N。
        head_dim: 0-D 编译期标量；注意力头维度 D。
        block_size_qo: 0-D 编译期标量；Q/output tile 的序列长度 BLOCK_SIZE_QO，也就是每个程序一次能处理的 query token 数量。
        block_size_kv: 0-D 编译期标量；K/V tile 的序列长度 BLOCK_SIZE_KV，也就是每个程序在每一次循环迭代中加载的 key/value token 数量。
    """
    # 为了稍后使用更快的 tl.exp2 替代 tl.exp，需要将 softmax 缩放值乘以 ln2
    rln2: tl.constexpr = 1.4426950408889634  # 0-D 编译期标量：1 / math.log(2)。
    softmax_scale *= rln2
    # 根据换底公式： log_2(e) = 1 / ln(2)，因此：
    # log_2(e) = 1 / ln(2) -> 变成指数形式 ->
    # 2^(1 / ln(2)) = e -> 两边同时取 x 次幂 ->
    # e^x = 2^(x / ln(2))
    # 预先将缩放系数乘以 rln2 后即可使用更快的 exp2；反向传播还需补偿该变量替换。

    # 与普通 assert 不同，static_assert 在编译时执行
    tl.static_assert(block_size_kv <= head_dim)
    # 该约束保证 k/v tile 不宽于完整头维。

    # 指示要处理序列长度中的哪个块
    query_block_id = tl.program_id(0)  # 0-D 标量；Q tile 索引。
    # 指示要处理哪个头和批次。每个程序关联单个批次中的单个头
    batch_head_id = tl.program_id(1)  # 0-D 标量；批次和头的合并索引。
    # 指示此程序关联哪个批次（每个批次有 num_heads 个头）
    batch_id = batch_head_id // num_heads  # 0-D 标量；批次索引 [0, B)。
    # 指示该头在批次中的位置
    head_id = batch_head_id % num_heads  # 0-D 标量；头索引 [0, H)。

    # 由于 Q、K、V 和 output 的逻辑形状均为 (B, H, N, D)，因此可以通过
    # 批次和头索引，获得 Q、K、V 和 output 中形状为 (N, D) 的当前头视图。
    q_ptr += batch_id * stride_q_batch + head_id * stride_q_head
    k_ptr += batch_id * stride_k_batch + head_id * stride_k_head
    v_ptr += batch_id * stride_v_batch + head_id * stride_v_head
    output_ptr += batch_id * stride_output_batch + head_id * stride_output_head

    # seq_len 的偏移按 PID 划分，而 head_dim 的完整内容保留在 SRAM 中。
    query_offsets = query_block_id * block_size_qo + tl.arange(0, block_size_qo)  # [BLOCK_SIZE_QO]。
    key_value_offsets = tl.arange(0, block_size_kv)  # [BLOCK_SIZE_KV]。
    head_offsets = tl.arange(0, head_dim)  # [D]。

    # 为每个张量创建专属偏移
    q_offsets = (
        query_offsets[:, None] * stride_q_seq
        + head_offsets[None, :] * stride_q_dim
    )  # [BLOCK_SIZE_QO, D]；Q 偏移。
    # 形状 (block_size_qo, head_dim)
    # 在加载 k 时对其转置（无需另写一个转置内核）
    k_transpose_offsets = (
        head_offsets[:, None] * stride_k_dim
        + key_value_offsets[None, :] * stride_k_seq
    )  # [D, BLOCK_SIZE_KV]；转置 K 偏移。
    # 形状 (head_dim, block_size_kv)
    v_offsets = (
        key_value_offsets[:, None] * stride_v_seq
        + head_offsets[None, :] * stride_v_dim
    )  # [BLOCK_SIZE_KV, D]；V 偏移。
    # 形状 (block_size_kv, head_dim)

    # 加载此 PID 将使用的 q 块；它会在整个内部循环期间保留在 SRAM 中
    query_mask = query_offsets < seq_len  # [BLOCK_SIZE_QO] 布尔掩码。
    q = tl.load(
        q_ptr + q_offsets, mask=query_mask[:, None], other=0.0
    )  # [BLOCK_SIZE_QO, D]。
    # 序列掩码将块中超出 seq_len 的不存在 token 设为零向量

    # 预分配在线 Softmax 状态和输出累加器。
    # 运行中的最大值。当前处理块中的每个查询各有一个条目
    row_max = tl.full(
        shape=[block_size_qo], value=-1e6, dtype=tl.float32
    )  # [BLOCK_SIZE_QO]；在线行最大值。
    # 运行中的总和。每个查询各有一个条目（因为按行汇总注意力分数）
    denominator = tl.full(
        shape=[block_size_qo], value=1.0, dtype=tl.float32
    )  # [BLOCK_SIZE_QO]；在线指数和。
    # 输出累加器，即 output 矩阵中的一组行
    output = tl.zeros([block_size_qo, head_dim], dtype=tl.float32)  # [BLOCK_SIZE_QO, D]。

    # 计算稠密块（掩码全为 1 的块）的注意力。
    # 此步骤处理因果注意力中对角线下方的块
    output, denominator, row_max = _attention_forward_inner(
        q,
        output,
        denominator,
        row_max,
        k_ptr,
        v_ptr,
        k_transpose_offsets,
        v_offsets,
        query_block_id,
        softmax_scale,
        stride_k_seq,
        stride_v_seq,
        block_size_qo,
        block_size_kv,
        False,  # 稠密的严格下三角区域无需逐元素掩码。
        query_offsets,
        key_value_offsets,
        seq_len,
        head_dim,
    )

    # 此步骤处理因果注意力掩码中对角线上的块
    output, denominator, row_max = _attention_forward_inner(
        q,
        output,
        denominator,
        row_max,
        k_ptr,
        v_ptr,
        k_transpose_offsets,
        v_offsets,
        query_block_id,
        softmax_scale,
        stride_k_seq,
        stride_v_seq,
        block_size_qo,
        block_size_kv,
        True,  # 对角块应用逐元素因果掩码。
        query_offsets,
        key_value_offsets,
        seq_len,
        head_dim,
    )

    # 最后除以 softmax 的分母。
    # 注意，已先乘以 v 得到 output，因此这与朴素 softmax 实现的顺序不同
    output = output / denominator[:, None]  # [BLOCK_SIZE_QO, D]；按行归一化。
    # 可按此顺序执行，因为矩阵乘法（_attention_forward_inner 中的 tl.dot）与逐元素除法满足结合律。
    # 矩阵乘法与逐元素操作通常不满足结合律，但在这一粒度下实际是单独的点积。
    # 被掩码的不存在 token 在 output 底部行中是一组无意义值，在 denominator 底部条目中通常约为 seq_len。
    # 前者除以后者不会造成问题，稍后存储时会将它们掩码掉。

    # 反向传播计算 logsumexp (lse) 时需要此值。即不分别保存最大值和总和，
    # 而是将它们合并保存；借助指数运算，这种做法仍然有效
    lse = row_max + tl.math.log2(denominator)  # [BLOCK_SIZE_QO]。
    # denominator 由 _attention_forward_inner() 中的求和和 exp 操作构成
    # 这可行，因为 softmax(x_i) = exp(x_i - m_i) / l_i
    #                                     = exp(x_i - m_i) / exp(log(l_i))
    #                                     = exp(x_i - m_i - log(l_i))
    # 被掩码的不存在 token 在 row_max 底部条目中是一组 0，在 denominator 底部条目中是一组约为 seq_len 的值。
    # 因此它们在 lse 底部会是一些 log_2(seq_len) 条目，当然不会使用。

    # 将 lse 和输出写回 DRAM。
    lse_offsets = batch_head_id * stride_lse_head + query_offsets  # [BLOCK_SIZE_QO]。
    lse_mask = (
        query_block_id * block_size_qo + tl.arange(0, block_size_qo) < seq_len
    )  # [BLOCK_SIZE_QO] 布尔掩码。
    tl.store(
        lse_ptr + lse_offsets, lse, mask=lse_mask
    )  # 保存有效 token 的 lse。
    # 掩码避免保存 lse 底部无用的 log_2(n) 值
    output_offsets = (
        query_offsets[:, None] * stride_output_seq
        + head_offsets[None, :] * stride_output_dim
    )  # [BLOCK_SIZE_QO, D]。
    tl.store(
        output_ptr + output_offsets, output, mask=query_mask[:, None]
    )  # 保存有效输出行。
    # 掩码避免保存 output 底部对应不存在 token 的无用值


@triton.autotune(
    [
        triton.Config(
            {"pre_block_size_row": pre_block_size_row},
            num_stages=num_stages,
            num_warps=num_warps,
        )
        for pre_block_size_row in [32]  # 可继续评估 64、128 和 256。
        for num_stages in [3]  # 可继续评估 5 和 7。
        for num_warps in [4]  # 可继续评估 8 和 16。
    ],
    key=["head_dim"],
)
@triton.jit
def _attention_backward_preprocess(
    output_ptr,
    grad_output_ptr,
    delta_ptr,
    stride_output_batch,
    stride_output_head,
    stride_output_seq,
    stride_output_dim,
    stride_grad_output_batch,
    stride_grad_output_head,
    stride_grad_output_seq,
    stride_grad_output_dim,
    stride_delta_batch,
    stride_delta_head,
    stride_delta_seq,
    seq_len,
    head_dim: tl.constexpr,
    pre_block_size_row: tl.constexpr,
):
    """预计算反向传播共享的 `delta = sum(output * grad_output)`。

    Args:
        output_ptr: 前向输出指针，逻辑形状为 `(B, H, N, D)`。
        grad_output_ptr: 上游输出梯度指针，形状为 `(B, H, N, D)`。
        delta_ptr: Delta 输出指针，形状为 `(B, H, N)`。
        stride_*: 0-D 标量；对应张量在各维度上的元素步幅。
        seq_len: 0-D 标量；序列长度 N。
        head_dim: 0-D 编译期标量；注意力头维度 D。
        pre_block_size_row: 0-D 编译期标量；每个程序处理的 token 数 BLOCK_SIZE_ROW。
    """
    batch_head_id = tl.program_id(1)  # 0-D 标量；合并的批次/头索引。
    row = tl.program_id(0)  # 0-D 标量；序列块索引。

    row_offsets = row * pre_block_size_row + tl.arange(0, pre_block_size_row)  # [BLOCK_SIZE_ROW]。
    column_offsets = tl.arange(0, head_dim)  # [D]。
    mask = row_offsets < seq_len  # [BLOCK_SIZE_ROW] 布尔掩码。

    # 加载 output 的 pre_block_size_row 行
    output_ptr += batch_head_id * stride_output_head  # 移至当前批次和注意力头。
    output_offsets = (
        row_offsets[:, None] * stride_output_seq
        + column_offsets[None, :] * stride_output_dim
    )  # [BLOCK_SIZE_ROW, D]。
    output = tl.load(
        output_ptr + output_offsets, mask=mask[:, None], other=0.0
    )  # [BLOCK_SIZE_ROW, D]。

    # 加载 grad_output 的 pre_block_size_row 行
    grad_output_ptr += batch_head_id * stride_grad_output_head
    grad_output_offsets = (
        row_offsets[:, None] * stride_grad_output_seq
        + column_offsets[None, :] * stride_grad_output_dim
    )  # [BLOCK_SIZE_ROW, D]。
    # grad_output tile 的形状为 [BLOCK_SIZE_ROW, D]。
    grad_output = tl.load(
        grad_output_ptr + grad_output_offsets, mask=mask[:, None], other=0.0
    )  # [BLOCK_SIZE_ROW, D]。

    # delta 是 output 与 grad_output 沿 head_dim 的点积，因此每个 token
    # 对应一个标量。预先计算它可供 grad_q、grad_k 两条路径共同复用。
    # 它将在反向传播的后续部分发挥作用
    delta = tl.sum(
        grad_output.to(tl.float32) * output.to(tl.float32), axis=1
    )  # [BLOCK_SIZE_ROW]；每个 token 一个标量。
    delta_ptr += batch_head_id * stride_delta_head  # 指向当前头，局部逻辑形状为 (N,)。
    tl.store(delta_ptr + row_offsets, delta, mask=mask)


@triton.jit
def _attention_backward_kv(
    k,
    v,
    grad_k,
    grad_v,  # 形状 (block_size_col, D)
    q_ptr,
    grad_output_ptr,
    lse_ptr,
    delta_ptr,
    stride_seq,
    stride_dim,
    num_heads,
    seq_len,
    head_dim: tl.constexpr,
    block_size_row: tl.constexpr,  # 不再使用 _1，因为此子内核就是 _1
    block_size_col: tl.constexpr,
    start_row,
    start_col,
    num_steps,
    scale,
    ln2: tl.constexpr,
    rln2: tl.constexpr,
    apply_mask: tl.constexpr,
):
    r"""计算一个 k/v tile 对应的 grad_k 和 grad_v 部分和。

    此子内核处理 k 和 v 的特定分块，其中将 k 和 v 的序列长度称为
    NxN 注意力矩阵的列，并遍历 q 的序列长度的行，以计算该分块的
    grad_k 和 grad_v。
                         seq_len of k & v
                        |    |   |   |   |
                        |    |   |   |   |
    seq_len of q        |    |   |   |   |
                        |    |   |   |   |
                       \|/  \|/ \|/ \|/ \|/
    箭头表示此 PID 的 for 循环方向；每个箭头对应不同的 PID。

    Args:
        k: 当前 K tile，形状为 `[BLOCK_SIZE_COL, D]`。
        v: 当前 V tile，形状为 `[BLOCK_SIZE_COL, D]`。
        grad_k: K 梯度累加器，形状为 `[BLOCK_SIZE_COL, D]`。
        grad_v: V 梯度累加器，形状为 `[BLOCK_SIZE_COL, D]`。
        q_ptr: 当前注意力头的 Q 指针，局部逻辑形状为 `(N, D)`。
        grad_output_ptr: 当前头的上游梯度指针，局部形状为 `(N, D)`。
        lse_ptr: 前向 LSE 指针，局部形状为 `(N,)`。
        delta_ptr: Delta 指针，局部形状为 `(N,)`。
        stride_seq: 0-D 标量；张量沿序列维的步幅。
        stride_dim: 0-D 标量；张量沿头维的步幅。
        num_heads: 0-D 标量；注意力头数 H。
        seq_len: 0-D 标量；序列长度 N。
        head_dim: 0-D 编译期标量；注意力头维度 D。
        block_size_row: 0-D 编译期标量；每次遍历的 Q 行数 BLOCK_SIZE_ROW。
        block_size_col: 0-D 编译期标量；当前 K/V tile 列数 BLOCK_SIZE_COL。
        start_row: 0-D 标量；首个 Q 行块的起始坐标。
        start_col: 0-D 标量；当前 K/V 列块的起始坐标。
        num_steps: 0-D 标量；需要遍历的 Q 行块数量。
        scale: 0-D 标量；注意力 logits 的缩放系数。
        ln2: 0-D 编译期标量；`ln(2)` 的近似值。
        rln2: 0-D 编译期标量；`1 / ln(2)` 的近似值。
        apply_mask: 0-D 编译期布尔值；是否应用因果掩码。

    Returns:
        更新后的 `grad_k` 和 `grad_v`，形状均为 `[BLOCK_SIZE_COL, D]`。
    """
    row_offsets = start_row + tl.arange(0, block_size_row)  # [BLOCK_SIZE_ROW]。
    column_offsets = start_col + tl.arange(0, block_size_col)  # [BLOCK_SIZE_COL]。
    head_offsets = tl.arange(0, head_dim)  # [D]。

    # 在加载 q 时对其转置，而非使用独立内核
    q_transpose_offsets = (
        head_offsets[:, None] * stride_dim + row_offsets[None, :] * stride_seq
    )  # [D, BLOCK_SIZE_ROW]。
    grad_output_offsets = (
        row_offsets[:, None] * stride_seq + head_offsets[None, :] * stride_dim
    )  # [BLOCK_SIZE_ROW, D]。

    for block_idx in range(num_steps):  # 0-D 标量；当前 Q 块迭代索引。
        # 在计算 scores 前加载 row_max 以减少流水线停顿（计算 grad_v 前也先加载 grad_output）。
        # 这样 Triton 编译器可更轻松地同时加载 row_max 并计算 k 与 QT 的点积。
        # 一般应先加载一批数据再计算一批数据，而非在加载和计算之间来回切换。
        sequence_mask = row_offsets < seq_len  # [BLOCK_SIZE_ROW] 布尔掩码。
        q_transpose = tl.load(
            q_ptr + q_transpose_offsets, mask=sequence_mask[None, :], other=0.0
        )  # [D, BLOCK_SIZE_ROW]。
        lse = tl.load(
            lse_ptr + row_offsets, mask=sequence_mask, other=0.0
        )  # [BLOCK_SIZE_ROW]。
        # grad_output tile 的形状为 [BLOCK_SIZE_ROW, D]。
        grad_output = tl.load(
            grad_output_ptr + grad_output_offsets,
            mask=sequence_mask[:, None],
            other=0.0,
        )  # [BLOCK_SIZE_ROW, D]。
        delta = tl.load(
            delta_ptr + row_offsets, mask=sequence_mask, other=0.0
        )  # [BLOCK_SIZE_ROW]。
        # 注意，加载顺序由下方的使用顺序决定

        # 重新计算 scores 和 probabilities 矩阵的转置，因为这样更快；更重要的是，
        # 比在前向传播中保存它们并在此读取更节省内存。
        scores_transpose = tl.dot(
            k, q_transpose
        )  # [BLOCK_SIZE_COL, BLOCK_SIZE_ROW]。
        # 此处无需缩放，因为运算满足结合律，已提前在 k 上完成
        # 得益于 k 和 q_transpose 的掩码，越界的不存在 token 在 scores_transpose 底边和右边呈现为一组零。
        # 从 scores_transpose 中减去 logsumexp，再取指数以获得 probabilities_transpose
        probabilities_transpose = tl.exp2(
            scores_transpose - lse[None, :]
        )  # [BLOCK_SIZE_COL, BLOCK_SIZE_ROW]。
        # 此导数实际还需额外乘以 ln(2)，下方会在 grad_score_transpose 处完成
        # 原先为一组 0 的不存在 token 现在变为一组 1

        if apply_mask:  # 对角块需要因果掩码。
            # 实现下三角掩码。因已转置，它看起来像上三角；这也是列和行反转的原因。
            mask = (
                column_offsets[:, None] <= row_offsets[None, :]
            )  # [BLOCK_SIZE_COL, BLOCK_SIZE_ROW] 布尔掩码。
            probabilities_transpose = tl.where(
                mask, probabilities_transpose, 0.0
            )

        # 计算 grad_v
        grad_v = tl.dot(
            probabilities_transpose, grad_output, acc=grad_v
        )  # [BLOCK_SIZE_COL, D]。

        # 计算 grad_probability_transpose 和 grad_score_transpose 以获得 grad_k
        grad_probability_transpose = tl.dot(
            v, tl.trans(grad_output)
        )  # [BLOCK_SIZE_COL, BLOCK_SIZE_ROW]。
        grad_score_transpose = (
            probabilities_transpose
            * (grad_probability_transpose - delta[None, :])
            * ln2
        )  # [BLOCK_SIZE_COL, BLOCK_SIZE_ROW]；Softmax logits 梯度。
        grad_k = tl.dot(
            grad_score_transpose, tl.trans(q_transpose), acc=grad_k
        )  # 累加当前 q 块的贡献。
        # acc 告知 tl.dot 将结果累加到 grad_k 中

        # 递增指针
        row_offsets += block_size_row
        q_ptr += block_size_row * stride_seq
        grad_output_ptr += block_size_row * stride_seq

    return grad_k, grad_v


@triton.jit
def _attention_backward_q(
    grad_q,
    q,
    grad_output,
    lse,
    k_ptr,
    v_ptr,
    delta_ptr,
    stride_seq,
    stride_dim,
    num_heads,
    seq_len,
    head_dim: tl.constexpr,
    block_size_row: tl.constexpr,
    block_size_col: tl.constexpr,
    start_row,
    start_col,
    num_steps,
    scale,
    ln2: tl.constexpr,
    rln2: tl.constexpr,
    apply_mask: tl.constexpr,
):
    """计算一个 q tile 对应的 grad_q 部分和。

    此子内核处理 q 的特定分块，并遍历 k 和 v 的行以计算对应分块的 grad_q。
    我称 k 和 v 的“行”，但实际上将它们称为列，因为这里考虑的不是形状为
    `(batch_size, num_heads, seq_len, head_dim)` 的输入，而是形状为
    `(batch_size, num_heads, seq_len, seq_len)` 的注意力 logits；其中第一个
    `seq_len`
    按 "block_size_row" 划分，第二个 seq_len 按 "block_size_col" 划分。
                          seq_len of k & v
                        ------------------->
                        ------------------->
    seq_len of q        ------------------->
                        ------------------->
                        ------------------->
    箭头表示此 PID 的 for 循环方向；每个箭头对应不同的 PID。

    Args:
        grad_q: Q 梯度累加器，形状为 `[BLOCK_SIZE_ROW, D]`。
        q: 当前 Q tile，形状为 `[BLOCK_SIZE_ROW, D]`。
        grad_output: 当前 Q tile 的上游梯度，形状为 `[BLOCK_SIZE_ROW, D]`。
        lse: 当前 Q tile 的 log-sum-exp，形状为 `[BLOCK_SIZE_ROW, 1]`。
        k_ptr: 当前注意力头的 K 指针，局部逻辑形状为 `(N, D)`。
        v_ptr: 当前注意力头的 V 指针，局部逻辑形状为 `(N, D)`。
        delta_ptr: Delta 指针，局部逻辑形状为 `(N,)`。
        stride_seq: 0-D 标量；张量沿序列维的步幅。
        stride_dim: 0-D 标量；张量沿头维的步幅。
        num_heads: 0-D 标量；注意力头数 H。
        seq_len: 0-D 标量；序列长度 N。
        head_dim: 0-D 编译期标量；注意力头维度 D。
        block_size_row: 0-D 编译期标量；当前 Q tile 行数 BLOCK_SIZE_ROW。
        block_size_col: 0-D 编译期标量；每次遍历的 K/V 列数 BLOCK_SIZE_COL。
        start_row: 0-D 标量；当前 Q 行块的起始坐标。
        start_col: 0-D 标量；首个 K/V 列块的起始坐标。
        num_steps: 0-D 标量；需要遍历的 K/V 列块数量。
        scale: 0-D 标量；注意力 logits 的缩放系数。
        ln2: 0-D 编译期标量；`ln(2)` 的近似值。
        rln2: 0-D 编译期标量；`1 / ln(2)` 的近似值。
        apply_mask: 0-D 编译期布尔值；是否应用因果掩码。

    Returns:
        更新后的 `grad_q`，形状为 `[BLOCK_SIZE_ROW, D]`。
    """
    row_offsets = start_row + tl.arange(0, block_size_row)  # [BLOCK_SIZE_ROW]。
    column_offsets = start_col + tl.arange(0, block_size_col)  # [BLOCK_SIZE_COL]。
    head_offsets = tl.arange(0, head_dim)  # [D]。

    # 在加载 v 时对其转置
    key_value_transpose_offsets = (
        head_offsets[:, None] * stride_dim
        + column_offsets[None, :] * stride_seq
    )  # [D, BLOCK_SIZE_COL]。

    delta = tl.load(
        delta_ptr + row_offsets, mask=row_offsets < seq_len, other=0.0
    )  # [BLOCK_SIZE_ROW]。

    for block_idx in range(num_steps):  # 0-D 标量；当前 K/V 块迭代索引。
        k_transpose = tl.load(
            k_ptr + key_value_transpose_offsets,
            mask=(column_offsets < seq_len)[None, :],
            other=0.0,
        )
        # k_transpose：[D, BLOCK_SIZE_COL]。
        v_transpose = tl.load(
            v_ptr + key_value_transpose_offsets,
            mask=(column_offsets < seq_len)[None, :],
            other=0.0,
        )
        # v_transpose：[D, BLOCK_SIZE_COL]。

        scores = tl.dot(
            q, k_transpose
        )  # [BLOCK_SIZE_ROW, BLOCK_SIZE_COL]。
        # 此处无需缩放，因为运算满足结合律，已提前在 q 上完成
        probabilities = tl.exp2(scores - lse)  # [BLOCK_SIZE_ROW, BLOCK_SIZE_COL]。

        if apply_mask:  # 对角块需要因果掩码。
            mask = (
                row_offsets[:, None] >= column_offsets[None, :]
            )  # [BLOCK_SIZE_ROW, BLOCK_SIZE_COL] 布尔掩码。
            # 梯度为上三角，因此将下三角值设为零
            probabilities = tl.where(
                mask, probabilities, 0.0
            )  # 屏蔽未来 token 的概率。

        # 计算 grad_probability 和 grad_score 以获得 grad_q
        grad_probability = tl.dot(
            grad_output, v_transpose
        )  # [BLOCK_SIZE_ROW, BLOCK_SIZE_COL]。
        grad_score = (
            probabilities * (grad_probability - delta[:, None]) * ln2
        )  # [BLOCK_SIZE_ROW, BLOCK_SIZE_COL]；Softmax logits 梯度。
        # 此行等价于：
        # weighted_grad_probability = tl.sum(
        #     grad_probability * probabilities, axis=1
        # )
        # grad_score = probabilities * (
        #     grad_probability - weighted_grad_probability[:, None]
        # )
        # 但以一次内存访问换取二元运算和规约操作
        grad_q += tl.dot(
            grad_score, tl.trans(k_transpose)
        )  # 累加当前 k 块的贡献。
        # 最终需要对 grad_q 反缩放，因为 k_transpose 已预缩放
        # 稍后再做而非现在做，因为现在做需要 num_steps * flops，而稍后只需 flops

        # 递增指针
        column_offsets += block_size_col
        k_ptr += block_size_col * stride_seq
        v_ptr += block_size_col * stride_seq

    return grad_q


@triton.autotune(
    [
        triton.Config(
            {
                "block_size_macro": block_size_macro,
                "block_size_micro": block_size_micro,
            },
            num_stages=num_stages,
            num_warps=num_warps,
        )
        for block_size_micro in [16]  # 可继续评估 32 和 64。
        for block_size_macro in [32]  # 可继续评估 64 和 128。
        for num_stages in [3]  # 可继续评估 5 和 7。
        for num_warps in [4]  # 可继续评估 8 和 16。
        if block_size_macro > block_size_micro  # 保证宏块包含多个微块。
    ],
    key=["head_dim"],
)
@triton.jit
def attention_backward(
    q_ptr,
    k_ptr,
    v_ptr,
    grad_output_ptr,
    grad_q_ptr,
    grad_k_ptr,
    grad_v_ptr,
    lse_ptr,
    delta_ptr,
    scale,
    stride_batch,
    stride_head,
    stride_seq,
    stride_dim,
    num_heads,
    seq_len,
    head_dim: tl.constexpr,
    block_size_micro: tl.constexpr,  #
    block_size_macro: tl.constexpr,  #
):
    """分两个阶段计算因果注意力的 grad_k、grad_v 和 grad_q。

    第一阶段固定 k/v 宏块并遍历 q 微块，第二阶段固定 q 宏块并遍历 k/v
    微块。两个阶段都先处理需要因果掩码的对角块，再处理稠密块。

    Args:
        q_ptr: 前向 Q 指针，逻辑形状为 `(B, H, N, D)`。
        k_ptr: 前向 K 指针，逻辑形状为 `(B, H, N, D)`。
        v_ptr: 前向 V 指针，逻辑形状为 `(B, H, N, D)`。
        grad_output_ptr: 上游梯度指针，形状为 `(B, H, N, D)`。
        grad_q_ptr: Q 梯度输出指针，形状为 `(B, H, N, D)`。
        grad_k_ptr: K 梯度输出指针，形状为 `(B, H, N, D)`。
        grad_v_ptr: V 梯度输出指针，形状为 `(B, H, N, D)`。
        lse_ptr: 前向 LSE 指针，形状为 `(B, H, N)`。
        delta_ptr: Delta 指针，形状为 `(B, H, N)`。
        scale: 0-D 标量；注意力 logits 的缩放系数。
        stride_batch: 0-D 标量；批次步幅。
        stride_head: 0-D 标量；注意力头步幅。
        stride_seq: 0-D 标量；序列步幅。
        stride_dim: 0-D 标量；头维步幅。
        num_heads: 0-D 标量；注意力头数 H。
        seq_len: 0-D 标量；序列长度 N。
        head_dim: 0-D 编译期标量；注意力头维度 D。
        block_size_micro: 0-D 编译期标量；内层序列块大小 BLOCK_SIZE_MICRO。
        block_size_macro: 0-D 编译期标量；每个程序负责的块大小 BLOCK_SIZE_MACRO。
    """
    # 稍后会在 q 上使用这些常量
    ln2: tl.constexpr = 0.6931471824645996  # 0-D 编译期标量；= ln(2)。
    rln2: tl.constexpr = 1.4426950408889634  # 0-D 编译期标量；= 1 / ln(2)。
    # 通常将已知常量定义为其若干位数字的近似值，
    # 比每次计算实际值更高效

    # 移动 (batch_size, num_heads, seq_len, D) 矩阵的指针，以定位到正确的批次和头
    batch_head_id = tl.program_id(1)  # 0-D 标量；合并的批次/头索引。
    batch_id = batch_head_id // num_heads  # 0-D 标量；批次索引。
    head_id = batch_head_id % num_heads  # 0-D 标量；头索引。
    batch_head_jump = batch_id * stride_batch + head_id * stride_head  # 0-D 标量；指针偏移。
    q_ptr += batch_head_jump
    k_ptr += batch_head_jump
    v_ptr += batch_head_jump
    grad_output_ptr += batch_head_jump
    grad_q_ptr += batch_head_jump
    grad_k_ptr += batch_head_jump
    grad_v_ptr += batch_head_jump

    # 移动 (batch_size, num_heads, seq_len) 矩阵的指针，以定位到正确的批次和头
    batch_head_jump = batch_head_id * seq_len  # 0-D 标量；LSE/Delta 指针偏移。
    lse_ptr += batch_head_jump
    delta_ptr += batch_head_jump

    # block_size_macro 必须是 block_size_micro 的倍数，
    # 因为用它们确定 num_steps，且不希望有余数
    tl.static_assert(block_size_macro % block_size_micro == 0)

    # 阶段 1：计算 grad_k 和 grad_v。
    # 在前向循环中，我们将一块 q 保留在 SRAM 中并遍历 k 和 v；此处执行相反操作

    # ROW 和 COL 分别指 (q 和 output) 与 (k 和 v) 的 seq_len 维
    # 对阶段 1，每个 PID 将处理 k 和 v 的 block_size_macro 个 token，并有一个
    # 每次遍历 q 的 block_size_micro 个 token 的内部 for 循环
    block_size_row_1: tl.constexpr = block_size_micro  # 0-D 编译期标量。
    block_size_col_1: tl.constexpr = block_size_macro  # 0-D 编译期标量。

    # 先计算块对角线上的梯度，因为它们的处理方式不同，
    # 即具有三角形因果掩码
    pid = tl.program_id(0)  # 0-D 标量；当前宏块索引。
    start_col = pid * block_size_col_1  # 0-D 标量；列块起点。
    start_row = start_col  # 0-D 标量；对角线行块起点。
    num_steps = block_size_col_1 // block_size_row_1  # 0-D 标量；微块数量。

    # 加载 k 和 v
    column_offsets_1 = start_col + tl.arange(0, block_size_col_1)  # [BLOCK_SIZE_MACRO]。
    head_offsets = tl.arange(0, head_dim)  # [D]。
    key_value_offsets = (
        column_offsets_1[:, None] * stride_seq
        + head_offsets[None, :] * stride_dim
    )  # [BLOCK_SIZE_MACRO, D]。
    key_value_mask = column_offsets_1[:, None] < seq_len  # [BLOCK_SIZE_MACRO, 1] 布尔掩码。
    k = tl.load(
        k_ptr + key_value_offsets, mask=key_value_mask, other=0.0
    )  # [BLOCK_SIZE_MACRO, D]。
    v = tl.load(
        v_ptr + key_value_offsets, mask=key_value_mask, other=0.0
    )  # [BLOCK_SIZE_MACRO, D]。

    # 预缩放 k 使我们只需在此乘一次，而非在 _attention_backward_kv 中乘 num_steps 次。
    # 还会乘以 rln2 以考虑 tl.exp2() 的导数；出于同一原因，
    # 在此处完成而非在 _attention_backward_kv 内部完成。
    k *= scale * rln2

    # 将梯度累加到这些张量中
    grad_k = tl.zeros([block_size_col_1, head_dim], dtype=tl.float32)  # [BLOCK_SIZE_MACRO, D]。
    grad_v = tl.zeros([block_size_col_1, head_dim], dtype=tl.float32)  # [BLOCK_SIZE_MACRO, D]。

    # 计算块化对角线上的 grad_k 和 grad_v 部分
    grad_k, grad_v = _attention_backward_kv(
        k,
        v,
        grad_k,
        grad_v,
        q_ptr,
        grad_output_ptr,
        lse_ptr,
        delta_ptr,
        stride_seq,
        stride_dim,
        num_heads,
        seq_len,
        head_dim,
        block_size_row_1,
        block_size_col_1,
        start_row,
        start_col,
        num_steps,
        scale,
        ln2,
        rln2,
        apply_mask=True,
    )

    # 接下来处理块对角线上不需要三角形掩码的所有块。
    # 这会使我们向前移动以离开块对角线。
    start_row += block_size_col_1  # 0-D 标量；移动到下一行块。
    # start_col 不变，因为它由 PID 确定
    # 然后计算需要处理多少块。
    # 对 seq_len 的此调整处理序列长度不是 block_size_col_1 整数倍的情况
    padded_seq_len = tl.cdiv(seq_len, block_size_col_1) * block_size_col_1  # 0-D 标量。
    num_steps = (padded_seq_len - start_row) // block_size_row_1  # 0-D 标量。

    # 计算未掩码块的 grad_k 和 grad_v
    grad_k, grad_v = _attention_backward_kv(
        k,
        v,
        grad_k,
        grad_v,
        q_ptr,
        grad_output_ptr,
        lse_ptr,
        delta_ptr,
        stride_seq,
        stride_dim,
        num_heads,
        seq_len,
        head_dim,
        block_size_row_1,
        block_size_col_1,
        start_row,
        start_col,
        num_steps,
        scale,
        ln2,
        rln2,
        apply_mask=False,
    )

    # 进行缩放；为节省 flops，未在 _attention_backward_kv 内部完成此操作
    grad_k *= scale * rln2
    # 写回 grad_k 和 grad_v
    tl.store(grad_k_ptr + key_value_offsets, grad_k, mask=key_value_mask)
    tl.store(grad_v_ptr + key_value_offsets, grad_v, mask=key_value_mask)

    # 阶段 2：计算 grad_q。
    # 此部分与前向传播类似，处理 q 的特定块并遍历 k 和 v

    # ROW 和 COL 分别指 q 和 k/v 的 seq_len 维
    # 对阶段 2，每个 PID 将处理 k 和 v 的 block_size_macro 个 token，
    # 并有一个遍历 q 的 block_size_micro 个 token 的内部 for 循环
    block_size_row_2: tl.constexpr = block_size_macro  # 0-D 编译期标量。
    block_size_col_2: tl.constexpr = block_size_micro  # 0-D 编译期标量。

    # 再次从处理块对角线开始
    start_row = pid * block_size_row_2  # 0-D 标量；Q 行块起点。
    start_col = start_row  # 0-D 标量；对角 K/V 列块起点。
    num_steps = block_size_row_2 // block_size_col_2  # 0-D 标量；微块数量。
    # 这是单个块的步数，即对角线上的块

    row_offsets = start_row + tl.arange(0, block_size_row_2)  # [BLOCK_SIZE_MACRO]。
    query_output_offsets = (
        row_offsets[:, None] * stride_seq + head_offsets[None, :] * stride_dim
    )  # [BLOCK_SIZE_MACRO, D]。
    row_mask = row_offsets < seq_len  # [BLOCK_SIZE_MACRO] 布尔掩码。
    q = tl.load(
        q_ptr + query_output_offsets, mask=row_mask[:, None], other=0.0
    )  # [BLOCK_SIZE_MACRO, D]。
    q *= scale * rln2
    # grad_output tile 的形状为 [BLOCK_SIZE_MACRO, D]。
    grad_output = tl.load(
        grad_output_ptr + query_output_offsets,
        mask=row_mask[:, None],
        other=0.0,
    )  # [BLOCK_SIZE_MACRO, D]。
    lse = tl.load(lse_ptr + row_offsets, mask=row_mask, other=0.0)[
        :, None
    ]  # [BLOCK_SIZE_MACRO, 1]。

    # 将梯度累加到这里
    grad_q = tl.zeros([block_size_row_2, head_dim], dtype=tl.float32)  # [BLOCK_SIZE_MACRO, D]。

    # 计算对角块对 grad_q 的贡献。
    grad_q = _attention_backward_q(
        grad_q,
        q,
        grad_output,
        lse,
        k_ptr,
        v_ptr,
        delta_ptr,
        stride_seq,
        stride_dim,
        num_heads,
        seq_len,
        head_dim,
        block_size_row_2,
        block_size_col_2,
        start_row,
        start_col,
        num_steps,
        scale,
        ln2,
        rln2,
        apply_mask=True,
    )

    # 现在处理不在块对角线上的部分
    end_col = start_col  # 0-D 标量；对角 K/V 块结束坐标。
    # 非对角部分始终从首个 k/v tile 开始。
    start_col = 0  # 0-D 标量；非对角区域从第一个 K/V 块开始。
    num_steps = end_col // block_size_col_2  # 0-D 标量；非对角微块数量。
    grad_q = _attention_backward_q(
        grad_q,
        q,
        grad_output,
        lse,
        k_ptr,
        v_ptr,
        delta_ptr,
        stride_seq,
        stride_dim,
        num_heads,
        seq_len,
        head_dim,
        block_size_row_2,
        block_size_col_2,
        start_row,
        start_col,
        num_steps,
        scale,
        ln2,
        rln2,
        apply_mask=False,
    )
    grad_q *= scale * rln2
    tl.store(grad_q_ptr + query_output_offsets, grad_q, mask=row_mask[:, None])


class _FlashAttention(torch.autograd.Function):
    """将因果 FlashAttention 内核接入 PyTorch Autograd。"""

    @staticmethod
    def forward(ctx, q, k, v, scale):
        """计算因果注意力，并保存反向传播需要的中间结果。

        Args:
            ctx: PyTorch 提供的 Autograd 上下文。
            q: FP32 查询张量，形状为 `(B, H, N, D)`。
            k: FP32 键张量，形状为 `(B, H, N, D)`。
            v: FP32 值张量，形状为 `(B, H, N, D)`。
            scale: 0-D 标量；注意力 logits 的缩放系数。

        Returns:
            与 `q` 形状和 dtype 相同的因果注意力输出。

        Raises:
            AssertionError: 如果输入形状、设备、dtype 不一致，或 `head_dim > 128`。
        """
        assert q.shape == k.shape == v.shape
        assert q.shape[-1] <= 128, (
            "flash attention only supports head dimension of 128 less but got "
            f"{q.shape[-1]}"
        )
        # 限制头维可避免单个程序耗尽 SRAM。
        batch_size, num_heads, seq_len, head_dim = q.shape  # 4 个 0-D 标量：B、H、N、D。
        assert q.device == k.device and q.device == v.device
        assert q.dtype == k.dtype == v.dtype == torch.float32

        # 预分配输出张量
        output = torch.empty_like(q)  # (B, H, N, D)。
        # 同时预分配存储 logsumexp 的张量
        lse = torch.empty(  # (B, H, N)。
            (batch_size, num_heads, seq_len),
            device=q.device,
            dtype=torch.float32,
        )


        def forward_grid(meta):
            r"""构造按查询块、批次和注意力头划分的启动网格。"""
            return (
                # 二维启动网格：[ceil(N / BLOCK_QO), B * H]。
                # 序列有 seq_len 个 token，而每个程序一次能处理的 query token 数为 block_size_qo。
                triton.cdiv(seq_len, meta["block_size_qo"]),
                # 批次和注意力头完全独立，不共享数据，因此合并到第二维。
                batch_size * num_heads,
            )
        r"""假设只有 3 个 SM，PID 维度为 (3, 2)，则：
            [0, 0] 和 [1, 0] 在 SM0 上运行;
            [2, 0] 和 [0, 1] 在 SM1 上运行;
            [1, 1] 和 [2, 1] 在 SM2 上运行。
        即 PID 按照第一维的顺序分配给 SM，而第二维的 PID 仅在第一维的 PID 分配完后才分配给 SM。
        """

        attention_forward[forward_grid](
            q,
            k,
            v,
            output,
            lse,
            scale,
            q.stride(0),
            q.stride(1),
            q.stride(2),
            q.stride(3),
            k.stride(0),
            k.stride(1),
            k.stride(2),
            k.stride(3),
            v.stride(0),
            v.stride(1),
            v.stride(2),
            v.stride(3),
            output.stride(0),
            output.stride(1),
            output.stride(2),
            output.stride(3),
            lse.stride(0),
            lse.stride(1),
            lse.stride(2),
            batch_size,
            num_heads,
            seq_len,
            head_dim,
        )

        ctx.save_for_backward(q, k, v, output, lse)
        ctx.batch_size, ctx.num_heads, ctx.seq_len, ctx.head_dim = (  # 4 个 0-D 元数据标量。
            batch_size,
            num_heads,
            seq_len,
            head_dim,
        )
        ctx.scale = scale
        return output

    @staticmethod
    def backward(ctx, grad_output):
        """计算损失相对于 q、k 和 v 的梯度。

        Args:
            ctx: 前向传播保存的 Autograd 上下文。
            grad_output: 损失相对于注意力输出的梯度，形状为 `(B, H, N, D)`。

        Returns:
            `(grad_q, grad_k, grad_v, None)`，其中 `scale` 不计算梯度。
        """
        q, k, v, output, lse = ctx.saved_tensors  # 4 个 (B, H, N, D)，以及 lse (B, H, N)。
        scale = ctx.scale  # 0-D 元数据标量。
        batch_size, num_heads, seq_len, head_dim = (  # 4 个 0-D 元数据标量：B、H、N、D。
            ctx.batch_size,
            ctx.num_heads,
            ctx.seq_len,
            ctx.head_dim,
        )

        grad_q = torch.empty_like(q)  # (B, H, N, D)。
        grad_k = torch.empty_like(k)  # (B, H, N, D)。
        grad_v = torch.empty_like(v)  # (B, H, N, D)。

        grad_output = grad_output.contiguous()  # (B, H, N, D)。
        assert (
            q.stride()
            == k.stride()
            == v.stride()
            == output.stride()
            == grad_output.stride()
        )

        delta = torch.empty_like(lse)  # (B, H, N)。

        # 网格的顺序很重要，因为它决定哪些程序最终共享同一块 SRAM
        def preprocess_grid(meta):
            """构造 Delta 预处理内核的二维启动网格。"""
            return (  # 二维启动网格：[ceil(N / BLOCK_ROW), B * H]。
                triton.cdiv(seq_len, meta["pre_block_size_row"]),
                batch_size * num_heads,
            )

        # 此处希望沿 seq_len 维的并行任务彼此接近以共享数据，
        # 而跨批次和头的并行任务无需共享数据
        _attention_backward_preprocess[preprocess_grid](
            output,
            grad_output,
            delta,
            output.stride(0),
            output.stride(1),
            output.stride(2),
            output.stride(3),
            grad_output.stride(0),
            grad_output.stride(1),
            grad_output.stride(2),
            grad_output.stride(3),
            delta.stride(0),
            delta.stride(1),
            delta.stride(2),
            seq_len,
            head_dim,
        )

        def backward_grid(meta):
            """构造主反向内核的二维启动网格。"""
            return (  # 二维启动网格：[ceil(N / BLOCK_MACRO), B * H]。
                triton.cdiv(seq_len, meta["block_size_macro"]),
                batch_size * num_heads,
            )

        attention_backward[backward_grid](
            q,
            k,
            v,
            grad_output,
            grad_q,
            grad_k,
            grad_v,
            lse,
            delta,
            scale,
            q.stride(0),
            q.stride(1),
            q.stride(2),
            q.stride(3),  # 所有张量使用相同步幅。
            num_heads,
            seq_len,
            head_dim,
        )

        return grad_q, grad_k, grad_v, None


triton_attention = _FlashAttention.apply  # 输入/输出均为 (B, H, N, D)。


# 步骤 1：数值测试。
def test_flash_attention_kernel(
    batch_size, num_heads, seq_len, head_dim, device=DEVICE, atol=5e-3
):
    """比较 Triton 与 PyTorch 因果注意力的前向结果和全部梯度。

    Args:
        batch_size: 0-D 标量；批次大小 B。
        num_heads: 0-D 标量；注意力头数 H。
        seq_len: 0-D 标量；序列长度 N。
        head_dim: 0-D 标量；注意力头维度 D。
        device: 0-D/设备元数据。
        atol: 0-D 标量；比较结果的绝对误差阈值。
    """
    q = torch.randn(  # (B, H, N, D)。
        (batch_size, num_heads, seq_len, head_dim),
        dtype=torch.float32,
        device=device,
        requires_grad=True,
    )
    k = torch.randn(  # (B, H, N, D)。
        (batch_size, num_heads, seq_len, head_dim),
        dtype=torch.float32,
        device=device,
        requires_grad=True,
    )
    v = torch.randn(  # (B, H, N, D)。
        (batch_size, num_heads, seq_len, head_dim),
        dtype=torch.float32,
        device=device,
        requires_grad=True,
    )
    # 标准的 1/sqrt(head_dim) 缩放可控制点积 logits 的方差。
    softmax_scale = 1 / math.sqrt(head_dim)  # 0-D 标量。
    triton_output = triton_attention(q, k, v, softmax_scale)  # (B, H, N, D)。
    reference_output = torch.nn.functional.scaled_dot_product_attention(  # (B, H, N, D)。
        q, k, v, is_causal=True
    )


    # 如需直观分析误差模式，可以取消下面代码的注释
    # import os
    # import numpy as np
    # import matplotlib.pyplot as plt
    # # 转换为 NumPy 数组
    # actual = triton_output.detach().cpu().numpy()  # (B, H, N, D) NumPy 数组。
    # expected = reference_output.detach().cpu().numpy()  # (B, H, N, D) NumPy 数组。
    # # 计算差异和掩码
    # abs_diff = np.abs(expected - actual)  # (B, H, N, D)。
    # abs_fail_mask = (abs_diff > 1e-2).astype(np.int32)  # (B, H, N, D)。
    # plt.figure(figsize=(8, 6))
    # plt.imshow(abs_fail_mask[0][0], cmap="hot", aspect="auto")
    # plt.xlabel("Model/Head Dimension")
    # plt.ylabel("Sequence Position")
    # plt.colorbar()
    # plt.savefig('./out_heatmap.png')
    # plt.close()


    # 比较
    torch.testing.assert_close(
        triton_output, reference_output, atol=atol, rtol=0
    )
    print("passed fwd")

    # 反向传播（Triton）
    grad_output = 0.1 * torch.randn_like(q)  # (B, H, N, D)。
    triton_output.backward(grad_output, retain_graph=True)
    grad_q_triton, grad_k_triton, grad_v_triton = [  # 3 个 (B, H, N, D)。
        _.grad.clone() for _ in [q, k, v]
    ]
    q.grad, k.grad, v.grad = None, None, None
    # 反向传播（PyTorch）
    reference_output.backward(grad_output, retain_graph=True)
    grad_q_reference, grad_k_reference, grad_v_reference = [  # 3 个 (B, H, N, D)。
        _.grad.clone() for _ in [q, k, v]
    ]
    q.grad, k.grad, v.grad = None, None, None

    """
    # 如需直观分析误差模式，可以取消下面代码的注释
    import os
    import numpy as np
    import matplotlib.pyplot as plt
    # grad_q 转换为 NumPy 数组
    actual = grad_q_reference.detach().cpu().numpy()  # (B, H, N, D)。
    expected = grad_q_triton.detach().cpu().numpy()  # (B, H, N, D)。
    # 计算差异和掩码
    abs_diff = np.abs(expected - actual)  # (B, H, N, D)。
    abs_fail_mask = (abs_diff > atol).astype(np.int32)  # (B, H, N, D)。
    plt.figure(figsize=(8, 6))
    plt.imshow(abs_fail_mask[0][0], cmap="hot", aspect="auto")
    plt.xlabel("Model/Head Dimension")
    plt.ylabel("Sequence Position")
    plt.colorbar()
    plt.savefig('./dLdq_out_heatmap.png')
    plt.close()
    # grad_k 转换为 NumPy 数组
    actual = grad_k_reference.detach().cpu().numpy()  # (B, H, N, D)。
    expected = grad_k_triton.detach().cpu().numpy()  # (B, H, N, D)。
    # 计算差异和掩码
    abs_diff = np.abs(expected - actual)  # (B, H, N, D)。
    abs_fail_mask = (abs_diff > atol).astype(np.int32)  # (B, H, N, D)。
    plt.figure(figsize=(8, 6))
    plt.imshow(abs_fail_mask[0][0], cmap="hot", aspect="auto")
    plt.xlabel("Model/Head Dimension")
    plt.ylabel("Sequence Position")
    plt.colorbar()
    plt.savefig('./dLdk_out_heatmap.png')
    plt.close()
    # grad_v 转换为 NumPy 数组
    actual = grad_v_reference.detach().cpu().numpy()  # (B, H, N, D)。
    expected = grad_v_triton.detach().cpu().numpy()  # (B, H, N, D)。
    # 计算差异和掩码
    abs_diff = np.abs(expected - actual)  # (B, H, N, D)。
    abs_fail_mask = (abs_diff > atol).astype(np.int32)  # (B, H, N, D)。
    plt.figure(figsize=(8, 6))
    plt.imshow(abs_fail_mask[0][0], cmap="hot", aspect="auto")
    plt.xlabel("Model/Head Dimension")
    plt.ylabel("Sequence Position")
    plt.colorbar()
    plt.savefig('./dLdv_out_heatmap.png')
    plt.close()
    """

    # 比较
    torch.testing.assert_close(
        grad_q_triton, grad_q_reference, atol=atol, rtol=0
    )
    torch.testing.assert_close(
        grad_k_triton, grad_k_reference, atol=atol, rtol=0
    )
    torch.testing.assert_close(
        grad_v_triton, grad_v_reference, atol=atol, rtol=0
    )
    print("Passed bwd")


# 在固定批次、头数和头维时改变序列长度。
_BENCHMARK_CONFIGS = []  # [2]；两个基准模式的配置列表。
for mode in ["fwd", "bwd"]:  # 字符串元数据；当前基准模式。
    _BENCHMARK_CONFIGS.append(
        triton.testing.Benchmark(
            x_names=["seq_len"],
            x_vals=[512 * i for i in range(1, 17)],  # 显存不足时应缩小范围。
            line_arg="provider",
            line_vals=["torch", "this_tutorial"],
            line_names=[
                "torch.nn.functional.scaled_dot_product_attention",
                "This tutorial's implementation",
            ],
            styles=[("red", "-"), ("blue", "-")],
            ylabel="TFLOPS",
            plot_name=f"attention-performance-{mode}",
            args={"mode": mode},
        )
    )


@triton.testing.perf_report(_BENCHMARK_CONFIGS)
def bench_flash_attention(seq_len, mode, provider, device=DEVICE):
    """测量 PyTorch 或 Triton 因果注意力的前向或反向吞吐量。

    Args:
        seq_len: 0-D 标量；序列长度 N。
        mode: 0-D/字符串元数据；`fwd` 或 `bwd`。
        provider: 0-D/字符串元数据；参考实现名称。
        device: 0-D/设备元数据。
    """
    assert mode in ["fwd", "bwd"]
    dtype = torch.float32  # 类型元数据。
    batch_size, num_heads = 32, 4  # 2 个 0-D 标量：B、H。
    head_dim = 128  # 0-D 标量；头维 D。
    q = torch.randn(  # (B, H, N, D)。
        (batch_size, num_heads, seq_len, head_dim),
        dtype=dtype,
        device=device,
        requires_grad=True,
    )
    k = torch.randn(  # (B, H, N, D)。
        (batch_size, num_heads, seq_len, head_dim),
        dtype=dtype,
        device=device,
        requires_grad=True,
    )
    v = torch.randn(  # (B, H, N, D)。
        (batch_size, num_heads, seq_len, head_dim),
        dtype=dtype,
        device=device,
        requires_grad=True,
    )
    softmax_scale = 1 / math.sqrt(head_dim)  # 0-D 标量。
    if provider == "torch":

        def run_forward():
            """运行 PyTorch 参考前向传播。"""
            return torch.nn.functional.scaled_dot_product_attention(
                q, k, v, is_causal=True
            )

    if provider == "this_tutorial":

        def run_forward():
            """运行 Triton 前向传播。"""
            return triton_attention(q, k, v, softmax_scale)

    if mode == "bwd":
        output = run_forward()  # (B, H, N, D)。
        grad_output = torch.randn_like(output)  # (B, H, N, D)。

        def run_benchmark():
            """运行反向传播基准回调。"""
            return output.backward(grad_output, retain_graph=True)

    else:
        run_benchmark = run_forward
    ms = triton.testing.do_bench(run_benchmark)  # 0-D 标量；毫秒耗时。
    flops_per_matmul = (  # 0-D 标量；一次矩阵乘法 FLOP 数。
        2.0 * batch_size * num_heads * seq_len * seq_len * head_dim
    )
    total_flops = 2 * flops_per_matmul * 0.5  # 0-D 标量；总 FLOP 数。
    if mode == "bwd":
        total_flops *= 2.5  # 2.0(bwd) + 0.5(recompute)
    return total_flops * 1e-12 / (ms * 1e-3)


def main():
    """运行数值测试，并按需运行性能基准。"""
    test_flash_attention_kernel(1, 1, 128, 32)  # 序列长度可整除块大小。
    test_flash_attention_kernel(1, 1, 128, 64)  # 序列长度可整除块大小。
    test_flash_attention_kernel(1, 1, 128, 128)  # 序列长度可整除块大小。
    test_flash_attention_kernel(32, 8, 69, 128)  # 验证序列尾块掩码。

    if len(sys.argv) > 1 and sys.argv[1] == "--benchmark":
        bench_flash_attention.run(save_path=".", print_data=True)


if __name__ == "__main__":
    main()
