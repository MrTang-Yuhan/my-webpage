"""实验性地融合输出投影、在线 Softmax 和交叉熵损失。

该实现仍处于教学和调试阶段，不能作为经过验证的交叉熵实现使用。
"""

import sys

import torch
import triton
import triton.language as tl

DEVICE = torch.device(f"cuda:{torch.cuda.current_device()}")


def naive_ce_loss(x, embedding, targets):
    """使用 PyTorch 运算计算数值稳定的平均交叉熵。

    Args:
        x: 形状为 `(batch_size, seq_len, hidden_dim)` 的输入特征。
        embedding: 形状为 `(hidden_dim, vocab_size)` 的输出嵌入矩阵。
        targets: 形状为 `(batch_size, seq_len)` 的目标类别索引。

    Returns:
        所有 token 的平均负对数似然。
    """
    logits = x @ embedding
    vocab_size = embedding.shape[1]
    logits_2d = logits.reshape(-1, vocab_size)
    targets_1d = targets.reshape(-1)

    # 减去行最大值可以避免 exp 溢出。平移量在 log-sum-exp 中加回，
    # 因此不会改变最终 log-softmax。
    max_logits, _ = torch.max(logits_2d, dim=1, keepdim=True)
    shifted_logits = logits_2d - max_logits
    log_sum_exp = (
        torch.log(
            torch.sum(
                torch.exp(shifted_logits),
                dim=1,
                keepdim=True,
            )
        )
        + max_logits
    )
    log_softmax = logits_2d - log_sum_exp

    token_indices = torch.arange(
        log_softmax.size(0),
        device=targets_1d.device,
    )
    negative_log_likelihood = -log_softmax[token_indices, targets_1d]
    return torch.mean(negative_log_likelihood)


@triton.autotune(
    [
        triton.Config(
            {
                "block_size_n": block_size_n,
                "block_size_d": block_size_d,
                "block_size_v": block_size_v,
            },
            num_stages=num_stages,
            num_warps=num_warps,
        )
        for block_size_n in [16]
        for block_size_d in [16]
        for block_size_v in [16]
        for num_stages in [3]
        for num_warps in [4]
    ],
    key=["seq_len", "hidden_dim", "vocab_size"],
)
@triton.jit
def fused_ce_loss_kernel(
    x_ptr,
    embedding_ptr,
    targets_ptr,
    output_ptr,
    stride_x_batch,
    stride_x_seq,
    stride_x_hidden,
    stride_embedding_hidden,
    stride_embedding_vocab,
    stride_targets_batch,
    stride_targets_seq,
    stride_output_batch,
    stride_output_seq,
    batch_size,
    seq_len,
    hidden_dim: tl.constexpr,
    vocab_size: tl.constexpr,
    block_size_n: tl.constexpr,
    block_size_d: tl.constexpr,
    block_size_v: tl.constexpr,
):
    """分块计算输出投影，并在线归约 Softmax 分母和目标分子。

    Args:
        x_ptr: 输入特征首元素的指针。
        embedding_ptr: 输出嵌入矩阵首元素的指针。
        targets_ptr: 目标类别索引首元素的指针。
        output_ptr: 每个 token 的 NLL 输出指针。
        stride_x_batch: 输入特征的批次步幅。
        stride_x_seq: 输入特征的序列步幅。
        stride_x_hidden: 输入特征的隐藏维步幅。
        stride_embedding_hidden: 嵌入矩阵的隐藏维步幅。
        stride_embedding_vocab: 嵌入矩阵的词表维步幅。
        stride_targets_batch: 目标张量的批次步幅。
        stride_targets_seq: 目标张量的序列步幅。
        stride_output_batch: 输出张量的批次步幅。
        stride_output_seq: 输出张量的序列步幅。
        batch_size: 批次大小。
        seq_len: 序列长度。
        hidden_dim: 隐藏维度。
        vocab_size: 词表大小。
        block_size_n: 每个程序处理的 token 数量。
        block_size_d: 矩阵乘法沿隐藏维的块大小。
        block_size_v: 矩阵乘法沿词表维的块大小。
    """
    program_id = tl.program_id(0)
    offsets_n = tl.arange(0, block_size_n)
    offsets_v = tl.arange(0, block_size_v)

    # 以下寻址沿用实验代码。它尚未正确处理全部批次和尾块，README 中已
    # 明确标记这一限制；风格重构不改变该算法行为。
    x_ptr += program_id * block_size_n * stride_x_batch
    targets_ptr += program_id * block_size_n * stride_targets_seq
    output_ptr += program_id * block_size_n * stride_output_seq

    row_max = tl.full(
        (block_size_n,),
        value=-1e6,
        dtype=tl.float32,
    )
    denominator = tl.full(
        (block_size_n,),
        value=1.0,
        dtype=tl.float32,
    )
    selected_numerator = tl.zeros(
        (block_size_n,),
        dtype=tl.float32,
    )
    targets = tl.load(targets_ptr + offsets_n * stride_targets_seq).to(tl.int32)

    # 遍历词表块时在线更新全局最大值和 Softmax 分母，避免将完整
    # (batch_size, seq_len, vocab_size) logits 写入 DRAM。
    for vocab_block_start in range(0, vocab_size, block_size_v):
        logits = tl.zeros(
            (block_size_n, block_size_v),
            dtype=tl.float32,
        )
        offsets_d = tl.arange(0, block_size_d)

        for hidden_block_start in range(0, hidden_dim, block_size_d):
            x_offsets = (
                offsets_n[:, None] * stride_x_seq
                + offsets_d[None, :] * stride_x_hidden
            )
            embedding_offsets = (
                offsets_d[:, None] * stride_embedding_hidden
                + offsets_v[None, :] * stride_embedding_vocab
            )
            x = tl.load(x_ptr + x_offsets)
            embedding = tl.load(embedding_ptr + embedding_offsets)
            logits = tl.dot(x, embedding, acc=logits)
            offsets_d += block_size_d
        offsets_v += block_size_v

        # 新块出现更大值时，旧分母必须乘 exp(old_max - new_max)，才能
        # 与使用新基准计算的当前块指数处于同一尺度。
        new_row_max = tl.maximum(row_max, tl.max(logits, axis=1))
        shifted_logits = logits - new_row_max[:, None]
        numerator = tl.exp(shifted_logits)
        correction = tl.exp(row_max - new_row_max)
        block_denominator = tl.sum(numerator, axis=1)
        denominator = denominator * correction + block_denominator

        adjusted_targets = targets - vocab_block_start
        target_mask = (
            tl.arange(0, block_size_v)[None, :] == adjusted_targets[:, None]
        )
        selected_numerator += tl.sum(
            tl.where(target_mask, numerator, 0.0),
            axis=1,
        )
        row_max = new_row_max

    target_probability = selected_numerator / denominator
    negative_log_likelihood = -tl.log(target_probability)
    tl.store(
        output_ptr + offsets_n * stride_output_seq,
        negative_log_likelihood,
    )


def fused_ce_loss(x, embedding, targets):
    """启动实验性融合内核并返回 token 损失的平均值。

    Args:
        x: 形状为 `(batch_size, seq_len, hidden_dim)` 的输入特征。
        embedding: 形状为 `(hidden_dim, vocab_size)` 的输出嵌入矩阵。
        targets: 形状为 `(batch_size, seq_len)` 的目标类别索引。

    Returns:
        所有 token 的平均负对数似然。

    Raises:
        AssertionError: 如果输入隐藏维与嵌入矩阵不兼容。
    """
    assert x.shape[-1] == embedding.shape[0]
    batch_size, seq_len, hidden_dim = x.shape
    _, vocab_size = embedding.shape
    output = torch.empty(
        (batch_size, seq_len),
        dtype=torch.float32,
        device=x.device,
    )

    def grid(meta):
        """计算覆盖全部 token 所需的一维程序数。"""
        return (
            triton.cdiv(
                batch_size * seq_len,
                meta["block_size_n"],
            ),
        )

    fused_ce_loss_kernel[grid](
        x,
        embedding,
        targets,
        output,
        x.stride(0),
        x.stride(1),
        x.stride(2),
        embedding.stride(0),
        embedding.stride(1),
        targets.stride(0),
        targets.stride(1),
        output.stride(0),
        output.stride(1),
        batch_size,
        seq_len,
        hidden_dim,
        vocab_size,
    )
    return torch.mean(output)


def test_naive_ce_loss(
    batch_size,
    seq_len,
    hidden_dim,
    vocab_size,
    device=DEVICE,
    atol=1e-3,
):
    """比较朴素实现与 PyTorch 交叉熵的数值结果。"""
    torch.cuda.empty_cache()
    assert vocab_size <= 32_768
    x = torch.randn(
        (batch_size, seq_len, hidden_dim),
        dtype=torch.float32,
        device=device,
        requires_grad=False,
    )
    embedding = torch.randn(
        (hidden_dim, vocab_size),
        dtype=torch.float32,
        device=device,
        requires_grad=False,
    )
    targets = torch.randint(
        0,
        vocab_size,
        (batch_size, seq_len),
        device=device,
        requires_grad=False,
    )
    naive_loss = naive_ce_loss(x, embedding, targets)
    logits = (x @ embedding).reshape(-1, vocab_size)
    reference_loss = torch.nn.functional.cross_entropy(
        logits,
        targets.reshape(-1),
    )
    torch.testing.assert_close(
        naive_loss,
        reference_loss,
        atol=atol,
        rtol=0,
    )
    print(f"naive passed {vocab_size}")


def test_fused_ce_loss(
    batch_size,
    seq_len,
    hidden_dim,
    vocab_size,
    device=DEVICE,
    atol=1e-3,
):
    """比较实验性融合实现与 PyTorch 交叉熵的数值结果。"""
    torch.cuda.empty_cache()
    x = torch.randn(
        (batch_size, seq_len, hidden_dim),
        dtype=torch.float32,
        device=device,
        requires_grad=False,
    )
    embedding = torch.randn(
        (hidden_dim, vocab_size),
        dtype=torch.float32,
        device=device,
        requires_grad=False,
    )
    targets = torch.randint(
        0,
        vocab_size,
        (batch_size, seq_len),
        device=device,
        requires_grad=False,
    )
    logits = (x @ embedding).reshape(-1, vocab_size)
    reference_loss = torch.nn.functional.cross_entropy(
        logits,
        targets.reshape(-1),
    )
    triton_loss = fused_ce_loss(x, embedding, targets)
    torch.testing.assert_close(
        triton_loss,
        reference_loss,
        atol=atol,
        rtol=0,
    )
    print(f"triton passed {vocab_size}")


_BENCHMARK_CONFIGS = [
    triton.testing.Benchmark(
        x_names=["vocab_size"],
        x_vals=[2**i for i in range(10, 14)],
        line_arg="provider",
        line_vals=["torch", "triton"],
        line_names=[
            "torch.nn.functional.cross_entropy()",
            "Fused & sparse Triton implementation",
        ],
        styles=[("red", "-"), ("blue", "-")],
        ylabel="TFLOPS",
        plot_name="CELoss-performance",
        args={},
    )
]


@triton.testing.perf_report(_BENCHMARK_CONFIGS)
def bench_ce_loss(vocab_size, provider, device=DEVICE):
    """测量 PyTorch 或实验性 Triton 交叉熵的吞吐量。"""
    dtype = torch.float32
    batch_size, seq_len, hidden_dim = 32, 1024, 384
    x = torch.randn(
        (batch_size, seq_len, hidden_dim),
        dtype=dtype,
        device=device,
        requires_grad=False,
    )
    embedding = torch.randn(
        (hidden_dim, vocab_size),
        dtype=dtype,
        device=device,
        requires_grad=False,
    )
    targets = torch.randint(
        0,
        vocab_size,
        (batch_size, seq_len),
        device=device,
        requires_grad=False,
    )

    if provider == "torch":
        logits = (x @ embedding).reshape(-1, vocab_size)
        targets_1d = targets.reshape(-1)

        def run_provider():
            """运行 PyTorch 交叉熵。"""
            return torch.nn.functional.cross_entropy(logits, targets_1d)

    if provider == "triton":

        def run_provider():
            """运行实验性 Triton 交叉熵。"""
            return fused_ce_loss(x, embedding, targets)

    milliseconds = triton.testing.do_bench(run_provider)
    total_flops = (
        2 * batch_size * seq_len * hidden_dim * vocab_size
        + 6 * batch_size * seq_len * vocab_size
    )
    return total_flops * 1e-12 / (milliseconds * 1e-3)


def main():
    """运行实验性数值测试，并按需运行性能测试。"""
    test_fused_ce_loss(32, 1024, 384, 32_768)
    if len(sys.argv) > 1 and sys.argv[1] == "--benchmark":
        bench_ce_loss.run(save_path=".", print_data=True)


if __name__ == "__main__":
    main()
