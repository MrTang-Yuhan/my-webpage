"""使用 Triton 实现将每一行驻留在 SRAM 中的融合 Softmax。

你将学习：
- 减少内存读写的重要性
- 如何将多个操作融合为一个内核
- 如何根据 GPU 规格选择元参数和启动规模
- 软件流水线和掩码填充值

参阅原始 Triton 文档：
https://triton-lang.org/main/getting-started/tutorials/02-fused-softmax.html
"""

import sys

import torch
import triton
import triton.language as tl

DEVICE = torch.device(f"cuda:{torch.cuda.current_device()}")
_DEVICE_PROPERTIES = triton.runtime.driver.active.utils.get_device_properties(
    DEVICE.index
)
NUM_SMS = _DEVICE_PROPERTIES["multiprocessor_count"]
NUM_REGISTERS = _DEVICE_PROPERTIES["max_num_regs"]
TOTAL_SRAM_PER_SM = _DEVICE_PROPERTIES["max_shared_mem"]
WARP_SIZE = _DEVICE_PROPERTIES["warpSize"]


# 步骤 1：朴素参考实现。
def naive_softmax(x):
    """计算二维张量每一行的数值稳定 Softmax。

    Args:
        x: 形状为 `(m, n)` 的输入张量。

    Returns:
        与 `x` 形状相同的 Softmax 结果。
    """
    # 减去行最大值不会改变 Softmax，却能避免指数溢出。
    row_max = x.max(dim=1)[0]
    shifted = x - row_max[:, None]
    numerator = torch.exp(shifted)
    denominator = numerator.sum(dim=1)
    return numerator / denominator[:, None]


# 朴素实现会反复读写中间张量。融合内核只读取一次输入，并在 SRAM 中
# 完成最大值归约、指数、求和与归一化，理论内存流量约为前者的四分之一。
@triton.jit
def _softmax_kernel(
    input_ptr,
    output_ptr,
    input_row_stride,
    output_row_stride,
    n_rows,
    n_cols,
    block_size: tl.constexpr,
    num_stages: tl.constexpr,
):
    """在单个 Triton 程序中融合一行 Softmax 的全部操作。

    Args:
        input_ptr: 输入矩阵首元素的指针。
        output_ptr: 输出矩阵首元素的指针。
        input_row_stride: 输入矩阵相邻行之间的元素步幅。
        output_row_stride: 输出矩阵相邻行之间的元素步幅。
        n_rows: 矩阵行数。
        n_cols: 矩阵列数。
        block_size: 填充后一行包含的元素数量。
        num_stages: 软件流水线阶段数。
    """
    row_start = tl.program_id(0)
    row_step = tl.num_programs(0)

    # 程序数可少于行数。每个程序以 row_step 为间隔处理多行，使有限的
    # 常驻程序能够覆盖整个矩阵，并允许循环迭代进入软件流水线。
    for row_index in tl.range(
        row_start,
        n_rows,
        row_step,
        num_stages=num_stages,
    ):
        row_ptr = input_ptr + row_index * input_row_stride
        column_offsets = tl.arange(0, block_size)
        mask = column_offsets < n_cols
        row = tl.load(
            row_ptr + column_offsets,
            mask=mask,
            other=float("-inf"),
        )

        # 填充位置为 -inf：它不会改变最大值，取指数后又变为 0，因此
        # 不会污染 Softmax 分母。
        shifted = row - tl.max(row, axis=0)
        numerator = tl.exp(shifted)
        denominator = tl.sum(numerator, axis=0)
        output = numerator / denominator

        output_row_ptr = output_ptr + row_index * output_row_stride
        tl.store(output_row_ptr + column_offsets, output, mask=mask)


def softmax(x):
    """启动融合 Triton 内核，计算二维张量每一行的 Softmax。

    Args:
        x: 位于当前 CUDA 设备、形状为 `(m, n)` 的连续张量。

    Returns:
        与 `x` 形状和 dtype 相同的 Softmax 结果。

    Raises:
        AssertionError: 如果输入不是二维张量，或单行无法放入 SRAM。
    """
    assert x.ndim == 2
    n_rows, n_cols = x.shape
    block_size = triton.next_power_of_2(n_cols)

    # 更宽的行需要更多 warp 协作。该启发式配置保持原教程取值不变。
    num_warps = 4
    if block_size >= 2048:
        num_warps = 8
    if block_size >= 4096:
        num_warps = 16

    # 软件流水线可让加载、计算和存储重叠；共享内存充足时使用更多阶段。
    num_stages = 4 if TOTAL_SRAM_PER_SM > 200_000 else 2
    output = torch.empty_like(x)

    kernel = _softmax_kernel.warmup(
        x,
        output,
        x.stride(0),
        output.stride(0),
        n_rows,
        n_cols,
        block_size=block_size,
        num_stages=num_stages,
        num_warps=num_warps,
        grid=(1,),
    )
    kernel._init_handles()
    registers_per_thread = kernel.n_regs
    sram_per_program = kernel.metadata.shared

    # 每个程序使用 registers_per_thread * WARP_SIZE * num_warps 个
    # 寄存器。寄存器和 SRAM 中更紧张的资源决定单个 SM 的占用率。
    register_occupancy = NUM_REGISTERS // (
        registers_per_thread * WARP_SIZE * num_warps
    )
    sram_occupancy = TOTAL_SRAM_PER_SM // sram_per_program
    programs_per_sm = min(register_occupancy, sram_occupancy)
    num_programs = min(NUM_SMS * programs_per_sm, n_rows)

    # warmup 后的内核要求三维网格，因此保留两个未使用的维度。
    grid = (num_programs, 1, 1)
    kernel[grid](
        x,
        output,
        x.stride(0),
        output.stride(0),
        n_rows,
        n_cols,
        block_size,
        num_stages,
    )
    return output


def test_softmax_kernel(size: tuple, atol=1e-3, rtol=1e-3, device=DEVICE):
    """使用不规则矩阵验证融合 Softmax 的结果和填充逻辑。"""
    torch.manual_seed(0)
    assert type(size) is tuple and len(size) == 2
    x = torch.randn(size[0], size[1], device=DEVICE)
    triton_output = softmax(x)
    reference_output = torch.softmax(x, axis=1)
    torch.testing.assert_close(
        triton_output,
        reference_output,
        atol=atol,
        rtol=rtol,
    )
    print("PASSED")


@triton.testing.perf_report(
    [
        triton.testing.Benchmark(
            x_names=["n"],
            x_vals=[128 * i for i in range(2, 100)],
            line_arg="provider",
            line_vals=["triton", "torch"],
            line_names=["Triton", "Torch"],
            styles=[("blue", "-"), ("green", "-")],
            ylabel="GB/s",
            plot_name="softmax-performance",
            args={"m": 4096},
        )
    ]
)
def benchmark(m, n, provider):
    """测量 PyTorch 或 Triton Softmax 的有效内存带宽。"""
    x = torch.randn(m, n, device=DEVICE, dtype=torch.float32)
    stream = getattr(torch, DEVICE.type).Stream()
    getattr(torch, DEVICE.type).set_stream(stream)

    def run_torch():
        """运行 PyTorch Softmax。"""
        return torch.softmax(x, axis=-1)

    def run_triton():
        """运行 Triton Softmax。"""
        return softmax(x)

    if provider == "torch":
        milliseconds = triton.testing.do_bench(run_torch)
    if provider == "triton":
        milliseconds = triton.testing.do_bench(run_triton)

    def to_gbps(elapsed_ms):
        """将耗时换算为有效内存带宽。"""
        transferred_bytes = 2 * x.numel() * x.element_size()
        return transferred_bytes * 1e-9 / (elapsed_ms * 1e-3)

    return to_gbps(milliseconds)


def main():
    """运行数值测试，并按需运行性能测试。"""
    test_softmax_kernel(size=(1823, 781))
    if len(sys.argv) > 1 and sys.argv[1] == "--benchmark":
        benchmark.run(save_path=".", print_data=False)


if __name__ == "__main__":
    main()
