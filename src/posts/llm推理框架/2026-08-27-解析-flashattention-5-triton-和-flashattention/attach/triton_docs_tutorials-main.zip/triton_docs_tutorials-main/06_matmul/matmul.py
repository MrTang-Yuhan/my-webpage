"""使用 Triton 实现分块矩阵乘法和组主序 PID 调度。

 你将学习：
- 自动性能调优
- 通过程序重排序提高 SRAM 命中率
- 多维指针算术
- 高精度数据类型累加
- 使用 Triton 解释器（某种程度上）

建议按以下顺序阅读代码：
步骤 1 - 单元测试
步骤 2 - 包装函数
步骤 3 - 内核
步骤 4 - 基准测试

对于形状为 (M, K) @ (K, N) = (M, N) 的矩阵乘法 A @ B = C，以下
算法在数值上等价于本代码的输出，但我们会以不同方式
得到结果。
for m in range(0, M, BLOCK_SIZE_M):  # 并行执行。
    for n in range(0, N, BLOCK_SIZE_N):  # 并行执行。
        acc = zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=float32)
        for k in range(0, K, BLOCK_SIZE_K):
            a = A[m : m+BLOCK_SIZE_M, k : k+BLOCK_SIZE_K]
            b = B[k : k+BLOCK_SIZE_K, n : n+BLOCK_SIZE_N]
            acc += dot(a,b)
        C[m : m+BLOCK_SIZE_M, n : n+BLOCK_SIZE_N] = acc

参阅原始文档：
https://triton-lang.org/main/getting-started/tutorials/03-matrix-multiplication.html
"""

import sys

import torch
import triton
import triton.language as tl

# 如需使用 Triton 解释器调试，可取消下面两行的注释。
# import os
# os.environ["TRITON_INTERPRET"] = "1"


DEVICE = torch.device(f"cuda:{torch.cuda.current_device()}")

# 步骤 3：Triton 内核。

# Triton 解释器可在 CPU 上模拟内核并允许使用 print() 调试，但它不支持所有
# Triton 功能。使用时应暂时移除 triton.autotune，只保留一组较小的块参数，
# 并将 M、N、K 标记为 tl.constexpr，使循环次数成为编译期常量。
# import os
# os.environ["TRITON_INTERPRET"] = "1"

# 自动调优预先定义多组元参数，Triton 会选择当前 GPU 上表现最好的一组。
# 这些候选值由启发式方法选择；
# 但请注意，为与一个 warp 中的线程数保持一致，所有值都是 32 的倍数。
_AUTOTUNE_CONFIGS = [
    triton.Config(
        {
            "block_size_m": 128,
            "block_size_n": 256,
            "block_size_k": 64,
            "group_size": 8,
        },
        num_stages=3,
        num_warps=8,
    ),
    triton.Config(
        {
            "block_size_m": 64,
            "block_size_n": 256,
            "block_size_k": 32,
            "group_size": 8,
        },
        num_stages=4,
        num_warps=4,
    ),
    triton.Config(
        {
            "block_size_m": 128,
            "block_size_n": 128,
            "block_size_k": 32,
            "group_size": 8,
        },
        num_stages=4,
        num_warps=4,
    ),
    triton.Config(
        {
            "block_size_m": 128,
            "block_size_n": 64,
            "block_size_k": 32,
            "group_size": 8,
        },
        num_stages=4,
        num_warps=4,
    ),
    triton.Config(
        {
            "block_size_m": 64,
            "block_size_n": 128,
            "block_size_k": 32,
            "group_size": 8,
        },
        num_stages=4,
        num_warps=4,
    ),
    triton.Config(
        {
            "block_size_m": 128,
            "block_size_n": 32,
            "block_size_k": 32,
            "group_size": 8,
        },
        num_stages=4,
        num_warps=4,
    ),
    triton.Config(
        {
            "block_size_m": 64,
            "block_size_n": 32,
            "block_size_k": 32,
            "group_size": 8,
        },
        num_stages=5,
        num_warps=2,
    ),
    triton.Config(
        {
            "block_size_m": 32,
            "block_size_n": 64,
            "block_size_k": 32,
            "group_size": 8,
        },
        num_stages=5,
        num_warps=2,
    ),
]


# 使用 `triton.autotune` 装饰器可对 `triton.jit` 修饰的函数进行自动调优；它接受：
#   1) 一个 `triton.Config` 对象列表，用于定义不同的元参数和编译选项配置
#   2) 一个自动调优“键”，其值的改变会触发对所有给定配置的新一轮评估，这意味着
#       每当新输入中的 M、N 或 K 发生变化时，Triton 都会重新检查哪种配置最佳
@triton.autotune(configs=_AUTOTUNE_CONFIGS, key=["m", "n", "k"])
@triton.jit
def _matmul_kernel(
    a_ptr,
    b_ptr,
    c_ptr,
    m,
    n,
    k,
    stride_a_m,
    stride_a_k,
    stride_b_k,
    stride_b_n,
    stride_c_m,
    stride_c_n,
    block_size_m: tl.constexpr,
    block_size_n: tl.constexpr,
    block_size_k: tl.constexpr,
    group_size: tl.constexpr,
):
    r"""
    将程序 ID 映射到输出 tile，并计算对应的分块矩阵乘法。

    首先，我们需要将每个程序 ID 映射到其要计算的 C 的块。
    让我们看一个示例，其中
    M = N = K = 8,
    BLOCK_SIZE_M = BLOCK_SIZE_K = BLOCK_SIZE_N = 2
    一个朴素的实现可能如下所示
    [0,   1,  2,  3]
    [4,   5,  6,  7]
    [8,   9, 10, 11]
    [12, 13, 14, 15]
    其中每个 PID 对应 C 的一个 2x2 块（C 的大小为 8x8）。
    以 0 为例，要计算其中一个块，我们需要 A 和 B 的哪些部分？
    让我们看看矩阵乘法的工作方式，其中 x 表示创建
    对应 PID=0 的 C 块时需要使用的 A 和 B 的块
        A           @       B           =       C
    [x, x, x, x]        [x, _, _, _]        [0, _, _, _]
    [_, _, _, _]        [x, _, _, _]        [_, _, _, _]
    [_, _, _, _]        [x, _, _, _]        [_, _, _, _]
    [_, _, _, _]        [x, _, _, _]        [_, _, _, _]
    因此，为了创建对应 PID=0 的 C 的 2x2 块，我们需要 A 顶部行中的四个 2x2 块
    以及 B 第一列中的四个 2x2 块。
    注意，我们无需同时将全部 8 个块加载到 SRAM 中，可以分别遍历 A/B 的列/行，
    对两个对应的块进行小型矩阵乘法，并在遍历过程中将它们累加起来。
        A           @       B
    [--------->]        [ | , _, _, _]
    [_, _, _, _]        [ | , _, _, _]
    [_, _, _, _]        [ | , _, _, _]
    [_, _, _, _]        [\|/, _, _, _]
    每次迭代只加载当前 K 维对应的 A、B 块，并将乘积累加到同一输出块。
    很好，按所述方式实现这个算法确实能够工作。
    然而，它远不如 PyTorch 的方法快，后者实现了更巧妙的方案。
    要理解原因，我们需要考虑 SRAM 的使用情况。
    请注意，PID 0 到 3 都使用 A 的同一行块，并且一个 SM 上可以有
    多个程序共享同一个 SRAM 池。
    这意味着，无需让它们分别加载 A 的同一行块而产生大量重复；
    一旦某个 PID 加载了该行中的一个 A 块，另外 3 个 PID 就可以复用它！

    Triton 的缓存机制可让同一 SM 上的相邻程序复用已经加载的输入块。
    虽然不必显式地告诉 Triton 这样做，但应仔细考虑如何通过调整 PID 的顺序，帮助 Triton
    最大化利用这种能力。
    PID 通常按顺序调度，因此 PID 顺序会影响哪些输出块能够复用输入数据。
    再次查看 PID 0 到 3，具体看看它们需要加载 A 和 B 的哪些块：
    PID = 0
    [x, x, x, x]        [x, _, _, _]
    [_, _, _, _]        [x, _, _, _]
    [_, _, _, _]        [x, _, _, _]
    [_, _, _, _]        [x, _, _, _]
    PID = 1
    [x, x, x, x]        [_, x, _, _]
    [_, _, _, _]        [_, x, _, _]
    [_, _, _, _]        [_, x, _, _]
    [_, _, _, _]        [_, x, _, _]
    PID = 2
    [x, x, x, x]        [_, _, x, _]
    [_, _, _, _]        [_, _, x, _]
    [_, _, _, _]        [_, _, x, _]
    [_, _, _, _]        [_, _, x, _]
    PID = 3
    [x, x, x, x]        [_, _, _, x]
    [_, _, _, _]        [_, _, _, x]
    [_, _, _, _]        [_, _, _, x]
    [_, _, _, _]        [_, _, _, x]
    注意，虽然它们都可以共享 A 的第一行块，从而避免加载另外三行块，
    但它们最终仍会加载 B 的每一列块。
    我们能做得更好吗？
    能否让相同数量的 PID（即相同数量的 C 块）使用更少的
    A 和 B 块来构建？
    目前，采用我们称为“行主序”的方法时，加载量为：
        (1 row of blocks of A) + (4 columns of blocks of B)
        = 5 total rows/cols of blocks loaded to SRAM

    那么，如果不将 PID 0 到 3 放到同一 SM 上，而是将 PID 0、1、4 和 5 放到同一 SM 上呢？
    看看 PID 4 和 5 需要加载什么：
    PID = 4
    [_, _, _, _]        [x, _, _, _]
    [x, x, x, x]        [x, _, _, _]
    [_, _, _, _]        [x, _, _, _]
    [_, _, _, _]        [x, _, _, _]
    PID = 5
    [_, _, _, _]        [_, x, _, _]
    [x, x, x, x]        [_, x, _, _]
    [_, _, _, _]        [_, x, _, _]
    [_, _, _, _]        [_, x, _, _]
    现在，在这个假设的新设置中，我们只需加载
        (2 rows of blocks of A) + (2 columns of blocks of B)
        = 4 total rows/cols of blocks loaded to SRAM
    但输出的 C 块数量仍然相同。
    这种策略称为“组主序”。
    在这个很小的示例中，效果看起来并不显著，但随着块数量增加，它能越来越有效地避免
    将大量重复的 A 和 B 块加载到不同的 SM 中。

    不过，请记住 Triton 根据 PID 的顺序将块加载到 SM 中。因此，尽管我们希望
    PID 0、1、4 和 5 共享同一 SRAM，实际上 PID 3 和 4 很可能会妨碍
    这种情况发生。
    那么如何确保对应 PID 4 和 5 的 C 块与 0 和 1 加载到同一 SM 上？
    实际上，我们必须重新排序 PID，即将它们重新分配给不同的 C 块。
    请记住，我们的输入启动网格是一维的（与此前所有启动网格一样），这意味着它
    由仅包含一个条目的元组定义。
    进入内核后，我们的任务是将这个一维 PID 列表转换为所需的形状。
    关键点是数值彼此接近的 PID 更可能最终位于同一 SM 上。尽管让 0、1、4 和
    5 共享数据更有效，朴素启动顺序实际会优先调度 0、1、2 和 3。
    因此，我们需要移动 2 和 3，使它们对应于之前分配给 4 和 5 的 C 块。
    无需赘述，请查看这个新的可视化顺序：
    [0,  2,  4,  6]
    [1,  3,  5,  7]
    [8, 10, 12, 14]
    [9, 11, 13, 15]
    现在，0 到 3 对应组主序！请注意，在此示例中，我们可以将其可视化为把
    PID 划分为由虚线标示的“组”
    [0,  2, |  4,  6]
    [1,  3, |  5,  7]
    --------|--------
    [8, 10, | 12, 14]
    [9, 11, | 13, 15]
    这些组的大小由 `group_size` 元参数定义。

    Args:
        a_ptr: 输入矩阵 A 首元素的指针。
        b_ptr: 输入矩阵 B 首元素的指针。
        c_ptr: 输出矩阵 C 首元素的指针。
        m: 输出矩阵的行数。
        n: 输出矩阵的列数。
        k: 矩阵乘法的归约维度。
        stride_a_m: A 沿 M 维的步幅。
        stride_a_k: A 沿 K 维的步幅。
        stride_b_k: B 沿 K 维的步幅。
        stride_b_n: B 沿 N 维的步幅。
        stride_c_m: C 沿 M 维的步幅。
        stride_c_n: C 沿 N 维的步幅。
        block_size_m: 输出 tile 沿 M 维的大小。
        block_size_n: 输出 tile 沿 N 维的大小。
        block_size_k: 每次归约沿 K 维处理的大小。
        group_size: 组主序调度中每组包含的 M 维 tile 数。
    """

    # 每组包含 group_size 行的输出 tile，组内按列优先分配 PID。这样相邻
    # 程序会集中在较小的二维区域，更可能复用 A 的行块和 B 的列块。
    program_id = tl.program_id(axis=0)
    num_pid_m = tl.cdiv(m, block_size_m)
    num_pid_n = tl.cdiv(n, block_size_n)
    num_pid_in_group = group_size * num_pid_n
    group_id = program_id // num_pid_in_group
    first_pid_m = group_id * group_size

    # 最后一组可能不足 group_size 行，必须使用实际行数计算组内坐标，
    # 否则末组 PID 会映射到输出矩阵之外。
    actual_group_size = min(num_pid_m - first_pid_m, group_size)
    pid_in_group = program_id % num_pid_in_group
    pid_m = first_pid_m + pid_in_group % actual_group_size
    pid_n = pid_in_group // actual_group_size

    offsets_m = pid_m * block_size_m + tl.arange(0, block_size_m)
    offsets_n = pid_n * block_size_n + tl.arange(0, block_size_n)
    offsets_k = tl.arange(0, block_size_k)

    # 调试 PID 映射时，可按需取消下面代码的注释。
    # tl.static_print("offsets_m shape =", (block_size_m,))
    # if program_id == 1:
    #     tl.device_print("pid_m =", pid_m)
    #     tl.device_print("offsets_m =", offsets_m)

    # 计算 A 和 B 矩阵中选中的块的线性地址。
    # [:, None] 和 [None, :] 用于将一维向量扩展为二维，以便进行广播。
    a_offsets = (
        offsets_m[:, None] * stride_a_m + offsets_k[None, :] * stride_a_k
    )
    b_offsets = (
        offsets_k[:, None] * stride_b_k + offsets_n[None, :] * stride_b_n
    )
    # 使用 FP32 累加低精度输入的乘积，以减小归约误差。
    accumulator = tl.zeros(
        (block_size_m, block_size_n),
        dtype=tl.float32,
    )

    # 沿 A 和 B 的 K 维度迭代，以计算 C 矩阵的单个块
    for block_index_k in range(0, tl.cdiv(k, block_size_k)):
        k_mask = offsets_k < k - block_index_k * block_size_k

        # 现在加载 A 和 B 矩阵的块。如果同一组中的多个块位于同一 SM 上，
        # 它们可以共享这些已加载的值，从而减少代价高昂的 DRAM 加载次数
        # 将一维 K 掩码广播为与 A、B tile 匹配的二维掩码。
        # 将一维 K 掩码广播为两个 tile 的二维掩码。越界位置填 0，
        # 因而不会影响点积归约。
        a = tl.load(a_ptr + a_offsets, mask=k_mask[None, :], other=0.0)
        b = tl.load(b_ptr + b_offsets, mask=k_mask[:, None], other=0.0)

        # 沿 K 维度累加
        accumulator = tl.dot(a, b, acc=accumulator)

        # 将指针沿 K 维度推进到下一个块
        a_offsets += block_size_k * stride_a_k
        b_offsets += block_size_k * stride_b_k

    accumulator = accumulator.to(tl.float16)

    c_offsets = (
        stride_c_m * offsets_m[:, None] + stride_c_n * offsets_n[None, :]
    )
    c_mask = (offsets_m[:, None] < m) & (offsets_n[None, :] < n)
    tl.store(c_ptr + c_offsets, accumulator, mask=c_mask)


# 步骤 2：Python 包装函数。
def matmul(a, b):
    """使用 Triton 计算两个二维矩阵的乘积。

    Args:
        a: 形状为 `(M, K)` 的输入矩阵。
        b: 形状为 `(K, N)` 的输入矩阵。

    Returns:
        形状为 `(M, N)`、dtype 为 FP16 的输出矩阵。

    Raises:
        AssertionError: 如果输入不是二维矩阵或归约维度不匹配。
    """
    assert (
        a.ndim == b.ndim == 2
    ), "only supports matrices, not vectors or tensors"
    assert a.shape[1] == b.shape[0], "incompatible dimensions"
    # 当前寻址逻辑通过 stride 支持非连续输入；无需强制连续。
    # assert a.is_contiguous() and b.is_contiguous()
    a, b = a.to(torch.float16), b.to(torch.float16)
    (m, k), (_, n) = a.shape, b.shape
    c = torch.empty((m, n), device=a.device, dtype=torch.float16)

    def grid(meta):
        """计算矩阵乘法内核的一维启动网格。

        Triton 会为每个输出 tile 启动一个 program。输出矩阵的
        `(m, n)` 区域分别按照 `block_size_m` 和 `block_size_n` 分块，
        因此 program 总数等于两个维度上的 tile 数量之积。

        `meta` 是 Triton 根据当前 autotune 配置提供的编译期元参数。
        返回值必须是元组；单元素元组表示使用一维启动网格。
        """
        num_pid_m = triton.cdiv(m, meta["block_size_m"])
        num_pid_n = triton.cdiv(n, meta["block_size_n"])
        return (num_pid_m * num_pid_n,)  # 必须有 , ，即元组形式

    # 方括号不是普通的 Python 下标操作，而是 Triton 的内核启动语法：
    # `_matmul_kernel[grid](...)` 会先调用 grid(meta) 计算启动网格，
    # 再启动对应数量的 Triton program。每个 program 通过
    # `tl.program_id(0)` 获取自己在一维网格中的 PID，并负责计算
    # 输出矩阵中的一个 tile。
    _matmul_kernel[grid](
        a,
        b,
        c,
        m,
        n,
        k,
        a.stride(0),
        a.stride(1),
        b.stride(0),
        b.stride(1),
        c.stride(0),
        c.stride(1),
    )
    return c


# 步骤 1：数值测试。
def test_matmul_kernel(size: tuple, atol=1e-2, rtol=1e-1, device=DEVICE):
    """将 Triton 矩阵乘法与 PyTorch 参考结果进行比较。

    我们使用比之前测试更高的容差值，因为在矩阵乘法中，所有浮点运算的
    累加误差确实会不断累积；即使块大小和启动网格顺序与 PyTorch 的做法仅有
    细微差异，也可能导致相当明显的偏差。
    """
    torch.manual_seed(0)
    assert type(size) is tuple and len(size) == 2
    a = torch.randn((512, 512), device=DEVICE, dtype=torch.float16)
    b = torch.randn((512, 512), device=DEVICE, dtype=torch.float16)
    triton_output = matmul(a, b)
    reference_output = torch.matmul(a, b)
    torch.testing.assert_close(
        triton_output,
        reference_output,
        atol=atol,
        rtol=rtol,
    )
    print("PASSED")


# 步骤 4：性能测试。
_BENCHMARK_CONFIGS = [
    triton.testing.Benchmark(
        x_names=["m", "n", "k"],
        x_vals=[128 * i for i in range(2, 33)],
        line_arg="provider",
        line_vals=["torch", "triton"],
        line_names=["PyTorch", "Triton"],
        styles=[("green", "-"), ("blue", "-")],
        ylabel="TFLOPS",
        plot_name="matmul-performance",
        args={},
    )
]


@triton.testing.perf_report(_BENCHMARK_CONFIGS)
def benchmark(m, n, k, provider):
    """测量 PyTorch 或 Triton 矩阵乘法的吞吐量。"""
    a = torch.randn((m, k), device=DEVICE, dtype=torch.float16)
    b = torch.randn((k, n), device=DEVICE, dtype=torch.float16)
    quantiles = [0.5, 0.05, 0.95]

    def run_torch():
        """运行 PyTorch 矩阵乘法。"""
        return torch.matmul(a, b)

    def run_triton():
        """运行 Triton 矩阵乘法。"""
        return matmul(a, b)

    if provider == "torch":
        milliseconds, min_ms, max_ms = triton.testing.do_bench(
            run_torch,
            quantiles=quantiles,
        )
    if provider == "triton":
        milliseconds, min_ms, max_ms = triton.testing.do_bench(
            run_triton,
            quantiles=quantiles,
        )

    def to_tflops(elapsed_ms):
        """按原教程公式将耗时换算为 TFLOPS。"""
        return 3 * m * n * k * 1e-12 / (elapsed_ms * 1e-3)

    return (
        to_tflops(milliseconds),
        to_tflops(max_ms),
        to_tflops(min_ms),
    )


def main():
    """运行数值测试，并按需运行性能测试。"""
    test_matmul_kernel(size=(1024, 1024))
    if len(sys.argv) > 1 and sys.argv[1] == "--benchmark":
        benchmark.run(save_path=".", print_data=False)


if __name__ == "__main__":
    main()
