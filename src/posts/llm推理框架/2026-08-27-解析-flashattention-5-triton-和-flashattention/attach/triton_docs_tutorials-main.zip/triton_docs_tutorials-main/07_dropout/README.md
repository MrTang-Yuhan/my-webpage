# 低内存 Dropout

## 实现目标

`dropout.py` 实现确定性的 inverted dropout。随机掩码直接在 Triton 程序内部生成
和消费，无需将掩码保存到 DRAM，从而降低额外内存占用和带宽开销。

## 核心数据流

1. `seeded_dropout()` 分配输出，并创建覆盖所有元素的一维启动网格。
2. `_seeded_dropout()` 根据 PID 生成当前块的元素偏移量和边界掩码。
3. `tl.rand(seed, offsets)` 以全局元素偏移作为计数器，为每个元素生成可复现的
   `[0, 1)` 随机值。
4. 随机值大于丢弃概率 `p` 时保留输入，并除以 `1 - p`；否则写入零。

## 关键细节与限制

- 相同输入、seed 和元素位置会产生相同掩码；改变 seed 会生成不同结果。
- `1 / (1 - p)` 缩放使输出期望值与输入一致。
- 输入必须连续，`p` 应位于 `[0, 1)`；`p=1` 会导致除零，因此不可使用。
- 文件底部的示例直接展示相同 seed 和不同 seed 的输出差异，没有独立基准测试。

## 运行示例

```bash
python3 dropout.py
```

## 配套视频

[bilibili](https://www.bilibili.com/video/BV1fMyWBgERM?spm_id_from=333.788.videopod.episodes&vd_source=e98b669ccbafff4b5aa59dd6303b722f&p=9)
