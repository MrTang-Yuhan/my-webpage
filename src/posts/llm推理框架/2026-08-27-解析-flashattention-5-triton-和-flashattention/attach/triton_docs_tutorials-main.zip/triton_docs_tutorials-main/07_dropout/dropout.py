"""使用 Triton 实现无需保存随机掩码的低内存 Dropout。

你将学到：
- 并行伪随机数生成
"""

import torch
import triton
import triton.language as tl

DEVICE = torch.device(f"cuda:{torch.cuda.current_device()}")


@triton.jit
def _seeded_dropout(
    x_ptr,
    output_ptr,
    n_elements,
    dropout_probability,
    seed,
    block_size: tl.constexpr,
):
    """生成随机掩码并应用 inverted dropout。

    Args:
        x_ptr: 输入向量首元素的指针。
        output_ptr: 输出向量首元素的指针。
        n_elements: 输入向量的元素总数。
        dropout_probability: 丢弃概率，取值范围为 `[0, 1)`。
        seed: 随机数生成种子。
        block_size: 每个 Triton 程序处理的元素数量。
    """
    program_id = tl.program_id(axis=0)
    offsets = program_id * block_size + tl.arange(0, block_size)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask)

    # 随机数由 seed 和全局元素偏移共同决定。相同输入位置和 seed 会得到
    # 相同随机值，因此无需将掩码写入 DRAM 也能复现结果。
    random_values = tl.rand(seed, offsets)
    keep_mask = random_values > dropout_probability
    output = tl.where(
        keep_mask,
        x / (1 - dropout_probability),
        0.0,
    )
    # 除以保留概率可保持输出的期望值与输入一致。
    tl.store(output_ptr + offsets, output, mask=mask)


def seeded_dropout(x, dropout_probability, seed):
    """为连续 CUDA 张量应用确定性的 inverted dropout。

    Args:
        x: 连续的输入张量。
        dropout_probability: 丢弃概率，取值范围为 `[0, 1)`。
        seed: 随机数生成种子。

    Returns:
        与 `x` 形状和 dtype 相同的 Dropout 输出。

    Raises:
        AssertionError: 如果输入张量不连续。
    """
    output = torch.empty_like(x)
    assert x.is_contiguous()
    n_elements = x.numel()

    def grid(meta):
        """计算覆盖输入张量所需的一维程序数。"""
        return (triton.cdiv(n_elements, meta["block_size"]),)

    _seeded_dropout[grid](
        x,
        output,
        n_elements,
        dropout_probability,
        seed,
        block_size=1024,
    )
    return output


def main():
    """展示相同种子可复现、不同种子产生不同掩码。"""
    x = torch.randn(size=(8,), device=DEVICE)
    output_1 = seeded_dropout(x, dropout_probability=0.5, seed=123)
    output_2 = seeded_dropout(x, dropout_probability=0.5, seed=123)
    output_3 = seeded_dropout(x, dropout_probability=0.5, seed=512)
    print(x, output_1, output_2, output_3, sep="\n")


if __name__ == "__main__":
    main()
