"""使用 Triton GPU 内核对两个向量执行逐元素加法。

你将学到：
- 如何构建测试，确保 Triton 内核的数值结果正确
- Triton 内核基础（语法、指针、启动网格、DRAM 与 SRAM 等）
- 如何将 Triton 内核与 PyTorch 进行基准测试对比

推荐按以下顺序阅读代码：
步骤 1 - 单元测试
步骤 2 - 包装函数
步骤 3 - 内核
步骤 4 - 基准测试

观看配套 YouTube 视频：
https://youtu.be/fYMS4IglLgg
查看原始 Triton 文档：
https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html
"""

import sys

import torch
import triton
import triton.language as tl

DEVICE = torch.device(f"cuda:{torch.cuda.current_device()}")


# 步骤 3：Triton 内核。
@triton.jit
def add_kernel(
    x_ptr,
    y_ptr,
    output_ptr,
    n_elements,
    block_size: tl.constexpr,
):
    """计算两个等长向量的逐元素和。

    传入内核的 PyTorch 张量会被转换为指向首元素的指针。该内核不实现
    广播，每个程序只处理一个连续元素块。

    Args:
        x_ptr: 第一个输入向量首元素的指针。
        y_ptr: 第二个输入向量首元素的指针。
        output_ptr: 输出向量首元素的指针。
        n_elements: 输入向量的元素总数。
        block_size: 每个程序处理的元素数量，必须为 2 的幂。
    """
    # 一维启动网格中的每个程序都获得唯一 PID。长度为 256 且块大小为
    # 64 时，PID 0 到 3 分别处理一个长度为 64 的连续区间。
    program_id = tl.program_id(axis=0)
    block_start = program_id * block_size
    offsets = block_start + tl.arange(0, block_size)

    # 最后一个块可能超出向量末尾，因此加载和存储必须共用该掩码。
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask, other=None)
    y = tl.load(y_ptr + offsets, mask=mask, other=None)
    output = x + y
    tl.store(output_ptr + offsets, output, mask=mask)


# 步骤 2：Python 包装函数。
def add(x: torch.Tensor, y: torch.Tensor):
    """启动 Triton 内核以计算两个向量的逐元素和。

    Args:
        x: 位于当前 CUDA 设备的第一个输入张量。
        y: 与 `x` 形状相同的第二个输入张量。

    Returns:
        与输入形状和 dtype 相同的逐元素和。

    Raises:
        AssertionError: 如果输入或输出不在当前 CUDA 设备。
    """
    output = torch.empty_like(x)
    assert (
        x.device == DEVICE and y.device == DEVICE and output.device == DEVICE
    ), (
        f"DEVICE: {DEVICE}, x.device: {x.device}, "
        f"y.device: {y.device}, output.device: {output.device}"
    )

    n_elements = output.numel()

    def grid(meta):
        """计算覆盖输入向量所需的一维程序数。"""
        return (triton.cdiv(n_elements, meta["block_size"]),)

    # 1024 是兼顾内存延迟隐藏和程序并发度的启发式块大小。
    add_kernel[grid](
        x,
        y,
        output,
        n_elements,
        block_size=1024,
    )
    return output


# 步骤 1：数值测试。
def test_add_kernel(size, atol=1e-3, rtol=1e-3, device=DEVICE):
    """将 Triton 向量加法与 PyTorch 参考结果进行比较。"""
    torch.manual_seed(0)
    x = torch.rand(size, device=DEVICE)
    y = torch.rand(size, device=DEVICE)
    triton_output = add(x, y)
    reference_output = x + y
    torch.testing.assert_close(
        triton_output,
        reference_output,
        atol=atol,
        rtol=rtol,
    )
    print("PASSED")


# 步骤 4：性能测试。
@triton.testing.perf_report(
    [
        triton.testing.Benchmark(
            x_names=["size"],
            x_vals=[2**i for i in range(12, 28)],
            x_log=True,
            line_arg="provider",
            line_vals=["triton", "torch"],
            line_names=["Triton", "Torch"],
            styles=[("blue", "-"), ("green", "-")],
            ylabel="GB/s",
            plot_name="vector-add-performance",
            args={},
        )
    ]
)
def benchmark(size, provider):
    """测量 Triton 或 PyTorch 向量加法的有效内存带宽。"""
    x = torch.rand(size, device=DEVICE, dtype=torch.float32)
    y = torch.rand(size, device=DEVICE, dtype=torch.float32)
    quantiles = [0.5, 0.05, 0.95]

    def run_torch():
        """运行 PyTorch 参考实现。"""
        return x + y

    def run_triton():
        """运行 Triton 向量加法。"""
        return add(x, y)

    if provider == "torch":
        milliseconds, min_ms, max_ms = triton.testing.do_bench(
            run_torch,
            quantiles=quantiles,
        )
    if provider == "triton":
        milliseconds, min_ms, max_ms = triton.testing.do_bench(
            run_triton,
            quantiles=quantiles,
        )

    def to_gbps(elapsed_ms):
        """将耗时换算为有效内存带宽。"""
        # 每个元素对应两次读取和一次写入。
        transferred_bytes = 3 * x.numel() * x.element_size()
        return transferred_bytes * 1e-9 / (elapsed_ms * 1e-3)

    return to_gbps(milliseconds), to_gbps(max_ms), to_gbps(min_ms)


def main():
    """运行数值测试，并按需运行性能测试。"""
    test_add_kernel(size=98432)
    if len(sys.argv) > 1 and sys.argv[1] == "--benchmark":
        benchmark.run(save_path=".", print_data=False)


if __name__ == "__main__":
    main()
