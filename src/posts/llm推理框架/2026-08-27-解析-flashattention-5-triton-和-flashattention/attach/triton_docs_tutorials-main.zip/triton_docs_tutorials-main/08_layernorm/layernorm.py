"""使用 Triton 实现接入 PyTorch Autograd 的 LayerNorm。

在本课程中，我们会将内核连接到 PyTorch 的反向传播计算图。请注意，
这个内核速度很快，但它只能归一化能容纳在 SRAM 中的向量，因此我们以较差的泛化能力
换取了更高的速度。

你将学到：
- 编写反向传播内核
- 在反向传播中复用前向传播的中间值
- 使用 torch.autograd.Function 连接到 PyTorch 的反向传播计算图
- 锁和原子操作
- 如何使用带中间张量的顺序内核，以比单个内核更高效地完成计算

建议的代码阅读顺序：
步骤 1 - 单元测试
步骤 2 - 包装器
步骤 3 - 前向传播内核
步骤 4 - 反向传播内核
步骤 5 - 基准测试

参见原文
https://triton-lang.org/main/getting-started/tutorials/05-layer-norm.html#sphx-glr-getting-started-tutorials-05-layer-norm-py
"""

import sys

import torch
import triton
import triton.language as tl

DEVICE = torch.device(f"cuda:{torch.cuda.current_device()}")  # 0-D/设备元数据。


# 步骤 3：前向传播内核。
@triton.jit
def _layer_norm_forward(
    x_ptr,
    y_ptr,
    weight_ptr,
    bias_ptr,
    mean_ptr,
    rstd_ptr,
    row_stride,
    n_cols,
    eps,
    block_size: tl.constexpr,
):
    """计算 LayerNorm 前向结果，并保存每行的均值和标准差倒数。

    Args:
        x_ptr: 形状为 `(M, N)` 的输入张量指针。
        y_ptr: 形状为 `(M, N)` 的输出张量指针。
        weight_ptr: 形状为 `(N,)` 的权重指针。
        bias_ptr: 形状为 `(N,)` 的偏置指针。
        mean_ptr: 形状为 `(M,)` 的均值输出指针。
        rstd_ptr: 形状为 `(M,)` 的标准差倒数输出指针。
        row_stride: 0-D 标量；输入和输出相邻行之间的元素步幅。
        n_cols: 0-D 标量；每行的特征数 N。
        eps: 0-D 标量；防止方差归一化除零的稳定项。
        block_size: 0-D 编译期标量；块长度 BLOCK_SIZE。
    """
    # 使用程序 ID 将 x_ptr 和 y_ptr 移动到它们应计算的 X 和 Y 行
    row = tl.program_id(0)  # 0-D 标量；当前行索引，范围为 [0, M)。
    x_ptr += row * row_stride  # 指向当前行，逻辑局部形状为 (N,)。
    y_ptr += row * row_stride  # 指向当前行，逻辑局部形状为 (N,)。

    sum_accumulator = tl.zeros([block_size], dtype=tl.float32)  # [BLOCK_SIZE]。
    for offset in range(0, n_cols, block_size):  # 0-D 标量；当前列块起点。
        columns = offset + tl.arange(0, block_size)  # [BLOCK_SIZE] 列索引。
        # 最后一维必须连续，因此列偏移无需乘以额外步幅。
        x = tl.load(
            x_ptr + columns,
            mask=columns < n_cols,
            other=0.0,
        ).to(tl.float32)  # [BLOCK_SIZE]，当前行的输入块。
        # 使用 FP32 累加；越界位置填零，不影响求和。
        sum_accumulator += x
    mean = tl.sum(sum_accumulator, axis=0) / n_cols  # 0-D 标量；当前行均值。
    # 沿列归约后，每行只得到一个均值。

    # 计算方差和标准差的倒数
    variance_accumulator = tl.zeros([block_size], dtype=tl.float32)  # [BLOCK_SIZE]。
    for offset in range(0, n_cols, block_size):  # 0-D 标量；当前列块起点。
        columns = offset + tl.arange(0, block_size)  # [BLOCK_SIZE]。
        x = tl.load(
            x_ptr + columns,
            mask=columns < n_cols,
            other=0.0,
        ).to(tl.float32)  # [BLOCK_SIZE]。
        difference = tl.where(columns < n_cols, x - mean, 0.0)  # [BLOCK_SIZE]。
        # 将越界差值显式置零，避免填充值减去均值后影响方差。
        variance_accumulator += difference * difference
    variance = tl.sum(variance_accumulator, axis=0) / n_cols  # 0-D 标量。
    rstd = 1 / tl.sqrt(variance + eps)  # 0-D 标量；标准差倒数。
    # eps 防止方差为零时发生除零。

    # 保存 mean 和 rstd 供后续反向传播使用
    tl.store(mean_ptr + row, mean)
    tl.store(rstd_ptr + row, rstd)

    # 归一化并应用线性变换
    for offset in range(0, n_cols, block_size):  # 0-D 标量；当前列块起点。
        columns = offset + tl.arange(0, block_size)  # [BLOCK_SIZE]。
        mask = columns < n_cols  # [BLOCK_SIZE] 布尔掩码。
        weight = tl.load(weight_ptr + columns, mask=mask)  # [BLOCK_SIZE]。
        bias = tl.load(bias_ptr + columns, mask=mask)  # [BLOCK_SIZE]。
        x = tl.load(x_ptr + columns, mask=mask)  # [BLOCK_SIZE]。
        normalized_x = (x - mean) * rstd  # [BLOCK_SIZE]。
        y = normalized_x * weight + bias  # [BLOCK_SIZE]；输出块。
        tl.store(y_ptr + columns, y, mask=mask)


# 步骤 4：反向传播内核。
@triton.jit
def _layer_norm_backward_input(
    x_ptr,
    grad_x_ptr,
    grad_y_ptr,
    weight_ptr,
    grad_weight_partial_ptr,
    grad_bias_partial_ptr,
    mean_ptr,
    rstd_ptr,
    locks_ptr,
    row_stride,
    n_cols,
    group_size: tl.constexpr,
    block_size_n: tl.constexpr,
):
    """计算输入梯度，并分组累加权重和偏置梯度的部分和。

    每个 PID 负责一行输入梯度，并通过锁将该行的参数梯度贡献累加到
    `group_size` 个中间行之一。后续内核再归约这些部分和。

    Args:
        x_ptr: 输入张量指针，逻辑形状为 `(M, N)`。
        grad_x_ptr: 输入梯度输出指针，逻辑形状为 `(M, N)`。
        grad_y_ptr: 上游输出梯度指针，逻辑形状为 `(M, N)`。
        weight_ptr: LayerNorm 权重指针，逻辑形状为 `(N,)`。
        grad_weight_partial_ptr: 权重梯度部分和指针，逻辑形状为 `(GROUP_SIZE, N)`。
        grad_bias_partial_ptr: 偏置梯度部分和指针，逻辑形状为 `(GROUP_SIZE, N)`。
        mean_ptr: 前向传播保存的均值指针，逻辑形状为 `(M,)`。
        rstd_ptr: 前向传播保存的标准差倒数指针，逻辑形状为 `(M,)`。
        locks_ptr: 分组锁及首次写入计数器的指针，逻辑形状为 `(2 * GROUP_SIZE,)`。
        row_stride: 0-D 标量；输入和梯度相邻行之间的元素步幅。
        n_cols: 0-D 标量；每行的特征数 N。
        group_size: 0-D 标量；参数梯度部分和的分组数量 GROUP_SIZE。
        block_size_n: 0-D 编译期标量；列块长度 BLOCK_SIZE_N。
    """
    # 每个程序处理输入、输出梯度和输入梯度中的同一行。
    program_id = tl.program_id(0)  # 0-D 标量；当前输入行索引 [0, M)。
    columns = tl.arange(0, block_size_n)  # [BLOCK_SIZE_N]。
    mask = columns < n_cols  # [BLOCK_SIZE_N] 布尔掩码。
    x_ptr += program_id * row_stride  # 指向当前行，局部形状为 (N,)。
    grad_x_ptr += program_id * row_stride  # 指向当前行，局部形状为 (N,)。
    grad_y_ptr += program_id * row_stride  # 指向当前行，局部形状为 (N,)。

    # 批量加载后再计算，可让编译器更好地安排内存访问和浮点指令。
    x = tl.load(x_ptr + columns, mask=mask, other=0).to(tl.float32)  # [BLOCK_SIZE_N]。

    grad_y = tl.load(
        grad_y_ptr + columns,
        mask=mask,
        other=0,
    ).to(tl.float32)  # [BLOCK_SIZE_N]；dL/dy。
    weight = tl.load(weight_ptr + columns, mask=mask).to(tl.float32)  # [BLOCK_SIZE_N]。
    mean = tl.load(mean_ptr + program_id)  # 0-D 标量；当前行均值。
    rstd = tl.load(rstd_ptr + program_id)  # 0-D 标量；当前行标准差倒数。

    # if program_id == 1:
    #     tl.device_print("x =", x)
    #     tl.device_print("offsets_m =", columns)

    normalized_x = tl.where(mask, (x - mean) * rstd, 0.0)  # [BLOCK_SIZE_N]。
    grad_normalized_x = tl.where(mask, weight * grad_y, 0.0)  # [BLOCK_SIZE_N]。
    projection = tl.sum(normalized_x * grad_normalized_x, axis=0) / n_cols  # 0-D 标量。
    grad_mean = tl.sum(grad_normalized_x, axis=0) / n_cols  # 0-D 标量。

    # LayerNorm 反向传播公式计算：
    # 每一行的 grad_x 只依赖同一行的数据，不需要任何其他行的信息。而 grad_w 和 grad_b 必须跨行累加。
    grad_x = (grad_normalized_x - normalized_x * projection - grad_mean) * rstd
    # grad_x：[BLOCK_SIZE_N]；dL/dx。
    tl.store(grad_x_ptr + columns, grad_x, mask=mask)
    grad_weight_contribution = (grad_y * normalized_x).to(weight.dtype)  # [BLOCK_SIZE_N]。
    grad_bias_contribution = grad_y.to(weight.dtype)  # [BLOCK_SIZE_N]。

    # 所有输入行都会产生参数梯度贡献，但不同 PID 不能无同步地对同一
    # DRAM 位置执行读取、累加和写回，否则会互相覆盖。这里将 PID 分配到
    # group_size 个组，每组用独立锁串行更新一行，而不同组仍可并行。
    # locks 的前半部分保存锁状态，后半部分记录该组是否已有初始值。第二个
    # 内核再将二维部分和归约为最终的一维参数梯度。
    lock_id = program_id % group_size  # 0-D 标量；把 M 个 PID 映射到锁槽。
    # locks_ptr += lock_id 把指针移到当前组的锁状态位；count_ptr = locks_ptr + group_size
    # 从那里再跳 GROUP_SIZE 步，落到同一组的使用计数位。
    locks_ptr += lock_id
    count_ptr = locks_ptr + group_size  # 指向 0-D 计数器的指针。
    grad_weight_partial_ptrs = (  # [BLOCK_SIZE_N] 部分和元素指针。
        grad_weight_partial_ptr + lock_id * n_cols + columns
    )
    grad_bias_partial_ptrs = grad_bias_partial_ptr + lock_id * n_cols + columns  # [BLOCK_SIZE_N]。
    # 中间缓冲区由包装器创建且连续，因此行步幅可直接使用 n_cols。
    # atomic_cas 比较锁状态，仅在锁为 0 时写入 1。返回 1 表示其他程序
    # 仍持有该锁，当前程序必须继续等待。
    while tl.atomic_cas(locks_ptr, 0, 1) == 1:
        pass

    count = tl.load(count_ptr)  # 0-D 标量；当前组的访问次数。
    if count == 0:
        # 第一次访问可直接写入，无需加载初始的全零中间行。
        # atomic_xchg 无条件将锁状态置为 1，返回旧值。这里旧值必然为 0，因为我们刚刚获取了锁。
        tl.atomic_xchg(count_ptr, 1)
    else:
        # 后续访问必须在持锁期间加载并累加已有部分和。
        grad_weight_contribution += tl.load(
            grad_weight_partial_ptrs,
            mask=mask,
        )
        grad_bias_contribution += tl.load(
            grad_bias_partial_ptrs,
            mask=mask,
        )

    tl.store(
        grad_weight_partial_ptrs,
        grad_weight_contribution,
        mask=mask,
    )
    tl.store(
        grad_bias_partial_ptrs,
        grad_bias_contribution,
        mask=mask,
    )

    # 完成读取、累加和写回后才能释放锁。
    tl.atomic_xchg(locks_ptr, 0)


@triton.jit
def _layer_norm_backward_params(
    grad_weight_partial_ptr,
    grad_bias_partial_ptr,
    grad_weight_ptr,
    grad_bias_ptr,
    group_size,
    n_cols,
    block_size_m: tl.constexpr,
    block_size_n: tl.constexpr,
):
    """将分组部分和 (GROUP_SIZE, N) 归约为最终的权重和偏置梯度 (N,)。

    Args:
        grad_weight_partial_ptr: 权重梯度部分和指针，形状为 `(GROUP_SIZE, N)`。
        grad_bias_partial_ptr: 偏置梯度部分和指针，形状为 `(GROUP_SIZE, N)`。
        grad_weight_ptr: 一维权重梯度输出指针，形状为 `(N,)`。
        grad_bias_ptr: 一维偏置梯度输出指针，形状为 `(N,)`。
        group_size: 0-D 标量；需要归约的有效部分和行数 GROUP_SIZE。
        n_cols: 0-D 标量；特征数 N。
        block_size_m: 0-D 编译期标量；每次加载的部分和行数 BLOCK_SIZE_M。
        block_size_n: 0-D 编译期标量；每个程序归约的特征数 BLOCK_SIZE_N。
    """
    program_id = tl.program_id(0)  # 0-D 标量；当前列块程序索引。
    columns = program_id * block_size_n + tl.arange(0, block_size_n)  # [BLOCK_SIZE_N]。
    grad_weight_accumulator = tl.zeros(
        (block_size_m, block_size_n),
        dtype=tl.float32,
    )  # [BLOCK_SIZE_M, BLOCK_SIZE_N]。
    grad_bias_accumulator = tl.zeros(
        (block_size_m, block_size_n),
        dtype=tl.float32,
    )  # [BLOCK_SIZE_M, BLOCK_SIZE_N]。

    # 将分组部分和 (GROUP_SIZE, N) 归约为最终的权重和偏置梯度 (N,)。
    for row_start in range(0, group_size, block_size_m):  # 0-D 标量；部分和行块起点。
        rows = row_start + tl.arange(0, block_size_m)  # [BLOCK_SIZE_M]。
        mask = (rows[:, None] < group_size) & (columns[None, :] < n_cols)
        # mask：[BLOCK_SIZE_M, BLOCK_SIZE_N] 布尔掩码。
        offsets = rows[:, None] * n_cols + columns[None, :]  # [BLOCK_SIZE_M, BLOCK_SIZE_N]。
        grad_weight_accumulator += tl.load(
            grad_weight_partial_ptr + offsets,
            mask=mask,
            other=0.0,
        )
        grad_bias_accumulator += tl.load(
            grad_bias_partial_ptr + offsets,
            mask=mask,
            other=0.0,
        )

    grad_weight = tl.sum(grad_weight_accumulator, axis=0)  # [BLOCK_SIZE_N]。
    grad_bias = tl.sum(grad_bias_accumulator, axis=0)  # [BLOCK_SIZE_N]。
    output_mask = columns < n_cols  # [BLOCK_SIZE_N] 布尔掩码。
    tl.store(grad_weight_ptr + columns, grad_weight, mask=output_mask)
    tl.store(grad_bias_ptr + columns, grad_bias, mask=output_mask)


# 步骤 2：PyTorch Autograd 包装器。
class LayerNorm(torch.autograd.Function):
    """将 Triton LayerNorm 前向和反向内核接入 PyTorch Autograd。

    该类通过 `apply` 调用，不应直接实例化。
    """

    @staticmethod
    def forward(
        ctx,
        x,
        normalized_shape,
        weight,
        bias,
        eps,
    ):
        """计算 LayerNorm，并保存反向传播所需的张量和元参数。

        Args:
            ctx: PyTorch 提供的 Autograd 上下文。
            x: 输入张量，逻辑形状为 `(..., N)`，展平后为 `(M, N)`。
            normalized_shape: 元组元数据；与 PyTorch LayerNorm 兼容的归一化形状参数。
            weight: 仿射权重，形状为 `(N,)`。
            bias: 仿射偏置，形状为 `(N,)`。
            eps: 0-D 标量；防止方差归一化除零的稳定项。

        Returns:
            与 `x` 形状和 dtype 相同的归一化输出。

        Raises:
            RuntimeError: 如果单行特征无法放入内核设定的 64 KB 上限。
        """
        num_rows, n_cols = x.reshape(-1, x.shape[-1]).shape  # 2 个 0-D 标量：M、N。
        mean = torch.empty((num_rows,), dtype=torch.float32, device=x.device)  # (M,)。
        rstd = torch.empty((num_rows,), dtype=torch.float32, device=x.device)  # (M,)。
        output = torch.empty_like(x)  # (..., N)，展平后为 (M, N)。

        # 一整行必须驻留在 SRAM 中。64 KB 是采用的保守上限，
        # 更通用的实现应查询当前 GPU 的实际共享内存容量。
        max_fused_size = 65536 // x.element_size()  # 0-D 标量；可融合的最大列数。
        block_size = min(  # 0-D 编译期标量；BLOCK_SIZE。
            max_fused_size,
            triton.next_power_of_2(n_cols),
        )
        if n_cols > block_size:
            raise RuntimeError(
                "This layer norm doesn't support feature dim >= 64KB."
            )

        num_warps = min(max(block_size // 256, 1), 8)  # 0-D 标量；warp 数量。
        _layer_norm_forward[(num_rows,)](
            x,
            output,
            weight,
            bias,
            mean,
            rstd,
            x.stride(0),
            n_cols,
            eps,
            block_size=block_size,
            num_warps=num_warps,
        )

        # ctx.save_for_backward: 仅接受 Tensor，反向时通过 ctx.saved_tensors 取出。
        ctx.save_for_backward(x, weight, bias, mean, rstd)
        # ctx.<attr>: 用于保存非 Tensor 的元数据（int/float/bool 等）。
        ctx.block_size = block_size  # 0-D 元数据标量。
        ctx.num_warps = num_warps  # 0-D 元数据标量。
        ctx.eps = eps  # 0-D 元数据标量。

        return output

    @staticmethod
    def backward(ctx, grad_output):
        """根据输出梯度计算输入、权重和偏置梯度。

        Args:
            ctx: 前向传播保存的 Autograd 上下文。
            grad_output: 损失相对于 LayerNorm 输出的梯度，形状为 `(..., N)`，展平后为 `(M, N)`。

        Returns:
            与 `forward()` 输入顺序对应的梯度元组。不需要梯度的
            `normalized_shape` 和 `eps` 对应位置返回 `None`。
        """
        x, weight, bias, mean, rstd = ctx.saved_tensors  # (..., N)、(N,)、(N,)、(M,)、(M,)。
        num_rows, n_cols = x.reshape(-1, x.shape[-1]).shape  # 2 个 0-D 标量：M、N。
        grad_weight = torch.empty(  # (N,)。
            (n_cols,),
            dtype=weight.dtype,
            device=weight.device,
        )
        grad_bias = torch.empty_like(grad_weight)  # (N,)。
        grad_x = torch.empty_like(grad_output)  # (..., N)，展平后为 (M, N)。

        # 较窄的行使用更多归约组，从而增加并行度。
        group_size = 64  # 0-D 标量；GROUP_SIZE。
        if n_cols <= 8192:
            group_size = 96
        if n_cols <= 4096:
            group_size = 128
        if n_cols <= 1024:
            group_size = 256

        grad_weight_partial = torch.zeros(  # (GROUP_SIZE, N)。
            (group_size, n_cols),
            dtype=x.dtype,
            device=weight.device,
        )
        grad_bias_partial = torch.zeros_like(grad_weight_partial)  # (GROUP_SIZE, N)。
        locks = torch.zeros(  # (2 * GROUP_SIZE,)。
            2 * group_size,
            dtype=torch.int32,
            device=weight.device,
        )

        _layer_norm_backward_input[(num_rows,)](
            x,
            grad_x,
            grad_output,
            weight,
            grad_weight_partial,
            grad_bias_partial,
            mean,
            rstd,
            locks,
            x.stride(0),
            n_cols,
            group_size=group_size,
            block_size_n=ctx.block_size,
            num_warps=ctx.num_warps,
        )

        # 第二个内核使用更少的 PID，将各锁组生成的中间行归约为最终参数
        # 梯度。独立启动还能保证第一个内核已经完成全部中间写入。
        def grid(meta):
            """计算覆盖特征维度所需的程序数。"""
            return [triton.cdiv(n_cols, meta["block_size_n"])]

        _layer_norm_backward_params[grid](
            grad_weight_partial,
            grad_bias_partial,
            grad_weight,
            grad_bias,
            min(group_size, num_rows),
            n_cols,
            block_size_m=32,
            block_size_n=128,
        )

        # 返回值必须与 forward 的输入顺序一致；形状和 eps 不需要梯度。
        return grad_x, None, grad_weight, grad_bias, None

# `torch.autograd.Function` 的子类必须通过 `apply()` 调用。
# `apply()` 会执行 `forward()`，并在输入需要梯度时创建对应的
# Autograd 节点，使 PyTorch 能在反向传播时调用 `backward()`。
# 直接写 `LayerNorm(...)` 只是尝试实例化 Function 对象，不是受支持的
# 自定义算子调用方式，通常会触发运行时错误或弃用行为。
layer_norm = LayerNorm.apply  # 函数元数据；输入 (..., N)，输出 (..., N)。


# 步骤 1：数值测试。
def test_layer_norm_kernel(
    num_rows,
    n_cols,
    dtype,
    eps=1e-5,
    device=DEVICE,
):
    """比较 Triton 与 PyTorch LayerNorm 的前向结果和全部梯度。

    Args:
        num_rows: 0-D 标量；测试输入的行数 M。
        n_cols: 0-D 标量；每行特征数 N。
        dtype: 0-D/类型元数据；输入和参数的数据类型。
        eps: 0-D 标量；LayerNorm 稳定项。
        device: 0-D/设备元数据；张量所在设备。
    """
    x = -2.3 + 0.5 * torch.randn(  # (M, N)。
        (num_rows, n_cols),
        dtype=dtype,
        device=device,
    )
    weight = torch.rand(  # (N,)。
        (n_cols,),
        dtype=dtype,
        device=device,
        requires_grad=True,
    )
    bias = torch.rand(  # (N,)。
        (n_cols,),
        dtype=dtype,
        device=device,
        requires_grad=True,
    )
    grad_output = 0.1 * torch.randn_like(x)  # (M, N)。
    # 在生成随机数据后才启用梯度，可避免把初始化乘加纳入测试计算图。
    x.requires_grad_(True)

    triton_output = layer_norm(x, (n_cols,), weight, bias, eps)  # (M, N)。
    reference_output = torch.nn.functional.layer_norm(  # (M, N)。
        x,
        (n_cols,),  # 仅对最后一个特征维度执行归一化。
        weight,
        bias,
        eps,
    ).to(dtype)
    torch.testing.assert_close(
        triton_output, reference_output, atol=1e-2, rtol=0
    )
    print("Passed fwd")

    # 保留计算图，以便随后用相同输入运行 PyTorch 参考反向传播。否则，需要重新运行前向传播后才能进行再一次的反向传播。
    triton_output.backward(grad_output, retain_graph=True)
    grad_x_triton, grad_weight_triton, grad_bias_triton = [  # (M, N)、(N,)、(N,)。
        tensor.grad.clone() for tensor in (x, weight, bias)
    ]
    x.grad, weight.grad, bias.grad = None, None, None

    reference_output.backward(grad_output, retain_graph=True)
    grad_x_reference, grad_weight_reference, grad_bias_reference = [  # (M, N)、(N,)、(N,)。
        tensor.grad.clone() for tensor in (x, weight, bias)
    ]
    torch.testing.assert_close(
        grad_x_triton,
        grad_x_reference,
        atol=1e-2,
        rtol=0,
    )
    torch.testing.assert_close(
        grad_bias_triton,
        grad_bias_reference,
        atol=1e-2,
        rtol=0,
    )
    torch.testing.assert_close(
        grad_weight_triton,
        grad_weight_reference,
        atol=1e-2,
        rtol=0,
    )
    print("Passed bwd")


# 步骤 5：性能测试。
@triton.testing.perf_report(
    [
        triton.testing.Benchmark(
            x_names=["n_cols"],
            x_vals=[512 * i for i in range(2, 32)],
            line_arg="provider",
            line_vals=["triton", "torch"],
            line_names=["Triton", "Torch"],
            styles=[("blue", "-"), ("green", "-")],
            ylabel="GB/s",
            plot_name="layer-norm-backward",
            args={
                "num_rows": 4096,
                "dtype": torch.float16,
                "mode": "backward",
            },
        )
    ]
)
def benchmark(
    num_rows,
    n_cols,
    dtype,
    provider,
    mode="backward",
    eps=1e-5,
    device=DEVICE,
):
    """测量 PyTorch 或 Triton LayerNorm 的有效内存带宽。

    Args:
        num_rows: 0-D 标量；输入行数 M。
        n_cols: 0-D 标量；每行特征数 N。
        dtype: 0-D/类型元数据；输入和参数的数据类型。
        provider: 0-D/字符串元数据；实现提供者名称。
        mode: 0-D/字符串元数据；前向或反向模式。
        eps: 0-D 标量；LayerNorm 稳定项。
        device: 0-D/设备元数据；张量所在设备。
    """
    x_shape = (num_rows, n_cols)  # 形状元组；对应 (M, N)。
    weight_shape = (n_cols,)  # 形状元组；对应 (N,)。
    weight = torch.rand(  # (N,)。
        weight_shape,
        dtype=dtype,
        device=device,
        requires_grad=True,
    )
    bias = torch.rand(  # (N,)。
        weight_shape,
        dtype=dtype,
        device=device,
        requires_grad=True,
    )
    x = -2.3 + 0.5 * torch.randn(x_shape, dtype=dtype, device=device)  # (M, N)。
    grad_output = 0.1 * torch.randn_like(x)  # (M, N)。
    x.requires_grad_(True)
    quantiles = [0.5, 0.05, 0.95]  # [3]；基准分位点。

    def run_forward():
        """运行当前 provider 的 LayerNorm 前向传播。"""
        if provider == "triton":
            return layer_norm(x, weight_shape, weight, bias, eps)  # (M, N)。
        if provider == "torch":
            return torch.nn.functional.layer_norm(  # (M, N)。
                x,
                weight_shape,
                weight,
                bias,
                eps,
            )

    if mode == "forward":
        memory_operations = 2  # 0-D 标量；前向内存操作次数。
        milliseconds, min_ms, max_ms = triton.testing.do_bench(
            run_forward,
            quantiles=quantiles,
            rep=500,
        )
    if mode == "backward":
        output = run_forward()  # (M, N)。
        memory_operations = 3  # 0-D 标量；反向内存操作次数。

        def run_backward():
            """运行当前 provider 的 LayerNorm 反向传播。"""
            return output.backward(grad_output, retain_graph=True)

        milliseconds, min_ms, max_ms = triton.testing.do_bench(
            run_backward,
            quantiles=quantiles,
            grad_to_none=[x],
            rep=500,
        )

    def to_gbps(elapsed_ms):
        """将耗时换算为有效内存带宽。"""
        transferred_bytes = memory_operations * x.numel() * x.element_size()  # 0-D 标量；字节数。
        return transferred_bytes * 1e-9 / (elapsed_ms * 1e-3)  # 0-D 标量；GB/s。

    return to_gbps(milliseconds), to_gbps(max_ms), to_gbps(min_ms)


def main():
    """运行数值测试，并按需运行性能测试。"""
    test_layer_norm_kernel(1151, 8192, torch.float16)
    if len(sys.argv) > 1 and sys.argv[1] == "--benchmark":
        benchmark.run(save_path=".", print_data=False)


if __name__ == "__main__":
    main()
